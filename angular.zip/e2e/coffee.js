import { Selector } from 'testcafe'; // first import testcafe selectors

fixture `Getting Started`// declare the fixture
    .page `http://localhost:4200`;  // specify the start page


//then create a test and place your code there
test('customer test should work', async t => {
    await t
        .typeText('#tel', '0933887163')
        .click('#client-form-search-btn')

        // Use the assertion to check if the actual header text is equal to the expected one
        .expect(Selector('table>tbody>tr').addCustomDOMProperties({
            innerHTML: el => el.innerHTML
        }).innerHTML).contains('0933887163');
});