// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html
module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular-devkit/build-angular/plugins/karma'),
      
      require('karma-html-detailed-reporter'),
      require('karma-htmlfile-reporter'),
    ],
    client: {
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    htmlDetailed: {
      splitResults: false,
      dir: '../unit_test/app',
      autoReload: false,
      useHostedBootstrap: true
    },
    htmlReporter: {
      outputFile: '../unit_test/units.html',      
    },
    coverageIstanbulReporter: {

    },
    browserNoActivityTimeout: 100000,
    captureTimeout: 100000, //reporters: ['progress', 'kjhtml'],
    // reporters: ['progress', 'kjhtml', 'htmlDetailed', 'html', 'coverage-istanbul'],
    reporters: ['progress', 'kjhtml'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['Chrome'],
    singleRun: false
  });
};
