export const environment = {
  production: true,
  api_url: 'https://esunbank-mars-ap.azurewebsites.net/api/'
};
