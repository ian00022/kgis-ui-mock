import { Injectable } from '@angular/core';

@Injectable()
export class LayoutService {

  private sideNavOpened: boolean = true;
  constructor() { }

  setSideNav(opened: boolean) {
    this.sideNavOpened = opened;
  }

  getSideNavStatus() {
    return this.sideNavOpened;
  }

}
