// angular module
import { Injectable } from '@angular/core';
// 3rd party module
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';
// service
import { ApiService } from './../../core/services/api.service';
// helper
import { DateHelper } from 'app/shared/helper/date-helper';
// model
import { CmsNotificationResponseDto, CmsNotificationDto, CmsStatusEnum } from './cms-notification.model';

/**
 * cms notification service
 *
 */
@Injectable({
  providedIn: 'root'
})
export class CmsNotificationService {

  constructor(private api: ApiService) { }

  /**
   * get all notifications
   *
   * @returns {Observable<CmsNotificationDto[]>}
   * @memberof CmsNotificationService
   */
  public getAllNotifications(): Observable<CmsNotificationDto[]> {
    return this.api.post('ContentMessage').pipe( map( data => {
      if (data.isOk) {
        return data.value.map( el => this.mapToNotification(el));
      };
      return [];
    }));
  }

  /**
   * update notification to read or recieved
   *
   * @param {*} body
   * @returns {Observable<any>}
   * @memberof CmsNotificationService
   */
  public updateNotification(body: {UUID?: string, cmsStatus: CmsStatusEnum}): Observable<any> {
    return this.api.put('ContentMessage', body);
  }


  /**
   * map response to notificaiton
   *
   * @param {CmsNotificationResponseDto} map
   * @returns {CmsNotificationDto}
   * @memberof CmsNotificationService
   */
  public mapToNotification(map: CmsNotificationResponseDto): CmsNotificationDto {
    return {
      cmsCategory: map.CmsCategory,
      cmsMessage: map.CmsMessage,
      cmsPriority: map.CmsPriority,
      cmsStatus: map.CmsStatus,
      cmsTitle: map.CmsTitle,
      cmsType: map.CmsType,
      cmsUrl: map.CmsUrl,
      createDate: DateHelper.formatDate(map.CreateDate),
      UUID: map.UUID,
      updateDate: DateHelper.formatDate(map.UpdateDate),
      isRead: this.mapToCmsIsRead(map)
    }
  }

  /**
   * map cms status to isRead property
   *
   * @private
   * @param {CmsNotificationResponseDto} map
   * @returns {boolean}
   * @memberof CmsNotificationService
   */
  private mapToCmsIsRead(map: CmsNotificationResponseDto): boolean {
    return _.toString(map.CmsStatus) === CmsStatusEnum.READ;
  }
}
