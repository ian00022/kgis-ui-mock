import { BaseResponseDto } from '../../core/models/comm-data';
/**
 * cms notification data struct from server
 */
export interface CmsNotificationResponseDto extends BaseResponseDto {
  /**
   * 通知原因
   */
  CmsCategory: string;
  /**
   * 推播訊息
   */
  CmsMessage: string;
  /**
   * 重要性
   */
  CmsPriority: string;
  /**
   * 推播狀態
   */
  CmsStatus: string;
  /**
   * 推播標題
   */
  CmsTitle: string;
  /**
   * 推播種類
   */
  CmsType: string;
  /**
   * 推播連結
   */
  CmsUrl: string;
  /**
   * UUID
   */
  UUID: string;
}

/**
 * cms notification data struct
 */
export interface CmsNotificationDto {
  /**
   * 通知原因
   */
  cmsCategory: string;
  /**
   * 推播訊息
   */
  cmsMessage: string;
  /**
   * 重要性
   */
  cmsPriority: string;
  /**
   * 推播狀態
   */
  cmsStatus: string;
  /**
   * 推播標題
   */
  cmsTitle: string;
  /**
   * 推播種類
   */
  cmsType: string;
  /**
   * 推播連結
   */
  cmsUrl: string;
  /**
   * 建立日期
   */
  createDate: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 更新日期
   */
  updateDate: string;
  /**
   * 是否已讀推播訊息
   */
  isRead: boolean;
}

/**
 * cms status enum
 */
export enum CmsStatusEnum {
  INIT = '0',
  SUCCESS = '1',
  FAIL = '2',
  READ = '3'
}
