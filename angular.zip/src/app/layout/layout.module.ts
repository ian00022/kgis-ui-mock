// angular module
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
// module
import { SharedModule } from '../shared/shared.module';
// component
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './menu/menu.component';
// service
import { LayoutService } from './layout.service';
import { CommonService } from './header/common.service';
import { CmsNotificationService } from './cms-notification/cms-notification.service';

@NgModule({
  imports: [
    SharedModule,
    RouterModule,
  ],
  declarations: [
    LayoutComponent,
    HeaderComponent,
    MenuComponent
  ],
  providers: [
    LayoutService,
    CmsNotificationService,
    CommonService
  ]
})
export class LayoutModule { }
