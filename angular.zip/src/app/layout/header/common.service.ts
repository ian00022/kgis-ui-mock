// angualr module
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
// model
import { VacationAgentDto, IEmployee } from 'app/core/models/comm-data';
// service
import { ApiService } from '../../core/services/api.service';

/**
 * common service
 */
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private api: ApiService) { }

  /**
   * 可代理人查詢
   */
  public getAllAgents(): Observable<any> {
    return this.api.get('Common/SwitchUsers').pipe(map( data => {
      return data.value.map( (el: {EmpId: string, EmpName: string}): IEmployee => {
        return {
          empId: el.EmpId,
          empName: el.EmpName
        }
      })
    }))
  }

  /**
   * 切換代理人
   */
  public switchUser(body): Observable<any> {
    return this.api.put('Common/SwitchUser', body);
  }

  /**
   * 休假代理資料查詢
   */
  public getVacationAgent(): Observable<any> {
    return this.api.get('Common/VacationAgent').pipe(map( data => {
      if (data.value) {
        return {
          UUID: data.value.UUID,
          vacationStartDate: data.value.VacationStartDate,
          vacationStartTime: data.value.VacationStartTime,
          vacationEndDate: data.value.VacationEndDate,
          vacationEndTime: data.value.VacationEndTime,
          agentEmpId: data.value.AgentEmpId,
          agentEmpName: data.value.AgentEmpName,
        };
      }
      return null;
    }))
  }

  /**
   * 更新休假代理資料
   */
  public updateVacationAgent(body: VacationAgentDto): Observable<any> {
    return this.api.put('Common/VacationAgent', body)
  }
}
