// angular module
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
// 3rd party module
import * as _ from 'lodash';
import { NzNotificationService } from 'ng-zorro-antd';
import { BroadcastEventListener, SignalRConnection } from 'ng2-signalr';
// model
import { Permissions, LoginUserDto } from 'app/core/models/permissions';
import { ISelectOptionModel, VacationAgentDto } from 'app/core/models/comm-data';
import { CmsNotificationDto, CmsNotificationResponseDto, CmsStatusEnum } from '../cms-notification/cms-notification.model';
import { ControlBase, ClockpickerControl, DatepickerControl, SingleDropdownControl } from '../../shared/components/dynamic-form/controls';
// component
import { DynamicFormComponent } from './../../shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmSideDialogComponent } from '../../shared/components/ibm-dialog/ibm-side-dialog/ibm-side-dialog.component';
// services
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { LoggerService } from 'app/shared/logger.service';
import { CmsNotificationService } from '../cms-notification/cms-notification.service';
import { ApiService, AuthService, BusinessOppotunityService, JwtService } from 'app/core/services';
import { CommonService } from './common.service';

/**
 * the header component
 *
 */
@Component({
  selector: 'esun-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  /**
   * output event emit when toggle side navigation
   *
   * @memberof HeaderComponent
   */
  @Output() onToggleSideNav = new EventEmitter();

  /**
   * 請假代理人 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('vacationAgentDialog') vacationAgentDialog: IbmDialogComponent;

  /**
   * 請假代理人 input form
   *
   * @type {DynamicFormComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('vacationAgentForm') vacationAgentForm: DynamicFormComponent;

  /**
   * 切換代理人 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('switchAgentDialog') switchAgentDialog: IbmDialogComponent;

  /**
   * 切換代理人 input form
   *
   * @type {DynamicFormComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('switchAgentForm') switchAgentForm: DynamicFormComponent;

  /**
   * 顯示通知內容 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('noticeDialog') noticeDialog: IbmDialogComponent;

  /**
   * 顯示行銷人員一覽 side dialog
   *
   * @type {IbmSideDialogComponent}
   * @memberof HeaderComponent
   */
  @ViewChild('sideInfoBox') sideInfoBoxDialog: IbmSideDialogComponent;

  /**
   * 請假代理人 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof HeaderComponent
   */
  public vacationAgentControls: ControlBase<any>[] = [];

  /**
   * 切換代理人 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof HeaderComponent
   */
  public switchAgentControls: ControlBase<any>[] = [];

  /**
   * when click notification row,
   * store row data for 顯示通知內容 dialog,
   *
   * @type {CmsNotificationDto}
   * @memberof HeaderComponent
   */
  public selectedNotification: CmsNotificationDto;

  /**
   * 行銷人員工作記錄一覽表
   *
   * @type {any[]}
   * @memberof HeaderComponent
   */
  public marketingPersonRecords: any[] = [];

  /**
   * 顯示登入者訊息
   * isAgent: 是否為代理狀態
   * profile: 登入者資訊
   *
   * @type {{ isAgent: boolean, profile: LoginUserDto}}
   * @memberof HeaderComponent
   */
  public userProfile: { isAgent: boolean, profile: LoginUserDto};

  /**
   * 請假資訊
   *
   * @type {VacationAgentDto}
   * @memberof HeaderComponent
   */
  public vacationAgent: VacationAgentDto;

  /**
   * permissions enum property for template
   *
   * @memberof HeaderComponent
   */
  public Permissions = Permissions;

  /**
   * 顯示通知筆數
   *
   * @private
   * @type {number}
   * @memberof HeaderComponent
   */
  private showNotificationCount: number = 1;

  /**
   * 通知列表
   *
   * @private
   * @type {CmsNotification[]}
   * @memberof HeaderComponent
   */
  private notifications: CmsNotificationDto[] = [];

  /**
   * 代理人選單
   *
   * @private
   * @type {ISelectOptionModel[]}
   * @memberof HeaderComponent
   */
  private agentOptions: ISelectOptionModel[] = [];

  /**
   * signalr connection
   *
   * @private
   * @type {SignalRConnection}
   * @memberof HeaderComponent
   */
  private _connection: SignalRConnection;

  /**
   * signalr server function listener
   *
   * @private
   * @type {BroadcastEventListener<any>}
   * @memberof HeaderComponent
   */
  private onMessageSent$: BroadcastEventListener<any>;

  constructor(
    private logger: LoggerService,
    private router: Router,
    private option: SelectOptionsService,
    private api: ApiService,
    private boService: BusinessOppotunityService,
    private auth: AuthService,
    private jwt: JwtService,
    private route: ActivatedRoute,
    private cms: CmsNotificationService,
    private common: CommonService,
    private notification: NzNotificationService,
  ) {
    this.agentOptions = this.option.getOptions('agentOptions');
    this.userProfile = {
      isAgent: false,
      profile: this.auth.getLoginUser()
    }
   }

  /**
   * component init
   *
   * @memberof HeaderComponent
   */
  ngOnInit() {
    this.getAllNotifications();
    this.common.getAllAgents().subscribe(
      (agents) => {
        this.agentOptions.splice(0, this.agentOptions.length);
        agents.forEach(element => {
          this.agentOptions.push({
            label: `${element.empId} ${element.empName}`,
            value: element.empId
          })
        });
      }
    )

    this._connection = this.route.snapshot.data['connection'];
    // 使用者資訊登入 notificationHub
    this._connection.invoke('UserConnected', this.auth.getLoginUser().loginEmpId).then(
      () => {
        // listen notification
        this.onMessageSent$ = this._connection.listenFor('sendMessage');
        // server push notification
        this.onMessageSent$.subscribe(
          (data: CmsNotificationResponseDto) => {
            this.notifications.unshift(this.cms.mapToNotification(data));
            // 標示為已收到
            this.cms.updateNotification({UUID: data.UUID, cmsStatus: CmsStatusEnum.SUCCESS}).subscribe();
            this.notification.info(data.CmsTitle, data.CmsMessage);
          }
        )
      }
    );

    this.prepareControls();
  }

  /**
   * emit onToggleSideNav when click sideNav button
   *
   * @memberof HeaderComponent
   */
  public onToggleNav() {
    this.onToggleSideNav.emit();
  }

  /**
   * login user info image
   *
   * @readonly
   * @type {string}
   * @memberof HeaderComponent
   */
  get imageSrc(): string {
    if (this.userProfile.isAgent) {
      return 'assets/images/agent.png';
    }
    return 'assets/images/E.SUN_Bank.png';
  }

  /**
   * notification list which display on the dropdown
   *
   * @readonly
   * @type {CmsNotificationDto[]}
   * @memberof HeaderComponent
   */
  get displayNotifications(): CmsNotificationDto[] {
    return this.notifications.slice(0, this.showNotificationCount* 10);
  }

  /**
   * unread count for notifications
   *
   * @readonly
   * @type {string}
   * @memberof HeaderComponent
   */
  get getNoticeCount(): string {
    /**
     * notifications unread count
     */
    let unread = this.notifications.filter((notice) => {
      return !notice.isRead;
    }).length;
    if ( unread > 99 ) {
      return '99+';
    }
    return _.toString(unread);
  }

  /**
   * mark all notification to isRead = true
   *
   * @memberof HeaderComponent
   */
  public markAllRead() {
    // 未帶入UUID，全部已讀
    this.cms.updateNotification({cmsStatus: CmsStatusEnum.READ}).subscribe(
      () => {
        this.getAllNotifications();
      }
    );
  }

  /**
   * click notification row
   *
   * @param {CmsNotificationDto} notice
   * @memberof HeaderComponent
   */
  public onNoticeClick(notice: CmsNotificationDto) {
    this.logger.debug('onNoticeClick: ', notice);
    // 單筆已讀, 傳入 UUID
    this.cms.updateNotification({ UUID: notice.UUID, cmsStatus: CmsStatusEnum.READ}).subscribe(
      () => { notice.isRead = true; }
    );
    this.selectedNotification = notice;
    this.noticeDialog.open();
  }

  /**
   * show more notification list
   *
   * @memberof HeaderComponent
   */
  public onClickMore() {
    this.showNotificationCount = this.showNotificationCount + 1;
  }

  /**
   * route to url from selectedNotification for handling event
   *
   * @memberof HeaderComponent
   */
  public navigateToCmsUrl() {
    this.router.navigate([this.selectedNotification.cmsUrl]);
    this.noticeDialog.close();
  }

  /**
   * check dynamic form is valid
   *
   * @param {DynamicFormComponent} form
   * @returns {boolean}
   * @memberof HeaderComponent
   */
  public isValid(form: DynamicFormComponent): boolean {
    return form.form.valid;
  }

  /**
   * handle dynamic form submit
   *
   * @param {*} value
   * @memberof HeaderComponent
   */
  public handleSubmit(value: any) {
    if (this.switchAgentDialog.isOpen) {
      this.common.switchUser({empId: value.agentEmpId}).subscribe(
        (resp) => {
          this.switchAgentDialog.close();
        }
      )
    } else if (this.vacationAgentDialog.isOpen) {
      this.common.updateVacationAgent(_.assign({}, this.vacationAgent, value)).subscribe(
        (resp) => {
          this.vacationAgentDialog.close();
        }
      )
    }
    this.logger.debug(JSON.stringify(value));
  }

  /**
   * handle dynamic form click confirm
   *
   * @param {DynamicFormComponent} form
   * @memberof HeaderComponent
   */
  public confirm(form: DynamicFormComponent) {
    form.submit();
  }

  /**
   * handle dynamic form click cancel
   *
   * @param {DynamicFormComponent} form
   * @param {IbmDialogComponent} dialog
   * @memberof HeaderComponent
   */
  public cancel(form: DynamicFormComponent, dialog: IbmDialogComponent) {
    form.reset();
    dialog.close();
  }

  /**
   * handle dynamic form click close
   *
   * @param {DynamicFormComponent} form
   * @memberof HeaderComponent
   */
  public close(form: DynamicFormComponent) {
    form.reset();
  }


  /**
   * logout current user
   *
   * @memberof HeaderComponent
   */
  public onLogoutMenuClick() {
    this.auth.removeAllPermissions();
    this.router.navigate(['./login']);
    this.jwt.destroyToken();
  }

  /**
   * 開啟切換代理人 dialog
   */
  public onSwitchAgentMenuClick() {
    this.common.getAllAgents().subscribe(
      (agents) => {
        this.agentOptions.splice(0, this.agentOptions.length);
        agents.forEach(element => {
          this.agentOptions.push({
            label: `${element.empId} ${element.empName}`,
            value: element.empId
          })
        });
        this.switchAgentDialog.open()
      }
    )
  }

  /**
   * 開啟請假代理人 dialog,
   * 確認是否有填寫過請假代理人記錄,
   * 如果有, 則填入相關資訊
   *
   * @memberof HeaderComponent
   */
  public onAgentMenuClick() {
    this.common.getVacationAgent().subscribe(
      (vacation) => {
        if (vacation) {
          this.vacationAgentForm.patchValue(vacation);
          this.vacationAgent = vacation;
        } else {
          this.vacationAgentForm.reset();
        }
        this.vacationAgentDialog.open();
      }
    )
  }

  /**
   * 開啟行銷人員一覽 side dialog
   *
   * @memberof HeaderComponent
   */
  public onSideInfoBoxClick() {
    this.boService.getMkPersonWorkStatus().subscribe(
      (resp) => {
        this.marketingPersonRecords = resp.value;
        this.sideInfoBoxDialog.open();
      }
    );
  }

  /**
   * prepare all dynamic form controls
   *
   * @private
   * @memberof HeaderComponent
   */
  private prepareControls() {
    this.vacationAgentControls = [
      new DatepickerControl({
        key: 'vacationStartDate',
        label: '請假起始日',
        columnClasses: ['6'],
        required: true,
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      }),
      new ClockpickerControl({
        key: 'vacationStartTime',
        label: '請假起始時間',
        columnClasses: ['6'],
        required: true,
        placeholder: '請選擇時間...'
      }),
      new DatepickerControl({
        key: 'vacationEndDate',
        label: '請假結束日',
        columnClasses: ['6'],
        required: true,
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      }),
      new ClockpickerControl({
        key: 'vacationEndTime',
        label: '請假結束時間',
        columnClasses: ['6'],
        required: true,
        placeholder: '請選擇時間...'
      }),
      new SingleDropdownControl({
        key: 'agentEmpId',
        label: '代理人',
        columnClasses: ['12'],
        required: true,
        enableAutocomplete: true,
        options: this.agentOptions,
        placeholder: '請選擇...'
      })

    ];

    this.switchAgentControls = [
      new SingleDropdownControl({
        key: 'agentEmpId',
        label: '切換代理人',
        columnClasses: ['12'],
        required: true,
        enableAutocomplete: true,
        options: this.agentOptions,
        placeholder: '請選擇代理人...'
      })
    ];
  }

  /**
   * get all notifications
   */
  private getAllNotifications() {
    this.cms.getAllNotifications().subscribe(
      (notifications) => {
        this.notifications = notifications;
      }
    );
  }
}
