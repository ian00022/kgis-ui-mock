import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { SignalR, ISignalRConnection } from 'ng2-signalr';

@Injectable({
  providedIn: 'root'
})
export class ConnectionResolverService implements Resolve<ISignalRConnection> {

  constructor(private _signalR: SignalR) { }

  /**
   * start connection
   *
   * @returns
   * @memberof ConnectionResolverService
   */
  resolve() {
    return this._signalR.connect();
  }

}
