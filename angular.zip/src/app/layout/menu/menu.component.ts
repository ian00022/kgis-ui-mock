import {Component, Input, OnInit} from '@angular/core';
import {MenuItem} from '../../core/models/comm-data';
import {MenuService} from '../../core/services/menu.service';

@Component({
  selector: 'esun-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  @Input() menu: MenuItem[] = [];
  menus: MenuItem[] = [];
  constructor(private menuService: MenuService) { }

  ngOnInit() {
    if (this.menu.length === 0) {
      this.menuService.getMenu().subscribe(
        (menus) => {
          this.menus = menus;
        }
      );
    } else {
      this.menus = this.menu;
    }
  }

}
