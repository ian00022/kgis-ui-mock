import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {MatSidenav} from '@angular/material';
import {LayoutService} from '../layout.service';
import { ScrollToHelper } from '../../shared/helper/scroll-to-helper';

@Component({
  selector: 'esun-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit, AfterViewInit {
  @ViewChild('sidenav') sidenav: MatSidenav;

  sideNavOpened = true;
  public hideScrollTopBtn = true;
  constructor(private layoutService: LayoutService) { }

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.sideNavOpened = this.sidenav.opened;
  }

  toggleNav(event) {
    this.sidenav.toggle();
    this.layoutService.setSideNav(this.sidenav.opened);
    this.sideNavOpened = this.sidenav.opened;
  }

  scrollTop() {
    ScrollToHelper.scrollTop();
    // window.scrollTo({left: 0, top: 0, behavior: 'smooth' });
  }

  onScroll(event) {
    if (event.target.scrollTop > 300 ) {
      this.hideScrollTopBtn = false;
    } else {
      this.hideScrollTopBtn = true;
    }
  }
}
