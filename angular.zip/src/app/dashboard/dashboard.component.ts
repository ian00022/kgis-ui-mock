// angular module
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject ,  forkJoin } from 'rxjs';
// 3rd party module
import { SlickComponent } from '../../../node_modules/ngx-slick';
import { CalendarComponent } from '../../ng-fullcalendar';
import * as _ from 'lodash';
// model
import { Permissions } from '../core/models/permissions';
import { ISelectOptionModel } from 'app/core/models/comm-data';
import { BOLNormalCaseVisitTableRowDto } from './../business-opportunity/business-opportunity.model';
import { CalendarEventDto, AnnounceTableRowDto, CalendarEventInfoDto, RelativeLinkTableRowDto } from 'app/dashboard/dashboard.model';
// component
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from './../shared/components/ibm-dialog/ibm-dialog.component';
import { ControlBase, DatepickerControl, ClockpickerControl, TextControl, TextareaControl, SingleDropdownControl } from '../shared/components/dynamic-form/controls';
// service
import { LoggerService } from '../shared/logger.service';
import { AuthService, BusinessOppotunityService, DashboardService } from 'app/core/services';
// helper
import { DateHelper } from '../shared/helper/date-helper';
import { NgxPermissionsService } from 'ngx-permissions';
// moment js
declare var moment: any;
/**
 * 行事曆切換顯示模式
 */
enum CalendarButtonType {
  /**
   * 日
   */
  MONTH = 1,
  /**
   * 週
   */
  AGENDAWEEK,
  /**
   * 月
   */
  AGENDADAY
}

/**
 * 行事曆行程 dialog mode
 */
enum EventDialogMode {
  /**
   * 新增行程
   */
  ADD = 'add',
  /**
   * 編輯行程
   */
  EDIT = 'edit'
}

/**
 * dashboard component
 * include CalendarComponent,
 */
@Component({
  selector: 'esun-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, OnDestroy {

  /**
   * 輪播 component
   *
   * @type {SlickComponent}
   * @memberof DashboardComponent
   */
  @ViewChild(SlickComponent) slick: SlickComponent;

  /**
   * 輪播詳細資訊 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof DashboardComponent
   */
  @ViewChild('messageDialog') messageDialog: IbmDialogComponent;

  /**
   * calendar
   *
   * @type {CalendarComponent}
   * @memberof DashboardComponent
   */
  @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;

  /**
   * 新增 or 編輯行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof DashboardComponent
   */
  @ViewChild('eventDialog') eventDialog: IbmDialogComponent;

  /**
   * 新增 or 編輯行程 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof DashboardComponent
   */
  @ViewChild('eventForm') eventForm: DynamicFormComponent;

  /**
   * permissions enum property for template
   *
   * @memberof DashboardComponent
   */
  public Permissions = Permissions;

  /**
   * 新增 or 編輯行程 dynamic form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof DashboardComponent
   */
  public eventControls: ControlBase<any>[] = [];

  /**
   * 行事曆可綁定名單選項
   *
   * @type {ISelectOptionModel[]}
   * @memberof DashboardComponent
   */
  public BOLlistForEvent: ISelectOptionModel[] = [];

  /**
   * 行事曆行程 dialog mode
   */
  public eventDialogMode = EventDialogMode.ADD;

  /**
   * 行程列表
   *
   * @type {any[]}
   * @memberof DashboardComponent
   */
  public events: CalendarEventDto[] = [];

  /**
   * calendar component setting
   *
   * @type {*}
   * @memberof DashboardComponent
   */
  public calendarOptions: any = {
    themeSystem: 'bootstrap4',
    header: {
        left: 'today prev title next',
        center: '',
        right: 'agendaDay,agendaWeek,month'
    },
    views: {
        agenda: {
            titleFormat: 'YYYY年 MM月 DD日'
        },
        month: {
            titleFormat: 'YYYY年 MM月'
        }
    },
    buttonText: {
        today: '今天',
        month: '月',
        agendaWeek: '週',
        agendaDay: '日'
    },
    editable: true,
    eventLimit: true,
    eventBackgroundColor: '#009F96',
    eventBorderColor: '#009F96',
    eventTextColor: '#fff',
    eventDurationEditable: false,
    events: [],
  };

  /**
   * 是否顯示刪除行程 button
   *
   * @type {boolean}
   * @memberof DashboardComponent
   */
  public showDeleteEventBtn: boolean = false;

  /**
   * 今日行程列表
   *
   * @type {BOLNormalCaseVisitTableRowDto[]}
   * @memberof DashboardComponent
   */
  public todayScheduleList: BOLNormalCaseVisitTableRowDto[] = [];

  /**
   * 相關專區連結列表
   *
   * @type {RelativeLinkTableRowDto[]}
   * @memberof DashboardComponent
   */
  public relativeLinks: RelativeLinkTableRowDto[] = [];

  /**
   * 名單執行提醒列表
   *
   * @type {any[]}
   * @memberof DashboardComponent
   */
  public BOLReminds: any[] = [];

  /**
   * slick component settting
   *
   * @memberof DashboardComponent
   */
  public slickConfig = {
    prevArrow: '',
    nextArrow: '',
    autoplay: true,
    autoplaySpeed: 5000,
  };

  /**
   * display current slick page
   *
   * @memberof DashboardComponent
   */
  public currentSlickPage = 1;

  /**
   * 輪播列表
   *
   * @type {AnnounceTableRowDto[]}
   * @memberof DashboardComponent
   */
  public announces: AnnounceTableRowDto[] = [];

  /**
   * 已選輪播消息
   *
   * @type {AnnounceTableRowDto}
   * @memberof DashboardComponent
   */
  public selectedAnnounce: AnnounceTableRowDto = {} as any;

  /**
   * 已選行程 UUID
   *
   * @private
   * @memberof DashboardComponent
   */
  private selectedEvnetUUID;

  /**
   * 查詢行程 search params
   *
   * @private
   * @memberof DashboardComponent
   */
  private queryEventParams = {
    empId: this.auth.getLoginUser().loginEmpId,
    selectType: 1,
    selectDate: new Date().toISOString()
  };

  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private permissionsService: NgxPermissionsService,
    private logger: LoggerService,
    private dashboardService: DashboardService,
    private auth: AuthService,
    private boService: BusinessOppotunityService
  ) { }


  ngOnInit() {
    forkJoin(
      this.boService.queryTodaySchedule({orderCol: 'assignedDate'}),
      this.dashboardService.getRelativeLinks(),
      this.dashboardService.getBOLReminds(),
      this.dashboardService.getAnnounce(),
      this.boService.getMarketingPersonAllBOL()
    ).subscribe(
      ([scheduleResult, linkResult, BOLRemindsResult, announceResult, bolOptions]) => {
        this.todayScheduleList = scheduleResult;
        this.BOLReminds = BOLRemindsResult;
        this.relativeLinks = linkResult
        this.announces = announceResult;

        bolOptions.forEach(element => {
          this.BOLlistForEvent.push(element);
        });
      },
      (error) => {
        console.log(error);
      }
    );

    this.prepareControls();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * 輪播 prev btn click
   */
  public onSlickPrevClick() {
    this.slick.slickPrev();
  }

  /**
   * 輪播 next btn click
   */
  public onSlickNextClick() {
    this.slick.slickNext();
  }

  /**
   * before SlickChange handler
   *
   * @param {*} event
   * @memberof DashboardComponent
   */
  public beforeSlickChange(event) {
    this.currentSlickPage = event.nextSlide + 1;
  }

  /**
   * check event dialog type and return proper header
   *
   * @readonly
   * @type {string}
   * @memberof DashboardComponent
   */
  get eventDialogHeader(): string {
    if (this.eventDialogMode === EventDialogMode.ADD) {
      return '新增行程';
    }
    return '編輯行程';
  }

  /**
   * handle evnet form submit,
   * dialog type equals to EventDialogMode.ADD,
   * call addEven.
   * dialog type equals to EventDialogMode.EDIT,
   * call editEvent.
   *
   * @param {CalendarEventInfoDto} formData
   * @memberof DashboardComponent
   */
  public onEventFormSubmit(formData: CalendarEventInfoDto) {
    if (this.eventDialogMode === EventDialogMode.ADD) {
      const data = _.assign({ bOlName: formData.BOLNo }, formData);
      this.dashboardService.addEvent(data).subscribe(() => {
        this.getEvents(this.queryEventParams);
        this.getBOLReminds();
        this.getTodayVisit();
        this.eventDialog.close();
      });
    } else {
      const data = _.assign({UUID: this.selectedEvnetUUID}, formData);
      this.dashboardService.editEvent(data).subscribe(() => {
        this.getEvents(this.queryEventParams);
        this.getBOLReminds();
        this.getTodayVisit();
        this.eventDialog.close();
      });
    }
  }

  /**
   * on single event click
   *
   * @param {*} data
   * @returns
   * @memberof DashboardComponent
   */
  public onEventClick(data) {
    if (!this.permissionsService.hasPermission(Permissions.VISIT_UPDATE)) {
      return;
    }

    this.selectedEvnetUUID = data.event.id;
    const event = _.find(this.events, ['id', data.event.id]);
    this.eventDialogMode = EventDialogMode.EDIT;

    if (event.data.BOLNo) {
      // 綁定名單的行程不能刪除
      this.showDeleteEventBtn = false;
      // 綁定的名單不得更改
      this.eventForm.form.controls['BOLNo'].disable();
    } else {
      this.showDeleteEventBtn = true;
      this.eventForm.form.controls['BOLNo'].enable();
    }

    this.eventForm.patchValue({
      BOLNo: event.data.BOLNo,
      visitDate: DateHelper.formatDate(event.data.VisitDate),
      visitTime: DateHelper.formatTime(event.data.VisitTime, 'HH:mm:ss'),
      subject: event.data.Subject,
      visitAddress: event.data.VisitAddress,
      contactPhone: event.data.ContactPhone,
      remark: event.data.Remark
    });

    this.changeEventFormState();
    this.eventDialog.open();
  }

  /**
   * 行事曆切換模式, render 之後 call this.getEvents,
   * 取得當頁狀態的行程
   *
   * @param {*} data
   * @memberof DashboardComponent
   */
  public onCalViewRender(data) {
    this.queryEventParams.selectDate = moment(data.view.intervalStart).toISOString();
    this.queryEventParams.selectType = parseInt(CalendarButtonType[data.view.type.toUpperCase()], 10) || this.queryEventParams.selectType;
    this.getEvents(this.queryEventParams);
  }

  /**
   * single event drop
   *
   * @param {*} eventDetail
   * @memberof DashboardComponent
   */
  public onEvnetDrop(eventDetail) {
    let event = _.cloneDeep(eventDetail.event) as CalendarEventDto;
    let changeDate = moment(event.start).format('YYYY/MM/DD');
    let changeTime = moment(event.start).format('HH:mm');
    this.selectedEvnetUUID = event.data.UUID;
    this.eventDialogMode = EventDialogMode.EDIT;
    this.eventForm.patchValue({
      BOLNo: event.data['BOLNo'],
      visitDate: changeDate,
      visitTime: changeTime,
      subject: event.data['Subject'],
      visitAddress: event.data['VisitAddress'],
      contactPhone: event.data['ContactPhone'],
      remark: event.data['Remark']
    });
    this.changeEventFormState();

    if (!event.data.BOLNo) {
      // 未選定名單可以選名單
      this.eventForm.form.controls['BOLNo'].enable();
    } else {
      this.eventForm.form.controls['BOLNo'].disable();
    }

    this.eventDialog.open();
  }

  /**
   * add event
   *
   * @memberof DashboardComponent
   */
  public onAddEventButtonClick() {
    this.eventDialogMode = EventDialogMode.ADD;
    this.showDeleteEventBtn = false;
    this.eventForm.reset();
    this.changeEventFormState();
    this.eventDialog.open();
  }

  /**
   * delete event
   *
   * @memberof DashboardComponent
   */
  public onEventDeleteClick() {
    this.dashboardService.deleteEvent({ UUID: this.selectedEvnetUUID}).subscribe(
      (resp) => {
        this.getEvents(this.queryEventParams);
        this.eventDialog.close();
      }
    );
  }

  /**
   * calculate today visit length
   *
   * @readonly
   * @type {string}
   * @memberof DashboardComponent
   */
  get todayScheduleTitle(): string {
    return `今日行程(${this.todayScheduleList.length})`;
  }

  /**
   * open outside link
   *
   * @param {RelativeLinkTableRowDto} data
   * @memberof DashboardComponent
   */
  public openLink(data: RelativeLinkTableRowDto) {
    this.logger.debug(data);
    window.open(data.url);
  }

  /**
   * handle single announce click and set selectedAnnounce
   *
   * @param {AnnounceTableRowDto} msg
   * @memberof DashboardComponent
   */
  public handleAnnounceClick(msg: AnnounceTableRowDto) {
    this.selectedAnnounce = msg;
    this.messageDialog.open();
  }

  /**
   * check if form is valid
   *
   * @param {DynamicFormComponent} form
   * @returns
   * @memberof DashboardComponent
   */
  public isEventFormValid(form: DynamicFormComponent) {
    if (!form.form) {
      return false;
    } else {
      return form.form.valid;
    }
  }

  /**
   * get events
   *
   * @private
   * @param {*} params
   * @memberof DashboardComponent
   */
  private getEvents(params) {
    this.dashboardService.getEvents(params).subscribe((events) => {
      this.events = events;
      setTimeout( () => {
        this.ucCalendar.renderEvents(this.events);
      }, 1);
    });
  }

  /**
   * get BOLReminds
   */
  private getBOLReminds() {
    this.dashboardService.getBOLReminds().subscribe( reminds => {
      this.BOLReminds = reminds;
    });
  }

  /**
   * get today visit
   */
  private getTodayVisit() {
    this.boService.queryTodaySchedule({orderCol: 'assignedDate'}).subscribe( visits => {
      this.todayScheduleList = visits;
    })
  }

  /**
   * prepare form controls
   *
   * @private
   * @memberof DashboardComponent
   */
  private prepareControls() {
    this.eventControls = [
      new SingleDropdownControl({
        key: 'BOLNo',
        label: '名單',
        columnClasses: ['12'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.BOLlistForEvent
      }),
      new DatepickerControl({
        key: 'visitDate',
        label: '續訪日期',
        columnClasses: ['6'],
        required: true,
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      }),
      new ClockpickerControl({
        key: 'visitTime',
        label: '續訪時間',
        columnClasses: ['6'],
        required: true,
        placeholder: '請選擇時間...'
      }),
      new TextControl({
          key: 'subject',
          label: '主旨',
          columnClasses: ['12'],
          placeholder: 'e.g. 出訪顧客-王大明',
      }),
      new TextControl({
        key: 'visitAddress',
        label: '約訪地址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
      }),
      new TextControl({
        key: 'contactPhone',
        label: '連絡電話',
        columnClasses: ['12'],
        placeholder: 'e.g. 0988125888',
      }),
      new TextareaControl({
        key: 'remark',
        label: '備註',
        isWordCount: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }

  /**
   * change event form state
   *
   * @private
   * @memberof DashboardComponent
   */
  private changeEventFormState() {
    let editScheduleLabel = [
      'BOLNo',
      'subject',
      'visitAddress',
      'contactPhone',
    ];

    editScheduleLabel.forEach( (el) => {
      if (this.eventDialogMode === EventDialogMode.EDIT) {
        this.eventForm.form.controls[el].disable();
      } else {
        this.eventForm.form.controls[el].enable();
      }
    });

  }
}
