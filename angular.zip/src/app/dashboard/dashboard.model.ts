import { BaseResponseDto } from '../core/models/comm-data';

export interface CalendarEventResponseDto extends BaseResponseDto {
  /**
   * 名單編號
   */
  BOLNo: string;
  /**
   * 聯絡電話
   */
  ContactPhone: string;
  /**
   * 備註
   */
  Remark: string;
  /**
   * 主旨
   */
  Subject: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 訪談地址
   */
  VisitAddress: string;
  /**
   * 訪談日期
   */
  VisitDate: string;
  /**
   * 訪談時間
   */
  VisitTime: string;
}

export interface CalendarEventDto {
  /**
   * event start date
   */
  start: string;
  /**
   * event end date
   */
  end: string;
  /**
   * event display label
   */
  title: string;
  /**
   * event id
   */
  id: string;
  /**
   *  event data
   */
  data: CalendarEventResponseDto;
  /**
   * event display color
   */
  color: string;
}

export interface CalendarEventInfoDto {
  /**
   * 名單編號
   */
  BOLNo: string;
  /**
   * 訪談日期
   */
  visitDate: string;
  /**
   * 訪談時間
   */
  visitTime: string;
  /**
   * 主旨
   */
  subject: string;
  /**
   * 訪談地址
   */
  visitAddress: string;
  /**
   * 聯絡電話
   */
  contactPhone: string;
  /**
   * 備註
   */
  remark: string;
}

export interface CalendarEventEditInfo extends CalendarEventInfoDto {
  /**
   * UUID
   */
  UUID: string;
}

export interface RelativeLinkResponseDto extends BaseResponseDto {
  /**
   * 申請者
   */
  ApplyEmpId: string;
  /**
   * 專區連結標題
   */
  Name: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 專區連結 Url
   */
  Url: string;
  /**
   * 覆核者
   */
  VerifyEmpId: string;
}

export interface RelativeLinkTableRowDto {
  /**
   * 專區連結標題
   */
  name: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 專區連結 Url
   */
  url: string;
}

export interface AnnounceResponseDto extends BaseResponseDto {
  /**
   * 內文
   */
  Content: string;
  /**
   * 重要性
   */
  Importance: boolean;
  /**
   * 發布日期
   */
  PublishDate: string;
  /**
   * 結束日期
   */
  PublishEndDate: string;
  /**
   * 標題
   */
  Title: string;
  /**
   * UUID
   */
  UUID: string;
}

export interface AnnounceTableRowDto {
  /**
   * 發布日期
   */
  publishDate: string;
  /**
   * 標題
   */
  title: string;
  /**
   * 內文
   */
  content: string;
}
