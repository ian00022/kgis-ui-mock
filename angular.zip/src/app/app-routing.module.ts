import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PreloadAllModules, RouterModule, Routes} from '@angular/router';

import { LayoutComponent } from './layout/layout/layout.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SamplePagesComponent } from './sample-pages/sample-pages.component';
import { UnauthComponent } from './unauth/unauth.component';
import { Permissions } from './core/models/permissions';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { ConnectionResolverService } from './layout/connection-resolver.service';


const appRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [NgxPermissionsGuard],
    resolve: { connection: ConnectionResolverService },
    data: {
      permissions: {
        only: ['LOGIN_SUCCESS'],
        redirectTo: '/login'
      }
    },
    children:
      [
        {
          path: 'dashboard',
          component: DashboardComponent,
          canActivate: [NgxPermissionsGuard],
          data: {
            breadcrumb: '儀錶板',
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.VISIT_SEARCH,
                Permissions.ANNOUNCE_SEARCH,
                Permissions.REAL_LINK_SEARCH,
                Permissions.TODAY_VISIT_SEARCH
              ],
            }
          }
        },
        {
          path: 'clients',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/client/client.module#ClientModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.PERSONAL_SEARCH,
                Permissions.PERSONAL_SPECIAL_MEMBER_SEARCH
              ],
            }
          }
        },
        {
          path: 'business-op',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/business-opportunity/business-opportunity.module#BusinessOpportunityModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.GENERAL_BOL_SEARCH,
                Permissions.HEAD_OFFICE_BOL_SEARCH,
                Permissions.MY_FAVORITE_BOL_SEARCH,
                Permissions.TODAY_VISIT_SEARCH,
                Permissions.LOAN_BOL_SEARCH,
                Permissions.GENERAL_BOL_APPROVE_SEARCH,
                Permissions.HEAD_OFFICE_BOL_APPROVE_SEARCH,
                Permissions.ASSIGN_GENETAL_BOL_SEARCH,
                Permissions.ASSIGN_HEAD_OFFFICE_SEARCH
              ]
            }
          }
        },
        {
          path: 'referral',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/referral/referral.module#ReferralModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [ Permissions.REFERRAL_SEARCH ]
            }
          }
        },
        {
          path: 'marketing',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/marketing/marketing.module#MarketingModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.LOAN_CALCULATE_SEARCH,
                Permissions.EDM_SEARCH,
                Permissions.MAP_SEARCH,
                Permissions.REAL_ESTATE_TRANSACTION_SEARCH,
              ]
            }
          }
        },
        {
          path: 'effect-report',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/effect-report/effect-report.module#EffectReportModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.BOL_RESULT_SEARCH,
                Permissions.BOL_DETAIL_SEARCH
              ]
            }
          }
        },
        {
          path: 'management',
          canLoad: [NgxPermissionsGuard],
          loadChildren: 'app/management/management.module#ManagementModule',
          data: {
            permissions: {
              redirectTo: '/no-auth',
              only: [
                Permissions.USER_ROLE_SEARCH,
                Permissions.ROLE_SEARCH,
                Permissions.MARKETING_TEAM_SEARCH,
                Permissions.EMAIL_TEMPLATE_LIST_SEARCH,
                Permissions.NOTIFICATION_SEARCH,
                Permissions.CASE_MANAGEMENT_BOL_SEARCH,
                Permissions.OVERDUE_NOTIFICATION_LIST_SEARCH,
                Permissions.RECOMMEND_PRODUCTS_SEARCH,
                Permissions.PRODUCT_PARAMETER_SEARCH,
                Permissions.SYSTEM_PROPERTY_SEARCH,
              ]
            }
          }
        },
        { path: 'sample-page', component: SamplePagesComponent },
        // TODO: no auth page
        { path: 'no-auth', component: UnauthComponent},
        { path: '', redirectTo: '/dashboard', pathMatch: 'full'},
    ]},
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes,
      {
        // enableTracing: true,
        useHash: true,
        preloadingStrategy: PreloadAllModules
      })
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
