import { FormGroup, FormControl, Validators, FormArray, AbstractControl, ValidatorFn } from '@angular/forms';
import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MarketingService } from './../../core/services/marketing.service';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { LoggerService } from './../../shared/logger.service';
import * as _ from 'lodash';
import { EmailService } from 'app/core/services/email.service';
import { NzNotificationService } from 'ng-zorro-antd';
import { Permissions } from './../../core/models/permissions';

@Component({
  selector: 'esun-loan-trial',
  templateUrl: './loan-trial.component.html',
  styleUrls: ['./loan-trial.component.scss']
})
export class LoanTrialComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('emailDialog') emailDialog: IbmDialogComponent;

  public formSearchConfig: any;
  public loanTrialForm: FormGroup;
  public printHTML: any;
  public loadTrial: any = {};
  public recipient = '';
  public recipients = [];
  public notAllowStrings = [];
  public Permissions = Permissions;

  private loanTrialConfig = {
    LoanAmt: 10,
    months: 1,
    LoanFee: '',
    FreeMonth: '',
    periodMode: 1,
  };
  constructor(
    private logger: LoggerService,
    private marketingService: MarketingService,
    private email: EmailService,
    private noti: NzNotificationService,
    private sanitized: DomSanitizer
  ) { }

  ngOnInit() {
    this.initForm();
  }

  ngAfterViewInit() {
    this.loanTrialForm.get('periodMode').valueChanges
    .subscribe(
      (value) => {
        this.logger.debug(value);
        this.changeLoanRatePeriods(value);
    });
    this.loanTrialForm.get('months').valueChanges
    .subscribe( () => {
        this.initLoanRatePeriods();
      });
    // this.loanTrialForm.valueChanges.subscribe(value => {
    //   this.logger.debug('loanTrialForm.valueChanges: ', value);
    // });
  }

  ngOnDestroy() {
    this.email.removeRecipient(this.recipients);
  }

  /**
   * main search & list
   * fn: onSearchClick => means submit the search form
   * fn: check main search form is valid
   * fn: for rendering dynamic '期間' input ctrls in html
   * @memberof LoanTrialComponent
   */

  public onSearchClick() {
    const dataCfg = _.cloneDeep(this.loanTrialForm.value);
    delete dataCfg.months;
    delete dataCfg.periodMode;
    dataCfg.LoanAmt = dataCfg.LoanAmt * 10000;
    dataCfg.SegmentRates = dataCfg.SegmentRates.map(rate => {
      rate.InterestRate = rate.InterestRate / 100;
      return rate;
    });
    this.formSearchConfig = dataCfg;
    this.logger.debug('onSearchClick: ', dataCfg);

    this.marketingService.getLoanTrial(dataCfg)
      .subscribe(
        (response) => {
          this.loadTrial = response.value;
          this.logger.debug('marketingService.getLoanTrial: ', this.loadTrial);
        }
      );
  }

  get isValid(): boolean {
    return this.loanTrialForm.valid;
  }

  get loanRatePeriodsControls(): AbstractControl[] {
    return (<FormArray>this.loanTrialForm.get('SegmentRates')).controls;
  }


  /**
   * change start mon of next row
   *
   * @memberof LoanTrialComponent
   */
  handleEndChange(i) {
    const loanRatePeriodsControls = this.loanRatePeriodsControls;
    // the last
    if (i === loanRatePeriodsControls.length - 1) {
      return;
    } else {
      const v =  loanRatePeriodsControls[i].get('EndNum').value;
      const nextIndex = i + 1;
      loanRatePeriodsControls[nextIndex].get('StartNum').setValue(v + 1);
    }
  }

  /**
   * send email dialog
   * fn: handleEmailDialogCancel
   * fn: handleEmailDialogConfirm
   * fn: removeRecipient
   * fn: addRecipient
   * fn: autoCompleteRecipients
   * fn: sendable
   * fn: notFinishYetFields
   * @memberof LoanTrialComponent
   */
  public handleEmailDialogCancel() {
    this.emailDialog.close();
  }
  public handleEmailDialogConfirm() {
    if (_.isEmpty(this.formSearchConfig)) {
      this.noti.error('', '請進行試算後再寄出信件');
    } else {
      const config = {
        Input: this.formSearchConfig,
        ToMails: this.recipients
      };
      this.logger.debug('handleEmailDialogConfirm: ', config);

      this.marketingService.sendMailMktLoanTrial(config).subscribe(res => {
        this.logger.debug('sendMailMktLoanTrial: ', res);

        res.isOk ? this.noti.success('成功', '成功寄出信件') : this.noti.error('錯誤', '');
        this.emailDialog.close();
      });

    }
  }
  public removeRecipient(recipient: string) {
    this.email.removeRecipient(recipient);
  }
  public addRecipient(recipients: string) {
    const tmpRecipients = recipients.split(/,|，|;|；|\s|<|>/);
    if (tmpRecipients.length > 0) {
      this.notAllowStrings = this.email.illegalOrDuplicate([...tmpRecipients, ...this.email.getRecipient()]);
      const safeRecipients = tmpRecipients.filter(r => this.email.isEmail(r));
      this.email.setRecipients(safeRecipients);
      this.recipients = this.email.getRecipient();
    }
  }
  public autoCompleteRecipients(event: any) {
    // if (event) { event.preventDefault(); }

    const eventTrigger = () => {
      return (
        // blur
        event.type === 'blur' ||
        // space or ; or ,
        _.includes([32, 186, 188], event.keyCode) ||
        // ctrl + v
        event.type === 'paste'
      );
    };

    const addValue = () => {
      const value = event.target.value;
      event.target.value = '';
      this.addRecipient(value);
    };

    if (eventTrigger() && event.target.value) {
      // async after event trigger (for paste event)
      if (event.type === 'paste') {
        setTimeout(() => {
          addValue();
        }, 500);
      } else { addValue(); }
    }
  }
  public closeErrorAlert(event) {
    this.notAllowStrings = [];
  }
  get sendable(): boolean {
    return this.recipients.length > 0 && !_.isEmpty(this.formSearchConfig);
  }
  get notFinishYetFields(): boolean {
    return _.isEmpty(this.formSearchConfig);
  }

  /**
   * search result print
   *
   * @memberof LoanTrialComponent
   */
  print(): void {
    if (_.isEmpty(this.formSearchConfig)) {
      this.noti.error('請進行試算後再列印', '');
    } else {
      if (!_.isEmpty(this.formSearchConfig)) {
        const config = {
          Input: this.formSearchConfig
        };
        this.logger.debug('printHTML: ', config);

        this.marketingService.printMktLoanTrial(config).subscribe(res => {
          this.logger.debug('printMktLoanTrial: ', res);
          this.printHTML = this.sanitized.bypassSecurityTrustHtml(res.value);

          // waiting for bypassSecurityTrustHtml done
          setTimeout(() => {
            window.print();
          }, 1000);
        });
      }
    }
  }

  /**
   * private functions
   * fn: initForm => init main search form
   * fn: changeLoanRatePeriods => if '貸款利率' is changed, show '期間(n)' input rows.
   * fn: initLoanRatePeriods => init (reInit) '貸款利率' after '期間(n)' rows of inputs are different.
   */
  private initForm() {
    this.loanTrialForm = new FormGroup({
      LoanAmt: new FormControl(this.loanTrialConfig.LoanAmt, [Validators.pattern(/^[1-9]+[0-9]*$/), Validators.required]),
      months:  new FormControl(this.loanTrialConfig.months, Validators.required),
      LoanFee: new FormControl('', Validators.required),
      FreeMonth: new FormControl('', Validators.required),
      periodMode: new FormControl(this.loanTrialConfig.periodMode),
      SegmentRates: new FormArray([
        new FormGroup({
          SortNo: new FormControl('', Validators.required),
          StartNum: new FormControl('', Validators.required),
          EndNum: new FormControl('', Validators.required),
          InterestRate: new FormControl('', Validators.required)
        }, this.segmentRatesValidator)
      ])
    });
    this.logger.debug(this.loanTrialForm);
    this.initLoanRatePeriods();
  }

  private changeLoanRatePeriods(num: number) {
    this.loanTrialForm.removeControl('SegmentRates');
    const SegmentRates = new FormArray([]);

    for (let i = 0; i < num; i ++) {
      SegmentRates.push(
        new FormGroup({
          SortNo: new FormControl('', Validators.required),
          StartNum: new FormControl('', Validators.required),
          EndNum: new FormControl('', Validators.required),
          InterestRate: new FormControl('', Validators.required)
        }, this.segmentRatesValidator));
    }

    this.loanTrialForm.addControl('SegmentRates', SegmentRates);
    this.initLoanRatePeriods();
  }

  private initLoanRatePeriods() {
    const months = this.loanTrialForm.get('months').value;
    const array = (<FormArray>this.loanTrialForm.get('SegmentRates'));
    // const lastNum = array.controls.length - 1;
    for (let i = 0; i < array.controls.length; i++) {
      // let end = i === array.controls.length - 1 ? months : i+2;
      let  start;
      if (i === 0) {
        start = 1;
      } else {
        start = i + 2;
      }
      const end = start + 1;
      array.at(i).patchValue({
        StartNum: start,
        EndNum: end
      });
    }
    // array.at(0).patchValue({
    //   StartNum: 1,
    // });
    // array.at(lastNum).patchValue({
    //   EndNum: months,
    // });
  }

  private segmentRatesValidator: ValidatorFn = (form: FormGroup): { [key: string]: boolean }  => {
    if (form.controls['EndNum'].value <= form.controls['StartNum'].value) {
      return {
        period: true
      };
    }
  }
}
