import { Component, OnInit, ViewChild, OnDestroy, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { isNullOrUndefined } from 'util';
import { Subject } from 'rxjs';
import { IbmSideDialogComponent } from './../../shared/components/ibm-dialog/ibm-side-dialog/ibm-side-dialog.component';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { LoggerService } from './../../shared/logger.service';
import { NzNotificationService, UploadFile, UploadXHRArgs, NzUploadBtnComponent, NzUploadComponent } from 'ng-zorro-antd';
import * as _ from 'lodash';
import * as querystring from 'querystring';
import { environment } from 'environments/environment';
import { ProductHelper } from 'app/core/models/comm-data';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { ApiService, MarketingService, EmailService, AuthService, JwtService } from 'app/core/services';
import { Permissions } from '../../core/models/permissions';


@Component({
  selector: 'esun-edm',
  templateUrl: './edm.component.html',
  styleUrls: ['./edm.component.scss']
})
export class EdmComponent implements OnInit, OnDestroy {

  @ViewChild('dmHistory') dmHistoryDialog: IbmDialogComponent;
  @ViewChild('dmPreview') dmPreview: IbmSideDialogComponent;
  @ViewChild('emailToUser') emailToUser: IbmDialogComponent;
  @ViewChild('uploadQRCode') uploadQRCode: IbmDialogComponent;
  @ViewChild('uploadEl') uploadEl: ElementRef;
  @ViewChild('previewIframe') previewIframe: ElementRef;
  @ViewChildren('nzUploader') nzUploader: QueryList<NzUploadComponent>;

  public prod: any;
  public prodOptions: any[];
  public dmList: any[] = [];
  public dmHistoryList: any[] = [];
  public selectedDM: any = {};
  public dmPreviewSrc;
  public recipient = '';
  public recipients = [];
  public notAllowStrings = [];
  public uploadURL = '';
  public orderTypes = [
    { label: '名稱', value: 'ProductName' },
    { label: '有效期限', value: 'Expried' }
  ];

  public uploadQRCodeTextInputs: any = [];
  public uploadQRCodeImgInputs: any = [];

  public displayPreviewIframe = false;
  public Permissions = Permissions;

  loading = false;

  private ngUnSubscribe: Subject<any> = new Subject();
  private orderType: any = this.orderTypes[0];

  constructor(
    private logger: LoggerService,
    private marketingService: MarketingService,
    private sanitizer: DomSanitizer,
    private email: EmailService,
    private notification: NzNotificationService,
    private auth: AuthService,
    private options: SelectOptionsService,
    private api: ApiService,
    private jwt: JwtService
  ) {
    this.prodOptions = this.options.getOptions('emailTemplateProductType');
  }

  ngOnInit() {}

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * List
   * fn get: orderTypeLabel
   * fn: chooseOrderType
   * fn get: isSearchInValid
   * fn: onSearchClick
   */
  get orderTypeLabel(): string {
    return this.orderType.label;
  }
  public chooseOrderType(type: any) {
    this.orderType = type;
    if (!this.isSearchInValid) {
      this.onSearchClick();
    }
  }
  get isSearchInValid(): boolean {
    return isNullOrUndefined(this.prod);
  }
  public onSearchClick() {
    const queryConfig = {
      ProductCategoryCode: this.prod,
      OrderByCol: this.orderType.value
    };
    this.logger.debug(queryConfig);
    this.marketingService.getDmList(queryConfig)
      .subscribe(
        (response) => {
          this.dmList = response.value.map(dmList => {
            dmList.src = `${environment.api_url}/MarketingDM/${dmList.UUID}/preview`;
            return dmList;
          });
        }
      );
  }

  /**
   * History Dialog
   * fn: onHistoryRecordClick
   * fn: dmHistoryDialogClose
   */
  public onHistoryRecordClick(value: any) {
    this.selectedDM = value;
    this.marketingService.getDmHistoryList(this.selectedDM.UUID)
      .subscribe(
        (response) => {
          this.dmHistoryList = response.value;
          this.dmHistoryDialog.open();
        }
      );
  }

  public dmHistoryDialogClose() {
    this.dmHistoryList = [];
  }

  public previewReady(url) {
    const that = this;
    function handler() {
      if (this.readyState === this.DONE) {
        if (this.status === 200) {
          // this.response is a Blob, because we set responseType above
          const dataUrl = URL.createObjectURL(this.response);
          that.previewIframe.nativeElement.src = dataUrl;
        } else {
          console.error('no data :(');
        }
      }
    }
    let xhr = new XMLHttpRequest();

    xhr.open('GET', url);
    xhr.onreadystatechange = handler;
    xhr.responseType = 'blob';
    xhr.setRequestHeader('authorization', this.jwt.getAuthToken());
    xhr.send();
    this.displayPreviewIframe = true;
  }

  /**
   * Preview
   * fn: onPreviewClick
   */
  public onPreviewClick(value: any) {
    this.selectedDM = value;
    this.displayPreviewIframe = false;
    this.previewReady(this.selectedDM.src);
    // load input fields when it's preview, so user can edit txt again and again.
    // If load fields when input dialog open, it'll be reset(because of reload) inputs everytime.
    this.marketingService.getEDMInputs(this.selectedDM.UUID, {})
      .subscribe((response) => {
        this.uploadQRCodeTextInputs = response.value.filter(i => i.FieldType === 'txt');
        this.uploadQRCodeImgInputs = response.value.filter(i => i.FieldType === 'img');
      });

    this.dmPreview.open();
  }

  /**
   * 確認寄出
   * fn: emailToUserOpen
   * fn: removeRecipient
   * fn: addRecipient
   * fn: autoCompleteRecipients
   * fn: closeErrorAlert
   * fn get: sendable
   * fn: sendEmail
   */
  public emailToUserOpen() {
    // this data is maybe from customer sendMail
    if (this.email.getRecipient().length > 0) {
      // this.recipient = this.email.getRecipient().join('，');
      this.recipients = this.email.getRecipient();
    }
    this.emailToUser.open();
  }

  public removeRecipient(recipient: string) {
    this.email.removeRecipient(recipient);
  }

  public addRecipient(recipients: string) {
    const tmpRecipients = recipients.split(/,|，|;|；|\s|<|>/);
    if (tmpRecipients.length > 0) {
      this.notAllowStrings = this.email.illegalOrDuplicate([...tmpRecipients, ...this.email.getRecipient()]);
      const safeRecipients = tmpRecipients.filter(r => this.email.isEmail(r));
      this.email.setRecipients(safeRecipients);
      this.recipients = this.email.getRecipient();
    }
  }

  public autoCompleteRecipients(event: any) {
    // if (event) { event.preventDefault(); }

    const eventTrigger = () => {
      return (
        // blur
        event.type === 'blur' ||
        // space or ; or ,
        _.includes([32, 186, 188], event.keyCode) ||
        // ctrl + v
        event.type === 'paste'
      );
    };

    const addValue = () => {
      const value = event.target.value;
      event.target.value = '';
      this.addRecipient(value);
    };

    if (eventTrigger() && event.target.value) {
      // async after event trigger (for paste event)
      if (event.type === 'paste') {
        setTimeout(() => {
          addValue();
        }, 500);
      } else { addValue(); }
    }
  }

  public closeErrorAlert(event) {
    this.notAllowStrings = [];
  }

  get notFinishYetFields(): string {
    return [...this.uploadQRCodeTextInputs, ...this.uploadQRCodeImgInputs]
      .filter(inputModel => _.isEmpty(inputModel.FieldValue))
      .map(inputsModel => inputsModel.FieldName).join('，');
  }

  get sendable(): boolean {
    return this.recipients.length > 0 && !this.notFinishYetFields;
  }

  get generateSendFields() {
    return [...this.uploadQRCodeTextInputs, ...this.uploadQRCodeImgInputs].map(field => {
      return {
        FieldName: field.FieldName,
        FieldType: field.FieldType,
        FieldValue: field.FieldValue
      };
    });
  }

  public sendEmail() {
    const body = {
      EmailTemplateUUID: this.selectedDM.UUID,
      Subject: this.selectedDM.ProductName,
      EmpId: this.auth.getLoginUser().loginEmpId,
      Priority: 'string',
      MailTo: this.recipients.join(','),
      Fields: this.generateSendFields,
      ActionEmp: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType
      }
    };
    if (_.isEmpty(body.Fields)) {
      delete body.Fields;
    }
    this.marketingService.sendMail(body).subscribe(res => {
      if (res.isOk) {
        this.notification.success('成功', '已發送信件');
        this.emailToUser.close();
      }
    });
  }

  /**
   * 聯絡資訊輸入
   * fn: uploadQRCodeOpen
   * fn: dmInputSubmit
   * fn: setParams
   * fn: beforeUpload
   * fn: beforeUpload
   */
  public uploadQRCodeOpen() {
    this.uploadQRCode.open();
  }
  public dmInputSubmit(f: NgForm) {
    const urlParams = this.setParams();
    const newURL = this.selectedDM.src + urlParams;

    this.displayPreviewIframe = false;
    this.previewReady(newURL);

    this.uploadQRCode.close();
  }

  public setParams() {
    const escapeSeparator = (value: string) => value.replace(/\|/g, '｜');
    const hasValueInputs = [
      ...this.uploadQRCodeTextInputs.filter(inputs => !_.isEmpty(inputs.FieldValue)),
      ...this.uploadQRCodeImgInputs.filter(inputs => !_.isEmpty(inputs.FieldValue))
    ];
    const valuesStringArr = hasValueInputs.map(inputs => `${escapeSeparator(inputs.FieldType)}|${escapeSeparator(inputs.FieldName)}|${escapeSeparator(inputs.FieldValue)}`);

    return !_.isEmpty(valuesStringArr) ? `?${querystring.stringify({ data: valuesStringArr })}` : '';
  }

  beforeUpload = (file: File) => {
    this.logger.debug('beforeUpload: ', this);
    const isImage =  _.includes(['image/jpeg', 'image/png', 'image/gif'], file.type);
    if (!isImage) {
      this.notification.error('錯誤', '只能上傳gif、png、jpg。');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      this.notification.error('錯誤', '檔案大小必須小於2MB。');
    }
    return isImage && isLt2M;
  }

  handleUploadChange = (item: UploadXHRArgs) => {
    this.logger.debug('handleUploadChange: ', this);

    let formData = new FormData();

    // tslint:disable-next-line:no-any
    formData.append('file', item.file as any);
    formData.append('fileInfo', JSON.stringify({
      'LoginUser': {
        'LoginEmpId': this.auth.getLoginUser().loginEmpId,
        'AgentEmpId': this.auth.getLoginUser().agentEmpId,
        'UnitId': this.auth.getLoginUser().unitId,
        'UseType': this.auth.getLoginUser().useType
      }
    }));

    // disabled upload before send to api
    this.uploadQRCodeImgInputs.map(inp => {
      if (inp.FieldName === item.name) {
        inp.isUploading = true;
      }
      return inp;
    });

    // success
    item.onSuccess = (ret: any, file: UploadFile, xhr: any) => {
      this.logger.debug('handleUploadChange onSuccess:', ret, item, file, xhr);
      this.uploadQRCodeImgInputs.map(inp => {
        if (inp.FieldName === item.name) {
          if (ret.IsOk) {
            inp.FieldValue = ret.Value.FileDownloadPath;
          } else {
            this.notification.error('上傳失敗', JSON.stringify(ret.Messages), { nzDuration: 30 * 1000 });
            console.error(ret);
          }
          inp.isUploading = false;
        }
        return inp;
      });
    };

    return this.marketingService.uploadQRcode(formData, item);
  }
}
