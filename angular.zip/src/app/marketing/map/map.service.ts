import { MarkerDto, CompanyLocationResponseDto } from 'app/marketing/map/map.model';
import { ApiService } from './../../core/services/api.service';
import { Observable ,  of } from 'rxjs';
import { Injectable } from '@angular/core';
import { MapIcon, GetMarketingMapDto, MarkerTypeHelper, MarkerTypeEnum } from './map.model';
import * as _ from 'lodash';
import { MarsHttpResponseResult } from 'app/core/models/response.model';
import { map } from 'rxjs/operators';

declare var moment;

@Injectable()
export class MapService {
  private markers = [];

  constructor(private api: ApiService) { }
  
  public getCities(): Observable<any> {
    return this.api.get('MarketingMap/addressZipName').pipe(map(data => {
      return data.value.map(option => {
        return { label: option.AddressZipName, value: option.AddressZipName };
      });
    }));
  }

  public getDistricts(city): Observable<any> {
    return this.api.get(`MarketingMap/${city}/addressZipSubName`).pipe(map(data => {
      return data.value.map(option => {
        return { label: option.AddressZipSubName, value: option.AddressZipSubName };
      });
    }));
  }

  public getLatLngByAddress(address: string): Observable<CompanyLocationResponseDto> {
    // return this.api.get('MarketingMap/GeoLocation', {
    //   'input.address': address
    // }).pipe(map(data => {
    //   return data.value;
    // }));
    return this.api.getExternal('https://maps.googleapis.com/maps/api/geocode/json', {'address': address, key: 'AIzaSyDAWy8FJzxHdW01aemx6Ln0Y5A25wEnATc'});
  }

  public getBanks(city, district): Observable<any> {
    return this.api.get(`MarketingMap/${city}/${district}/branches`).pipe(map(data => {
      return data.value.map(option => {
        return { label: option.BranchName, value: option.BranchCode };
      });
    }));
  }

  public getPositionFromBankId(id: string): Observable<any> {
    return this.api.get('MarketingMap/GeoLocation', {
      'input.branchCode': id,
      'input.type': 'Branch'
    }).pipe(map(data => {
      return data.value;
    }));
  }

  public getPositionFromCompanyId(id: string): Observable<CompanyLocationResponseDto> {
    return this.api.get('MarketingMap/GeoLocation', {
      'input.cID': id,
      'input.type': 'Company'
    }).pipe(map(data => {
      return data.value;
    }));
    // return asyncReturn({
    //   lat: 23.851148 + Math.random() * 0.1,
    //   lng: 120.5949259 + Math.random() * 0.1
    // });
  }

  public getIconSettings(type: MarkerTypeEnum) {
    return MarkerTypeHelper.mapTo(type);
  }

  public getMarker(type: MarkerTypeEnum, id): Observable<any> {
    return this.api.get(`MarketingMap/${type}/${id}`).pipe(map(data => data.value));
    // return new Observable((observer) => {
    //   setTimeout(() => {
    //     let marker = _.find(this.markers, {id: id});
    //     observer.next(Object.assign(marker, {owner: '01234板橋分行', savingSum: '83,121,652', name: '堤王人力派遣公司' + Math.floor(Math.random()*30)  }));
    //   }, 100);
    // });
  }

  public getMarkersByIds(ids: number[]): Observable<any> {
    return new Observable((observer) => {
      setTimeout(() => {
        let markers = this.markers.filter((marker) => {
          return _.includes(ids, marker.id);
        }).map((marker) => {
          return Object.assign(marker, {owner: '01234板橋分行', savingSum: '83,121,652', name: '堤王人力派遣公司' + Math.floor(Math.random()*30)   });
        });
        observer.next(markers);
      }, 100);
    });
  }

  public getMarkers(params: GetMarketingMapDto): Observable<MarsHttpResponseResult> {
    return this.api.get('MarketingMap', params);
    // this.markers = [
    //   {id:2, latLng: [25.1149569, 121.5440177], types: ['firm'], createDate: '2012-04-23', capital: 800},
    //   {id:3, latLng: [25.1209569, 121.5480177], types: ['estimate'], size: 45, estimateDate: '2018-07-04', completeDate: '2018-07-04'},
    //   {id:4, latLng: [25.1149569, 121.5400177], types: ['price']},
    //   {id:6, latLng: [25.1549569, 121.6000177], types: ['price']},
    //   {id:7, latLng: [25.1549569, 121.6000177], types: ['firm']},
    //   {id:8, latLng: [25.1549569, 121.6000177], types: ['estimate'], size: 45, estimateDate: '2018-07-04', completeDate: '2018-07-04'},
    //   {id:9, latLng: [25.1549569, 121.6000177], types: ['estimate'], size: 45, estimateDate: '2018-07-04', completeDate: '2018-07-04'},
    //   {id:10, latLng: [25.1549569, 121.6000177], types: ['estimate'], size: 45, estimateDate: '2018-07-04', completeDate: '2018-07-04'},
    //   {id:12, latLng: [25.1549569, 121.6000177], types: ['estimate'], size: 45, estimateDate: '2018-07-04', completeDate: '2018-07-04'},
    // ];
    // const markersLen = this.markers.length;
    // const types = ['estimate', 'firm', 'price'];
    // for (let i = 1; i < 45; i++) {

    //   this.markers.push({id: markersLen + i, latLng: [25.1549569, 121.6000177], types: [types[Math.floor(Math.random()*types.length)]] });
    // }
    // return of(this.markers);
  }

  public filterMarkers(search: IMarkerFilterDto, markers: MarkerDto[]): Observable<MarkerDto[]> {
    const rs = markers.filter((marker) => {
      // 判斷是否為勾選類別
      if (search.types.length > 0 && _.indexOf(search.types, marker.type) === -1) {
        return false;
      }
      let check = true;
      // marker 共用欄位
      // 估價
      if ( marker.type === MarkerTypeEnum.EVALUATION) {
        // 估價日期
        if (!_.isEmpty(search.estimateDate)) {
          let dates = search.estimateDate.split(' - ');
          if (!moment(marker.RealEstateEvaluation.ValuationDate)
            .isBetween(moment(dates[0]), moment(dates[1]))) {
            check = false;
          }
        }
        // 完工日期
        if (!_.isEmpty(search.completeDate)) {
          let dates = search.completeDate.split(' - ');
          if (!moment(marker.RealEstateEvaluation.CompletionDate)
              .isBetween(moment(dates[0]), moment(dates[1]))) {
            check = false;
          }
        }
        if (!_.isNull(search.sizeFrom)) {
          if (marker.RealEstateEvaluation.LandPing < search.sizeFrom) {
            check = false;
          }
        }
        if (!_.isNull(search.sizeTo)) {
          if (marker.RealEstateEvaluation.LandPing > search.sizeTo) {
            check = false;
          }
        }
      }
      // 時價
      if ( marker.type === MarkerTypeEnum.TRANSACTION ) {
        if (!_.isEmpty(search.dealDate)) {
          let dates = search.dealDate.split(' - ');
          if (!moment(marker.RealEstateTransaction.SoldDate).isBetween(moment(dates[0]), moment(dates[1]))) {
            check = false;
          }
        }
        if (!_.isNull(search.ageFrom)) {
          let age = search.ageFrom;
          if (marker.RealEstateTransaction.BuildingAge < age) {
            check = false;
          }
        }
        if (!_.isNull(search.ageTo)) {
          let age = search.ageTo;
          if (marker.RealEstateTransaction.BuildingAge > age) {
            check = false;
          }
        }
        if (!_.isNull(search.transferSizeFrom)) {
          let size = search.transferSizeFrom;
          if (search.transferSizeType === '2') {
            size = search.transferSizeFrom * 3.30579;
          }
          if (marker.RealEstateTransaction.LandPing < size) {
            check = false;
          }
        }
        if (!_.isNull(search.transferSizeTo)) {
          let size = search.transferSizeTo;
          if (search.transferSizeType === '2') {
            size = search.transferSizeTo * 3.30579;
          }
          if (marker.RealEstateTransaction.LandPing > size) {
            check = false;
          }
        }
      }

      // 公司
      if ( marker.type === MarkerTypeEnum.COMPANY ) {
        if (!_.isEmpty(search.createDate)) {
          let dates = search.createDate.split(' - ');
          if (!moment(marker.CompanyInfo.RegisterApprDate).isBetween(moment(dates[0]), moment(dates[1]))) {
            check = false;
          }
        }
        if (!_.isNull(search.capitalFrom)) {
          let capital = search.capitalFrom;
          if (marker.CompanyInfo.Capital < capital) {
            check = false;
          }
        }
        if (!_.isNull(search.capitalTo)) {
          let capital = search.capitalTo;
          if (marker.CompanyInfo.Capital > capital) {
            check = false;
          }
        }
        if (search.isDepositAccount) {
          if (!marker.CompanyInfo.IsDepositAccount) {
            check = false; 
          }
        }
        if (search.isSBAccount) {
          if (!marker.CompanyInfo.IsSbAccount) {
            check = false; 
          }
        }
      }
      
      return check;
      
    });
    return of(rs? rs: []);
  }
}

export interface IMarkerFilterDto {
  types: MarkerTypeEnum[];
  createDate: any;
  capitalFrom: any;
  capitalTo: any;
  isDepositAccount: boolean;
  isSBAccount: boolean;
  estimateDate: any;
  completeDate: any;
  sizeFrom: any;
  sizeTo: any;
  dealDate: any;
  ageFrom: any;
  ageTo: any;
  transferSizeType: any;
  transferSizeFrom: any;
  transferSizeTo: any;
}

function asyncReturn(value) {
  return new Observable((observer) => {
    observer.next(value);
  });
}