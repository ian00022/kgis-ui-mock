import * as _ from 'lodash';

export class MapIcon {
    constructor(public className, public shortText, public text){}
}

export interface GetMarketingMapDto {
    'input.screenLimit.MinLatitude': number;
    'input.screenLimit.MinLongitude': number;
    'input.screenLimit.MaxLatitude': number;
    'input.screenLimit.MaxLongitude': number;
}

export interface GetMarketingMapResponseDto {
    CardInfo: {
        Type: string,
        UUID: string,
        Name: string,
    };
    Coordinate: {
        Longitude: number,
        Latitude: number
    };
    RealEstateEvaluation: {
        BuildingPing: number,
        CompletionDate: string,
        LandPing: number,
        RealEstateType: string,
        ValuationDate: string,
    };
    CompanyInfo: {
        BusinessInfo: string,
        Capital: number,
        IsDepositAccount: boolean,
        IsSbAccount: boolean,
        RegisterApprDate: string,
    };
    RealEstateTransaction: {
        BuildingAge: number,
        BuildingType: string,
        LandPing: number,
        SoldDate: string,
    };
}

export interface MarkerDto {
    id: string;
    name: string;
    latLng: number[];
    type: MarkerTypeEnum;
    RealEstateEvaluation: {
        BuildingPing: number,
        CompletionDate: string,
        LandPing: number,
        RealEstateType: string,
        ValuationDate: string,
    };
    CompanyInfo: {
        BusinessInfo: string,
        Capital: number,
        IsDepositAccount: boolean,
        IsSbAccount: boolean,
        RegisterApprDate: string,
    };
    RealEstateTransaction: {
        BuildingAge: number,
        BuildingType: string,
        LandPing: number,
        SoldDate: string,
    };
}

export interface CompanyLocationResponseDto {
    Latitude: number;
    Longitude: number;
}

export enum MarkerTypeEnum {
    COMPANY = 'CompanyInfo', //經濟部商工登記公司
    EVALUATION = 'RealEstateEvaluationData', //本行既有估價資訊
    TRANSACTION = 'RealEstateTransactionData', //實價登錄資訊
}

export class MarkerTypeHelper {
    public static MapIconMap = {
        'CompanyInfo': new MapIcon('icon-orange', '經', '經濟部商工登記公司'),
        'RealEstateEvaluationData': new MapIcon('icon-purple', '估', '本行既有估價資訊'),
        'RealEstateTransactionData': new MapIcon('icon-blue', '實', '實價登錄資訊'),
    };
    public static CodeEnum = MarkerTypeEnum;
    public static mapTo(key: MarkerTypeEnum): MapIcon {
        return this.MapIconMap[key];
    }
}

export class MarkerHelper {
    public static mapTo(markerToMap: GetMarketingMapResponseDto): MarkerDto {
        const marker: MarkerDto = {
            id: _.result(markerToMap, 'CardInfo.UUID'),
            name: _.result(markerToMap, 'CardInfo.Name'),
            // latLng: [data.value[0].Coordinate.Latitude, data.value[0].Coordinate.Longitude],
            latLng: [
                _.result(markerToMap, 'Coordinate.Latitude'),
                _.result(markerToMap, 'Coordinate.Longitude'),
            ],
            type: _.result(markerToMap, 'CardInfo.Type') as MarkerTypeEnum,
            RealEstateEvaluation: markerToMap.RealEstateEvaluation,
            CompanyInfo: markerToMap.CompanyInfo,
            RealEstateTransaction: markerToMap.RealEstateTransaction
        };
        return marker;
    }
}

// // 'saving': new MapIcon('icon-red', '存', '本公司存款戶'),
// 'firm' : new MapIcon('icon-orange', '經', '經濟部商工登記公司'),
// // 'SB': new MapIcon('icon-brown', 'SB', 'SB舊戶'),
// 'estimate' : new MapIcon('icon-purple', '估', '本行既有估價資訊'),
// 'price': new MapIcon('icon-blue', '實', '實價登錄資訊'),
