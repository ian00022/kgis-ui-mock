import { DateHelper } from 'app/shared/helper/date-helper';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Map, GridLayer, LayerGroup, latLng } from 'leaflet';
import { MapService, IMarkerFilterDto } from './map.service';
import { MatSelectionList, MatListOption } from '@angular/material';
import * as _ from 'lodash';
import { GetMarketingMapDto, MarkerDto, GetMarketingMapResponseDto, MarkerTypeEnum, MarkerHelper } from 'app/marketing/map/map.model';

declare var L: any;
declare var moment: any;

enum IInfoDialogViewingMode {
  LIST,
  DATA
}

@Component({
  selector: 'esun-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit, AfterViewInit {
  public displayPanel: boolean = true;
  public markerTypes = [
    // {value: 'saving', label: '本公司存款戶', labelShort: '存', colorClass: 'red'},
    {value: MarkerTypeEnum.COMPANY, label: '經濟部商工登記公司', labelShort: '經', colorClass: 'orange'},
    // {value: 'SB', label: 'SB舊戶', labelShort: 'SB', colorClass: 'brown'},
    {value: MarkerTypeEnum.EVALUATION, label: '本行既有估價資訊', labelShort: '估', colorClass: 'purple'},
    {value: MarkerTypeEnum.TRANSACTION, label: '實價登錄資訊', labelShort: '實', colorClass: 'blue'},
  ];

  @ViewChild('typeList') typeList: MatSelectionList;
  @ViewChild('sideInfoBox') sideInfoBox;
  @ViewChild('mapContainer') mapContainer;
  public currentViewingType: MarkerTypeEnum;
  public markerTypeEnum = MarkerTypeEnum;
  public currentViewData;
  public currentViewMarkerList: MarkerDto[];
  public currentViewMakerIndex;
  public previousMarkerType;
  public nextMarkerType;
  public infoDialogViewingMode: IInfoDialogViewingMode;
  public infoDialogViewingModeEnum = IInfoDialogViewingMode;
  public searchMinDate;
  public searchMaxDate;
  public selectedSort;
  public sortableAttributes = [
    {
      label: '核准設立日期(升冪)',
      value: 'createDate',
      order: 'asc'
    },
    {
      label: '核准設立日期(降冪)',
      value: 'createDate',
      order: 'desc'
    },
    {
      label: '資本總額(元)(升冪)',
      value: 'capital',
      order: 'asc'
    },
    {
      label: '資本總額(元)(降冪)',
      value: 'capital',
      order: 'desc'
    },
    {
      label: '鑑價日期(升冪)',
      value: 'estimateDate',
      order: 'asc'
    },
    {
      label: '鑑價日期(降冪)',
      value: 'estimateDate',
      order: 'desc'
    },
    {
      label: '完工日期(升冪)',
      value: 'doneDate',
      order: 'asc'
    },
    {
      label: '完工日期(降冪)',
      value: 'doneDate',
      order: 'desc'
    },
    {
      label: '坪數(升冪)',
      value: 'size',
      order: 'asc'
    },
    {
      label: '坪數(降冪)',
      value: 'size',
      order: 'desc'
    }
  ];

  // 核准設立日期」、「資本總額(元)」、「鑑價日期」、「完工日期」、「坪數

  public city;
  public district;
  public bank;
  public address;
  public companyId;

  public cityList = [];
  public districtList = [];
  public bankList = [];

  public locationSearchType: string = '1';

  public searchModel: IMarkerFilterDto = {
    types: [],
    createDate: null,
    capitalFrom: null,
    capitalTo: null,
    isDepositAccount: false,
    isSBAccount: false,
    estimateDate: null,
    completeDate: null,
    sizeFrom: null,
    sizeTo: null,
    dealDate: null,
    ageFrom: null,
    ageTo: null,
    transferSizeType: '1',
    transferSizeFrom: null,
    transferSizeTo: null,
  };

  private map: Map;
  private markersLayer: LayerGroup;
  private markers: MarkerDto[];

  constructor(private mapService: MapService) {
    this.searchMinDate = moment(moment().subtract(1, 'year'));
    this.searchMaxDate = moment();
  }

  get sortedList(): any[] {
    if (!this.currentViewMarkerList) {
      return null;
    }
    if (!this.selectedSort) {
      return null;
    }

    let workingList = _.cloneDeep(this.currentViewMarkerList);
    workingList = workingList.map(markerShort => {
      return this.markers.filter((m: MarkerDto) => {
        return m.id === markerShort.id;
      })[0];
    });

    let attributeFunction;

    switch(this.selectedSort.value) {
      case 'createDate':
      attributeFunction =
          (m: MarkerDto) => _.result(m, 'CompanyInfo.RegisterApprDate');
        break;
      case 'capital':
        attributeFunction =
            (m: MarkerDto) => _.result(m, 'CompanyInfo.Capital');
          break;
      case 'estimateDate':
        attributeFunction =
            (m: MarkerDto) => _.result(m, 'RealEstateEvaluation.ValuationDate');
          break;
      case 'doneDate':
        attributeFunction =
            (m: MarkerDto) => _.result(m, 'RealEstateEvaluation.CompletionDate');
          break;
      case 'size':
        attributeFunction =
            (m: MarkerDto) => _.result(m, 'RealEstateEvaluation.LandPing');
          break;
    }

    return _.orderBy(workingList, attributeFunction, this.selectedSort.order);
  }

  get currentViewDataRows(): any[] {
    let rs = [];
    if (this.currentViewData) {
      const cv = this.currentViewData;
      // CompanyInfo
      if (!_.isEmpty(cv.CompanyInfo)) {
        rs.push({
          title: '統一編號:',
          text: _.result(cv, 'CompanyInfo.CID')
        });
        rs.push({
          title: '公司狀況:',
          text: _.result(cv, 'CompanyInfo.CompanyStatus')
        });
        rs.push({
          title: '公司名稱:',
          text: _.result(cv, 'CompanyInfo.CompanyName')
        });
        rs.push({
          title: '資本總額:',
          text: _.result(cv, 'CompanyInfo.Capital')
        });
        rs.push({
          title: '代表人姓名:',
          text: _.result(cv, 'CompanyInfo.RepName')
        });
        rs.push({
          title: '公司所在地:',
          text: _.result(cv, 'CompanyInfo.CompanyLocation')
        });
        rs.push({
          title: '登記機關:',
          text: _.result(cv, 'CompanyInfo.RegisterAuthority')
        });
        rs.push({
          title: '核准設立日:',
          text: DateHelper.formatDate(_.result(cv, 'CompanyInfo.RegisterApprDate', null))
        });
        rs.push({
          title: '最後核准變更日:',
          text: DateHelper.formatDate(_.result(cv, 'CompanyInfo.LastChangeApprDate', null))
        });
        rs.push({
          title: '登記機關:',
          text: _.result(cv, 'CompanyInfo.RegisterAuthority')
        });
      }
      if (!_.isEmpty(cv.RealEstateEvaluation)) {
        rs.push({
          title: '鑑價日期:',
          text: DateHelper.formatDate(_.result(cv, 'RealEstateEvaluation.ValuationDate', null))
        });
        rs.push({
          title: '建物門牌/土地地段:',
          text: _.result(cv, 'RealEstateEvaluation.LandLot')
        });
        rs.push({
          title: '建物坪數:',
          text: _.result(cv, 'RealEstateEvaluation.LandPing')
        });
        rs.push({
          title: '評估總值(萬元):',
          text: _.result(cv, 'RealEstateEvaluation.TotalPrice')
        });
        rs.push({
          title: '單價(萬元):',
          text: _.result(cv, 'RealEstateEvaluation.UnitPrice')
        });
        rs.push({
          title: '樓層別:',
          text: _.result(cv, 'RealEstateEvaluation.BuildingFloor')
        });
        rs.push({
          title: '建物完成日:',
          text: DateHelper.formatDate(_.result(cv, 'RealEstateEvaluation.CompletionDate', null))
        });
      }
      if (!_.isEmpty(cv.RealEstateTransaction)) {
        rs.push({
          title: '區段位置/區段門牌:',
          text: _.result(cv, 'RealEstateTransaction.LandLot')
        });
        rs.push({
          title: '總價(萬元):',
          text: _.result(cv, 'RealEstateTransaction.TotalPrice')
        });
        rs.push({
          title: '總價(萬元/坪):',
          text: _.result(cv, 'RealEstateTransaction.UnitPrice')
        });
        rs.push({
          title: '總面積:',
          text: _.result(cv, 'RealEstateTransaction.LandPing')
        });
        rs.push({
          title: '型態:',
          text: _.result(cv, 'RealEstateTransaction.BuildingType')
        });
        rs.push({
          title: '屋齡:',
          text: _.result(cv, 'RealEstateTransaction.BuildingAge')
        });
        rs.push({
          title: '樓別/樓高:',
          text: _.result(cv, 'RealEstateTransaction.BuildingFloor')
        });
        rs.push({
          title: '',
          text: '',
          divider: true,
        });
        rs.push({
          title: '交易標的:',
          text: _.result(cv, 'RealEstateTransaction.SoldTarget')
        });
        rs.push({
          title: '交易年月:',
          text: DateHelper.formatDate(_.result(cv, 'RealEstateTransaction.SoldDate', null))
        });
        rs.push({
          title: '總價(元):',
          text: _.result(cv, 'RealEstateTransaction.SoldUnitPrice')
        });
        rs.push({
          title: '交易單價(萬/坪):',
          text: _.result(cv, 'RealEstateTransaction.SoldUnitPrice')
        });
        rs.push({
          title: '建物轉移總面積(坪):',
          text: ''
        });
      }
    }
    return rs;
  }

  public notEmptyString(value: any): boolean {
    return !_.isNull(value) && value !== '';
  }

  public selectSort(item) {
    this.selectedSort = item;
  }

  public selectAll() {
    this.typeList.selectAll();
  }

  public resetFilter() {
    this.resetSearchModel();
    this.typeList.deselectAll();
  }

  public getMarkerAttr(value, attr) {
    if (value && attr) {
      return _.find(this.markerTypes, {value: value})[attr];
    }
  }

  public onTypeListSelectionChange() {
    this.searchModel.types = this.typeList.selectedOptions.selected.map((selectedItem: MatListOption) => selectedItem.value);
  }

  public isTypeSelected(value): boolean {
    if (this.searchModel.types) {
      return _.indexOf(this.searchModel.types, value) > -1;
    }
    return false;
  }

  public handleFilterChange(type: MarkerTypeEnum) {
    if (this.searchModel.types) {
      if (_.indexOf(this.searchModel.types, type) === -1) {
        this.searchModel.types.push(type);
      }
    }
  }

  public filterAndSearch() {
    this.mapService.filterMarkers(this.searchModel, this.markers).subscribe((markers) => {
      this.renderMarkers(markers);
    });
  }

  public onSubmenuTriggerClick(type) {
    this.currentViewingType = type;
  }

  public showMarkerInfoByListIndex(index: number) {
    const marker = this.sortedList[index];
    this.showMarkerInfo(marker.type, marker.id, index);
  }

  public showMarkerInfo(type: MarkerTypeEnum, id, index?) {
    this.mapService.getMarker(type, id).subscribe((data) => {
      this.infoDialogViewingMode = IInfoDialogViewingMode.DATA;
      this.currentViewData = MarkerHelper.mapTo(data);
      if(index > -1) {
        this.currentViewMakerIndex = index;
      }else {
        this.sideInfoBox.open();
      }
    });
    if (index !== undefined) {
      if (index !== 0) {
        const prevMarker = this.sortedList[index - 1];
        const prevId = prevMarker.id;
        const prevType = prevMarker.type;
        this.mapService.getMarker(prevType, prevId).subscribe((data) => {
          const mappedData = MarkerHelper.mapTo(data);
          this.previousMarkerType = mappedData.type;
        });
      }
      if ((index + 1) !== this.sortedList.length) {
        const nextMarker = this.sortedList[index + 1];
        const nextId = nextMarker.id;
        const markerType = nextMarker.type;
        this.mapService.getMarker(markerType, nextId).subscribe((data) => {
          const mappedData = MarkerHelper.mapTo(data);
          this.nextMarkerType = mappedData.type;
        });
      }
    }
  }

  public moveToCurrentPosition() {
    if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(this.setPosition.bind(this));
      }
  }

  public handleCityChange() {
    this.district = null;
    this.getDistricts();
  }

  public handleDistrictChange() {
    this.bank = null;
    this.getBanks();
  }

  public locationSearchClick() {
    switch(this.locationSearchType) {
      case '1':
        this.moveToCurrentPosition();
        break;
      case '2':
        this.getLatLngOfBankId();
        break;
      case '3':
        this.getLatLngOfAddress(this.address);
        break;
      case '4':
        this.getLatLngOfCompanyId();
        break;
      default:
        break;
    }
  }

  ngOnInit() {
    this.selectedSort = this.sortableAttributes[0];
  }

  ngAfterViewInit() {
    this.initMap();
    this.getMarksers();
    this.getCities();
  }

  private setPosition(position) {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    this.map.panTo(new L.LatLng(lat, lng));
  }

  private getCities() {
    this.mapService.getCities().subscribe((data) => {
      this.cityList = data;
    });
  }

  private getDistricts() {
    this.mapService.getDistricts(this.city).subscribe((data) => {
      this.districtList = data;
    });
  }

  private getBanks() {
    this.mapService.getBanks(this.city, this.district).subscribe((data) => {
      this.bankList = data;
    });
  }

  private getLatLngOfAddress(address: string) {
    this.mapService.getLatLngByAddress(address).subscribe((data) => {
      this.map.panTo(new L.LatLng(data.Latitude, data.Longitude));
    });
  }

  private getLatLngOfBankId() {
    if (this.bank) {
      this.mapService.getPositionFromBankId(this.bank).subscribe((data) => {
        this.map.panTo(new L.LatLng(data.Latitude, data.Longitude));
      });
    }
  }

  private getMarksers() {
    const bounds = this.map.getBounds();
    const params: GetMarketingMapDto = {
      'input.screenLimit.MinLatitude': bounds.getSouth(),
      'input.screenLimit.MinLongitude': bounds.getWest(),
      'input.screenLimit.MaxLatitude': bounds.getNorth(),
      'input.screenLimit.MaxLongitude': bounds.getEast(),
    };
    this.mapService.getMarkers(params).subscribe((data) => {
      let markers: MarkerDto[] = data.value.map( (m: GetMarketingMapResponseDto) => {
        return MarkerHelper.mapTo(m);
      });
      // for makeing cluster
      // this.markers = [...markers, ...markers];
      this.markers = markers;
      this.renderMarkers();
    });
  }

  private renderMarkers(markers?: MarkerDto[]) {
    this.markersLayer.clearLayers();
    if (!markers) {
      markers = this.markers;
    }

    markers.forEach((m) => {
      let divIcon = this.mapService.getIconSettings(m.type);
      let divIconClass = L.divIcon({ className: divIcon.className,  html: `<span>${divIcon.shortText}</span>` });

      let marker = L.marker(m.latLng, {icon: divIconClass});
      marker['cust_id'] = m.id;
      marker['cust_name'] = m.name;
      marker['cust_type'] = m.type;
      marker.on('click', (e) => {
        this.currentViewMarkerList = null;
        this.showMarkerInfo(m.type, m.id);
      });
      this.markersLayer.addLayer(marker);
    });
  }

  private getLatLngOfCompanyId() {
    this.mapService.getPositionFromCompanyId(this.companyId).subscribe((data) => {
      this.map.panTo(new L.LatLng(data.Latitude, data.Longitude));
    });
  }

  private resetSearchModel() {
    this.searchModel = {
      types: [],
      createDate: null,
      capitalFrom: null,
      capitalTo: null,
      isDepositAccount: false,
      isSBAccount: false,
      estimateDate: null,
      completeDate: null,
      sizeFrom: null,
      sizeTo: null,
      dealDate: null,
      ageFrom: null,
      ageTo: null,
      transferSizeType: '1',
      transferSizeFrom: null,
      transferSizeTo: null,
    };
  }

  private initMap() {
    this.map =  L.map(this.mapContainer.nativeElement).setView([25.1189569, 121.5420177], 13);
    this.map.on('moveend', () => {
      this.getMarksers();
    });
    // this.map.on('zoomend', () => {
    //   this.getMarksers();
    // });
     let roads: GridLayer = L.gridLayer.googleMutant({
       type: 'roadmap' // valid values are 'roadmap', 'satellite', 'terrain' and 'hybrid'
     });
    // let roads = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    //   attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    // });
    this.map.addLayer(roads);
    this.markersLayer = L.markerClusterGroup({
      spiderLegPolylineOptions: {weight: 0},
      clockHelpingCircleOptions: {weight: .7, opacity: 1, color: 'black', fillOpacity: 0, dashArray: '10 5'},
      elementsPlacementStrategy: 'clock',
      helpingCircles: true,
      spiderfyDistanceSurplus: 25,
      spiderfyDistanceMultiplier: 1,
      elementsMultiplier: 1.4,
      firstCircleElements: 8
    });

    this.markersLayer.on('clusterclick', (event) => {
      let childMakrers = event['layer'].getAllChildMarkers();
      this.currentViewMarkerList = childMakrers.map((m) => {
        return {
          id: m['cust_id'],
          name: m['cust_name'],
          type: m['cust_type'],
        };
      });
      this.infoDialogViewingMode = IInfoDialogViewingMode.LIST;
      this.sideInfoBox.open();
      // this.mapService.getMarkersByIds(ids).subscribe((data) => {
      //   this.currentViewMarkerList = data;
      //   this.infoDialogViewingMode = IInfoDialogViewingMode.LIST;
      //   this.sideInfoBox.open();
      // });
    });

    this.map.addLayer(this.markersLayer);
  }
}

