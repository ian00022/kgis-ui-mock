import { DateHelper } from './../../shared/helper/date-helper';
import { FormGroup, FormControl, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { LoggerService } from '../../shared/logger.service';
import { AddressSelectComponent } from '../../shared/components/address-select/address-select.component';
import { MarketingService } from '../../core/services/marketing.service';
import * as _ from 'lodash';
import { Subject } from 'rxjs';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';


declare var moment: any;

@Component({
  selector: 'esun-valuation',
  templateUrl: './valuation.component.html',
  styleUrls: ['./valuation.component.scss']
})
export class ValuationComponent implements OnInit, OnDestroy {

  @ViewChild('estatePricesTable') estatePricesTable: IbmTableComponent;
  @ViewChild('estatePricesDialog') estatePricesDialog: IbmDialogComponent;
  @ViewChild('address') address: AddressSelectComponent;

  public valuationForm: FormGroup;
  public realEstateTypeOptions = [
    { value: '集合住宅', label: '集合住宅'}, { value: '華廈', label: '華廈'}, { value: '店面', label: '店面'},
    { value: '公寓(有電梯)', label: '公寓(有電梯)'}, { value: '公寓(無電梯)', label: '公寓(無電梯)'}, { value: '辦公室-商業用', label: '辦公室-商業用'},
    { value: '辦公室-工業用', label: '辦公室-工業用'}, { value: '廠房', label: '廠房'}, { value: '透天', label: '透天'},
    { value: '透天(持分式)', label: '透天(持分式)'}, { value: '透店', label: '透店'}, { value: '農舍', label: '農舍'},
    { value: '套房', label: '套房'}, { value: '店面', label: '店面'}, { value: '住辦', label: '住辦'},
    { value: '住店', label: '住店'}, { value: '陽光屋', label: '陽光屋'}, { value: '車位', label: '車位'},
    { value: '乙工宅', label: '乙工宅'}, { value: '土地', label: '土地'}, { value: '置產型', label: '置產型'},
    { value: '其他', label: '其他'}
  ];

  public valuationList: any[] = [];
  public valuationConfig: any = {
    min: '',
    max: '',
    format: 'YYYY/MM/DD'
  };
  public estatePricesData;

  private ngUnSubscribe: Subject<any> = new Subject();
  private default;

  constructor(
    private logger: LoggerService,
    private marketingService: MarketingService,
    private ref: ChangeDetectorRef,
  ) {
    this.valuationConfig.min = moment(moment().subtract(3, 'years'));
    this.valuationConfig.max = moment();

    const defaultStartDate = moment().subtract(1, 'months').format(this.valuationConfig.format);
    const defaultEndDate = moment().format(this.valuationConfig.format);
    const valuationDate = DateHelper.combineDate(defaultStartDate, defaultEndDate);

    this.default = {
      valuationDate: valuationDate,
      buildingItem: 'building',
      creditGrantor: '',
      identityCardNo: '',
      communityName: '',
      realEstateType: ''
    };
  }

  ngOnInit() {
    this.initForm();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get realEstateTypeString(): string {
    if (!this.valuationForm.controls['realEstateType'].value) {
      return '';
    }
    return this.valuationForm.controls['realEstateType'].value.join('、');
  }

  get generateFormData() {
    const config = {
      buildingLocationRegion: this.address.getStringAddress()
    };

    if (this.valuationForm.value['valuationDate']) {
      let date = DateHelper.divideDate(this.valuationForm.value['valuationDate']);
      config['ValuationStrDate'] = date.startTime;
      config['ValuationEndDate'] = date.endTime;
    }

    for (const key in this.valuationForm.value) {
      if (this.valuationForm.value.hasOwnProperty(key) && key !== 'valuationDate') {
        config[key] = this.valuationForm.value[key];
      }
    }

    return config;
  }

  public onSearchClick() {
    const config = this.generateFormData;

    this.logger.debug(config);

    this.estatePricesTable.searchParams = config;
    this.estatePricesTable.url = 'MarketingEstate';
    this.estatePricesTable.getData();
    // this.marketingService
    //   .getValuationList(config)
    //   .subscribe( resp => {
    //     this.valuationList = resp.value;
    //   });
  }

  public onClearClick() {
    this.resetForm();
  }

  public getAddressLink() {
    return ['/marketing', 'map'];
  }

  public getAddressParams(data) {
    return { address: data.address};
  }

  public checkRealEstatePrices(row) {
    this.estatePricesData = row;
    this.ref.detectChanges();
    this.estatePricesDialog.open();
  }

  private initForm() {
    this.valuationForm = new FormGroup({
      valuationDate: new FormControl(this.default.valuationDate, Validators.required),
      buildingItem:  new FormControl(this.default.buildingItem),
      creditGrantor: new FormControl(this.default.creditGrantor),
      identityCardNo: new FormControl(this.default.identityCardNo, this.circiKeyValidator),
      communityName: new FormControl(this.default.communityName),
      realEstateType: new FormControl(this.default.realEstateType),
    });
  }

  private resetForm() {
    for (const key of Object.keys(this.valuationForm.controls)) {
      this.valuationForm.controls[key].setValue(this.default[key]);
    }
  }

  private circiKeyValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
    if (control.value) {
      console.log(this.valuationForm);
      let isCompID = /^[0-9]{8}$/.test(control.value);
      if (!isCompID) {
        return {
          circiKey: true
        };
      } else { return null; }
    } else { return null; }
  }
}
