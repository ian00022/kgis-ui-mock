import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RealEstatePricesDialogComponent } from './real-estate-prices-dialog.component';

describe('RealEstatePricesDialogComponent', () => {
  let component: RealEstatePricesDialogComponent;
  let fixture: ComponentFixture<RealEstatePricesDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RealEstatePricesDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RealEstatePricesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
