import { Component, OnInit, ViewChild, Input, Output } from '@angular/core';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { LoggerService } from 'app/shared/logger.service';
import * as _ from 'lodash';
import { MarketingService } from 'app/core/services/marketing.service';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';import { Permissions } from 'app/core/models/permissions';
// Dynamic Form
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import {
  ControlBase,
  TextControl,
  MultiSelectControl,
  DatepickerControl,
  SingleDropdownControl
} from 'app/shared/components/dynamic-form/controls';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { DateHelper } from 'app/shared/helper/date-helper';

@Component({
  selector: 'esun-real-estate-prices-dialog',
  templateUrl: './real-estate-prices-dialog.component.html',
  styleUrls: ['./real-estate-prices-dialog.component.scss']
})
export class RealEstatePricesDialogComponent implements OnInit {

  @ViewChild('estateTable') estateTable: IbmTableComponent;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @Input() estatePricesData: any;
  @Input() estateFormData: any;

  public estateList = [];
  public controls = [];
  public BuildingTypeOptions = [];

  constructor(
    private logger: LoggerService,
    private options: SelectOptionsService,
  ) {
    this.BuildingTypeOptions = this.options.getOptions('buildingType');
  }

  ngOnInit() {
    this.prepareControls();
  }

  public open() {
    if (this.estatePricesData && this.estateFormData) {
      this.logger.debug('open estatePricesData: ', this.estatePricesData);
      this.logger.debug('open estateFormData: ', this.estateFormData);
    }
    this.estateList = [];
    this.estateTable.clearData();
    this.dialog.open();
  }

  public close() {
    this.dialog.close();
  }

  public getEstateData(config) {

    this.logger.debug(config);

    this.estateTable.searchParams = config;
    this.estateTable.url = 'MarketingEstate/Transaction';
    this.estateTable.getData();
    // this.mktService
    //   .getEstatePrices(this.generateInputs)
    //   .subscribe(res => {
    //     this.logger.debug('getEstatePrices: ', res);
    //     if (res.isOk) {
    //       this.estateList = res.value;
    //     }
    //   });
  }

  public handleSubmit(formInputs) {
    this.logger.debug(formInputs);
    this.getEstateData({
      SoldDateInterval: DateHelper.divideDate(formInputs.SoldDateInterval),
      Meters: formInputs.Meters,
      BuildingType: formInputs.BuildingType
    });
  }

  public generateInputs(config) {
    return {
      Longitude: this.estatePricesData.Longitude,
      Latitude: this.estatePricesData.Latitude,
      ...config,
    };
  }

  public getAddressLink() {
    return ['/marketing', 'map'];
  }

  public getAddressParams(data) {
    return { address: (data || { address: '' }).address };
  }

  private prepareControls() {
    this.controls = [
      new DatepickerControl({
        key: 'SoldDateInterval',
        label: '交易起訖日',
        required: false,
        singleDatePicker: false,
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'Meters',
        label: '方圓半徑(公尺)',
        columnClasses: ['12', 'md-4', 'lg-3'],
        type: 'number',
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'BuildingType',
        label: '型態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.BuildingTypeOptions,
        placeholder: '請輸入...'
      }),

    ];
  }

}
