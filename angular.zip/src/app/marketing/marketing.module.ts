import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { MapComponent } from './map/map.component';
import { ValuationComponent } from './valuation/valuation.component';
import { LoanTrialComponent } from './loan-trial/loan-trial.component';
import { EdmComponent } from './edm/edm.component';
import { RealEstatePricesDialogComponent } from './valuation/real-estate-prices-dialog/real-estate-prices-dialog.component';
import { MapService } from './map/map.service';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { Permissions } from './../core/models/permissions';

@NgModule({
  imports: [
    SharedModule,
    FormsModule,
    RouterModule.forChild([
      {
        path: 'map',
        component: MapComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '行銷地圖',
          permissions: {
            only: [ Permissions.MAP_SEARCH ],
            redirectTo: '/no-auth'
          }
        }
      },
      {
        path: 'valuation',
        component: ValuationComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '估價查詢',
          permissions: {
            only: [ Permissions.REAL_ESTATE_TRANSACTION_SEARCH ],
            redirectTo: '/no-auth'
          }
        }
      },
      {
        path: 'loan-trial',
        component: LoanTrialComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '貸款試算',
          permissions: {
            only: [ Permissions.LOAN_CALCULATE_SEARCH ],
            redirectTo: '/no-auth'
          }
        }
      },
      {
        path: 'edm',
        component: EdmComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '電子 DM',
          permissions: {
            only: [ Permissions.EDM_SEARCH ],
            redirectTo: '/no-auth'
          }
        }
      },
      { path: '', redirectTo: 'map', pathMatch: 'full' },
    ]),
  ],
  providers: [MapService],
  declarations: [
    MapComponent,
    ValuationComponent,
    LoanTrialComponent,
    EdmComponent,
    RealEstatePricesDialogComponent
]
})
export class MarketingModule { }
