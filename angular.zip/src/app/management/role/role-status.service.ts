import { BaseCodeHelper } from 'app/core/models/base-enum-code';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { StatusColumnData, UserRoleStatusEnum } from './role.models';

@Injectable()
export class UserRoleStatusService extends BaseCodeHelper<number>{
    constructor() {
        const codeLabelMap = {
            '0': '停用' ,
            '1': '啟用' ,
            '2': '暫存' ,
            '3': '待覆核' ,
            '4': '主管退回'
        };
        super(codeLabelMap);
    }

    
    public mapTagClass(res: any): string {
        const code = this.mapStatusCode(res);
        if (code === UserRoleStatusEnum.TEMP_REJECT || code === UserRoleStatusEnum.ENABLED) {
            return 'blue';
        } else if (code === UserRoleStatusEnum.DISABLED || code === UserRoleStatusEnum.TEMP_REVIEWING) {
            return 'red';
        } else {
            return 'orange';
        }
    }


    public mapStatusDatas(toMap: any): StatusColumnData {
        return {
            text: this.mapStatus(toMap)
        };
    }

    public mapStatus(res: any): string {
        return this.mapTo(this.mapStatusCode(res));
    }

    public mapStatusCode(res: any): string {
        const duoStatus = parseInt(_.result(res, `DuoStatus`, '-1'), 10);
        const status = parseInt(_.result(res, `Status`, '-1'), 10);

        let returnStatus;
        if ( this.statusLarger(duoStatus, status) ) {
            returnStatus = duoStatus;
        } else {
            returnStatus = status;
        }
        return returnStatus + '';
    }

    // 3 > 4 > 2 > (1 or 0)
    private statusLarger(a: number, b: number) {
        // @todo
        // How to compare same value?
        if ( a === b ) {
            return true;
        } else {
            return this.convertStatusNumberForComparing(a) > this.convertStatusNumberForComparing(b);
        }
    }

    private convertStatusNumberForComparing(status: number): number {
        if ( status === 3 ) {
            return 50;
        } else if ( status === 4 ) {
            return 40; // smaller than 50
        } else {
            return status;
        }
    }

}