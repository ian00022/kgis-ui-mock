export interface UserRoleResponseDto {
    DuoStatus: string;
    Duo_oData: UserRoleInfoDto[];
    Duo_sData?: UserRoleInfoDto[];
    oData: UserRoleDto;
    sData?: UserRoleDto;
    Status: string;
}

export interface UserRoleDto {
    ActiveCode: string;
    ApplyEmpId: string;
    CreateDate: string;
    CreateEmpId: string;
    EmpId: string;
    JobTitle: string;
    ModifyStatus: string;
    ModifyUUID: string;
    Name: string;
    RejectReason: string;
    SearchStatus: string;
    UUID: string;
    UnitId: string;
    UnitName: string;
    UpdateDate: string;
    UpdateEmpId: string;
    UserAuthType: string;
    VerifyEmpId: string;
    Version: number;
}

export interface UserRoleSearchRequestDto {
    RoleIds: String[];
    Status: String[];
    ID: String;
    Name: String;
    JobTitle: String;
    UnitCode: String;
    OrderCol: String;
}

export interface UserRoleSearchFormDto {
    systemRoles: String[];
    status: String[];
    employeeName: String;
    employeeId: String;
    jobTitle: String;
    deptId: String;
}

export interface UserRoleTableRowDto {
    name?: string;
    duoData?: any[];
    employeeId?: String;
    jobTitle?: String;
    deptId?: String;
    systemRoles?: String;
    lastUpdateDate?: String;
    status: string;
    statusCode: string;
    roles: string;
    uuid: string;
    tagClass?: string;
    statusData?: StatusColumnData;
    canDisplayMenuDropdown?: boolean;
    rowColorClass?: string;
}

export interface UserRoleInfoDto {
    /// UserRoleSettingDetail UUID
    UUID: string;
    /// UserRoleSetting UUID
    UserRoleSettingUUID: string;
    /// 員工編號
    EmpId: string;
    /// Role ID
    RoleId: string;
    /// 角色名稱
    SystemRoleName: string;
    /// 資料權限類別
    UseType: string;
    /// 變更狀態
    ModifyStatus: string;
    /// 激活狀態代碼
    ActiveCode: string;
    /// 變更申請人
    ApplyEmpId: string;
    /// 審核主管
    VerifyEmpId: string;
    /// 退回原因
    RejectReason: string;
}

export enum UserRoleStatusEnum {
    DISABLED = '0', // 0 : 停用
    ENABLED = '1', // 1 : 啟用
    TEMP = '2', // 2 : 暫存
    TEMP_REVIEWING = '3', // 3 : 暫存 - 待覆核
    TEMP_REJECT = '4' // 4 : 暫存 - 主管退回
}

export class UserRoleStatusHelper {
    public static UserStatusLabelMap = {
        '0': '停用' ,
        '1': '啟用' ,
        '2': '暫存' ,
        '3': '待覆核' ,
        '4': '主管退回'
    };

    public static Code = UserRoleStatusEnum;
    public static mapTo(key: UserRoleStatusEnum): string {
        return this.UserStatusLabelMap[key];
    }
}

export class UserRoleSearchFormHelper {
    public static mapTo(toMap: UserRoleSearchFormDto): UserRoleSearchRequestDto {
        return {
            RoleIds: toMap.systemRoles,
            Status: toMap.status,
            Name: toMap.employeeName,
            ID: toMap.employeeId,
            JobTitle: toMap.jobTitle,
            UnitCode: toMap.deptId,
            OrderCol: ''
        };
    }
}

export class UserRoleSearchRequestHelper {
    public static mapTo(toMap: UserRoleSearchRequestDto): UserRoleSearchFormDto {
        return {
            systemRoles: toMap.RoleIds,
            status: toMap.Status,
            employeeName: toMap.Name,
            employeeId: toMap.ID,
            jobTitle: toMap.JobTitle,
            deptId: toMap.UnitCode
        };
    }
}

export interface RolesSearchResponseDto {
    DuoStatus: any;
    Duo_oData: any;
    Duo_sData: any;
    Status: string;
    oData: RolesInfoDto;
    sData: RolesInfoDto;
}

export interface RolesInfoDto {
    Version: number;
    UUID: string;
    RoleId: string;
    SystemRoleName: string;
    SystemRoleDesc: string;
    UseType: string;
    ActiveCode: string;
    IsSystemGen: string;
    ApplyEmpId: string;
    VerifyEmpId: string;
    ModifyUUID: string;
    ModifyStatus: string;
    RejectReason: string;
    CreateEmpId: string;
    CreateDate: string;
    UpdateEmpId: string;
    UpdateDate: string;
}

export interface RoleRequestDto {
    RoleId?: string;
    SystemRoleName?: string;
    SystemRoleDesc?: string;
    UseType?: string;
    ActiveCode?: string;
    ModifyStatus?: string;
    ProgramCode?: string[];
    LoginUser?: any;
}

export interface RoleRequestFormDto {
    roleId: string;
    roleName: string;
    roleDescription: string;
    roleUseType: string;
    rolePermission: string[];
    statusData?: any;
    modelChange?: any;
}

export class RoleRequestHelper {
    public static mapTo(toMap: RoleRequestFormDto, loginUser: any): RoleRequestDto {
        return {
            RoleId: toMap.roleId,
            SystemRoleName: toMap.roleName,
            SystemRoleDesc: toMap.roleDescription,
            UseType: toMap.roleUseType,
            ActiveCode: '1',
            LoginUser: loginUser,
            ProgramCode: toMap.rolePermission
        };
    }
}

export interface RoleTableRowDto {
    roleId: string;
    roleName: string;
    roleDescription: string;
    creatorName: string;
    createDate: string;
    status: string;
    tagClass?: string;
    uuid: string;
    statusCode?: any;
    statusData: StatusColumnData;
}

export interface StatusColumnData {
    text: string;
}

export interface UsersFormData {    
    roleSetting: string[];
}