import { UsersFormData } from './../role.models';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { UserRoleStatusService } from 'app/management/role/role-status.service';
import { RolesSearchResponseDto } from '../role.models';

@Injectable()
export class UsersMappingService {
    constructor(
        private userRoleStatusService: UserRoleStatusService,
        private statusService: UserRoleStatusService,
    ){}

    public mapToFormData(toMap: RolesSearchResponseDto): UsersFormData {
        return {
            roleSetting: []
        };
    }
}