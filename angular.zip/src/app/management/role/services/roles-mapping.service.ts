import { UserRoleResponseDto, UserRoleStatusEnum, RoleTableRowDto, StatusColumnData, RoleRequestFormDto } from './../role.models';
import { Injectable } from '@angular/core';
import { DateHelper } from 'app/shared/helper/date-helper';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';
import { UserRoleStatusService } from 'app/management/role/role-status.service';
import { RolesSearchResponseDto } from '../role.models';
import { ISelectOptionModel } from 'app/core/models/comm-data';

@Injectable()
export class RolesMappingService {
    constructor(
        private userRoleStatusService: UserRoleStatusService,
        private statusService: UserRoleStatusService,
    ){}

    public mapToFormData(toMap: RolesSearchResponseDto): RoleRequestFormDto {
        return {
            roleId: this.osData('RoleId', toMap),
            roleName: this.osData('SystemRoleName', toMap),
            roleDescription: this.osData('SystemRoleDesc', toMap),
            roleUseType: this.osData('UseType', toMap),
            rolePermission: this.mapPermissions(toMap),
            modelChange: this.mapModelChange(toMap),
        };
    }

    public mapDuoData(res: any): any {
        if (!res.Duo_sData || res.Duo_sData.length === 0) {
            return res.Duo_oData;
        }
        return res.Duo_sData;
    }

    public mapTo(toMap: RolesSearchResponseDto): RoleTableRowDto {
        return {
            roleId: this.osData('RoleId', toMap),
            roleName: this.osData('SystemRoleName', toMap),
            roleDescription: this.osData('SystemRoleDesc', toMap),
            creatorName: this.osData('CreateEmpId', toMap),
            createDate: DateHelper.formatDate(this.osData('CreateDate', toMap)),
            status: this.statusService.mapStatus(toMap),
            statusCode: this.statusService.mapStatusCode(toMap),
            uuid: this.osData('UUID', toMap),
            tagClass: this.statusService.mapTagClass(toMap),
            statusData: this.statusService.mapStatusDatas(toMap),
        };
    }

    public makeChangeBeforeAfter(key: string, res: any): any {
        const sData = this.getSData(key, res);
        const oData = this.getOData(key, res);
        if (sData === null) {
            return null;
        }
        return {
            valueBefore: oData,
            valueAfter: sData,
        };
    }

    public mapModelChange(toMap: RolesSearchResponseDto): any {
        let rs = {};
        rs['RoleId'] = this.makeChangeBeforeAfter('RoleId', toMap);
        rs['SystemRoleName'] = this.makeChangeBeforeAfter('SystemRoleName', toMap);
        rs['SystemRoleDesc'] = this.makeChangeBeforeAfter('SystemRoleDesc', toMap);
        return rs;
    }

    public mapPermissions(toMap: RolesSearchResponseDto): string[] {
        if (toMap.Duo_sData.length > 0) {
            return toMap.Duo_sData.map(data => data.PermissionCode);
        } else {
            return toMap.Duo_oData.map(data => data.PermissionCode);
        }
    }

    public mapToOptions(toMap: RolesSearchResponseDto): ISelectOptionModel {
        return {
            value: this.osData('RoleId', toMap),
            label: this.osData('SystemRoleName', toMap),
        };
    }


    // Table User資訊需從回傳的DuoSysData資料結構裡的oData,sData資訊做呈現，
    // 如果sData裡的欄位 =/= oData裡的欄位 優先show sData欄位
    private osData(key: string, res: RolesSearchResponseDto) {
        const sData = this.getSData(key, res);
        const oData = this.getOData(key, res);
        if ( sData !== null && sData !== oData) {
            return sData;
        }
        return oData;
    }

    private getOData(key: string, res: RolesSearchResponseDto) {
        return _.result(res, `oData.${key}`, null);
    }

    private getSData(key: string, res: RolesSearchResponseDto) {
        return _.result(res, `sData.${key}`, null);
    }
}