import { Component, OnInit, Input } from '@angular/core';
import { StatusColumnData } from 'app/management/role/role.models';

@Component({
  selector: 'esb-mars-status-cell',
  templateUrl: './status-cell.component.html',
  styleUrls: ['./status-cell.component.scss']
})
export class StatusCellComponent implements OnInit {
  @Input() data: StatusColumnData;

  constructor() { }

  ngOnInit() {
  }

}
