import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
// tab
import { IbmTabsComponent } from 'app/shared/components/ibm-tabs/ibm-tabs.component';
import { NgxPermissionsService } from 'ngx-permissions';
import { Permissions } from 'app/core/models/permissions';
// Dynamic Form
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import {
  ControlBase,
  TextControl,
  MultiSelectControl
} from 'app/shared/components/dynamic-form/controls';

// cust data table
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';

// dialog
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';

import * as _ from 'lodash';
import { RoleService } from './role.service';
import { UserRoleTableRowDto } from './role.models';
import { UserRoleStatusService } from './role-status.service';
import { ISelectOptionModel } from '../../core/models/comm-data';

@Component({
  selector: 'esun-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss'],
  providers: []
})
export class RoleComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('tabs') tabs: IbmTabsComponent;
  @ViewChild('employeeCaseForm') employeeCaseForm: DynamicFormComponent;
  @ViewChild('employeeCaseTable') normalCaseTable: IbmTableComponent;
  @ViewChild('employeeManagement') employeeManagementDialog: IbmDialogComponent;
  @ViewChild('roleManagement') roleManagementDialog: IbmDialogComponent;

  public preQueryParams: any = {};

  public tabTitle = {
    userManagement: '人員管理',
    roleManagement: '系統角色設定'
  };
  public isFirstLoad = {
    employeeManagement: true,
    roleManagement: true
  };
  public currentTab = this.tabTitle.userManagement;

  public Permissions = Permissions;

  public sysRoles: ISelectOptionModel[] = [];
  public sysStatus = [];

  public employeeCaseControls: ControlBase<any>[] = [];
  public employeeTableData: Array<any> = [];
  public isHeadOfficeCaseAnySelected = false;
  public recordID: string;

  // role management
  public roleTableData: Array<any> = [];
  public isRoleHeadOfficeCaseAnySelected = false;

  // 排序
  public orderTypes = [
    { label: '修改日期', value: 'updateDate' }
  ];
  public orderType: any = this.orderTypes[0];
  public roleOrderTypes = [
    { label: '建立日期', value: 'createDate' }
  ];
  public roleOrderType: any = this.roleOrderTypes[0];

  constructor(
    private roleService: RoleService,
    private userRoleStatusService: UserRoleStatusService,
    private cdr: ChangeDetectorRef,
    private permissionsService: NgxPermissionsService,
    private route: ActivatedRoute) { 
      this.sysStatus = this.userRoleStatusService.getAllOptions();
    }

  // dynamic form inputs
  prepareControls() {
    this.employeeCaseControls = [
      new MultiSelectControl({
        key: 'systemRoles', //
        label: '系統角色',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.sysRoles,
        value: this.preQueryParams.source || '',
        placeholder: '請選擇...'
      }),
      new MultiSelectControl({
        key: 'status', //
        label: '狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.sysStatus,
        value: this.preQueryParams.source || '',
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'employeeName',
        label: '員工姓名',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. 王大明'
      }),
      new TextControl({
        key: 'employeeId',
        label: '員工編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. 131313'
      }),
      new TextControl({
        key: 'jobTitle',
        label: '職稱',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. 副理'
      }),
      new TextControl({
        key: 'deptId',
        label: '部門代號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. C131313'
      }),
    ];
  }

  /**
   * for getting options from BE
   *
   * @memberof RoleComponent
   */
  public prepareOptions(): void {
    this.roleService.searchSystemRolesOptions()
      .subscribe(data => {
        this.employeeCaseControls.forEach(control => {
          if  (control.key === 'systemRoles') {
            control['options'] = data;
          }
        });
        this.employeeCaseControls = [...this.employeeCaseControls];
        this.sysRoles.splice(0, this.sysRoles.length);
        data.forEach(o => {
          this.sysRoles.push(o);
        });
      });
  }

  ngOnInit() {
    this.prepareControls();
    this.prepareOptions();
    this.changePermission(null);
  }

  ngAfterViewInit() {}

  ngOnDestroy() {}

  tabChanges(events) {
    if (!events || !events.tab) {
      return;
    }
    const tab = events.tab;
    this.currentTab = tab.tabTitle;
    switch (tab.tabTitle) {
      case this.tabTitle.userManagement:
        if (this.isFirstLoad.employeeManagement) {
          this.getQueryParams();
          this.isFirstLoad.employeeManagement = false;
        }
        break;
      case this.tabTitle.roleManagement:
        // 系統角色設定
        if (this.isFirstLoad.roleManagement) {
          this.roleTableCase();
          this.isFirstLoad.roleManagement = false;
        }
        break;
      default:
        break;
    }
  }

  getQueryParams() {
    this.route.queryParams
    .subscribe(
      (params) => {
        if (params && this.employeeCaseForm) {
          this.preQueryParams = params;
          this.employeeCaseForm.patchValue(this.preQueryParams);
          // 人員管理
          this.employeeCaseForm.submit();
        }
      });
  }

  strList(keyValueArr) {
    return keyValueArr.map(r => r.label).join('，');
  }
  handleCheckboxClick(scope, key) {
    switch (key) {
      case 'employeeOfficeCase':
        scope.checked = !scope.checked;
        this.isHeadOfficeCaseAnySelected = this.employeeTableData.filter(p => p.checked).length > 0;
        break;
      case 'roleOfficeCase':
        scope.checked = !scope.checked;
        this.isRoleHeadOfficeCaseAnySelected = this.roleTableData.filter(p => p.checked).length > 0;
        break;
      default:
        break;
    }
  }
  handleSelectAllCheckboxClick(key) {
    this.isHeadOfficeCaseAnySelected = !this.isHeadOfficeCaseAnySelected;
    this.isRoleHeadOfficeCaseAnySelected = !this.isRoleHeadOfficeCaseAnySelected;
    switch (key) {
      case 'employeeOfficeCase':
        this.employeeTableData = this.employeeTableData.map(data => {
          data.checked = data.status.value === 'waiting' ? this.isHeadOfficeCaseAnySelected : false;
          return data;
        });
        break;
      case 'roleOfficeCase':
        this.roleTableData = this.roleTableData.map(data => {
          data.checked = data.status.value === 'waiting' ? this.isRoleHeadOfficeCaseAnySelected : false;
          return data;
        });
        break;
      default:
        break;
    }
  }
  handleUserRolesFormSubmit(event) {
    this.roleService.searchUsers(event).subscribe((data: UserRoleTableRowDto[]) => {
      this.employeeTableData = data;
    });
  }

  roleTableCase() {
    this.roleService.getSystemRolesTableData().subscribe(data => {
      this.roleTableData = data;
    });
  }
  rowClassNameFunction(row, index) {
    if (row.status) {
      if (row.status.value === 'inactive') {
        return 'table-light';
      }
      if (row.status.value === 'waiting') {
        return 'markRed';
      }
    }
  }

  openModal(type: string, row: any, mode: string) {
    switch (type) {
      case 'employeeManagementDialog':
        this.recordID = row.employeeId;
        this.employeeManagementDialog.open();
        break;
      case 'roleManagementDialog':
        this.recordID = row !== null ? row.roleId : null;
        this.roleManagementDialog.open();
        break;
      default:
        break;
    }
  }

  handleEmpManagementDialogConfirm() {
    this.employeeCaseForm.submit();
  }

  handleManagementDialogConfirm() {
    this.roleTableCase();
  }

  get isSearchValid(): boolean {
    return this.employeeCaseForm.form.valid;
  }

  public chooseOrderType(type: string, selectedMenu: any) {
    switch (type) {
      case 'user':
        this.orderType = selectedMenu;
        break;
      case 'role':
        this.roleOrderType = selectedMenu;
        break;
      default:
        break;
    }
    if (!this.isSearchValid) {
    }
  }

  changePermission(event) {
    const permissions = this.permissionsService.getPermissions();
    const hadReview = _.has(permissions, Permissions.USER_ROLE_APPROVE_UPDATE);

    if (hadReview) {
      this.permissionsService.addPermission(Permissions.USER_ROLE_UPDATE);
      this.permissionsService.addPermission(Permissions.ROLE_UPDATE);
      this.permissionsService.addPermission(Permissions.ROLE_ADD);
      this.permissionsService.removePermission(Permissions.USER_ROLE_APPROVE_UPDATE);
    } else {
      this.permissionsService.addPermission(Permissions.USER_ROLE_APPROVE_UPDATE);
      this.permissionsService.removePermission(Permissions.USER_ROLE_UPDATE);
      this.permissionsService.removePermission(Permissions.ROLE_UPDATE);
      this.permissionsService.removePermission(Permissions.ROLE_ADD);
    }
  }
}
