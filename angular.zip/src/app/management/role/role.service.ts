import { Injectable } from '@angular/core';
import { RolesMappingService } from './services/roles-mapping.service';
import { UserRoleSearchFormDto, UserRoleTableRowDto, UserRoleSearchFormHelper, RolesSearchResponseDto, RoleRequestFormDto, RoleRequestHelper } from './role.models';
import { DateHelper } from 'app/shared/helper/date-helper';
import { Status } from './../system-settings/system-settings.model';
import { ApiService, AuthService } from 'app/core/services';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';
import { Observable } from 'rxjs';
import { BaseCodeHelper } from 'app/core/models/base-enum-code';
import { Builder } from 'protractor';
import { UserRoleResponseService } from './user-role-response.service';
import { ISelectOptionModel } from '../../core/models/comm-data';
import { result } from 'lodash';

const ROLE_WFOBJECTNAME = 'Role';
const USER_WFOBJECTNAME = 'User';

@Injectable()
export class RoleService {
    constructor(
        private api: ApiService,
        private auth: AuthService,
        private rolesMappingService: RolesMappingService,
        private userRoleResponseService: UserRoleResponseService
    ) {}

    searchUsers(param: UserRoleSearchFormDto): Observable<UserRoleTableRowDto[]> {
        const requestParams = UserRoleSearchFormHelper.mapTo(param);
        return this.api.post('User/Search', requestParams).pipe(map(data => {
            if (data.value) {
                return data.value.map(row => {
                    return this.userRoleResponseService.mapTo(row);
                });
            }
        }));
    }

    searchSystemRoles(): Observable<RolesSearchResponseDto[]> {
        return this.api.post('Role/Search', {}).pipe(map(data => {
            if (data.value) {
                return data.value;
            }
        }));
    }

    getSystemRolesTableData(): Observable<any[]> {
        return this.searchSystemRoles()
            .pipe(map(data => {
                if (data) {
                    return data.map(row => {
                        return this.rolesMappingService.mapTo(row);
                    });
                }
            }));
    }

    searchSystemRolesOptions(): Observable<ISelectOptionModel[]> {
        return this.searchSystemRoles()
            .pipe(map(data => {
                if (data) {
                    return data.map(row => {
                        return this.rolesMappingService.mapToOptions(row);
                    });
                }
            }));
    }

    updateRoleDetails(formData: RoleRequestFormDto): Observable<any> {
        const requestParams = RoleRequestHelper.mapTo(formData, this.auth.getLoginUser);
        return this.api.patch(`Role/${formData.roleId}`, requestParams)
            .pipe(map(data => {
                if (data.value) {
                    return data.value;
                }
            }));
    }

    getRoleDetails(roleId: string): Observable<any> {
        return this.api.get(`Role/${roleId}`)
            .pipe(map(data => {
                if (data) {
                    const v = data.value as RolesSearchResponseDto;
                    return {
                        formData: this.rolesMappingService.mapToFormData(v),
                        roleDetails: this.rolesMappingService.mapTo(v)
                    };
                }
            }));
    }

    getPermissionsOptions(): Observable<ISelectOptionModel[]> {
        // @todo temp way to get permissions
        return this.api.get('Permission/list', {}, true).pipe(map(data => {
            function mapTree(originalTree) {
                return originalTree.map(({ Children, ...node }) => ({
                    text: result(node, 'Data.Description', ''),
                    value: result(node, 'ID', ''),
                    children: mapTree(Children)
                }));
            }

            if (data.value) {
                return mapTree(data.value);
            }
        }));
    }

    addNewRole(formData: RoleRequestFormDto): Observable<any> {
        const requestParams = RoleRequestHelper.mapTo(formData, this.auth.getLoginUser);
        return this.api.post('Role', requestParams).pipe(map(data => {
            if (data.value) {
                return data.value;
            }
        }));
    }

    getUserDetails(empId: string): Observable<any> {
        return this.api.get(`User/${empId}`)
            .pipe(map(data => {
                if (data.value) {
                    return this.userRoleResponseService.mapTo(data.value);
                }
            }));
    }

    tempSaveUser(empId: string, formData): Observable<any> {
        return this.api.patch(`User/${empId}/Role`, {
                roleIds: formData.roleSetting
            }).pipe(map(data => {
                    return data;
            }));
    }

    submitRole(params) {
        params = Object.assign(params, {
            WFObjectName: ROLE_WFOBJECTNAME
        });
        return this.api.post(`Role/wf/submit`, params)
            .pipe(map(data => {
                return data;
            }));
    }

    submitUser(params) {
        params = Object.assign(params, {
            WFObjectName: USER_WFOBJECTNAME
        });
        return this.api.post(`User/wf/submit`, params)
            .pipe(map(data => {
                return data;
            }));
    }
}
