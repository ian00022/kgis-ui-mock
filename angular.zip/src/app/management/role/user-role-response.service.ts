import { Injectable } from '@angular/core';
import { UserRoleResponseDto, UserRoleTableRowDto, UserRoleStatusEnum } from './role.models';
import { DateHelper } from 'app/shared/helper/date-helper';
import { map } from 'rxjs/operators';
import { UserRoleStatusService } from './role-status.service';
import * as _ from 'lodash';

@Injectable()
export class UserRoleResponseService {
    constructor(
        private statusService: UserRoleStatusService
    ){}

    public mapTo(toMap: UserRoleResponseDto): UserRoleTableRowDto {
        return {
            name: this.osData('Name', toMap),
            employeeId: this.osData('EmpId', toMap),
            jobTitle: this.osData('JobTitle', toMap),
            systemRoles: '', //@todo
            lastUpdateDate: DateHelper.formatDate(this.osData('UpdateDate', toMap)),
            duoData: this.mapDuoData(toMap),
            status: this.statusService.mapStatus(toMap),
            uuid: this.osData('UUID', toMap),
            tagClass: this.statusService.mapTagClass(toMap),
            statusCode: this.statusService.mapStatusCode(toMap),
            statusData: this.statusService.mapStatusDatas(toMap),
            roles: this.mapRoles(toMap),
            canDisplayMenuDropdown: this.canDisplayMenuDropdown(toMap)
        };
    }

    private mapDuoData(res: UserRoleResponseDto): any {
        if (!res.Duo_sData || res.Duo_sData.length === 0) {
            return res.Duo_oData;
        }
        return res.Duo_sData;
    }

    private canDisplayMenuDropdown(res: UserRoleResponseDto): boolean {
        const status = this.statusService.mapStatusCode(res);
        return _.includes([
            UserRoleStatusEnum.TEMP,
            UserRoleStatusEnum.TEMP_REJECT,
            UserRoleStatusEnum.TEMP_REVIEWING
        ], status);
    }

    // Table User資訊需從回傳的DuoSysData資料結構裡的oData,sData資訊做呈現，
    // 如果sData裡的欄位 =/= oData裡的欄位 優先show sData欄位
    private osData(key: string, res: UserRoleResponseDto) {
        const sData = _.result(res, `sData.${key}`, null);
        const oData = _.result(res, `oData.${key}`, null);
        if ( sData !== null && sData !== oData) {
            return sData;
        }
        return oData;
    }

    private mapRoles(res: UserRoleResponseDto): string {
        let outputRoles = [];
        if (res.Duo_sData) {
            outputRoles = res.Duo_oData.map((data) => data.SystemRoleName);
        }
        if (res.Duo_oData) {
            outputRoles = res.Duo_sData.map((data) => data.SystemRoleName);
        }
        return [...outputRoles].join(', ');
    }

}