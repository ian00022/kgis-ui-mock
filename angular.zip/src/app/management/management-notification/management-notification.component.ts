
import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ValidatorFn, FormGroup } from '@angular/forms';
import { ControlBase, MultiSelectControl, TextControl, DatepickerControl } from '../../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { ManagementHelper } from '../management-helper';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
import { CheckBoxTableHelper } from 'app/shared/helper/table-checkbox-helper';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import * as _ from 'lodash';
import * as moment from 'moment';
import { LoggerService } from '../../shared/logger.service';
import { Permissions } from 'app/core/models/permissions';
import { ManagementService } from '../../core/services/management.service';
import { ManagementWFStatusHelper, ManagementWFType, ManagementWFStatus } from '../management.model';
import { NgxPermissionsService } from 'ngx-permissions';
import { Subject } from 'rxjs';

@Component({
  selector: 'esun-management-notification',
  templateUrl: './management-notification.component.html',
  styleUrls: ['./management-notification.component.scss']
})
export class ManagementNotificationComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('searchForm') searchForm: DynamicFormComponent;
  @ViewChild('notificationTable') notificationTable: IbmTableComponent;
  @ViewChild('view') viewDialog: IbmDialogComponent;
  @ViewChild('notification') notificationDialog: IbmDialogComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;

  public searchControls: ControlBase<any>[] = [];
  public orderTypes = [
    { label: '建立日期', value: 'createDate' },
    { label: '發布日期', value: 'publishDate' }
  ];
  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public notificationList: any[] = [];
  public WFType: ManagementWFType = ManagementWFType.NOTIFICATION;

  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public reviewPermission: boolean = false;
  public notificationRow: any = {};
  public reviewList: any[] = [];

  // public fakePermissions = {
  //   manager: ['REVIEW_NOTIFICATION'],
  //   employee: ['CREATE_NOTIFICATION']
  // };
  public notificationDialogType = 'create';
  public disableNotificationDialog = false;

  public Permissions = Permissions;
  private orderType: any = this.orderTypes[0];
  private ngUnSubscribe: Subject<any> = new Subject();
  private dateFormatter = 'YYYY/MM/DD';
  private statusOptions;

  constructor(
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.statusOptions = ManagementWFStatusHelper.getAllOptions();
    this.prepareControls();
    // will move when realworld
    this.permissionService.addPermission([
      Permissions.NOTIFICATION_ADD,
      Permissions.NOTIFICATION_SEARCH,
      Permissions.NOTIFICATION_FIND,
      Permissions.NOTIFICATION_UPDATE
    ]);
    //
    this.checkPermission();
  }

  ngAfterViewInit() {
    this.searchForm.form.get('publishDate').valueChanges.subscribe(value => {
      let control = _.find(this.searchForm.controls, ['key', 'publishEndDate']);
      control['minDate'] = (moment(value).isValid()) ? value : false;
    });

    // this.searchForm.form.valueChanges.subscribe(value => {
    //   this.searchForm.controls = [...this.searchForm.controls.map(item => {
    //     if (item.key === 'publishEndDate') {
    //       item.minDate = moment(value.startDate, this.dateFormatter).isValid() ? value.startDate : false;
    //     }
    //     return item;
    //   })];
    // });
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * user has review permission or not
   */

  public changeFakePermission() {
    const permissions = this.permissionService.getPermissions();
    const hadReview = _.has(permissions, Permissions.NOTIFICATION_APPROVE_UPDATE);

    if (hadReview) {
      this.permissionService.removePermission(Permissions.NOTIFICATION_APPROVE_UPDATE);
    } else {
      this.permissionService.addPermission(Permissions.NOTIFICATION_APPROVE_UPDATE);
    }

    this.checkPermission();
  }

  /**
   * whether all search inputs valid or not
   */
  get isSearchValid(): boolean {
    return this.searchForm.form.valid;
  }
  public searchFormValidators: ValidatorFn = (group: FormGroup): { [key: string]: any } => {
    let isValid = true;
    const startDate = moment(group.controls['publishDate'].value, this.dateFormatter), endDate = moment(group.controls['publishEndDate'].value, this.dateFormatter);
    isValid = endDate.isSameOrAfter(startDate) || !group.controls['publishDate'].value || !group.controls['publishEndDate'].value ? true : false;
    return isValid ? null : { dateRangeError: '結束日期應大於等於發布日期' };
  }

  /**
   * table data orderType handler
   */
  get orderTypeLabel(): string {
    return this.orderType.label;
  }

  public chooseOrderType(type: any) {
    this.orderType = type;
    if (this.isSearchValid) {
      this.searchForm.submit();
    }
  }

  /**
   * searchForm submit
   */
  public handleSearchSubmit(value: any) {
    let searchConfig = _.assign({orderCol: this.orderType.value}, value);
    this.managementService.getNotificationList(searchConfig).subscribe(
      (resp) => {
        this.notificationList = resp.value.map( el => ManagementHelper.handleManagementDisplayData(el));
      }
    );
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.notificationTable) {
      return this.notificationTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.notificationTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public isRowSelectable(row: any) {
    return row.status === ManagementWFStatus.STAGE_REVIEW;
  }

  public onReviewActionClick(dateType: string, reviewType: string) {
    if (dateType === 'single') {
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.NOTIFICATION)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  /**
    * table row action handler
    */
  public openReviewMenu(row: any) {
    this.selectedRow = row;
    this.notificationRow = _.cloneDeep(this.selectedRow);
  }

  public onViewClick(row: any) {
    this.selectedRow = row;
    this.viewDialog.open();
  }

  /**
   *
   * notification dialog handler
   */
  public onCreateNotification() {
    this.notificationRow = {};
    this.notificationDialogType = 'create';
    this.disableNotificationDialog = false;
    this.ref.detectChanges();
    this.notificationDialog.open();
  }

  public onEditNotification(row: any, dialogType?: string) {
    const permissions = this.permissionService.getPermissions();
    if (row) {
      this.selectedRow = row;
      this.notificationRow = _.cloneDeep(this.selectedRow);
    }
    if (_.includes([ManagementWFStatus.INACTIVE, ManagementWFStatus.STAGE_REVIEW], this.selectedRow.status) ||
      !_.has(permissions, Permissions.NOTIFICATION_UPDATE) ||
      dialogType === 'view'
    ) {
      this.disableNotificationDialog = true;
    } else {
      this.disableNotificationDialog = false;
    }
    this.notificationDialogType = dialogType === 'view' ? 'view' : 'edit';
    this.ref.detectChanges();
    this.notificationDialog.open();
  }

  get getDialogHeaderStatusClass(): string {
    return ManagementHelper.headerTagStatusClass(this.selectedRow.status);
  }


  public discardNotificationChange() {
  }

  public handleReviewAction(isApprove: boolean) {
    if (isApprove) {
      this.onReviewActionClick('single', 'approve');
    } else {
      this.onReviewActionClick('single', 'reject');
    }
  }

  public handleAfterAction() {
    this.searchForm.submit();
  }

  /**
   * initControls
   */
  private prepareControls() {
    this.searchControls = [
      new MultiSelectControl({
        key: 'status',
        label: '狀態',
        options: this.statusOptions,
        enableAutoComplete: true,
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'title',
        label: '標題',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '以關鍵字搜尋...'
      }),
      new MultiSelectControl({
        key: 'createEmpId',
        label: '建立人',
        options: [
          { value: '0001', label: '0001 王小圖' },
          { value: '0002', label: '0002 王經理' },
          { value: '0003', label: '0003 蕭大山' },
          { value: '0004', label: '0004 蕭筱珊' },
          { value: '0005', label: '0005 黃明明' }
        ],
        enableAutoComplete: true,
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇...',
        breakAfter: true,
      }),
      new DatepickerControl({
        key: 'publishDate',
        label: '發布日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      }),
      new DatepickerControl({
        key: 'publishEndDate',
        label: '結束日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      })
    ];
  }

  /**
   * check permission
   */
  private checkPermission() {
    this.permissionService.hasPermission(Permissions.NOTIFICATION_APPROVE_UPDATE)
        .then( (hasPermission) => this.disableNotificationDialog = hasPermission )
        .catch ( (err) => this.logger.debug('checkPermission error: ', err ) );
  }

}
