import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Subject } from 'rxjs';

import * as _ from 'lodash';
import { NgxPermissionsService } from 'ngx-permissions';

import { LoggerService } from 'app/shared/logger.service';
import { ManagementService } from './../../core/services/management.service';
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { ManagementHelper } from 'app/management/management-helper';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { ManagementWFStatus, ManagementWFType } from '../management.model';
import { ISelectOptionModel } from 'app/core/models/comm-data';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { NzNotificationService } from 'ng-zorro-antd';
import { Router } from '@angular/router';
import { AuthService } from 'app/core/services/auth.service';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-expiry-notification',
  templateUrl: './expiry-notification.component.html',
  styleUrls: ['./expiry-notification.component.scss']
})
export class ExpiryNotificationComponent implements OnInit, OnDestroy {
  @ViewChild('expiryNotificationTable') expiryNotificationTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('expirySetting') expirySettingDialog: IbmDialogComponent;
  // @ViewChild('view') viewDialog: IbmDialogComponent;

  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public notificationList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public reviewList: any[] = [];
  public reviewPermission = 'REVIEW_EXPIRY_NOTIFICATION';
  public createPermission = 'CREATE_EXPIRY_NOTIFICATION';
  public notificationInfo: any;
  public dialogType: string = '';
  public orderTypes = [
    { value: 'Type', label: '通知原因' },
    { value: 'Event', label: '通知事件' },
    { value: 'ProductType', label: '產品別' },
    { value: 'CreateDate', label: '建立日期' }
  ];
  public orderType: any = this.orderTypes[0];
  public Permissions = Permissions;
  public WFType: ManagementWFType = ManagementWFType.OVERDUE;

   /**
   *
   * all options
   * @type {ISelectOptionModel[]}
   * @memberof ExpiryNotificationDialogComponent
   */
  public TypeOptions: ISelectOptionModel[] = [];
  public EventOptions: ISelectOptionModel[] = [];
  public SourceTypeOptions: ISelectOptionModel[] = [];
  public ProductTypeOptions: ISelectOptionModel[] = [];

  private currentPermissions: string;
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private router: Router,
    private auth: AuthService,
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private options: SelectOptionsService,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef,
    private notification: NzNotificationService,
  ) {
    this.currentPermissions = this.reviewPermission;
    const option = this.options.getOptions(
      [
        'notifyReason',
        'notifyEvent',
        'boSource',
        'overdueProductType',
      ]);
    this.TypeOptions = option['notifyReason'];
    this.EventOptions = option['notifyEvent'];
    this.SourceTypeOptions = option['boSource'];
    this.ProductTypeOptions = option['overdueProductType'];
  }

  /**
   * user has review permission or not
   */

  public changeFakePermission() {

    this.permissionService.removePermission(this.currentPermissions);
    if (this.currentPermissions === this.reviewPermission) {
      this.currentPermissions = this.createPermission;
    } else {
      this.currentPermissions = this.reviewPermission;
    }
    this.permissionService.addPermission(this.currentPermissions);
    this.checkPermission();
  }

  public chooseOrderType(menu) {
    this.orderType = menu;
    this.getList();
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.expiryNotificationTable) {
      return this.expiryNotificationTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.expiryNotificationTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public isRowSelectable(row: any) {
    // console.log(this.auth.getLoginUser().loginEmpId, row.ApplyEmpId);
    return row.status === ManagementWFStatus.STAGE_REVIEW &&
      row.ApplyEmpId !== this.auth.getLoginUser().loginEmpId;
  }

  public onReviewActionClick(dateType: string, reviewType: string, UUID?: string) {
    if (dateType === 'single') {
      // tslint:disable-next-line
      UUID ? this.selectedRow.UUID = UUID : null;
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.OVERDUE)
      .subscribe(resp => {
        if (resp.isOk) {
          if (reviewType === 'approve') {
            this.approveDialog.open();
          } else {
            this.returnDialog.open();
          }}
      });
  }

  /**
    * table row action handler
    */

  public openReviewMenu(row: any) {
    this.selectedRow = row;
  }

  /**
   *
   * notification dialog handler
   */
  public createExpiryNotification() {
    this.selectedRow = {};
    this.dialogType = 'create';
    this.ref.detectChanges();
    this.expirySettingDialog.open();
  }

  public onEditNotification(row: any, type: string) {
    if (row) {
      this.selectedRow = row;
    }
    this.dialogType = '';
    this.ref.detectChanges();
    this.expirySettingDialog.open();
  }

  get getDialogHeaderStatusClass(): string {
    if (this.notificationInfo) {
      return ManagementHelper.headerTagStatusClass(this.notificationInfo.status);
    }
    return ManagementHelper.headerTagStatusClass('');
  }


  public discardNotificationChange() {
  }

  public handleReviewAction(isApprove) {
    if (isApprove.review) {
      this.onReviewActionClick('single', 'approve', isApprove.UUID);
    } else {
      this.onReviewActionClick('single', 'reject', isApprove.UUID);
    }
  }

  public handleAfterReviewAction() {
    this.getList();
  }


  /**
   *
   *
   * @param {*} value
   * @memberof ExpiryNotificationComponent
   */
  public onViewClick(value) {
    // this.managementService.getOverdueInfo(value.id).subscribe(
    //   (info) => {
    //     this.notificationInfo = info;
    //     this.viewDialog.open();
    //   }
    // );
    if (value) {
      this.selectedRow = value;
    }

    this.dialogType = 'view';

    this.ref.detectChanges();
    this.expirySettingDialog.open();
  }

  public arrayToString(array: string[], connector: string = '、'): string {
    return array.join(connector);
  }

  /**
   * getList
   */
  public getList() {
    this.managementService.getOverdueList({OrderCol: this.orderType.value}).subscribe(
      (list) => {
        this.notificationList = list.value.map(el => ManagementHelper.handleManagementDisplayData(el));
        this.logger.debug('notificationList: ', this.notificationList);
        this.logger.debug('overdue api data: ', list.value);
      }
    );
  }

  ngOnInit() {
    this.permissionService.hasPermission([this.reviewPermission, this.createPermission])
      .then( (hasMarketingPermisson) => {
        if (!hasMarketingPermisson) {
          this.permissionService.addPermission(this.currentPermissions);
        }
      });
    this.checkPermission();
    this.getList();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

    /**
   * check permission
   */
  private checkPermission() {
    this.permissionService.hasPermission(this.reviewPermission)
        .then( () => {} )
        .catch ( (err) => this.logger.debug('checkPermission error: ', err ) );
  }
}
