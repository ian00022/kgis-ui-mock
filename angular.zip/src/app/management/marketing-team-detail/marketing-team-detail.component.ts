import { Permissions } from 'app/core/models/permissions';
import { AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CheckBoxTableHelper } from 'app/shared/helper/table-checkbox-helper';
import * as _ from 'lodash';
import { ManagementService } from '../../core/services/management.service';
import { MarketingTeamDialogType } from '../shared-components/management-marketing-team-dialog/management-marketing-team-dialog.component';
import { ManagementWFStatus, ManagementWFType } from './../management.model';
import { SelectOptionsService } from '../../shared/services/select-options.service';

@Component({
  selector: 'esun-marketing-team-detail',
  templateUrl: './marketing-team-detail.component.html',
  styleUrls: ['./marketing-team-detail.component.scss']
})
export class MarketingTeamDetailComponent implements OnInit, AfterViewInit {

  @ViewChild('teamMemberTable') teamMemberTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('removeConfirm') removeConfirmDialog: IbmDialogComponent;
  @ViewChild('marketingTeam') marketingTeamDialog: IbmDialogComponent;

  public collapsed: boolean = true;
  public reviewList: any[] = [];
  public selectedRowList: any[] = [];
  // public marketingInfo: any;
  //public teamMember: any[] = [];
  public teamData: any = {};
  public dialogType = MarketingTeamDialogType;
  public marketingTeamDialogType: MarketingTeamDialogType = MarketingTeamDialogType.EDITINFO;
  public WFType: ManagementWFType = ManagementWFType.MARKETINGTEAM;

  public stageInfo: any;
  public originInfo: any;
  public Permissions = Permissions;
  private stageMember: any[] = [];
  private originMember: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef,
    private option: SelectOptionsService
  ) { }

  ngOnInit() {
    this.getTeamDetail();
  }

  ngAfterViewInit() {
    // this.teamData = _.cloneDeep(this.marketingInfo);
    // this.teamData.teamMember = this.teamData.teamMember.map( (member) => member.empId);
  }

  get marketingInfo(): any {
    return this.stageInfo ? this.stageInfo : (this.originInfo ? this.originInfo : {});
  }

  get teamMember(): any[] {
    return this.stageMember !== [] ? this.stageMember : (this.originMember ? this.originMember : []);
  }

  get isTeamInfoEditable(): boolean {
    return this.marketingInfo.status !== ManagementWFStatus.STAGE_REVIEW;
  }

  get isTeamMemberEditable(): boolean {
    return _.includes([ManagementWFStatus.ACTIVE, ManagementWFStatus.STAGE_REJECT, ManagementWFStatus.STAGE], this.marketingInfo.status);
  }

  get marketingTeamHeader(): string {
    if (this.marketingInfo) {
      return `${this.marketingInfo.TeamName || ''} (${this.teamMember.length || 0})`;
    }
    return '';
  }

  get isAnySelected(): boolean {
    if (this.teamMemberTable) {
      return this.teamMemberTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  // public handleSelectAllCheckboxClick() {
  //   this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
  //     this.isAnySelected,
  //     this.teamMemberTable.getcurrentPageRows(),
  //     this.selectedRowList,
  //     'TeamNo'
  //   );
  // }

  // public handleCheckboxClick(row: any) {
  //   this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList, 'TeamNo');
  // }

  public onReviewActionClick(reviewType: string) {
    this.reviewList = _.cloneDeep(this.selectedRowList);

    if (reviewType === 'approve') {
      this.approveDialog.open();
    } else {
      this.returnDialog.open();
    }
  }

  public onRemoveClick(value: any) {
    this.removeConfirmDialog.open();
  }

  public onRemoveConfirmClick() {
    this.removeConfirmDialog.close();
  }

  public handleAfterAction() {
    this.getTeamDetail();
  }

  public onEditActionClick(type: MarketingTeamDialogType) {
    this.marketingTeamDialogType = type;
    this.ref.detectChanges();
    this.marketingTeamDialog.open();
  }

  public showModelChange(prop) {
    if (this.stageInfo && this.originInfo) {
      return this.stageInfo[prop] !== this.originInfo[prop];
    }
    return false;
  }

  public displayProduct(prod) {
    if (prod) {
      return prod.split(',').map( el => this.option.getOptionLabel('prod', el)).join('、');
    }
    return '';
  }

  public displayBOLSource(source) {
    if (source) {
      return source.split(',').map( el => this.option.getOptionLabel('boSource', el)).join('、');
    }
    return '';
  }

  public displayTeamCategory(category) {
    if (category) {
      return this.option.getOptionLabel('marketingTeamCategory', category);
    }
    return '';
  }


  private getTeamDetail() {
    const teamNo = this.route.snapshot.params['id'];
    this.managementService.getMarketingTeamInfo(teamNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          if (resp.value.sData) {
            this.stageInfo = _.assign({status: resp.value.Status}, resp.value.sData);
          }
          if (resp.value.oData) {
            this.originInfo = _.assign({status: resp.value.Status}, resp.value.oData);
          }
        }
      }
    );
    this.managementService.getMarketingTeamMember(teamNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.stageMember = resp.value.sData;
          this.originMember = resp.value.oData;
        }
      }
    );
  }

}
