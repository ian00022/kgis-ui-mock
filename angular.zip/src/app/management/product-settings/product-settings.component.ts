import { ManagementWFType, ManagementWFStatus } from './../management.model';
import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { NgxPermissionsService } from 'ngx-permissions';
import { Permissions } from 'app/core/models/permissions';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { ManagementHelper } from '../management-helper';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { ManagementService } from '../../core/services/management.service';
import { LoggerService } from '../../shared/logger.service';
import { CheckBoxTableHelper } from '../../shared/helper/table-checkbox-helper';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';

@Component({
  selector: 'esun-product-settings',
  templateUrl: './product-settings.component.html',
  styleUrls: ['./product-settings.component.scss']
})
export class ProductSettingsComponent implements OnInit, OnDestroy {

  @ViewChild('prodSettingTable') prodSettingTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('prodSetting') prodSettingDialog: IbmDialogComponent;

  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public prodSettingList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public reviewList: any[] = [];
  public Permissions = Permissions;
  // public reviewPermission = 'REVIEW_PRODUCT_SETTING';
  // public createPermission = 'CREATE_PRODUCT_SETTING';
  public productSettingInfo: any = {};

  public orderTypes = [
    { label: '代碼', value: 'ProductCode' },
    { label: '產品名', value: 'ProductName' }
  ];
  public currentOrderType = this.orderTypes[0];
  public WFType: ManagementWFType = ManagementWFType.PRODUCTSETTING;

  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef
  ) {}

  ngOnInit() {
    // it will remove when real world system link.
    this.permissionService.hasPermission([
      Permissions.PRODUCT_PARAMETER_SEARCH,
      Permissions.PRODUCT_PARAMETER_ADD,
      Permissions.PRODUCT_PARAMETER_UPDATE,
      Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE
    ])
      .then( (hasMarketingPermisson) => {
        if (!hasMarketingPermisson) {
          this.permissionService.addPermission([
            Permissions.PRODUCT_PARAMETER_SEARCH,
            Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE
          ]);
        }
      });
    this.checkPermission();

    // this.managementService.getProdSettingList({}).subscribe(
    //   (list) => {
    //     this.prodSettingList = list;
    //   }
    // );
    this.getProductSetting();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * user has review permission or not
   */

  public changeFakePermission() {
    const currentPermissions = this.permissionService.getPermissions();

    if (_.has(currentPermissions, Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE)) {
      this.permissionService.removePermission(Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE);
      this.permissionService.addPermission([
        Permissions.PRODUCT_PARAMETER_ADD,
        Permissions.PRODUCT_PARAMETER_UPDATE
      ]);
    } else {
      this.permissionService.removePermission(Permissions.PRODUCT_PARAMETER_ADD);
      this.permissionService.removePermission(Permissions.PRODUCT_PARAMETER_UPDATE);
      this.permissionService.addPermission([
        Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE
      ]);
    }
    this.checkPermission();
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.prodSettingTable) {
      return this.prodSettingTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.prodSettingTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public isRowSelectable(row: any) {
    return row.status === ManagementWFStatus.STAGE_REVIEW;
  }

  public onReviewActionClick(dateType: string, reviewType: string) {
    if (dateType === 'single') {
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.PRODUCTSETTING)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  /**
    * table row action handler
    */

  public openReviewMenu(row: any) {
    this.selectedRow = row;
    this.productSettingInfo = _.cloneDeep(row);
  }

  /**
   *
   * dialog handler
   */
  public createProduct() {
    this.selectedRow = {};
    this.productSettingInfo = {};
    this.ref.detectChanges();
    this.prodSettingDialog.open();
  }

  public onEditProductSettingInfo(row?: any) {
    if (row) {
      this.selectedRow = row;
      this.productSettingInfo = _.cloneDeep(row);
    }

    this.ref.detectChanges();
    this.prodSettingDialog.open();
  }

  public handleReviewAction(isApprove: boolean) {
    if (isApprove) {
      this.onReviewActionClick('single', 'approve');
    } else {
      this.onReviewActionClick('single', 'reject');
    }
  }

  public handleAfterReviewAction() {
    this.getProductSetting();
  }

  public arrayToString(array: string[], connector: string = '、'): string {
    return array.join(connector);
  }

  public onSortChange(orderType) {
    this.currentOrderType = orderType;
    this.getProductSetting();
  }

  // helper
  public periodString(value: any): string {
    if (value) {
      return `${value} 個月`;
    }
    return '-';
  }

  /**
   * check permission
   */
  private checkPermission() {
    this.permissionService.hasPermission(Permissions.PRODUCT_PARAMETER_APPROVE_UPDATE)
        .then( () => {} )
        .catch ( (err) => this.logger.debug('checkPermission error: ', err ) );
  }

  private getProductSetting() {
    this.managementService.getProductSettingList({ orderCol: this.currentOrderType.value})
      .subscribe(
        (resp) => {
          this.prodSettingList = resp.value.map( el => ManagementHelper.handleManagementDisplayData(el));
        }
      );
  }
}
