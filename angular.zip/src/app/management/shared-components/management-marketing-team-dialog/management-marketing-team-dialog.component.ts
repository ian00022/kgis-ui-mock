import { DatePipe } from '@angular/common';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { Component, OnInit, ViewChild, Input, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import {
  ControlBase,
  TextControl,
  TextareaControl,
  SingleDropdownControl,
  MultiSelectControl
} from 'app/shared/components/dynamic-form/controls';
import { ISelectOptionModel } from '../../../core/models/comm-data';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import * as _ from 'lodash';
import { LoggerService } from '../../../shared/logger.service';
import { ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper } from './../../management.model';
import { ManagementService } from '../../../core/services/management.service';
import { ProductHelper } from './../../../core/models/comm-data';
import { Router } from '@angular/router';
import { ManagementHelper } from 'app/management/management-helper';
import { isNullOrUndefined } from 'util';

export enum MarketingTeamDialogType {
  CREATE = 'create',
  EDITINFO = 'editInfo',
  ADDTEAM = 'addTeam'
}


@Component({
  selector: 'esun-management-marketing-team-dialog',
  templateUrl: './management-marketing-team-dialog.component.html',
  styleUrls: ['./management-marketing-team-dialog.component.scss'],
  providers: [DatePipe]
})
export class ManagementMarketingTeamDialogComponent implements OnInit, AfterViewInit {

  @ViewChild('teamInfoForm') teamInfoForm: DynamicFormComponent;
  @ViewChild('teamMemberForm') teamMemberForm: DynamicFormComponent;
  @ViewChild('teamInfo') teamInfoDialog: IbmDialogComponent;
  @ViewChild('teamMember') teamMemberDialog: IbmDialogComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  @Input('teamData')
  set teamData(value: any) {
    if (value) {
      this.data = value;
      // this.setFormValue();
    }
  }

  @Input('dialogType') dialogType: MarketingTeamDialogType;
  @Output('afterCreateOrUpdate') afterCreateOrUpdate: EventEmitter<any> = new EventEmitter();

  public infoModelChanges;
  public teamMemberChanges;
  public teamInfoControls: ControlBase<any>[] = [];
  public teamMemberControls: ControlBase<any>[] = [];

  public data: any = {};
  private marketingTeamCategoryOptions: ISelectOptionModel[] = [];
  private marketingMemberOptions: ISelectOptionModel[] = [];
  private marketingMemberLeaderOptions: ISelectOptionModel[] = [];
  private organizationCodeOptions:  ISelectOptionModel[] = [];
  private boTypeOptions:  ISelectOptionModel[] = [];
  private boSourceOptions:  ISelectOptionModel[] = [];
  private prodOptions:  ISelectOptionModel[] = [];

  constructor(
    private options: SelectOptionsService,
    private logger: LoggerService,
    private datePipe: DatePipe,
    private managementService: ManagementService,
    private router: Router
  ) {
    const option = this.options.getOptions(['marketingTeamCategory', 'employee', 'organizationCode', 'boType', 'boSource']);
    this.marketingTeamCategoryOptions = option['marketingTeamCategory'];
    this.marketingMemberOptions = option['employee'];
    this.organizationCodeOptions = option['organizationCode'];
    this.boTypeOptions = option['boType'];
    this.boSourceOptions = option['boSource'];
    this.prodOptions = ProductHelper.getAllOptions();
  }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.teamMemberForm.form.valueChanges.subscribe(
      (changes) => {
        this.marketingMemberLeaderOptions.splice(0, this.marketingMemberLeaderOptions.length);
        if (changes['TeamMember'] && changes['TeamMember'].length > 0) {
          changes['TeamMember'].forEach(element => {
            let option = _.find(this.marketingMemberOptions, ['value', element]);
            this.marketingMemberLeaderOptions.push(option);
          });
        }
      }
    );

    // 可承作商品為信貸 && 自動分派名單來源為網路進件時
    // 自動分派名單類型增加 線上核貸
    this.teamInfoForm.form.valueChanges.subscribe(
      (changes) => {
        if (_.includes(changes['AcceptBOLSource'], '2') && _.includes(changes['Product'], '4')) {
          if (this.boTypeOptions.length === 3) {
            this.boTypeOptions.push(
              {
                label: '線上核貸',
                value: '4'
              },
            );
          }
          return;
        } else if (this.boTypeOptions.length === 4) {
          this.boTypeOptions.splice(3, 1);
          let newValue = _.filter(this.teamInfoForm.form.controls['AcceptBOLType'].value, (el) => {
            return el !== '4';
          });
          this.teamInfoForm.form.controls['AcceptBOLType'].setValue(newValue);
        }
      }
    );
  }

  /**
   * dialog helper
   */
  get teamInfoDialogHeader(): string {
    if (this.dialogType === MarketingTeamDialogType.CREATE) {
      return '新增行銷團隊 (第 1/2 步：填寫團隊資訊)';
    } else if (this.dialogType === MarketingTeamDialogType.EDITINFO) {
      return '編輯團隊資訊';
    }
    return '團隊資訊';
  }

  get teamMemberDialogHeader(): string {
    if (this.dialogType === MarketingTeamDialogType.CREATE) {
      return '新增行銷團隊 (第 2/2 步：加入成員)';
    } else if (this.dialogType === MarketingTeamDialogType.ADDTEAM) {
      return '新增團隊成員';
    }
    return '團隊成員';
  }

  get getDialogHeaderStatusClass(): string {
    return this.data ? ManagementHelper.headerTagStatusClass(this.data.status) : '';
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

  get selectedMember(): any[] {
    if (this.teamMemberForm) {
      return this.teamMemberForm.form.controls['TeamMember'].value || [];
    }
    return [];
  }

  get selectedMemberLabel(): string {
    if (this.teamMemberForm) {
      const labels = (this.teamMemberForm.form.controls['TeamMember'].value || []).map( (empId) => {
        return  (_.find(this.marketingMemberOptions, {value: empId}) as ISelectOptionModel ).label;
      });
      return labels.join('、');
    }
    return '';
  }


  /**
   * action buttons by status
   */
  get discardable(): boolean {
    return ManagementHelper.discardable(this.data);
  }
  get showDisableBtn(): boolean {
    return ManagementHelper.showDisableBtn(this.data);
  }
  get showEnableBtn(): boolean {
    return ManagementHelper.showEnableBtn(this.data);
  }
  get showSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.data) || this.dialogType === MarketingTeamDialogType.CREATE;
  }
  get showTempSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.data) || this.dialogType === MarketingTeamDialogType.EDITINFO;
  }
  get showMemberTempSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.data) || this.dialogType === MarketingTeamDialogType.ADDTEAM;
  }

  get showReviewBtn(): boolean {
    return ManagementHelper.showReviewBtn(this.data);
  }

  get enableSaveBtn(): boolean {
    if (isNullOrUndefined(this.data.status)) {
      return this.teamInfoForm.form.valid;
    } else {
      if (this.data.status === ManagementWFStatus.STAGE) {
        return this.teamInfoForm.form.valid;
      } else if (this.data.status === ManagementWFStatus.STAGE_REJECT || this.data.status === ManagementWFStatus.ACTIVE) {
        return this.teamInfoForm.form.valid && this.teamInfoForm.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableTempSaveBtn(): boolean {
    return this.enableSaveBtn && this.teamInfoForm.form.dirty;
  }

  get enableMemberSaveBtn(): boolean {
    if (isNullOrUndefined(this.data.status)) {
      return this.teamMemberForm.form.valid;
    } else {
      if (this.data.status === ManagementWFStatus.STAGE) {
        return this.teamMemberForm.form.valid;
      } else if (this.data.status === ManagementWFStatus.STAGE_REJECT || this.data.status === ManagementWFStatus.ACTIVE) {
        return this.teamMemberForm.form.valid && this.teamMemberForm.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableMemberTempSaveBtn(): boolean {
    return this.enableMemberSaveBtn && this.teamMemberForm.form.dirty;
  }


  get showNextBtn(): boolean {
    return this.dialogType === MarketingTeamDialogType.CREATE;
  }

  /**
   * actions
   */
  public roleActivationClick(active: boolean) {

    this.managementService.updateMarketingTeamInfo(_.assign({}, this.data, { ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE }))
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            this.closeDialog();
            this.afterCreateOrUpdate.emit();
          }
        }
      );
  }

  public onSaveClick() {
    if (this.dialogType === MarketingTeamDialogType.CREATE) {
      // 新增時預設為生效
      let body = _.assign({activeCode: ManagementWFStatus.ACTIVE}, this.teamInfoForm.form.value, this.teamMemberForm.form.value);
      if (!body['AcceptBOLType']) {
        body['AcceptBOLType'] = [];
      }
      this.managementService.createMarketingTeam(body).subscribe(
        (resp) => {
          this.logger.debug(resp);
          this.closeDialog();
          this.afterCreateOrUpdate.emit();
        }
      );
    } else {
      this.closeDialog();
      this.chooseMgrDialog.open();
    }
    this.logger.debug(this.teamInfoForm.form.value, this.teamMemberForm.form.value);
  }

  public onTempSaveClick() {
    if (this.dialogType === MarketingTeamDialogType.EDITINFO) {
      this.managementService.updateMarketingTeamInfo(_.assign({}, this.data, this.teamInfoForm.form.value))
        .subscribe(
          (resp) => {
            if (resp.isOk) {
              this.closeDialog();
              this.afterCreateOrUpdate.emit();
            }
          }
        );
    } else if (this.dialogType === MarketingTeamDialogType.ADDTEAM){
      this.managementService.updateMarketingTeamMember(_.assign({}, this.data, this.teamMemberForm.form.value))
        .subscribe(
          (resp) => {
            if (resp.isOk) {
              this.closeDialog();
              this.afterCreateOrUpdate.emit();
            }
          }
        );
    } else {
      this.onSaveClick();
    }
  }

  public onCancelClick(dialog: IbmDialogComponent, form: DynamicFormComponent) {
    if (form.form.dirty) {
      this.cancelCheckDialog.open();
    } else {
      dialog.close();
      this.resetForms();
    }
  }

  public cancelCheckSave() {
    this.onTempSaveClick();
  }

  public cancelCheckUnSave() {
    this.closeDialog();
    this.resetForms();
  }

  public onNextStepClick() {
    this.teamInfoDialog.close();
    this.teamMemberDialog.open();
  }

  public onPreStepClick() {
    this.teamMemberDialog.close();
    this.teamInfoDialog.open();
  }

  public open() {
    if (this.dialogType === MarketingTeamDialogType.ADDTEAM) {
      this.managementService.getMarketingTeamMember(this.data.TeamNo)
        .subscribe(
          (resp) => {
            if (resp.value.sData) {
              this.setFormValue(resp.value.sData);
              // let changes = [];
              // this.teamMemberControls.forEach(
              //   (el) => {
              //     if (resp.value.sData[el.key] !== resp.value.oData[el.key]) {
              //       changes.push( this.displayModelChanges(el.key, resp.value.sData[el.key], resp.value.oData[el.key]) );
              //     }
              //   }
              // );
              // this.teamMemberChanges = changes;
            } else {
              this.setFormValue(resp.value.oData);
            }
            this.teamMemberDialog.open();
          }
        );
    } else {
      if (this.dialogType === MarketingTeamDialogType.CREATE) {
        this.resetForms();
        const code = this.datePipe.transform(new Date(), 'yyyyMMddHHmmss');
        this.teamInfoForm.form.controls['TeamNo'].setValue(`MT${code}`);
        this.setFormEditable(true);
        this.teamInfoDialog.open();
      } else {
        this.managementService.getMarketingTeamInfo(this.data.TeamNo)
        .subscribe(
          (resp) => {
            if (resp.value.sData) {
              let data = _.cloneDeep(resp.value.sData);
              data['Product'] = data['Product'].split(',');
              data['AcceptBOLType'] = data['AcceptBOLType'].split(',');
              data['AcceptBOLSource'] = data['AcceptBOLSource'].split(',');
              this.setFormValue(data);
              let changes = [];
              this.teamInfoControls.forEach(
                (el) => {
                  if (resp.value.sData[el.key] !== resp.value.oData[el.key]) {
                    changes.push( this.displayModelChanges(el.key, resp.value.sData[el.key], resp.value.oData[el.key]) );
                  }
                }
              );
              this.infoModelChanges = changes;
            } else {
              let data = _.cloneDeep(resp.value.oData);
              data['Product'] = data['Product'].split(',');
              data['AcceptBOLType'] = data['AcceptBOLType'].split(',');
              data['AcceptBOLSource'] = data['AcceptBOLSource'].split(',');
              this.setFormValue(data);
            }
            this.teamInfoDialog.open();
          }
        );
      }
    }
  }

  public afterChooseWFApprMgr(mgrId) {
    let updateData = {};
    if (this.teamInfoForm.form.dirty) {
      _.assign(updateData, ManagementHelper.showDirtyFormControl(this.teamInfoControls, this.teamInfoForm));

    }

    if (this.teamMemberForm.form.dirty) {
      _.assign(updateData, ManagementHelper.showDirtyFormControl(this.teamMemberControls, this.teamMemberForm));
    }

    let body = {
      UUIDs: [this.data.UUID],
      WFApprMgrEmpId: mgrId,
      UpdateData: updateData,
      WFObjectName: this.managementService.getWFObjectName(),
      BaseUrl: this.router.url,
    };

    this.managementService.submitWF(body, ManagementWFType.MARKETINGTEAM).subscribe(
      (resp) => {
        this.closeDialog();
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  public discardChange() {
    this.managementService.discard(this.data.UUID, ManagementWFType.MARKETINGTEAM).subscribe(
      (resp) => {
        this.closeDialog();
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  public teamInfoFormValidators: ValidatorFn = (form: FormGroup): { [key: string]: any } => {
    let typeIndex = _.findIndex(this.teamInfoControls, ['key', 'AcceptBOLType']);

    if (_.includes(form.controls['AcceptBOLSource'].value, '2')) {
      this.teamInfoControls[typeIndex].required = true;
      if (!form.controls['AcceptBOLType'].value || _.isEmpty(form.controls['AcceptBOLType'].value)) {
        return {
          AcceptBOLSourceRequire: true
        };
      }
    } else {
      this.teamInfoControls[typeIndex].required = false;
    }
  }

  private setFormValue(data) {
    if (!this.teamInfoForm.form && !this.teamMemberForm.form) {
      return;
    }
    for (const key of Object.keys(data)) {
      if (this.teamInfoForm.form.controls[key]) {
        this.teamInfoForm.form.controls[key].setValue(data[key]);
      }
      if (this.teamMemberForm.form.controls[key]) {
        this.teamMemberForm.form.controls[key].setValue(data[key]);
      }
    }

    if (this.data.status === ManagementWFStatus.INACTIVE || this.data.status === ManagementWFStatus.STAGE_REVIEW) {
      this.setFormEditable(false);
    } else {
      this.setFormEditable(true);
    }
  }

  private setFormEditable(editable: boolean) {
    for ( const key of Object.keys(this.teamInfoForm.form.controls)) {
      if (editable && this.dialogType === MarketingTeamDialogType.EDITINFO) {
        _.includes(['TeamCategory', 'TeamNo', 'OrganizationCode'], key) ?
          this.teamInfoForm.form.controls[key].disable() :
          this.teamInfoForm.form.controls[key].enable();
      } else if (editable) {
        this.teamInfoForm.form.controls[key].enable();
      } else {
        this.teamInfoForm.form.controls[key].disable();
      }
    }

    for ( const key of Object.keys(this.teamMemberForm.form.controls)) {
      if (editable) {
        this.teamMemberForm.form.controls[key].enable();
      } else {
        this.teamMemberForm.form.controls[key].disable();
      }
    }
  }

  private resetForms() {
    this.teamInfoForm.reset();
    this.teamMemberForm.reset();
  }

  private prepareControls() {
    this.teamInfoControls = [
      new SingleDropdownControl({
        key: 'TeamCategory',
        label: '團隊類型',
        columnClasses: ['6'],
        required: true,
        placeholder: '請選擇...',
        options: this.marketingTeamCategoryOptions
      }),

      new TextControl({
        key: 'TeamNo',
        label: '團隊編號',
        required: true,
        columnClasses: ['6'],
        placeholder: '請輸入...'
      }),

      new TextControl({
        key: 'TeamName',
        label: '團隊名稱',
        required: true,
        columnClasses: ['6'],
        placeholder: '請輸入...'
      }),

      new SingleDropdownControl({
        key: 'OrganizationCode',
        label: '組織代碼',
        required: true,
        columnClasses: ['6'],
        placeholder: '請選擇...',
        options: this.organizationCodeOptions
      }),

      new TextControl({
        key: 'BOLMaxLimit',
        label: '名單上限',
        addonString: '筆',
        required: true,
        columnClasses: ['6'],
        placeholder: '請輸入...'
      }),

      new MultiSelectControl({
        key: 'Product',
        label: '可承作商品',
        required: true,
        columnClasses: ['6'],
        placeholder: '請選擇...',
        options: this.prodOptions
      }),

      new MultiSelectControl({
        key: 'AcceptBOLSource',
        label: '自動分派名單來源',
        required: true,
        columnClasses: ['12'],
        placeholder: '請選擇...',
        options: this.boSourceOptions
      }),

      new MultiSelectControl({
        key: 'AcceptBOLType',
        label: '自動分派名單類型',
        columnClasses: ['12'],
        placeholder: '請選擇...',
        options: this.boTypeOptions,
        condition: (form: FormGroup) => {
          // 自動分派名單來源有網路進件時需有名單類型
          const index = _.indexOf(form.controls['AcceptBOLSource'].value, '2');
          return index !== -1;
        }
      }),

      new TextareaControl({
        key: 'Description',
        label: '描述',
        columnClasses: ['12'],
        placeholder: '請選擇...',
      })
    ];

    this.teamMemberControls = [

      new MultiSelectControl({
        key: 'TeamMember',
        label: '團隊成員',
        required: true,
        columnClasses: ['12'],
        placeholder: '請選擇...',
        options: this.marketingMemberOptions
      }),

      new SingleDropdownControl({
        key: 'TeamLeader',
        label: '團隊組長',
        required: true,
        columnClasses: ['12'],
        placeholder: '請選擇...',
        options: this.marketingMemberLeaderOptions
      })
    ];
  }

  private closeDialog() {
    if (this.teamInfoDialog.isOpen) {
      this.teamInfoDialog.close();
    }
    if (this.teamMemberDialog.isOpen) {
      this.teamMemberDialog.close();
    }
    this.infoModelChanges = null;
    this.teamMemberChanges = null;
  }

  private displayModelChanges(key, sData, oData) {
    let sLabels, oLabels;
    let model = {
      key: key
    };

    switch(key) {
      case 'Product':
        sLabels = this.findLabels(sData, this.prodOptions);
        oLabels = this.findLabels(oData, this.prodOptions);
        break;
      case 'AcceptBOLSource':
        sLabels = this.findLabels(sData, this.boSourceOptions);
        oLabels = this.findLabels(oData, this.boSourceOptions);
        break;
      case 'AcceptBOLType':
        sLabels = this.findLabels(sData, this.boTypeOptions);
        oLabels = this.findLabels(oData, this.boTypeOptions);
        break;
      default:
        break;
    }

    model['valueAfter'] = sLabels ? sLabels.join('、') : sData;
    model['valueBefore'] = oLabels ? oLabels.join('、') : oData;

    return model;
  }

  private findLabels(data, options, key = 'label') {
    return data.split(',').map(element => {
      return _.result(_.find(options, (prod) => {
        return prod.value === element;
      }), key);
    });
  }
}

