import { Component, OnInit, Input, ViewChild, AfterViewInit, OnChanges, OnDestroy, Output, EventEmitter } from '@angular/core';
import { ControlBase, MultiSelectControl } from 'app/shared/components/dynamic-form/controls';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import * as _ from 'lodash';
import { Permissions } from 'app/core/models/permissions';
import { RoleService } from 'app/management/role/role.service';
import { UserRoleStatusEnum } from 'app/management/role/role.models';

@Component({
  selector: 'esun-employee-management-dialog',
  templateUrl: './employee-management-dialog.component.html',
  styleUrls: ['./employee-management-dialog.component.scss']
})
export class EmployeeManagementDialogComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('form') form: DynamicFormComponent;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  @Input('header') header: string;
  @Input('recordID') recordID: string;
  @Input('sysRoles') sysRoles: Array<any>;
  @Input('sysStatus') sysStatus: Array<any>;
  @Output() afterConfirm = new EventEmitter();

  // permission
  public Permissions = Permissions;

  public controls: ControlBase<any>[] = [];
  // public requiredAnyKeys = ['roleSetting'];
  
  public paramModelChanges;
  public currentEmployee: any = {};
  public currentRoleString: String = '';
  public currentEmployeeStatus: String;
  public currentSelectedRoles: Array<any> = [];
  public statusEnum = UserRoleStatusEnum;

  public enableToEditFormStatus: Array<string> = [UserRoleStatusEnum.ENABLED, UserRoleStatusEnum.TEMP, UserRoleStatusEnum.TEMP_REJECT];

  constructor(
    private roleService: RoleService,
    // private permissionsService: NgxPermissionsService,
  ) { }

  public prepareControls() {
    this.controls = [
      new MultiSelectControl({
        key: 'roleSetting',
        label: '角色設定',
        columnClasses: ['12'],
        options: this.sysRoles,
        placeholder: '請選擇...'
      })
    ];
  }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.form.form.valueChanges
      .subscribe(filters => {
        this.currentSelectedRoles = this.sysRoles.filter(role =>
          _.includes(filters.roleSetting, role.value));
      });
  }

  ngOnChanges() {
    if (this.dialog.isOpen) {
      if (this.recordID) {
        this.roleService.getUserDetails(this.recordID)
          .subscribe(data => {
            this.form.patchValue({
              // @todo role settings
              roleSetting: data.duoData.map(d => d.RoleId)
            });
            if (!_.includes(this.enableToEditFormStatus, this.currentEmployee.statusCode)) {
              this.form.form.controls['roleSetting'].disable();
            } else {
              this.form.form.controls['roleSetting'].enable();
            }

            this.currentEmployee = data;
          });
        // this.getCurrentEmployee(this.recordID)
        //   .then(res => {
        //     this.patchValueByEmployeeId();
        //     this.setCurrentRoleString();
        //   });
      }
    }
  }

  ngOnDestroy(): void {}

  open() {
    this.dialog.open();
  }

  confirm(submitType) {
    switch(submitType) {
      case 'editCommit':
        this.chooseMgrDialog.open();
        break;
      default:
        break;
    }
  }

  afterChooseWFApprMgr(mgrId) {
    const request = {
      UUIDs: [
        this.currentEmployee.uuid
      ],
      WFApprMgrEmpId: mgrId,
      UpdateData: {},
      BaseUrl: '',
      WFObjectName: ''
    };

    // @todo
    // if (hasDouUUID) {
    //   request.UUIDs.push(this.currentEmployee.DouUUID)
    // }

    this.roleService.submitUser(request)
      .subscribe(data => {
        this.dialog.close();
        this.chooseMgrDialog.close();
        this.afterConfirm.emit();
      });
  }

  cancel() {
    this.dialog.close();
  }

  tempSave() {
    if (!this.form.form.invalid) {
      this.roleService.tempSaveUser(this.recordID, this.form.form.value)
        .subscribe(data => {
          this.dialog.close();
        });
    }
  }

  onSubmit(event) { }

  setCurrentRoleString() {

    this.currentRoleString = this.setShownString(this.sysRoles, this.currentEmployee.systemRole);

    const currentEmployeeStatus = this.sysStatus.find(status => this.currentEmployee.status === status.value);

    this.currentEmployeeStatus = currentEmployeeStatus ? currentEmployeeStatus.label : '-';

    if (currentEmployeeStatus && currentEmployeeStatus.value === 'reject') {
      this.currentEmployeeStatus = '生效';
    }
  }

  setShownString(labelValueArray: Array<any>, valueArray: Array<any>) {
    const current = labelValueArray.filter(item =>
      _.includes(valueArray, item.value));

    return current.map(i => i.label).join('，');
  }

  discardChange(e: Event) {
    e.preventDefault();
  }
}
