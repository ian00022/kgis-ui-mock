import { Component, OnInit, ViewChild, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import * as XLSX from 'xlsx';
import { combineLatest } from 'rxjs';
import { FileUploader, FileItem, ParsedResponseHeaders } from 'ng2-file-upload';
import { LoggerService } from 'app/shared/logger.service';
import { SelectOptionsService } from '../../../shared/services/select-options.service';
import { ManagementHelper } from './../../management-helper';
import { IbmDialogComponent } from './../../../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { ControlBase, TextareaControl, DatepickerControl, TextControl, SingleDropdownControl } from 'app/shared/components/dynamic-form/controls';
import { ISelectOptionModel } from '../../../core/models/comm-data';
import { ManagementWFStatus, ManagementWFStatusHelper, ManagementWFType } from '../../management.model';
import { LoginUserDto } from 'app/core/models/permissions';
import { DateHelper } from './../../../shared/helper/date-helper';
import { environment } from 'environments/environment';
import { isNullOrUndefined } from 'util';
import { ApiService, AuthService, ManagementService } from 'app/core/services';
import { UploadHeadOfficeAssignResponseDto } from 'app/core/models/file.model';
import { FileDto } from '../../../core/models/file.model';
import { HeadOfficeAssignmentDialogType, InputHeadOfficeAssignmentDetailMethod, HeadOfficeAssignmentDetail } from 'app/management/head-office-assignment/head-office-assignment.model';


@Component({
  selector: 'esun-head-office-assignment-dialog',
  templateUrl: './head-office-assignment-dialog.component.html',
  styleUrls: ['./head-office-assignment-dialog.component.scss']
})
export class HeadOfficeAssignmentDialogComponent implements OnInit {

  @Input() dialogType: HeadOfficeAssignmentDialogType;
  @Input('info') info: any;

  @ViewChild('createInfoFirst') createInfoFirstDialog: IbmDialogComponent;
  @ViewChild('createInfoForm') createInfoForm: DynamicFormComponent;
  @ViewChild('createInfoSecond') createInfoSecondDialog: IbmDialogComponent;
  @ViewChild('editInfo') editInfoDialog: IbmDialogComponent;
  @ViewChild('editInfoForm') editInfoForm: DynamicFormComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('uploadEl') uploadEl: ElementRef;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;


  @Output('afterCreateOrUpdate') afterCreateOrUpdate: EventEmitter<any> = new EventEmitter();

  // fileUpload
  public maxFileSize: number = 2;
  public showUploadErrorText: boolean = false;
  public hasUploadedFile: boolean = false;
  public xlsxUploader: FileUploader;
  public assignmentUploader: FileUploader;
  public uploadedFiles: any[] = [];


  public infoControls: ControlBase<any>[] = [];
  public assignmentTypeOptions: ISelectOptionModel[];
  public employeeOptions: ISelectOptionModel[];
  public bankBranchesOptions: ISelectOptionModel[];
  public assignmentDetail: {
    addBoType: InputHeadOfficeAssignmentDetailMethod,
    caseDetails?: HeadOfficeAssignmentDetail[],
    caseDetailUploadXLS?: FileDto
  };

  public assignmentInfo: any = {};
  public inputMethod = InputHeadOfficeAssignmentDetailMethod;
  public isUploading: boolean = false;
  private user: LoginUserDto;

  constructor(
    private options: SelectOptionsService,
    private logger: LoggerService,
    private auth: AuthService,
    private managementService: ManagementService,
    private router: Router,
    private api: ApiService
  ) {

    this.user = this.auth.getLoginUser();
    const option = this.options.getOptions([
      'headOfficeAssignmentType',
      'employee',
      'bankBranches'
    ]);

    this.assignmentTypeOptions = option['headOfficeAssignmentType'];
    this.employeeOptions = option['employee'];
    this.bankBranchesOptions = option['bankBranches'];

    this.assignmentUploader = this.api.createFileUploader({
      url: `${environment.api_url}File`,
      method: 'POST',
      itemAlias: 'file',
      autoUpload: true,
      maxFileSize: this.maxFileSize * 1024 * 1024
    });

    this.xlsxUploader = this.api.createFileUploader({
      url: `${environment.api_url}CaseMgm/details`,
      method: 'POST',
      itemAlias: 'file',
      autoUpload: true,
      allowedFileType: ['xls']
    });

    this.assignmentDetail = {
      addBoType: InputHeadOfficeAssignmentDetailMethod.KEYIN,
      caseDetails: [],
      caseDetailUploadXLS: null
    };
  }

  ngOnInit() {
    this.prepareControls();
    this.xlsxUploader.onAfterAddingFile = this.onAfterAddingFile.bind(this);
    this.xlsxUploader.onBuildItemForm = this.onBuildItemForm.bind(this);
    this.xlsxUploader.onCompleteAll = this.onCompleteAll.bind(this);
    this.xlsxUploader.onAfterAddingAll = this.onAfterAddingAll.bind(this);
    this.xlsxUploader.onSuccessItem = (item: FileItem, response: string, status: number, headers: ParsedResponseHeaders) => {
      let resp = JSON.parse(response);
      if (resp.IsOk) {
        let dto = resp.Value as UploadHeadOfficeAssignResponseDto;
        let file: FileDto = {
          FileUUID: dto.Result.FileUUID,
          FileDownloadPath: dto.Result.FileDownloadPath,
          FileName: item.file.name,
          DataCount: dto.Result.DataCount
        };
        this.assignmentDetail.caseDetailUploadXLS = file;
      }
    };

    this.assignmentUploader.onAfterAddingFile = this.onAfterAddingFile.bind(this);
    this.assignmentUploader.onBuildItemForm = this.onBuildItemForm.bind(this);
    this.assignmentUploader.onCompleteAll = this.onCompleteAll.bind(this);
    this.assignmentUploader.onAfterAddingAll = this.onAfterAddingAll.bind(this);
    this.assignmentUploader.onSuccessItem = (item: FileItem, response: string, status: number, headers: ParsedResponseHeaders) => {
      let resp = JSON.parse(response);
      if (resp.IsOk) {
        let file: FileDto = {
          FileUUID: resp.Value.FileUUID,
          FileDownloadPath: resp.Value.FileDownloadPath,
          FileName: item.file.name,
          isNew: true
        };
        this.uploadedFiles.push(file);
      }
    };

    this.assignmentUploader.onWhenAddingFileFailed = (fileItem) => {
      this.showUploadErrorText = true;
    };
  }

  /**
   * action buttons by status
   */

  get getDialogHeaderStatusClass(): string {
    return ManagementHelper.headerTagStatusClass(this.assignmentInfo.status);
  }
  get discardable(): boolean {
    return ManagementHelper.discardable(this.assignmentInfo);
  }
  get showDisableBtn(): boolean {
    return ManagementHelper.showDisableBtn(this.assignmentInfo);
  }
  get showEnableBtn(): boolean {
    return ManagementHelper.showEnableBtn(this.assignmentInfo);
  }
  get showSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.assignmentInfo) && this.isUploading === false;
  }
  get showReviewBtn(): boolean {
    return ManagementHelper.showReviewBtn(this.assignmentInfo);
  }

  get enableSaveBtn(): boolean {
    let form = (this.isCreateMode || this.isCopyMode) ? this.createInfoForm : this.editInfoForm;
    if (isNullOrUndefined(this.assignmentInfo.status)) {
      return form.form.valid;
    } else {
      if (this.assignmentInfo.status === ManagementWFStatus.STAGE) {
        return form.form.valid;
      } else if (this.assignmentInfo.status === ManagementWFStatus.STAGE_REJECT || this.assignmentInfo.status === ManagementWFStatus.ACTIVE) {
        return form.form.valid && form.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableTempSaveBtn(): boolean {
    let form = (this.isCreateMode || this.isCopyMode) ? this.createInfoForm : this.editInfoForm;
    return this.enableSaveBtn && form.form.dirty;
  }

  get disableNextStepBtn(): boolean {
    return !this.createInfoForm.form.valid;
  }

  // common
  get isCreateMode(): boolean {
    return this.dialogType === HeadOfficeAssignmentDialogType.CREATE;
  }

  get isCopyMode(): boolean {
    return this.dialogType === HeadOfficeAssignmentDialogType.COPY;
  }

  get createInfoHeader(): string {
    let createType = this.isCreateMode ? '填寫' : '複製';
    return `新增總行指派案件 (第 1/2 步：${createType}案件資訊)`;
  }

  // upload helper

  public onUploadFileClick() {
    this.uploadEl.nativeElement.click();
    this.showUploadErrorText = false;
  }

  public removeUploadedFile(file, index?: number) {
    this.managementService.removeFileByUUID(file.FileUUID).subscribe(
      (resp) => {
        if (resp.isOk) {
          if (!index && index !== 0) {
            this.assignmentDetail.caseDetailUploadXLS = null;
          } else {
            this.uploadedFiles.splice(index, 1);
          }
        }
      }
    );
  }

  /**
   * dialog actions
   */

  public roleActivationClick(active: boolean) {
    this.managementService.updateHeadOfficeAssignment(_.assign( _.cloneDeep(this.assignmentInfo),
      { ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE }
    )).subscribe(
      (resp) => {
        this.afterCreateOrUpdate.emit();
        this.close();
      }
    );
  }

  public onSaveClick(type: string) {
    if (this.isCreateMode || this.isCopyMode) {
      let attachFileUUID = this.uploadedFiles.map((el) => el.FileUUID);
      let body = _.assign({
        AttachedFileUUIds: attachFileUUID,
        ActiveCode: ManagementWFStatus.ACTIVE
      }, this.createInfoForm.form.value);

      if (this.assignmentDetail.addBoType === InputHeadOfficeAssignmentDetailMethod.KEYIN) {
        body['CaseDetails'] = this.assignmentDetail.caseDetails;
        body['CaseDetailUploadXLSUUId'] = null;
      } else {
        body['CaseDetails'] = [];
        body['CaseDetailUploadXLSUUId'] = this.assignmentDetail.caseDetailUploadXLS.FileUUID;
      }

      this.managementService.createHeadOfficeAssignment(body).subscribe(
        (resp) => {
          this.afterCreateOrUpdate.emit();
          this.close();
        }
      );
    } else {
      let newAttachedFileUUIds = this.uploadedFiles.filter((el) => el.isNew ).map((el) => el.FileUUID);
      let body = _.assign({
        NewAttachedFileUUIds: newAttachedFileUUIds,
      }, this.assignmentInfo, this.editInfoForm.form.value);

      if (type === 'temp') {
        this.managementService.updateHeadOfficeAssignment(body).subscribe(
          (resp) => {
            this.afterCreateOrUpdate.emit();
            this.close();
          }
        );
      } else {
        if (newAttachedFileUUIds.length > 0 || this.editInfoForm.form.dirty) {
          this.managementService.updateHeadOfficeAssignment(body).subscribe(
            (resp) => {

              if (resp.isOk) {
                this.managementService.getHeadOfficeAssignmentByCaseNo(this.assignmentInfo.CaseNo).subscribe(
                  (resp2) => {

                    if (resp2.isOk) {
                      this.assignmentInfo = ManagementHelper.handleManagementDisplayData(resp2.value);
                      this.close();
                      this.chooseMgrDialog.open();
                    }
                  }
                );
              }
            }
          );
        } else {
          this.close();
          this.chooseMgrDialog.open();
        }
      }
    }
  }

  public onCancelClick() {
    if (this.isCreateMode || this.isCopyMode) {
      if (this.createInfoFirstDialog.isOpen) {
        this.cancelAction(this.createInfoForm, this.createInfoFirstDialog);
      } else if (this.createInfoSecondDialog.isOpen) {
        this.cancelCheckDialog.open();
      } else {
        this.logger.debug('assignment dialog error');
      }
    } else {
      this.cancelAction(this.editInfoForm, this.editInfoDialog);
    }
  }

  public cancelCheckSave() {
    this.onSaveClick('temp');
  }

  public cancelCheckUnSave() {
    if (this.createInfoFirstDialog.isOpen) {
      this.createInfoFirstDialog.close();
    } else if (this.createInfoSecondDialog.isOpen) {
      this.createInfoSecondDialog.close();
    } else if (this.editInfoDialog.isOpen) {
      this.editInfoDialog.close();
    }
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

  public discardChange() {
    this.managementService.discard(this.assignmentInfo.UUID, ManagementWFType.HEADOFFFICEASSIGNMENT)
      .subscribe(
        (resp) => {
          this.afterCreateOrUpdate.emit();
          this.close();
        }
      );
  }

  public open() {
    this.reset();
    this.initFormControls(this.dialogType);

    if (this.isCreateMode) {
      this.createInfoForm.form.controls['CreateEmpId'].setValue(`(${this.user.loginEmpId}) ${this.user.name}`);
      this.createInfoFirstDialog.open();
    } else {
      combineLatest(
        this.managementService.getHeadOfficeAssignmentByCaseNo(this.info.CaseNo),
        this.managementService.getHeadOfficeAssignmentFilesByCaseNo(this.info.CaseNo)
      ).subscribe(
        ([infoResp, files]) => {

          this.assignmentInfo = ManagementHelper.handleManagementDisplayData(infoResp.value);
          let value = {};
          this.infoControls.forEach(
            (control) => {
              if (this.assignmentInfo[control.key]) {
                if (control.key === 'ReplyDate') {
                  value[control.key] = DateHelper.formatDate(this.assignmentInfo[control.key]);
                } else {
                  value[control.key] = this.assignmentInfo[control.key];
                }
              }
            }
          );

          if (files.value.sData && files.value.sData.length > 0) {
            this.uploadedFiles = files.value.sData.map( (el) => {
              el['isNew'] = false;
              return el;
            } );
          } else if (files.value.oData && files.value.oData.length > 0) {
            this.uploadedFiles = files.value.oData.map( (el) => {
              el['isNew'] = false;
              return el;
            } );
          }

          if (this.isCopyMode) {
            value['CreateEmpId'] = `(${this.user.loginEmpId}) ${this.user.name}`;
            this.createInfoForm.form.patchValue(value);
            this.createInfoFirstDialog.open();
          } else {
            this.editInfoForm.form.patchValue(value);
            this.editInfoDialog.open();
          }
        }
      );
    }
  }

  public close() {
    if (this.isCreateMode || this.isCopyMode) {
      if (this.createInfoFirstDialog.isOpen) {
        this.createInfoFirstDialog.close();
      } else {
        this.createInfoSecondDialog.close();
      }
    } else {
      this.editInfoDialog.close();
    }
  }

  public onNextStepClick() {
    this.createInfoFirstDialog.close();
    this.createInfoSecondDialog.open();
  }

  public onPreStepClick() {
    this.createInfoSecondDialog.close();
    this.createInfoFirstDialog.open();
  }

  // assignmentDetail helper
  public addBo() {
    this.assignmentDetail.caseDetails.push(_.cloneDeep(new HeadOfficeAssignmentDetail()));
  }

  public removeBo(index: number) {
    this.assignmentDetail.caseDetails.splice(index, 1);
  }

  get boFilesCount(): number {
    if (this.assignmentDetail.caseDetailUploadXLS) {
      return this.assignmentDetail.caseDetailUploadXLS.DataCount;
    }
    return 0;
    // if (this.assignmentDetail.caseDetailUploadXLS.length === 0 ) {
    //   return 0;
    // } else {
    //   let count = 0;
    //   this.assignmentDetail.caseDetailUploadXLS.forEach(element => {
    //     count += element.count;
    //   });
    //   return count;
    // }
  }

  public downloadTemplate() {
    // todo window.open(downloadURL);
  }

  public afterChooseWFApprMgr(mgrId) {
    let body = {
      UUIDs: [this.assignmentInfo.UUID],
      WFApprMgrEmpId: mgrId,
      WFObjectName: this.managementService.getWFObjectName(),
      BaseUrl: this.router.url,
    };

    this.managementService.submitWF(body, ManagementWFType.HEADOFFFICEASSIGNMENT)
    .subscribe(
      (resp) => {
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  private reset() {
    this.editInfoForm.reset();
    this.createInfoForm.reset();
    this.uploadedFiles = [];
  }

  private initFormControls(type: HeadOfficeAssignmentDialogType) {
    switch (type) {
      case HeadOfficeAssignmentDialogType.EDIT:
        this.editInfoForm.form.controls['CaseCategory'].disable();
        this.editInfoForm.form.controls['ReplyDate'].disable();
        return;
      case HeadOfficeAssignmentDialogType.CREATE:
      case HeadOfficeAssignmentDialogType.COPY:
        return;
    }
  }

  private prepareControls() {
    this.infoControls = [
      new TextControl({
        key: 'Subject',
        label: '主旨',
        maxlength: 20,
        isWordCount: true,
        required: true,
        placeholder: '請輸入...',
        columnClasses: ['12']
      }),

      new SingleDropdownControl({
        key: 'CaseCategory',
        label: '類別',
        required: true,
        options: this.assignmentTypeOptions,
        columnClasses: ['6'],
        placeholder: '請選擇...',
      }),

      new TextControl({
        key: 'CreateEmpId',
        label: '建立者',
        required: true,
        disabled: true,
        columnClasses: ['6'],
      }),

      new DatepickerControl({
        key: 'ReplyDate',
        label: '指定回覆日期',
        columnClasses: ['6'],
        singleDatePicker: true,
        required: true,
        placeholder: '請選擇日期...'
      }),

      new TextareaControl({
        key: 'CaseContent',
        label: '內文',
        required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...',
      })
    ];
  }

  private cancelAction(form: DynamicFormComponent, dialog: IbmDialogComponent) {
    if (form.form.dirty) {
      this.cancelCheckDialog.open();
    } else {
      dialog.close();
    }
  }

  // 前端讀取 xlsx
  private convertFileToJSon(file: File): any {
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      const data = <any[][]>(XLSX.utils.sheet_to_json(ws, {header: 1}));
      // this.assignmentDetail.caseDetailUploadXLS.push({
      //   fileName: file.name,
      //   count: data.length - 1,
      //   fileIndex: this.assignmentDetail.caseDetailUploadXLS.length
      // });
    };
    reader.readAsBinaryString(file);
  }

  // override uploader method
  private onAfterAddingFile (fileItem: FileItem) {
    fileItem.withCredentials = false;
  }

  private onBuildItemForm (fileItem: any, form: any) {
    form.append('fileInfo', JSON.stringify({
      LoginUser: this.auth.getLoginUser()
    }));
  }

  private onAfterAddingAll() {
    this.isUploading = true;
  }

  private onCompleteAll() {
    this.isUploading = false;
  }

}

