import { Output, EventEmitter, ViewChild, Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-management-cancel-check-dialog',
  templateUrl: './management-cancel-check-dialog.component.html',
  styleUrls: ['./management-cancel-check-dialog.component.scss']
})
export class ManagementCancelCheckDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;

  @Input() type: string;
  @Output() save: EventEmitter<any> = new EventEmitter();
  @Output() unsave: EventEmitter<any> = new EventEmitter();

  public dialogType = {
    discard: 'discard'
  };
  constructor() { }

  public unSaveClick() {
    this.unsave.emit();
    this.dialog.close();

  }
  public onSaveClick () {
    this.save.emit();
    this.dialog.close();
  }

  public open() {
    this.dialog.open();
  }

  get header(): string {
    switch (this.type) {
      case this.dialogType.discard:
        return '是否要還原成最後生效狀態？';
      default:
        return '是否放棄儲存此次變更？';
    }
  }

  get content(): string {
    switch (this.type) {
      case this.dialogType.discard:
        return '還原至最後生效狀態，將會放棄此次所有暫存的內容。';
      default:
        return '若不儲存，將會還原成上一次的權限設定。';
    }
  }

  get showUnSave(): boolean {
    switch (this.type) {
      case this.dialogType.discard:
        return false;
      default:
        return true;
    }
  }

  get btnSaveText(): string {
    switch (this.type) {
      case this.dialogType.discard:
        return '確認';
      default:
        return '儲存';
    }
  }

  ngOnInit() {
  }

}
