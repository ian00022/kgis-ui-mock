import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { ManagementHelper } from 'app/management/management-helper';
import { IbmDialogComponent } from './../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ControlBase, TextControl } from './../../../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from '../../../shared/components/dynamic-form/dynamic-form.component';
import { ManagementService } from '../../../core/services/management.service';
import * as _ from 'lodash';
import { SingleCheckboxControl } from '../../../shared/components/dynamic-form/controls';
import { Permissions } from 'app/core/models/permissions';
import { ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper } from './../../management.model';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';


enum DialogMode {
  CREATE = 'create',
  EDIT = 'edit'
}

@Component({
  selector: 'esun-product-settings-dialog',
  templateUrl: './product-settings-dialog.component.html',
  styleUrls: ['./product-settings-dialog.component.scss']
})
export class ProductSettingsDialogComponent implements OnInit {

  @Input('productCode')
  set productCode(value: any) {
    if (value || value === 0 || value === '0') {
      this.code = value;
    } else {
      this.code = '';
    }
  }
  get productCode(): any {
    return this.code;
  }

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  @Output('reviewAction') reviewAction: EventEmitter<boolean> = new EventEmitter();
  @Output('afterCreateOrUpdate') afterCreateOrUpdate: EventEmitter<any> = new EventEmitter();

  public prodSettingInfo: any = {};

  public prodSettingControls: ControlBase<any>[] = [];
  public Permissions = Permissions;
  public modelChanges;

  private code: string = '';
  private hasSData = false;
  constructor(
    private managementService: ManagementService,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.prepareControls();
  }


  get getDialogHeaderStatusClass(): string {
    if (this.prodSettingInfo) {
      return ManagementHelper.headerTagStatusClass(this.prodSettingInfo.status);
    }
    return ManagementHelper.headerTagStatusClass('');
  }

  get dialogMode(): DialogMode {
    if (this.code === '') {
      return DialogMode.CREATE;
    }
    return DialogMode.EDIT;
  }

  get isCreateMode(): boolean {
    return this.dialogMode === DialogMode.CREATE;
  }

  public open() {
    this.prodSettingInfo = {};
    this.form.form.reset();
    this.modelChanges = {};
    if (this.isCreateMode) {

      this.setProductSettingFormEditable(true);
      this.dialog.open();
    } else {
      this.managementService.getProductSettingByProdcutCode(this.code).subscribe(
        (resp) => {

          this.prodSettingInfo = ManagementHelper.handleManagementDisplayData(resp.value);
          if (this.prodSettingInfo.status === ManagementWFStatus.STAGE_REVIEW ||
            this.prodSettingInfo.status === ManagementWFStatus.INACTIVE) {
            this.setProductSettingFormEditable(false);
          } else {
            this.setProductSettingFormEditable(true);
            this.form.form.controls['ProductCode'].disable();
          }
          this.setProductSettingFormValue(this.prodSettingInfo);

          if (this.prodSettingInfo.status !== ManagementWFStatus.ACTIVE &&
              this.prodSettingInfo.status !== ManagementWFStatus.INACTIVE) {
            let changes = [];
            this.prodSettingControls.forEach(
              (el) => {
                if (resp.value.sData[el.key] !== resp.value.oData[el.key]) {
                  changes.push({
                    key: el.key,
                    valueAfter: resp.value.sData[el.key],
                    valueBefore: resp.value.oData[el.key],
                  });
                }
              }
            );
            this.modelChanges = changes;
          }

          this.dialog.open();
        }
      );
    }
  }

  public afterClosed() {
    // this.initInfo();
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.ManagementWFStatusLabelMap[status];
  }

  /**
   * action buttons by status
   */

  get discardable(): boolean {
    return ManagementHelper.discardable(this.prodSettingInfo);
  }
  get showDisableBtn(): boolean {
    return ManagementHelper.showDisableBtn(this.prodSettingInfo);
  }
  get showEnableBtn(): boolean {
    return ManagementHelper.showEnableBtn(this.prodSettingInfo);
  }
  get showSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.prodSettingInfo) || this.isCreateMode;
  }
  get showReviewBtn(): boolean {
    return ManagementHelper.showReviewBtn(this.prodSettingInfo);
  }

  get enableSaveBtn(): boolean {
    if (isNullOrUndefined(this.prodSettingInfo.status)) {
      return this.form.form.valid;
    } else {
      if (this.prodSettingInfo.status === ManagementWFStatus.STAGE) {
        return this.form.form.valid;
      } else if (this.prodSettingInfo.status === ManagementWFStatus.STAGE_REJECT || this.prodSettingInfo.status === ManagementWFStatus.ACTIVE) {
        return this.form.form.valid && this.form.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableTempSaveBtn(): boolean {
    return this.enableSaveBtn && this.form.form.dirty;
  }

  public roleActivationClick(active: boolean) {
    this.managementService.updateProductSetting(_.assign({}, this.prodSettingInfo, { ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE }))
    .subscribe(
      (resp) => {
        if (resp.isOk) {
          this.dialog.close();
          this.chooseMgrDialog.open();
          // this.afterCreateOrUpdate.emit();
        }
      }
    );
  }

  public onSaveClick(type: string) {
    if (this.isCreateMode) {
      let body = _.assign({ActiveCode: ManagementWFStatus.ACTIVE}, this.form.form.value);
      this.managementService.createProductSetting(body)
        .subscribe(
          (resp) => {
            this.dialog.close();
            this.afterCreateOrUpdate.emit();
          }
        );
    } else if (type === 'temp') {
      let body = _.assign({}, this.prodSettingInfo, this.form.form.value);
      this.managementService.updateProductSetting(body)
      .subscribe(
        (resp) => {
          this.dialog.close();
          this.afterCreateOrUpdate.emit();
        }
      );
    }  else {
      this.dialog.close();
      this.chooseMgrDialog.open();
    }
  }

  public onRejectClick() {
    this.reviewAction.emit(false);
    this.dialog.close();
  }

  public onApproveClick() {
    this.reviewAction.emit(true);
    this.dialog.close();
  }

  public onCancelClick() {
    if (this.form.form.dirty) {
      this.cancelCheckDialog.open();
    } else {
      this.dialog.close();
    }
  }

  public cancelCheckSave() {
    this.onSaveClick('temp');
  }

  public cancelCheckUnSave() {
    this.dialog.close();
  }

  public discardChange() {
    this.managementService.discard(this.prodSettingInfo.UUID, ManagementWFType.PRODUCTSETTING)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            this.dialog.close();
            this.afterCreateOrUpdate.emit();
          }
        }
      );
  }

  public afterChooseWFApprMgr(mgrId) {
    let submitBody = {
      WFApprMgrEmpId: mgrId,
      WFObjectName: this.managementService.getWFObjectName(),
      BaseUrl: this.router.url,
    };
    if (this.form.form.dirty) {
      let body = _.assign({}, this.prodSettingInfo, this.form.form.value);
      this.managementService.updateProductSetting(body)
      .subscribe(
        (updateResp) => {
          if (updateResp.isOk) {
            this.managementService.getProductSettingByProdcutCode(this.prodSettingInfo.ProductCode)
              .subscribe(
                (getSettingResp) => {
                  if (getSettingResp.isOk) {
                    submitBody['UUIDs'] = [getSettingResp.value.sData.UUID];
                    this.managementService.submitWF(submitBody, ManagementWFType.PRODUCTSETTING).subscribe(
                      (resp) => {
                        this.dialog.close();
                        this.afterCreateOrUpdate.emit();
                      }
                    );
                  }
                }
              );
          }
          this.dialog.close();
          this.afterCreateOrUpdate.emit();
        }
      );
    } else {
      submitBody['UUIDs'] = [this.prodSettingInfo.UUID];
      this.managementService.submitWF(submitBody, ManagementWFType.PRODUCTSETTING).subscribe(
        (resp) => {
          this.dialog.close();
          this.afterCreateOrUpdate.emit();
        }
      );
    }
  }

  private setProductSettingFormValue(row: any) {
    if (!this.form) {
      return;
    }
    for (const key of Object.keys(row)) {
      if (this.form.form.controls[key]) {
        this.form.form.controls[key].setValue(row[key]);
      }
    }
  }

  private setProductSettingFormEditable(editable: boolean) {
    for ( const key of Object.keys(this.form.form.controls)) {
      if (editable) {
        this.form.form.controls[key].enable();
      } else {
        this.form.form.controls[key].disable();
      }
    }
  }

  private prepareControls() {
    this.prodSettingControls = [
      new TextControl({
        key: 'ProductCode',
        label: '代碼',
        columnClasses: ['6'],
        required: true,
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'ProductName',
        label: '產品名',
        columnClasses: ['6'],
        required: true,
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'ProductPeriod',
        label: '產品效期',
        addonString: '個月',
        columnClasses: ['6'],
        required: true,
        type: 'number',
        min: 0
      }),
      new TextControl({
        key: 'ExtendPeriod',
        label: '延期效期',
        addonString: '個月',
        columnClasses: ['6'],
        type: 'number',
        min: 0
      }),
      new SingleCheckboxControl({
        key: 'IsAcceptable',
        label: '可受理產品',
        columnClasses: ['12'],
        customizeClasses: ['mb-0'],
      }),
      new SingleCheckboxControl({
        key: 'IsReferral',
        label: '轉介產品',
        columnClasses: ['12'],
      })

    ];
  }
}
