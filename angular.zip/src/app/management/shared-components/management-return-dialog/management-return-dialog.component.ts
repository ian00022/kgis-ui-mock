import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { DynamicFormComponent } from '../../../shared/components/dynamic-form/dynamic-form.component';
import * as _ from 'lodash';
import { ControlBase } from '../../../shared/components/dynamic-form/controls/control-base';
import { TextareaControl } from '../../../shared/components/dynamic-form/controls/textarea-control';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ManagementWFType } from '../../management.model';
import { ManagementService } from './../../../core/services/management.service';
import { WFAction } from '../../../core/models/comm-data';
import { LoggerService } from 'app/shared/logger.service';
import { DateHelper } from './../../../shared/helper/date-helper';

@Component({
  selector: 'esun-management-return-dialog',
  templateUrl: './management-return-dialog.component.html',
  styleUrls: ['./management-return-dialog.component.scss']
})
export class ManagementReturnDialogComponent implements OnInit {

  @ViewChild('form') form: DynamicFormComponent;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('doubleCheck') doubleCheckDialog: IbmDialogComponent;

  @Input('dataSource')
  set dataSource(value: any[]) {
    if (value) {
      this.returnList = value;
    }
  }
  get dataSource(): any[] {
    return this.returnList;
  }

  @Input('WFType') WFType: ManagementWFType;

  @Output('afterReturned') afterReturned: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];
  private returnList: any[] = [];
  private nextStep: boolean = false;
  private needCancelCheckout: boolean = true;

  constructor(
    private logger: LoggerService,
    private managementService: ManagementService,
    private router: Router
  ) { }

  get isValid() {
    return this.form.form.valid || false;
  }

  get header(): string {
    return this.returnList.length === 1 ? '退回' : `退回(${this.returnList.length})`;
  }

  get returnListDesc(): string {
    return this.returnList.length === 1 ? '' : ` ${this.returnList.length} `;
  }

  get applicants(): any[] {
    const applicant = [];
    if (this.returnList.length !== 0) {
      const applicantGroup = _.groupBy(this.returnList, 'ApplyEmpId');
      for ( const applicantKey of Object.keys(applicantGroup)) {
        const applyDates = [];
        const applyDateGroup = _.groupBy(_.map(applicantGroup[applicantKey], (el) => {
          el['UpdateDate'] = DateHelper.formatDate(el['UpdateDate']);
          return el;
        }), 'UpdateDate');
        for (const dateKey of Object.keys(applyDateGroup)) {
          applyDates.push({
            date: dateKey,
            count: applyDateGroup[dateKey].length
          });
        }
        applicant.push({
          applicant: applicantGroup[applicantKey][0].applicant,
          applicantId: applicantKey,
          applyDates: applyDates
        });
      }
    }
    return applicant;
  }

  public onSubmit(value) {
    this.needCancelCheckout = false;
    this.logger.debug('rejectData: ', value);
    this.logger.debug('return returnList: ', this.returnList);
    let body = {
      UUIDs: this.returnList.map( el => el.UUID),
      Action: WFAction.REJECT,
      Comment: value.returnReason,
      BaseUrl: this.router.url,
      WFObjectName: this.managementService.getWFObjectName()
    };

    this.managementService.checkinWF(body, this.WFType).subscribe(
      (resp) => {
        this.logger.debug(resp);
        this.doubleCheckCancel();
        this.afterReturned.emit();
      }
    );
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    this.nextStep = true;
    this.doubleCheckDialog.open();
    this.dialog.close();
  }
  public cancel() {
    this.nextStep = false;
    this.form.reset();
    this.dialog.close();
  }

  public doubleCheckConfirm() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }

  public doubleCheckCancel() {
    this.doubleCheckDialog.close();
  }

  public afterClose() {
    if (!this.nextStep) {
      this.checkoutWF();
    }
  }

  public doubleCheckAfterClose() {
    this.form.reset();
    this.checkoutWF();
    this.nextStep = false;
  }

  ngOnInit() {
    this.prepareControls();
  }

  private prepareControls() {
    this.controls = [
      // 退回原因
      new TextareaControl({
        key: 'returnReason',
        label: '說明',
        isWordCount: true,
        required: true,
        columnClasses: ['12'],
        placeholder: '請簡述退回原因'
      })
    ];
  }

  private checkoutWF() {
    if (this.needCancelCheckout) {
      let body = {
        UUIDs: this.returnList.map( el => el.UUID),
        WFObjectName: this.managementService.getWFObjectName()
      };

      this.managementService.cancelCheckoutWF(body, this.WFType)
      .subscribe(
        (resp) => {
          this.logger.debug(resp);
        }
      );
    } else {
      this.needCancelCheckout = true;
    }
  }
}
