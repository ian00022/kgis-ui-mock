import { SingleDropdownControl } from './../../../shared/components/dynamic-form/controls/single-dropdown-control';
import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { ControlBase } from './../../../shared/components/dynamic-form/controls/control-base';

@Component({
  selector: 'esun-choose-approve-manager-dialog',
  templateUrl: './choose-approve-manager-dialog.component.html',
  styleUrls: ['./choose-approve-manager-dialog.component.scss']
})
export class ChooseApproveManagerDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;
  @Output() afterChooseWFApprMgr: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];

  constructor() { }

  ngOnInit() {
    this.prepareControls();
  }

  get isValid(): boolean {
    return this.form.form.valid;
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    this.afterChooseWFApprMgr.emit(this.form.form.value['WFApprMgrEmpId']);
    this.dialog.close();
    this.form.reset();
  }

  public cancel() {
    this.dialog.close();
    this.form.reset();
  }

  private prepareControls() {
    this.controls = [
      new SingleDropdownControl({
        key: 'WFApprMgrEmpId',
        label: '審核主管',
        required: true,
        columnClasses: ['12'],
        options: [
          {value: '0002', label: '王經理'}
        ],
        placeholder: '請選擇...'
      })
    ];
  }

}
