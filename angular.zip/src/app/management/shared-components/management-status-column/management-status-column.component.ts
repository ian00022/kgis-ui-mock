import { Component, OnInit, Input } from '@angular/core';
import { ManagementWFStatusHelper, ManagementWFStatus } from '../../management.model';

@Component({
  selector: 'esun-management-status-column',
  templateUrl: './management-status-column.component.html',
  styleUrls: ['./management-status-column.component.scss']
})
export class ManagementStatusColumnComponent implements OnInit {

  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

  get isRejectMode(): boolean {
    if (this.data && this.data.status ) {
      return this.data.status === ManagementWFStatus.STAGE_REJECT;
    }
    return false;
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

}
