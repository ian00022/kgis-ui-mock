import { Component, OnInit, ViewChild, Input, EventEmitter, Output, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ManagementService } from '../../../core/services/management.service';
import { ManagementHelper } from '../../management-helper';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { ISelectOptionModel } from '../../../core/models/comm-data';
import { SelectOptionsService } from '../../../shared/services/select-options.service';
import { Permissions } from 'app/core/models/permissions';
import {
  ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper,
  OverdueEvent, OverdueNoticeFrequency, OverdueNoticeType, OverdueType
} from '../../management.model';
import { LoggerService } from 'app/shared/logger.service';
import { NzNotificationService } from 'ng-zorro-antd';
import * as moment from 'moment';
import { AuthService } from 'app/core/services/auth.service';
import { formInputsFromData } from 'app/shared/functions/common';
import { LabelsFromOptionPipe } from 'app/shared/pipes/labels-from-option.pipe';

enum  DialogMode {
  CREATE = 'create',
  EDIT = 'edit',
  VIEW = 'view'
}

@Component({
  selector: 'esun-expiry-notification-dialog',
  templateUrl: './expiry-notification-dialog.component.html',
  styleUrls: ['./expiry-notification-dialog.component.scss']
})
export class ExpiryNotificationDialogComponent implements OnInit {

  @Input() dialogType;

  @Input('UUID')
  set UUID(value: any) {
    if (value || value === 0 || value === '0') {
      this.expiryNotificationId = value;
      this.dialogMode = DialogMode.EDIT;
    } else {
      this.expiryNotificationId = '';
      this.dialogMode = DialogMode.CREATE;
    }
  }
  get UUID(): any {
    return this.expiryNotificationId;
  }

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('chooseMgr') chooseMgr: IbmDialogComponent;

  @Output('reviewAction') reviewAction = new EventEmitter();
  @Output('getList') getList = new EventEmitter();

  public expiryNotificationInfo = {
    UUID: '',
    Type: '',
    Event: '',
    SourceType: '',
    ProductType: '',
    status: '',
    OverdueRules: []
  };
  public Permissions = Permissions;
  public oData:any = {};
  public sData:any = {};

  public isDiscardCancelCheck = false;
  /**
   *
   * all options
   * @type {ISelectOptionModel[]}
   * @memberof ExpiryNotificationDialogComponent
   */
  public TypeOptions: ISelectOptionModel[] = [];
  public SourceTypeOptions: ISelectOptionModel[] = [];
  public ProductTypeOptions: ISelectOptionModel[] = [];
  public EventOptions: ISelectOptionModel[] = [];
  public MethodOptions: ISelectOptionModel[] = [];
  public notifyToOptions: ISelectOptionModel[] = [];
  public TimingTypeOptions: ISelectOptionModel[] = [];
  public NoticeFrequencyOptions: ISelectOptionModel[] = [];
  public managementStatusOptions: ISelectOptionModel[] = [];

  // create, edit
  public dialogMode: DialogMode = DialogMode.CREATE;
  private overdueReviewUUID;
  private expiryNotificationId: string = '';
  private originalExpiryNotificationInfo;
  private defaultRule = {
    NoticeType: [],
    NoticeTo: '',
    NoticeCC: '',
    Title: '',
    Content: '',
    TimingType: '',
    TimingValue: '',
    NoticeFrequency: '1',
    collapsed: true
  };
  private defaultInfo = {
    UUID: '',
    Type: '',
    Event: '',
    SourceType: '',
    ProductType: '',
    status: '',
    OverdueRules: [this.defaultRule]
  };

  constructor(
    private router: Router,
    private managementService: ManagementService,
    private options: SelectOptionsService,
    private logger: LoggerService,
    private notification: NzNotificationService,
    private auth: AuthService,
    private ref: ChangeDetectorRef,
  ) {
    const option = this.options.getOptions(
      [
        'notifyReason',
        'boSource',
        'overdueProductType',
        'notifyEvent',
        'notifyMethod',
        'notifyTo',
        'dateType',
        'overdueFrequency',
        'managementStatus'
      ]);
    this.TypeOptions = option['notifyReason'];
    this.SourceTypeOptions = option['boSource'];
    this.ProductTypeOptions = option['overdueProductType'];
    this.EventOptions = option['notifyEvent'];
    this.MethodOptions = option['notifyMethod'];
    this.notifyToOptions = option['notifyTo'];
    this.TimingTypeOptions = option['dateType'];
    this.NoticeFrequencyOptions = option['overdueFrequency'];
    this.managementStatusOptions = option['managementStatus'];
    this.initInfo();
  }

  ngOnInit() {
  }

  get getDialogHeaderStatusClass(): string {
    if (this.expiryNotificationInfo) {
      return ManagementHelper.headerTagStatusClass(this.expiryNotificationInfo.status);
    }
    return ManagementHelper.headerTagStatusClass('');
  }

  get isCreateMode(): boolean {
    return this.dialogMode === DialogMode.CREATE;
  }

  get isEditMode(): boolean {
    return this.dialogMode === DialogMode.EDIT &&
      this.expiryNotificationInfo.status !== ManagementWFStatus.STAGE_REVIEW;
  }

  get isRejectedMode(): boolean {
    // console.log(this.dialogMode, this.expiryNotificationInfo.status);
    return this.dialogMode === DialogMode.EDIT &&
      this.expiryNotificationInfo.status === ManagementWFStatus.STAGE_REJECT;
  }

  get isViewMode(): boolean {
    return this.dialogType === DialogMode.VIEW;
  }

  get getTimingLabel(): string {
    switch (this.expiryNotificationInfo.Type) {
      case OverdueType.ASSIGN_NOT_YET:
        return '名單建立日期';
      case OverdueType.ASSIGN_ALREADY:
      case OverdueType.EXECUTE_NOT_YET:
        return '名單分派日期';
      case OverdueType.EXPIRED:
        return '下次追蹤日期';
      case OverdueType.EXPIRE_NOTIFICATION:
        return '名單到期日';
      default:
        return '';
    }
  }

  public open() {
    if (this.isCreateMode) {
      this.initInfo();
      this.dialog.open();
    } else {
      this.overdueReviewUUID = this.UUID;
      this.managementService.getOverdueInfo(this.UUID).subscribe(
        (info) => {
          this.managementService.getOverdueInfoDetail(this.UUID).subscribe(detail => {
            const overdueDetail = {
              ...ManagementHelper.handleManagementDisplayData(info.value)
            };
            this.oData = _.cloneDeep(info.value.oData);
            this.sData = _.cloneDeep(info.value.sData || { ...info.value.oData, isOData: true });

            this.overdueReviewUUID = this.sData.UUID; // 送審帶入的是暫存的UUID

            // this.sData.Event = '5'; // for test

            if (detail.isOk && !_.isEmpty(detail.value)) {
              overdueDetail.OverdueRules = detail.value.sData || detail.value.oData;
              overdueDetail.OverdueRules = overdueDetail.OverdueRules.map((rule, idx) => {
                rule.collapsed = (idx === 0) ? true : false;
                return rule;
              });
              this.oData.OverdueRules = _.cloneDeep(detail.value.oData);

              // this.oData.OverdueRules[0].TimingValue = 2; // for test
              // this.oData.OverdueRules[0].TimingType = '2'; // for test
              // this.oData.OverdueRules[0].Content = 'iarigidfhgliaerh'; // for test

              // tslint:disable-next-line
              this.sData ? this.sData.OverdueRules = _.cloneDeep(detail.value.sData || { ...detail.value.oData, isOData: true }) : null;
            } else {
              overdueDetail.OverdueRules = [];
              this.oData.OverdueRules = [];
              // tslint:disable-next-line
              this.sData ? this.sData.OverdueRules = [] : null;
            }
            this.logger.debug('overdueDetail: ', overdueDetail);
            this.logger.debug('oData: ', this.oData);
            this.logger.debug('sData: ', `is oData? ${this.sData.isOData}`, this.sData);

            this.originalExpiryNotificationInfo = _.cloneDeep(overdueDetail);
            this.expiryNotificationInfo = _.cloneDeep(overdueDetail);
            this.dialog.open();
          });
        }
      );
    }
  }

  public afterClosed() {
    // this.initInfo();
  }

  public addRule() {
    this.expiryNotificationInfo.OverdueRules.push(_.cloneDeep(this.defaultRule));
  }

  /**
   * action buttons by status
   */
  get discardable(): boolean {
    return this.expiryNotificationInfo.status === ManagementWFStatus.STAGE;
  }
  get showDisableBtn(): boolean {
    return this.expiryNotificationInfo.status === ManagementWFStatus.ACTIVE;
  }
  get showEnableBtn(): boolean {
    return this.expiryNotificationInfo.status === ManagementWFStatus.INACTIVE;
  }
  get showSaveBtn(): boolean {
    return _.includes([
      ManagementWFStatus.ACTIVE,
      ManagementWFStatus.STAGE,
      ManagementWFStatus.STAGE_REJECT ], this.expiryNotificationInfo.status) &&
           this.isEditMode;
  }

  get showReviewBtn(): boolean {
    return this.expiryNotificationInfo.status === ManagementWFStatus.STAGE_REVIEW;
  }

  get disableSaveBtn(): boolean {
    // return _.isEqual(this.originalExpiryNotificationInfo, this.expiryNotificationInfo);
    // this.logger.debug('get disableSaveBtn():', !this.isAllValid());
    return !this.isAllValid();
  }

  get disableSaveToReviewBtn(): boolean {
    // return _.isEqual(this.originalExpiryNotificationInfo, this.expiryNotificationInfo);
    return !this.isAllValid(true);
  }

  get disableInputs(): boolean {
    return _.includes([
      ManagementWFStatus.INACTIVE,
      ManagementWFStatus.STAGE_REVIEW
    ], this.expiryNotificationInfo.status) || this.isViewMode;
  }

  get hasChangedFormData(): boolean {
    const originalOverdue = _.cloneDeep(this.originalExpiryNotificationInfo);
    const expiryOverdue = _.cloneDeep(this.expiryNotificationInfo);
    originalOverdue.OverdueRules = originalOverdue.OverdueRules.map(rule => { delete rule.collapsed; return rule; });
    expiryOverdue.OverdueRules = expiryOverdue.OverdueRules.map(rule => { delete rule.collapsed; return rule; });

    return !_.isEqual(originalOverdue, expiryOverdue);
  }

  public isAllValid(toReview: boolean = false): boolean {
    let requiredFilled = true;

    if (
      _.isEmpty(this.expiryNotificationInfo.Type) ||
      _.isEmpty(this.expiryNotificationInfo.SourceType) ||
      _.isEmpty(this.expiryNotificationInfo.ProductType)
    ) {
      requiredFilled = false;
    }
    // <label>通知事件
    // <span *ngIf="expiryNotificationInfo.Type === '2'" class="markRed">*</span>
    // </label>
    // tslint:disable-next-line:one-line
    else if (
      (this.expiryNotificationInfo.Type === OverdueType.ASSIGN_ALREADY) &&
      _.isEmpty(this.expiryNotificationInfo.Event)
    ) {
      requiredFilled = false;
    }
    // 暫存時要判斷的項目 跟原本的input完全相同就不能暫存
    // tslint:disable-next-line:one-line
    else if ( !toReview && !this.hasChangedFormData ) {
      requiredFilled = false;
    }
    // OverdueRules 細項的必填欄位都有填
    // tslint:disable-next-line:one-line
    else {
      _.forEach(this.expiryNotificationInfo.OverdueRules, (item) => {
        if (_.includes([
          item.NoticeType,
          item.NoticeTo,
          item.Title,
          item.Content,
          item.TimingType,
          item.TimingValue,
          item.NoticeFrequency
        ], '') || _.isEmpty(item.NoticeType)) {
          requiredFilled = false;
        }
      });
    }
    // if (this.dialog.isOpen) { this.logger.debug('this.hasChangedFormData: ', this.hasChangedFormData, ' toReview: ', toReview); }
    return requiredFilled;
  }

  public deleteRule(event, index) {
    event.preventDefault();
    if (!_.isEmpty(this.expiryNotificationInfo.OverdueRules)) {
      this.expiryNotificationInfo.OverdueRules = this.expiryNotificationInfo.OverdueRules.filter((rule, idx) => {
        return idx !== index;
      });
    }
  }

  public roleActivationClick(active: boolean) {
    this.logger.debug('temp save: ', this.expiryNotificationInfo);
    this.managementService.updateOverdue({
        ...this.generateUpdateForm,
        ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE
      }).subscribe(res => {
        if (res.isOk) {
          this.notification.success('更新成功', '');
          this.getList.emit();
          this.dialog.close();
        }
      });
  }

  get canDiscard(): boolean {
    // oData.ModifyStatus = '1' 一定是新增，新增的資料不可被復原
    return this.expiryNotificationInfo.status === ManagementWFStatus.STAGE &&
      (this.oData || { ModifyStatus: '' }).ModifyStatus !== '1';
  }

  /**
   * 待api能提供正確的UUID再把這邊移掉
   * @readonly
   * @memberof ExpiryNotificationDialogComponent
   */
  // get generateUUID() {
  //   let d = Number(moment().format('s'));
  //   return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
  //     // tslint:disable-next-line
  //     const r = (d + Math.random() * 16) % 16 | 0;
  //     d = Math.floor(d / 16);
  //     // tslint:disable-next-line
  //     return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  //   });
  // }

  get generateCreateForm() {
    const gObj = {
      ..._.cloneDeep(this.expiryNotificationInfo),
      ActiveCode: ManagementWFStatus.ACTIVE,
    };

    delete gObj.status;
    delete gObj.UUID;

    gObj.OverdueRules = gObj.OverdueRules.map(rule => {
      // rule.UUID = this.generateUUID; // 為了能新增成功先塞UUID = =
      rule.NoticeType = rule.NoticeType.join(','); // 子table改join array
      // rule.CreateEmpId = this.auth.getLoginUser().loginEmpId;
      // rule.UpdateEmpId = this.auth.getLoginUser().loginEmpId;
      delete rule.collapsed;

      return rule;
    });

    return gObj;
  }

  get generateUpdateForm() {
    const gObj = {
      ..._.cloneDeep(this.expiryNotificationInfo),
      // ActiveCode: '1',
    };

    delete gObj.status;

    gObj.OverdueRules = gObj.OverdueRules.map(rule => {
      rule.NoticeType = rule.NoticeType.join(','); // 子table改join array
      // rule.CreateEmpId = this.auth.getLoginUser().loginEmpId;
      // rule.UpdateEmpId = this.auth.getLoginUser().loginEmpId;
      delete rule.collapsed;

      return rule;
    });

    return gObj;
  }

  public onSaveClick(type: string) {
    // this.logger.debug(type);
    switch (type) {
      case 'create':
        this.logger.debug('create: ', this.expiryNotificationInfo);
        this.managementService.createOverdue(this.generateCreateForm).subscribe(res => {
          if (res.isOk) {
            this.notification.success('新增成功', '');
            this.getList.emit();
            this.dialog.close();
          }
        });
        break;
      case 'temp':
        this.logger.debug('temp save: ', this.expiryNotificationInfo);
        this.managementService.updateOverdue(this.generateUpdateForm).subscribe(res => {
          if (res.isOk) {
            this.notification.success('更新成功', '');
            this.getList.emit();
            this.dialog.close();
          }
        });
        break;
      case 'save':
        this.chooseMgr.open();
        break;
      default:
        break;
    }
  }

  public setReviewSubmitData(selectedRowId, mgrId, updateData?) {
    const options: any = {
      UUIDs: selectedRowId,
      WFApprMgrEmpId: mgrId,
      ApplyEmp: this.auth.getLoginUser(),
      // UpdateData: {},
      BaseUrl: this.router.url,
      WFObjectName: this.managementService.getWFObjectName()
    };

    if (!_.isEmpty(updateData)) { options.UpdateData = updateData; }

    return options;
  }

  public afterChooseWFApprMgr(mgrId) {
    const submitWF = (UUID?) => {
      this.managementService.submitWF(this.setReviewSubmitData(
        [UUID || this.expiryNotificationInfo.UUID],
        mgrId
      ), ManagementWFType.OVERDUE).subscribe(() => {
        this.getList.emit();
        this.dialog.close();
      });
    };

    if (this.hasChangedFormData) {
      this.managementService
        .updateOverdue(this.generateUpdateForm)
        .subscribe(() => {
          // 存檔後重新打才拿得到oData & sData
          this.managementService
            .getOverdueInfo(this.oData.UUID)
            .subscribe((data) => {
              this.overdueReviewUUID = data.value.sData.UUID;
              submitWF(this.overdueReviewUUID);
            });
        });
    } else {
      submitWF();
    }
  }

  public onRejectClick() {
    this.reviewAction.emit({
      review: false,
      UUID: this.overdueReviewUUID
    });
  }

  public onApproveClick() {
    this.reviewAction.emit({
      review: true,
      UUID: this.overdueReviewUUID
    });
  }

  /**
   * btn 還原至最後生效狀態
   * sData.UUID
   */
  public discard() {
    this.managementService
      .discard(this.expiryNotificationInfo.UUID, ManagementWFType.OVERDUE)
      .subscribe((data) => {
        this.logger.debug(`sData.UUID: ${this.expiryNotificationInfo.UUID} 還原至最後生效狀態 discardOverdue: `, data);
        if (data.isOk) {
          this.notification.success('已還原至最後生效狀態', '');
          this.getList.emit();
          // reload this dialog
          this.dialog.close();
          this.dialog.open();
        }
      });
  }

  public onCancelClick(type?: string) {
    if (!_.isEqual(this.originalExpiryNotificationInfo, this.expiryNotificationInfo)) {
      if (type === 'discard') { this.isDiscardCancelCheck = true; }
      this.cancelCheckDialog.open();
    } else {
      this.dialog.close();
    }
  }

  public cancelCheckSave() {
    if (this.isDiscardCancelCheck) {
      this.isDiscardCancelCheck = false;
      this.discard();
    } else {
      this.onSaveClick('temp');
    }
  }

  public cancelCheckUnSave() {
    this.dialog.close();
  }

  public displayModelChange(key) {
    return !_.isEqual(_.at(this.oData, key), _.at(this.sData, key));
  }

  public displayChangePopover(label, key, selectOptions?, type?) {
    let valueBefore, valueAfter;
    if (type === 'Timing') {
      valueBefore = String(_.at(this.oData, key[0])) + new LabelsFromOptionPipe().transform(_.at(this.oData, key[1]), selectOptions);
      valueAfter = String(_.at(this.sData, key[0])) + new LabelsFromOptionPipe().transform(_.at(this.sData, key[1]), selectOptions);
    } else {
      valueBefore = _.isEmpty(selectOptions) ? String(_.at(this.oData, key)) : new LabelsFromOptionPipe().transform(_.at(this.oData, key), selectOptions);
      valueAfter = _.isEmpty(selectOptions) ? String(_.at(this.sData, key)) : new LabelsFromOptionPipe().transform(_.at(this.sData, key), selectOptions);
    }
    return {
      label: label,
      valueBefore: valueBefore,
      valueAfter: valueAfter
    };
  }

  private initInfo() {
    this.originalExpiryNotificationInfo = _.cloneDeep(this.defaultInfo);
    this.expiryNotificationInfo = _.cloneDeep(this.defaultInfo);
  }

}

