import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementStatusInfoDialogComponent } from './management-status-info-dialog.component';

describe('ManagementStatusInfoDialogComponent', () => {
  let component: ManagementStatusInfoDialogComponent;
  let fixture: ComponentFixture<ManagementStatusInfoDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagementStatusInfoDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementStatusInfoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
