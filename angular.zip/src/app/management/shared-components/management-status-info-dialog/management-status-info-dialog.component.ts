import { Component, OnInit, ViewChild } from '@angular/core';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-management-status-info-dialog',
  templateUrl: './management-status-info-dialog.component.html',
  styleUrls: ['./management-status-info-dialog.component.scss']
})
export class ManagementStatusInfoDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  public description: any;
  public objKeys = Object.keys;

  constructor() { }

  ngOnInit() {
    this.initStatusDescription();
  }

  public open() {
    this.dialog.open();
  }

  public close() {
    this.dialog.close();
  }

  private initStatusDescription() {
    this.description =  {
      '生效': '當顯示此標示時，即代表該筆為生效資訊',
      '停用': '當顯示此標示時，即代表該筆資訊已被停用',
      '待覆核': '當顯示此標示時，即代表該筆資訊待主管覆核',
      '暫存': '當顯示此標示時，即代表該筆資訊尚未送出',
      '主管退回': '當顯示此標示時，即代表該筆資訊遭主管退回'
    };
  }

}
