import { DateHelper } from 'app/shared/helper/date-helper';
import { NotificationPublishCategory } from './../../management.model';
import { RadioControl } from '../../../shared/components/dynamic-form/controls/radio-control';
import { Input, ViewChild, Output, EventEmitter, AfterViewInit, OnChanges } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ManagementHelper } from '../../management-helper';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import {
  ControlBase,
  TextControl,
  TextareaControl,
  SingleDropdownControl,
  DatepickerControl,
  MultiSelectControl
} from '../../../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import * as moment from 'moment';
import * as _ from 'lodash';
import { ValidatorFn, FormGroup } from '@angular/forms';
import { Permissions } from 'app/core/models/permissions';
import { AuthService } from 'app/core/services/auth.service';
import { ManagementWFStatus, ManagementWFStatusHelper, ManagementWFType } from '../../management.model';
import { SelectOptionsService } from '../../../shared/services/select-options.service';
import { ManagementService } from '../../../core/services/management.service';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';

enum NotificationDialogMode {
  EDIT = 'edit',
  CREATE = 'create',
  VIEW = 'view'
}


@Component({
  selector: 'esun-notification-dialog',
  templateUrl: './notification-dialog.component.html',
  styleUrls: ['./notification-dialog.component.scss']
})
export class NotificationDialogComponent implements OnInit, AfterViewInit, OnChanges {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('notificationForm') notificationForm: DynamicFormComponent;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  @Input('dialogType')
  set dialogType(value) {
    if (value) {
      this.notificationDialogMode = value;
    }
  }
  get dialogType(): any {
    return this.notificationDialogMode;
  }

  @Input('disabledAll')
  set disabledAll(value: boolean) {
    if (this.privateDisabledAll !== value && this.notificationForm.form ) {
      this.setNotificationFormDisable(value);
    }
    this.privateDisabledAll = value;
  }
  get disabledAll(): boolean {
    return this.privateDisabledAll;
  }
  @Input('info')
  set info(value: any) {
    if (value) {
      this.notificationinfo = value;
    }
  }
  get info(): any {
    return this.notificationinfo;
  }
  @Output('reviewAction') reviewAction: EventEmitter<boolean> = new EventEmitter();
  @Output('afterCreateOrUpdate') afterCreateOrUpdate: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];
  public paramModelChanges = [];
  public notificationDialogMode;
  public Permissions = Permissions;

  // options should take from backend
  public managers: any = [
    { value: '0002', label: '(0002)王經理'}
  ];
  public publishCategory: any = [];
  public publishTargets: any = [];

  private user;
  private notificationinfo: any = {};
  // private defaultValue: any = {
  //   subject: '',
  //   Content: '',
  //   applicant: '',
  //   reviewManager: '',
  //   importance: '1',
  //   releaseDate: '',
  //   endDate: '',
  //   publishType: '',
  //   publishTargets: '',
  // };
  private privateDisabledAll: boolean;
  private dateFormatter = 'YYYY/MM/DD';

  constructor(
    private auth: AuthService,
    private options: SelectOptionsService,
    private managementService: ManagementService,
    private router: Router
  ) {
    this.user = this.auth.getLoginUser();
    this.publishCategory = this.options.getOptions('publishCategory');
  }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.notificationForm.form.get('PublishDate').valueChanges.subscribe(value => {
      let control = _.find(this.notificationForm.controls, ['key', 'PublishEndDate']);
      control.minDate = (moment(value).isValid()) ? value : false;
    });

    this.notificationForm.form.get('NotificationCategory').valueChanges.subscribe(value => {
      this.notificationForm.form.get('NotificationTargets').setValue('');
      this.publishTargets.splice(0, this.publishTargets.length);
      if (value === NotificationPublishCategory.ALL) {
        this.notificationForm.form.get('NotificationTargets').disable();
      } else {
        // todo 取得推播對象 API
        this.publishTargets.push({
          label: '板橋分行',
          value: '0001'
        });
        this.notificationForm.form.get('NotificationTargets').enable();
      }
    });
    // this.notificationForm.form.valueChanges.subscribe(value => {
    //   // this.notificationForm.controls = [...this.notificationForm.controls.map(item => {
    //   //   if (item.key === 'PublishEndDate') {
    //   //     item.minDate = (moment(value.PublishDate).isValid()) ? value.PublishDate : false;
    //   //   }
    //   //   return item;
    //   // })];
    //   let control = _.find(this.notificationForm.controls, ['key', 'PublishEndDate']);
    //   console.log(control);
    //   console.log(value);
    //   console.log(this.notificationForm.form.value)
    //   control.minDate = (moment(value.PublishDate).isValid()) ? value.PublishDate : false;
    // });
  }

  public searchFormValidators: ValidatorFn = (group: FormGroup): { [key: string]: any } => {
    let isValid = true;
    const releaseDate = moment(group.controls['PublishDate'].value), endDate = moment(group.controls['PublishEndDate'].value);
    isValid = endDate.isSameOrAfter(releaseDate) || !group.controls['PublishDate'].value || !group.controls['PublishEndDate'].value ? true : false;
    return isValid ? null : { dateRangeError: '結束日期應大於等於發布日期' };
  }
  /**
   * action buttons by notification state
   */
  get discardable(): boolean {
    return ManagementHelper.discardable(this.info) && this.notificationDialogMode === NotificationDialogMode.EDIT;
  }
  get showDisableBtn(): boolean {
    return ManagementHelper.showDisableBtn(this.info);
  }
  get showEnableBtn(): boolean {
    return ManagementHelper.showEnableBtn(this.info);
  }
  get showSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.info) || this.notificationDialogMode === NotificationDialogMode.CREATE;
  }
  get showReviewBtn(): boolean {
    return ManagementHelper.showReviewBtn(this.info);
  }
  get enableSaveBtn(): boolean {
    if (isNullOrUndefined(this.info.status)) {
      return this.notificationForm.form.valid;
    } else {
      if (this.info.status === ManagementWFStatus.STAGE) {
        return this.notificationForm.form.valid;
      } else if (this.info.status === ManagementWFStatus.STAGE_REJECT || this.info.status === ManagementWFStatus.ACTIVE) {
        return this.notificationForm.form.valid && this.notificationForm.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableTempSaveBtn(): boolean {
    return this.enableSaveBtn && this.notificationForm.form.dirty;
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

  /**
   * notification form action
   */
  // todo: 打一次 API 就可以將狀態改為待覆核，需等到 update api 吐出新的UUID (sData.UUID)
  public roleActivationClick(active: boolean) {
    let body = _.assign( _.cloneDeep(this.info), this.notificationForm.form.value,
      { ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE }
    );
    // 未定義時為空陣列
    if (!body['NotificationTargets']) {
      body['NotificationTargets'] = [];
    }
    this.managementService.updateNotification(body).subscribe(
      (resp) => {
        this.dialog.close();
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  public onSaveClick(type: string) {
    if (this.notificationDialogMode === NotificationDialogMode.CREATE) {
      let body = _.assign({ ActiveCode: ManagementWFStatus.ACTIVE }, this.notificationForm.form.value);
      // 未定義時為空陣列
      if (!body['NotificationTargets']) {
        body['NotificationTargets'] = [];
      }
      this.managementService.createNotification(body).subscribe(
        (resp) => {
          console.log(resp);
          this.dialog.close();
          this.afterCreateOrUpdate.emit();
        }
      );
    } else if (type === 'temp') {
      console.log(this.notificationForm.form.value);
      let body = _.assign({}, this.info, this.notificationForm.form.value);
      // 未定義時為空陣列
      if (!body['NotificationTargets']) {
        body['NotificationTargets'] = [];
      }
      this.managementService.updateNotification(body).subscribe(
        (resp) => {
          this.dialog.close();
          this.afterCreateOrUpdate.emit();
        }
      );
    } else {
      this.dialog.close();
      this.chooseMgrDialog.open();
    }

  }

  public onCancelClick() {
    if (this.notificationForm.form.dirty) {
      this.cancelCheckDialog.open();
    } else {
      this.dialog.close();
    }
  }

  public onRejectClick() {
    this.reviewAction.emit(false);
  }

  public onApproveClick() {
    this.reviewAction.emit(true);
  }

  public cancelCheckSave() {
    this.onSaveClick('temp');
  }

  public cancelCheckUnSave() {
    this.dialog.close();
  }

  public afterChooseWFApprMgr(mgrId) {

    let body = {
      UUIDs: [this.info.UUID],
      WFApprMgrEmpId: mgrId,
      WFObjectName: this.managementService.getWFObjectName(),
      BaseUrl: this.router.url,
    };

    this.managementService.submitWF(body, ManagementWFType.NOTIFICATION).subscribe(
      (resp) => {
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  /**
   * dialog helper
   */
  get notificationDialogHeader(): string {
    // console.log(this.notificationDialogMode, this.dialogType);
    return this.notificationDialogMode === NotificationDialogMode.CREATE ?
        '新增推播通知' :
      this.notificationDialogMode === NotificationDialogMode.VIEW ?
        '檢視推播通知' : '編輯推播通知';
  }

  get getDialogHeaderStatusClass(): string {
    return this.info ? ManagementHelper.headerTagStatusClass(this.info.status) : '';
  }

  get isOpen(): boolean {
    return this.dialog.isOpen;
  }

  public open() {
    if (this.notificationDialogMode === NotificationDialogMode.CREATE) {
      this.notificationForm.reset();
      this.dialog.open();
    } else if (this.info) {
      this.managementService.getNotificationByUUID(this.info.UUID).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.notificationinfo = ManagementHelper.handleManagementDisplayData(resp.value);
            this.setNotificationFormValue(this.notificationinfo);
            if (this.notificationinfo.status !== ManagementWFStatus.ACTIVE &&
                this.notificationinfo.status !== ManagementWFStatus.INACTIVE) {
              let changes = [];
              this.controls.forEach(
                (el) => {
                  if (resp.value.sData[el.key] !== resp.value.oData[el.key]) {
                    changes.push({
                      key: el.key,
                      valueAfter: resp.value.sData[el.key],
                      valueBefore: resp.value.oData[el.key],
                    });
                  }
                }
              );
              this.paramModelChanges = changes;
            }
            this.dialog.open();
          }
        }
      );
    }
  }

  public close() {
    this.dialog.close();
  }

  public afterClosed() {
    this.paramModelChanges = [];
    this.notificationForm.reset();
  }

  public discardNotificationChange() {
    this.managementService.discard(this.info.UUID, ManagementWFType.NOTIFICATION).subscribe(
      (resp) => {
        this.dialog.close();
        this.afterCreateOrUpdate.emit();
      }
    );
  }

  ngOnChanges() {
    if (this.notificationDialogMode !== this.dialogType) {
      this.notificationDialogMode = this.dialogType;
    }
  }

  /**
   * form helper
   */

  private prepareControls() {
    this.controls = [
      new TextControl({
        key: 'Title',
        label: '標題',
        required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      }),
      new TextareaControl({
        key: 'Content',
        label: '內文',
        columnClasses: ['12'],
        placeholder: '請輸入...'
      }),
      // new SingleDropdownControl({
      //   key: 'ApplyEmpId',
      //   label: '申請人',
      //   options: [this.user],
      //   value: this.user.value,
      //   disabled: true,
      //   required: true,
      //   columnClasses: ['6'],
      // }),
      new TextControl({
        key: 'ApplyEmpId',
        label: '申請人',
        disabled: true,
        required: true,
        value: `(${this.user.loginEmpId})${this.user.name}`,
        columnClasses: ['6'],
      }),
      // new SingleDropdownControl({
      //   key: 'ReviewSupervisorId',
      //   label: '覆核主管',
      //   required: true,
      //   enableAutoComplete: true,
      //   options: this.managers,
      //   columnClasses: ['6'],
      //   placeholder: '請選擇...'
      // }),
      new RadioControl({
        key: 'Importance',
        label: '重要性',
        value: true,
        columnClasses: ['6'],
        required: true,
        breakAfter: true,
        options: [
          {value: true, label: '重要'},
          {value: false, label: '一般'}
        ]
      }),
      new DatepickerControl({
        key: 'PublishDate',
        label: '發布日期',
        required: true,
        columnClasses: ['6'],
        singleDatePicker: true,
        minDate: moment().format(this.dateFormatter),
        value: moment().format(this.dateFormatter),
        placeholder: '請選擇日期...'
      }),
      new DatepickerControl({
        key: 'PublishEndDate',
        label: '結束日期',
        required: true,
        columnClasses: ['6'],
        singleDatePicker: true,
        minDate: moment().format(this.dateFormatter),
        value: moment().add(3, 'days').format(this.dateFormatter),
        placeholder: '請選擇日期...'
      }),
      new SingleDropdownControl({
        key: 'NotificationCategory',
        label: '發布對象',
        required: true,
        columnClasses: ['6'],
        options: this.publishCategory,
        placeholder: '請選擇...'
      }),
      new MultiSelectControl({
        key: 'NotificationTargets',
        label: '　',
        columnClasses: ['6'],
        options: this.publishTargets,
        placeholder: '請選擇...'
      }),
    ];
  }

  private setNotificationFormValue(row: any) {
    if (!this.notificationForm) {
      return;
    }
    for (const key of Object.keys(row)) {
      if (this.notificationForm.form.controls[key]) {
        this.notificationForm.form.controls[key].setValue(row[key]);
      }
    }

    this.notificationForm.form.controls['PublishDate'].setValue(DateHelper.formatDate(row['PublishDate']));
    this.notificationForm.form.controls['PublishEndDate'].setValue(DateHelper.formatDate(row['PublishEndDate']));
    this.notificationForm.form.controls['ApplyEmpId'].setValue(row['ApplyEmpId'] ? row['ApplyEmpId'] : row['UpdateEmpId']);
    // this.notificationForm.form.controls['ReviewSupervisorId'].setValue(row['VerifyEmpId']);

    // this.paramModelChanges = row.contentBefore ? [{
    //   key: 'Content',
    //   valueBefore: row.contentBefore,
    //   valueAfter: row.Content
    // }] : [];
  }

  private setNotificationFormDisable(disabled: boolean) {
    for ( const key of Object.keys(this.notificationForm.form.controls)) {
      if (disabled) {
        this.notificationForm.form.controls[key].disable();
      } else {
        if (key === 'ApplyEmpId') {
          continue;
        }
        this.notificationForm.form.controls[key].enable();
      }
    }
  }
}

