import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ManagementWFType } from '../../management.model';
import { ManagementService } from '../../../core/services/management.service';
import { WFAction } from './../../../core/models/comm-data';
import { LoggerService } from 'app/shared/logger.service';
import { DateHelper } from 'app/shared/helper/date-helper';

@Component({
  selector: 'esun-management-approve-dialog',
  templateUrl: './management-approve-dialog.component.html',
  styleUrls: ['./management-approve-dialog.component.scss']
})
export class ManagementApproveDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;

  @Input('dataSource')
  set dataSource(value: any[]) {
    if (value) {
      this.approvementList = value;
    }
  }
  get dataSource(): any[] {
    return this.approvementList;
  }

  @Input('WFType') WFType: ManagementWFType;

  @Output('afterApproved') afterApproved: EventEmitter<any> = new EventEmitter;

  private approvementList: any[] = [];
  private needCancelCheckout: boolean = true;

  constructor(
    private logger: LoggerService,
    private router: Router,
    private managementService: ManagementService
  ) { }

  ngOnInit() {
  }

  get header(): string {
    return this.approvementList.length === 1 ? '放行' : `放行(${this.approvementList.length})`;
  }

  get approvementListDesc(): string {
    return this.approvementList.length === 1 ? '' : ` ${this.approvementList.length} `;
  }

  get applicants(): any[] {
    const applicant = [];
    if (this.approvementList.length !== 0) {
      const applicantGroup = _.groupBy(this.approvementList, 'ApplyEmpId');
      for ( const applicantKey of Object.keys(applicantGroup)) {
        const applyDates = [];

        const applyDateGroup = _.groupBy(_.map(applicantGroup[applicantKey], (el) => {
          el['UpdateDate'] = DateHelper.formatDate(el['UpdateDate']);
          return el;
        }), 'UpdateDate');
        for (const dateKey of Object.keys(applyDateGroup)) {
          applyDates.push({
            date: dateKey,
            count: applyDateGroup[dateKey].length
          });
        }
        applicant.push({
          applicant: applicantGroup[applicantKey][0].applicant,
          applicantId: applicantKey,
          applyDates: applyDates
        });
      }
    }
    return applicant;
  }

  public open() {
    this.dialog.open();
  }

  public onConfirmClick() {
    this.needCancelCheckout = false;
    let body = {
      UUIDs: this.approvementList.map( el => el.UUID),
      Action: WFAction.APPROVE,
      Comment: '',
      BaseUrl: this.router.url,
      WFObjectName: this.managementService.getWFObjectName()
    };

    this.managementService.checkinWF(body, this.WFType).subscribe(
      (resp) => {
        this.logger.debug(resp);
        this.dialog.close();
        this.afterApproved.emit();
      }
    );
  }

  public afterClose() {
    if (this.needCancelCheckout) {
      let body = {
        UUIDs: this.approvementList.map( el => el.UUID),
        WFObjectName: this.managementService.getWFObjectName()
      };

      this.managementService.cancelCheckoutWF(body, this.WFType)
      .subscribe(
        (resp) => {
          this.logger.debug(resp);
        }
      );
    } else {
      this.needCancelCheckout = true;
    }
  }
}
