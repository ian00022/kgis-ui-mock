import { RoleService } from './../../role/role.service';
import { Component, OnInit, Input, ViewChild, AfterViewInit, OnChanges, EventEmitter, Output } from '@angular/core';
// import { NgxPermissionsService } from 'ngx-permissions';
import { Permissions } from 'app/core/models/permissions';
// import { LoggerService } from 'app/shared/logger.service';
import {
  ControlBase,
  MultiSelectControl,
  TextareaControl,
  TextControl,
  SingleDropdownControl
} from 'app/shared/components/dynamic-form/controls';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import * as _ from 'lodash';
import { UserRoleStatusEnum } from 'app/management/role/role.models';
import { MultiSelectTreeControl } from 'app/shared/components/dynamic-form/controls/multi-select-tree-control';

@Component({
  selector: 'esun-role-management-dialog',
  templateUrl: './role-management-dialog.component.html',
  styleUrls: ['./role-management-dialog.component.scss']
})
export class RoleManagementDialogComponent implements OnInit, OnChanges, AfterViewInit {
  @ViewChild('form') form: DynamicFormComponent;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @Input('header') header: string;
  @Input('recordID') recordID: string;
  @Input('sysStatus') sysStatus: Array<any>;
  @Output() afterConfirm = new EventEmitter();

  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  public Permissions = Permissions;

  public statusEnum = UserRoleStatusEnum;
  public currentRole: any;
  public currentRoleStatus = '';
  public currentSelectedPermissions: Array<any> = [];

  public permissionOptions = [];

  //   { label: '顧客查詢', value: 'VIEW_CS', group: 'CS', root: true },
  //   { label: '顧客查詢——新增', value: 'CREATE_CS', group: 'CS' },
  //   { label: '顧客查詢——修改', value: 'EDIT_CS', group: 'CS' },
  //   { label: '顧客查詢——刪除', value: 'DELETE_CS', group: 'CS' },
  //   { label: '顧客查詢——審核', value: 'REVIEW_CS', group: 'CS' },
  //   { label: '名單管理', value: 'VIEW_BO', group: 'BO', root: true },
  //   { label: '名單管理——新增', value: 'CREATE_BO', group: 'BO' },
  //   { label: '名單管理——修改', value: 'EDIT_BO', group: 'BO' },
  //   { label: '名單管理——刪除', value: 'DELETE_BO', group: 'BO' },
  //   { label: '名單管理——審核', value: 'REVIEW_BO', group: 'BO' },
  // ];

  public useType = [
    { label: '經辦', value: '1' },
    { label: '行銷團隊組長', value: '2' },
    { label: '分行/總行/消金中心主管', value: '3' },
    { label: '系統管理員', value: '4' },
  ];

  public controls: ControlBase<any>[] = [];

  public roleTableData = [
    {
      roleId: 'MANAGEMENT_REVIEWER',
      roleName: '後台管理主管',
      roleDescription: '後台管理主管多為經理，分行MIS等',
      rolePermissions: ['VIEW_BO', 'REVIEW_BO'],
      roleUseType: 'ADMIN',
      creatorId: '0001',
      creatorName: '林新增',
      createDate: '2018/3/17',
      status: 'active'
    },
    {
      roleId: 'MANAGEMENT_EMPLOYEE',
      roleName: '後台管理人員',
      roleDescription: '後台人員主管多分行MIS等職等為8的員工',
      rolePermissions: [
        'VIEW_BO', 'CREATE_BO', 'EDIT_BO', 'DELETE_BO'
      ],
      roleUseType: 'ADMIN',
      creatorId: '0001',
      creatorName: '林新增',
      createDate: '2018/3/17',
      lastEditEmployeeId: '00009',
      lastEditEmployeeName: '林編輯',
      lastEditEmployeeTime: '2018/12/12',
      status: 'inactive'
    },
    {
      roleId: 'SELLER',
      roleName: '行銷職系經辦',
      roleDescription: '',
      rolePermissions: ['VIEW_CS'],
      roleUseType: 'OPERATOR',
      tempRoleName: '行銷經辦人員',
      tempRoleDescription: '系統預設',
      creatorId: '',
      creatorName: '系統預設',
      createDate: '2018/3/17',
      lastEditEmployeeId: '00009',
      lastEditEmployeeName: '林編輯',
      lastEditEmployeeTime: '2018/12/12',
      status: 'temp'
    },
    {
      roleId: 'MANAGEMENT_SELLER',
      roleName: '行銷職系主管',
      roleDescription: '',
      rolePermissions: ['REVIEW_CS'],
      roleUseType: 'SELL_TEAM_LEADER',
      creatorId: '0001',
      creatorName: '林新增',
      createDate: '2018/3/17',
      status: 'reject'
    },
    {
      roleId: 'MANAGEMENT_RIGON',
      roleName: '總行管理主管',
      rolePermissions: ['REVIEW_CS'],
      roleUseType: 'OPERATIONS_MANAGEMENT',
      roleDescription: '',
      tempRolePermissions: ['VIEW_CS', 'REVIEW_CS'],
      tempRoleUseType: 'SELL_TEAM_LEADER',
      tempRoleDescription: '系統預設',
      creatorId: '0001',
      creatorName: '林新增',
      createDate: '2018/3/17',
      lastEditEmployeeId: '00009',
      lastEditEmployeeName: '林編輯',
      lastEditEmployeeTime: '2018/12/12',
      status: 'waiting'
    },
    {
      roleId: 'EMPLOYEE_RIGON',
      roleName: '總行管理人員',
      rolePermissions: ['REVIEW_CS'],
      roleUseType: 'OPERATIONS_MANAGEMENT',
      roleDescription: '',
      creatorId: '0001',
      creatorName: '林新增',
      createDate: '2018/3/17',
      lastEditEmployeeId: '00009',
      lastEditEmployeeName: '林編輯',
      lastEditEmployeeTime: '2018/12/12',
      status: 'waiting'
    },
  ];
  public paramModelChanges = [];
  public enableToEditFormStatus: Array<string> = ['active', 'temp', 'reject'];

  constructor (
    private roleService: RoleService,
  ) { }

  public prepareControls() {
    this.controls = [
      new TextControl({
        key: 'roleId',
        label: '角色編號',
        columnClasses: ['12'],
        required: true,
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'roleName',
        label: '系統角色名稱',
        columnClasses: ['12'],
        required: true,
        placeholder: '請輸入...'
      }),
      new TextareaControl({
        key: 'roleDescription',
        label: '角色說明',
        required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'roleUseType',
        label: '權限類別',
        columnClasses: ['12'],
        options: this.useType,
        placeholder: '請選擇...'
      }),
      new MultiSelectTreeControl({
        key: 'rolePermission',
        label: '角色功能',
        columnClasses: ['12'],
        items: this.permissionOptions,
        placeholder: '請選擇...'
      })
    ];
  }

  getPermissions() {
    this.roleService.getPermissionsOptions().subscribe(data => {
      this.controls.forEach(control => {
        if (control.key === 'rolePermission') {
          control['items'] = data;
        }
      });
    });
  }

  ngOnInit() {
    this.getPermissions();
    this.prepareControls();
  }

  ngOnChanges() {
    if (this.dialog.isOpen) {
      // 先清掉
      this.paramModelChanges = [];
      this.form.patchValue({
        roleName : null,
        roleDescription : null,
        roleUseType : null,
        rolePermission : null
      });
      // 非新增
      if (this.recordID !== null) {
        this
          .roleService
          .getRoleDetails(this.recordID)
          .subscribe(data => {
            this.currentRole = data.roleDetails;
            this.form.patchValue(data.formData);
          });
      } else {
      }
    }
  }

  ngAfterViewInit() {
    this.form.form.valueChanges
      .subscribe(filters => {
        this.currentSelectedPermissions = this.permissionOptions.filter(role =>
          _.includes(filters.rolePermission, role.value));

      });
  }

  getCurrentRole(id) {
    this.currentRole = this.roleTableData.find(role => role.roleId === this.recordID);
    const currentRoleStatus = this.sysStatus.find(status => status.value === this.currentRole.status);
    this.currentRoleStatus = currentRoleStatus.value === 'reject' ? '生效' : currentRoleStatus.label;

    return new Promise((resolve, reject) => {
      if (!_.isEmpty(this.currentRole)) {
        resolve();
      } else {
        reject('There is no matching role');
      }
    });
  }

  setChange(ctrlType, current, temp, keylabelSource) {
    const opts: any = { key: current };

    switch (ctrlType) {
      case 'string':
        opts.valueBefore = this.currentRole[current];
        opts.valueAfter = this.currentRole[temp];
        break;
      case 'select':
        opts.valueBefore = this.setShownString(keylabelSource, this.currentRole[current]);
        opts.valueAfter = this.setShownString(keylabelSource, this.currentRole[temp]);
        break;
    }

    this.currentRole[temp] ? this.paramModelChanges.push(opts) :
      this.paramModelChanges = this.paramModelChanges.filter(c => c.key !== temp);
  }

  patchValueByRoleId() {
    this.form.patchValue({
      roleId: this.currentRole.roleId || '',
      roleName: this.currentRole.tempRoleName || this.currentRole.roleName || '',
      roleDescription: this.currentRole.tempRoleDescription || this.currentRole.roleDescription || '',
      roleUseType: this.currentRole.tempRoleUseType || this.currentRole.roleUseType || '',
      rolePermission: this.currentRole.tempRolePermission || this.currentRole.rolePermissions || [],
    });

    if (_.includes(['temp', 'waiting'], this.currentRole.status)) {
      this.setChange('string', 'roleName', 'tempRoleName', null);
      this.setChange('string', 'roleDescription', 'tempRoleDescription', null);
      this.setChange('select', 'roleUseType', 'tempRoleUseType', this.useType);
      this.setChange('select', 'rolePermission', 'tempRolePermission', this.permissionOptions);
    } else { this.paramModelChanges = []; }

    // 當dialog狀態不同的時候，會讓他無法異動內容(如送審or停用)
    if (!_.includes(this.enableToEditFormStatus, this.currentRole.status)) {
      _.forIn(this.form.form.controls, (value, key) => {
        this.form.form.controls[key].disable();
      });
    } else {
      _.forIn(this.form.form.controls, (value, key) => {
        this.form.form.controls[key].enable();
      });
      this.form.form.controls['roleId'].disable();
    }
  }

  onSubmit() {

  }

  open() {
    this.dialog.open();
  }

  addNewRow() {
    if (this.form.form.valid) {
      const formData = this.form.form.value;
      this.roleService.addNewRole(formData).subscribe(data => {
        this.dialog.close();
        this.afterConfirm.emit();
      });
    }
  }

  updateRow() {
    if (this.form.form.valid) {
      const formData = this.form.form.value;
      this.roleService.updateRoleDetails(formData).subscribe(data => {
        this.dialog.close();
        this.afterConfirm.emit();
      });
    }
  }

  confirm(submitType) {
    switch(submitType) {
      case 'createCommit':
        this.addNewRow();
        break;
      case 'tempUpdate':
        this.updateRow();
        break;
      case 'updateCommit':
        this.chooseMgrDialog.open();
        break;
      default:
        break;
    }
  }

  afterChooseWFApprMgr(mgrId) {
    const request = {
      UUIDs: [
        this.currentRole.uuid
      ],
      WFApprMgrEmpId: mgrId,
      UpdateData: {},
      BaseUrl: '',
      WFObjectName: ''
    };

    this.roleService.submitRole(request)
      .subscribe(data => {
        this.dialog.close();
        this.chooseMgrDialog.close();
        this.afterConfirm.emit();
      });
  }

  cancel() {
    this.dialog.close();
  }
  save() {
    this.dialog.close();
  }

  setShownString(labelValueArray: Array<any>, valueArray: Array<any>) {
    const current = labelValueArray.filter(item =>
      _.includes(valueArray, item.value));

    return current.map(i => i.label).join('，');
  }

  discardChange(e: Event) {
    e.preventDefault();
  }
}
