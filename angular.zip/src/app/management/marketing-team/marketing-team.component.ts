import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper } from './../management.model';
import { ManagementService } from './../../core/services/management.service';
import { ISelectOptionModel, SearchHistoryKey } from './../../core/models/comm-data';
import { Subject } from 'rxjs';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { ControlBase, SingleDropdownControl, TextControl } from 'app/shared/components/dynamic-form/controls';
import { ManagementHelper } from 'app/management/management-helper';
import { NgxPermissionsService } from 'ngx-permissions';
import { LoggerService } from 'app/shared/logger.service';
import { CheckBoxTableHelper } from 'app/shared/helper/table-checkbox-helper';
import * as _ from 'lodash';
import { SlicePipe } from '../../../../node_modules/@angular/common';
import { SelectOptionsService } from '../../shared/services/select-options.service';
import { MarketingTeamDialogType } from '../shared-components/management-marketing-team-dialog/management-marketing-team-dialog.component';
import { SearchHistoryService } from '../../core/services/search-history.service';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-marketing-team',
  templateUrl: './marketing-team.component.html',
  styleUrls: ['./marketing-team.component.scss'],
  providers: [SlicePipe]
})
export class MarketingTeamComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('searchForm') searchForm: DynamicFormComponent;
  @ViewChild('marketingTable') marketingTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('marketingTeam') marketingTeamDialog: IbmDialogComponent;

  public searchControls: ControlBase<any>[] = [];
  public marketingTeamCategoryOptions: ISelectOptionModel[] = [];
  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public teamList: any[] = [];
  public displayTeamList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public selectedTeamData: any = {};
  public reviewList: any[] = [];
  public disableNotificationDialog = false;
  public marketingTeamDialogType: MarketingTeamDialogType = MarketingTeamDialogType.CREATE;
  public dialogType = MarketingTeamDialogType; // template enum property
  public WFType: ManagementWFType = ManagementWFType.MARKETINGTEAM;
  public Permissions = Permissions;
  public hasEditPermission: boolean = false;

  private ngUnSubscribe: Subject<any> = new Subject();
  private searchHistoryKey = SearchHistoryKey.MARKETINGTEAM;

  constructor(
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private slice: SlicePipe,
    private options: SelectOptionsService,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef,
    private history: SearchHistoryService
  ) {
    this.options.getOptions('marketingTeamCategory').forEach(element => {
      this.marketingTeamCategoryOptions.push(element);
    });

    this.permissionService.hasPermission([
      Permissions.MARKETING_TEAM_UPDATE,
      Permissions.MARKETING_TEAM_MEMBER_UPDATE
    ])
      .then( hasPermission => {
        this.hasEditPermission = hasPermission;
      });
  }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit(): void {
    let history = this.history.getHistoryOf(this.searchHistoryKey);
    if (history) {
      this.searchForm.form.patchValue(history);
      this.searchForm.submit();
    }
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * whether all search inputs valid or not
   */
  get isSearchValid(): boolean {
    return this.searchForm.form.valid;
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.marketingTable) {
      return this.marketingTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public getTeamCategoryLabel(category) {
    return this.options.getOptionLabel('marketingTeamCategory', category);
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.marketingTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList,
      'TeamNo'
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList, 'TeamNo');
  }

  public isRowSelectable(row: any) {
    return row.status === ManagementWFStatus.STAGE_REVIEW;
  }

  public onReviewActionClick(dataType: string, reviewType: string) {
    if (dataType === 'single') {
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.MARKETINGTEAM)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  public onEditActionClick(type: MarketingTeamDialogType) {
    this.marketingTeamDialogType = type;
    this.ref.detectChanges();
    this.marketingTeamDialog.open();
  }

  /**
   * searchForm submit
   */
  public handleSearchSubmit(value: any) {
    let searchModel = _.assign({orderCol: 'TeamNo'}, value);
    this.history.storeHistory(this.searchHistoryKey, searchModel);
    this.managementService.getMarketingTeamList(searchModel).subscribe(
      (resp) => {
        this.logger.debug(resp);
        this.teamList = resp.value;
        this.displayTeamList = this.teamList.map( el => ManagementHelper.handleManagementDisplayData(el));
      }
    );
  }

  /**
    * table row action handler
    */

  // get isTeamInfoEditable(): boolean {
  //   return this.selectedRow.status !== '待覆核';
  // }

  // get isTeamMemberEditable(): boolean {
  //   return _.includes(['生效', '暫存', '主管退回'], this.selectedRow.status);
  // }

  public sliceDescription(description: string): string {
    if (description && description.length > 60 ) {
      return this.slice.transform(description, 0, 60) + '...';
    }
    return description;
  }
  public openReviewMenu(row: any, menu: any) {
    this.selectedRow = row;
    this.selectedTeamData = _.cloneDeep(this.selectedRow);
  }

  /**
   *
   * notification dialog handler
   */
  public createMarketingTeam() {
    this.selectedTeamData = {};
    this.marketingTeamDialogType = MarketingTeamDialogType.CREATE;
    this.ref.detectChanges();
    this.marketingTeamDialog.open();
  }

  get getDialogHeaderStatusClass(): string {
    return ManagementHelper.headerTagStatusClass(this.selectedRow.status);
  }


  public discardNotificationChange() {
  }

  public handleReviewAction(isApprove: boolean) {
    if (isApprove) {
      this.onReviewActionClick('single', 'approve');
    } else {
      this.onReviewActionClick('single', 'reject');
    }
  }

  /**
   * initControls
   */
  private prepareControls() {
    this.searchControls = [
      new SingleDropdownControl({
        key: 'teamCategory',
        label: '團隊類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇...',
        options: this.marketingTeamCategoryOptions
      }),
      new TextControl({
        key: 'teamName',
        label: '團隊名稱',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      })
    ];
  }
}
