import { Injectable } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HeadOfficeAssignmentResponseService } from './head-office-assignment-response.service';
import { HeadOfficeAssignmentDetailTableRowDto } from './head-office-assignment.model';

@Injectable({
  providedIn: 'root'
})
export class HeadOfficeAssignmentService {

  constructor(
    private api: ApiService,
    private response: HeadOfficeAssignmentResponseService
  ) { }

  public getHeadOfficeAssignmentBOLListByCaseNo(caseNo): Observable<HeadOfficeAssignmentDetailTableRowDto[]> {
    return this.api.get(`CaseMgm/${caseNo}/details`).pipe(map( data => {
      if (data.value) {
        return data.value.map( (el) => {
          return this.response.mapTo(el);
        });
      }
    }));
  }
}
