
export enum HeadOfficeAssignmentDialogType {
  CREATE = 'create',
  EDIT = 'edit',
  COPY = 'copy'
}

export enum InputHeadOfficeAssignmentDetailMethod {
  KEYIN = 'keyin',
  EXCEL = 'excel'
}

export class HeadOfficeAssignmentDetail {
  identityCardNumber: string;
  customerName: string;
  assignedUnit: string;

  constructor(options: {
    identityCardNumber?: string,
    customerName?: string,
    assignedUnit?: string,
  } = {}) {
    this.assignedUnit = options.assignedUnit || '';
    this.customerName = options.customerName || '';
    this.identityCardNumber = options.identityCardNumber || '';
  }
}

// need processLog model
export interface HeadOfficeAssignmentDetailResponseDto {
  ProcessLogs: any[];
  CaseDetail: HeadOfficeAssignmentDetailDto;
}

export interface HeadOfficeAssignmentDetailDto {
  AssignedDate?: string;
  AssignedUnit: string;
  BOLStatus: string;
  CreateDate: string;
  CreateEmpId: string;
  CustomerName: string;
  HeadOfficeCaseUUID: string;
  IdentityCardNumber: string;
  MarketingPerson?: string;
  Remark?: string;
  UUID: string;
  UpdateDate: string;
  UpdateEmpId: string;
}

// need processLog model
export interface HeadOfficeAssignmentDetailTableRowDto {
  assignedUnit: string;
  customerName: string;
  headOfficeCaseUUID: string;
  identityCardNumber: string;
  marketingPerson: string;
  status: string;
  updateEmpId: string;
  UUID: string;
  subRow?: any[];
}
