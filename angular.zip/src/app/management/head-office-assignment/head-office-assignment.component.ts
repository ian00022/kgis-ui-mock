import { Component, OnInit, ViewChild, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { NgxPermissionsService } from 'ngx-permissions';
import * as _ from 'lodash';
import { ManagementService } from './../../core/services/management.service';
import { SelectOptionsService } from './../../shared/services/select-options.service';
import { LoggerService } from '../../shared/logger.service';
import { ISelectOptionModel } from './../../core/models/comm-data';
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { ManagementHelper } from 'app/management/management-helper';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import {
  ControlBase,
  MultiSelectControl,
  SingleDropdownControl,
  TextControl,
  DatepickerControl
} from 'app/shared/components/dynamic-form/controls';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { ManagementWFStatusHelper } from '../management.model';
import { ManagementWFStatus } from 'app/management/management.model';
import { DateHelper } from '../../shared/helper/date-helper';
import { ManagementWFType } from './../management.model';
import { HeadOfficeAssignmentDialogType } from './head-office-assignment.model';
import { Permissions } from './../../core/models/permissions';

@Component({
  selector: 'esun-head-office-assignment',
  templateUrl: './head-office-assignment.component.html',
  styleUrls: ['./head-office-assignment.component.scss']
})
export class HeadOfficeAssignmentComponent implements OnInit, AfterViewInit {

  @ViewChild('searchForm') searchForm: DynamicFormComponent;
  @ViewChild('assignmentTable') assignmentTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('assignment') assignmentDialog: IbmDialogComponent;

  public orderTypes = [
    { label: '建立日期', value: 'createDate' },
    { label: '回覆日期', value: 'replyDate' },
    { label: '結案日期', value: 'closeDate' }
  ];

  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public headOfficeAssignmentList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public selectedAssignment: any;
  public reviewList: any[] = [];
  public searchFormControls: ControlBase<any>[] = [];
  public Permissions = Permissions;
  // public reviewPermission = 'REVIEW_HEAD_OFFICE_ASSIGNMENT';
  // public createPermission = 'CREATE_HEAD_OFFICE_ASSIGNMENT';

  public statusOptions: ISelectOptionModel[] = [];
  public dateSearchTypeOptions: ISelectOptionModel[] = [];
  public createEmpOptions: ISelectOptionModel[] = [];
  public WFType = ManagementWFType.HEADOFFFICEASSIGNMENT;

  public dialogType: HeadOfficeAssignmentDialogType;
  public HeadOfficeAssignmentDialogType = HeadOfficeAssignmentDialogType;
  public hasEditPermission: boolean = false;

  // private currentPermissions: string = this.reviewPermission;
  private orderType: any = this.orderTypes[0];
  constructor(
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private options: SelectOptionsService,
    private managementService: ManagementService,
    private ref: ChangeDetectorRef
  ) {
    const option = this.options.getOptions(
      [
        'dateSearchType'
      ]);
    this.dateSearchTypeOptions = option['dateSearchType'];
    this.statusOptions = ManagementWFStatusHelper.getAllOptions();
   }

  public searchFormValidators: ValidatorFn = (group: FormGroup): { [key: string]: any } => {
    if (group.controls['Type'].value && !group.controls['SelectDate'].value) {
      return { requireDate: true };
    }
  }

  ngOnInit() {
    this.prepareControls();
    this.permissionService.hasPermission([
      Permissions.CASE_MANAGEMENT_BOL_UPDATE,
      Permissions.CASE_MANAGEMENT_BOL_COPY_ADD
    ])
      .then( (hasPermisson) => {
        this.hasEditPermission = hasPermisson;
      });
  }

  ngAfterViewInit() {
    this.searchForm.form.get('Type').valueChanges.subscribe( value => {
      let control = _.find(this.searchFormControls, ['key', 'SelectDate']);
      if (value) {
        control.required = true;
        control.label = '';
      } else {
        control.required = false;
        control.label = '　';
      }
    });
  }

  /**
   * whether all search inputs valid or not
   */

  public chooseOrderType(type: any) {
    this.orderType = type;
    if (this.isSearchValid) {
      this.searchForm.submit();
    }
  }

  get isSearchValid(): boolean {
    return this.searchForm.form.valid;
  }

  /**
   * table data orderType handler
   */
  get orderTypeLabel(): string {
    return this.orderType.label;
  }

  public handleSearchFormSubmit(value) {
    let body = _.assign({ orderCol: this.orderType.value}, value);
    if (body['SelectDate']) {
      body['SelectDate'] = DateHelper.divideDate(body['SelectDate']);
    }
    this.logger.debug(body);
    this.managementService.getHeadOfficeAssignmentList(body).subscribe(
      (resp) => {
        // tslint:disable-next-line
        this.headOfficeAssignmentList = resp.value.map( el => ManagementHelper.handleManagementDisplayData(el));
      }
    );
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.assignmentTable) {
      return this.assignmentTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.assignmentTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public isRowSelectable(row: any) {
    return row.status === ManagementWFStatus.STAGE_REVIEW;
  }

  public onReviewActionClick(dataType: string, reviewType: string) {
    if (dataType === 'single') {
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.HEADOFFFICEASSIGNMENT)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  public handleAfterReviewAction() {
    this.searchForm.submit();
  }

  public openMenu(row) {
    this.selectedRow = row;
  }

  public assignmentDialogOpen(dialogType: HeadOfficeAssignmentDialogType, row?) {
    this.dialogType = dialogType;
    if (this.dialogType === HeadOfficeAssignmentDialogType.CREATE) {
      this.selectedAssignment = {};
    } else {
      this.selectedAssignment = _.cloneDeep(row);
    }
    this.ref.detectChanges();
    this.assignmentDialog.open();
  }

  private prepareControls() {
    this.searchFormControls = [
      new MultiSelectControl({
        key: 'Status',
        label: '狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.statusOptions,
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'CaseNo',
        label: '單號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'Subject',
        label: '主旨',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'CreateEmpId',
        label: '建立者',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.createEmpOptions,
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'Type',
        label: '日期類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.dateSearchTypeOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'SelectDate',
        label: '　',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      })
    ];
  }
}
