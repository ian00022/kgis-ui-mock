import { Injectable } from '@angular/core';
import { HeadOfficeAssignmentDetailTableRowDto, HeadOfficeAssignmentDetailDto, HeadOfficeAssignmentDetailResponseDto } from './head-office-assignment.model';
import { BolStatusService } from 'app/business-opportunity/bol-status.service';

@Injectable({
  providedIn: 'root'
})
export class HeadOfficeAssignmentResponseService {

  constructor(
    private bolStatus: BolStatusService
  ) { }

  public mapTo(map: HeadOfficeAssignmentDetailResponseDto): HeadOfficeAssignmentDetailTableRowDto {
    return {
      assignedUnit: map.CaseDetail.AssignedDate,
      customerName:  map.CaseDetail.CustomerName,
      headOfficeCaseUUID:  map.CaseDetail.HeadOfficeCaseUUID,
      identityCardNumber:  map.CaseDetail.IdentityCardNumber,
      marketingPerson:  map.CaseDetail.MarketingPerson,
      // only BOLStatusLabel
      status:  this.mapStatusLabel(map.CaseDetail),
      updateEmpId: map.CaseDetail.UpdateEmpId,
      UUID:  map.CaseDetail.UUID,
      subRow: this.mapLogs(map),
    };
  }

  private mapStatusLabel(map: HeadOfficeAssignmentDetailDto): string {
    return this.bolStatus.mapTo(map.BOLStatus);
  }

  // todo refactor processLogs
  private mapLogs(map: HeadOfficeAssignmentDetailResponseDto): any {
    if (map.ProcessLogs && map.ProcessLogs.length !== 0) {
      return map.ProcessLogs;
    }
    return null;
  }
}
