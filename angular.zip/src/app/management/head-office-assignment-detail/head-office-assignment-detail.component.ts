import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ManagementService } from './../../core/services/management.service';
import * as _ from 'lodash';
import { combineLatest } from 'rxjs';
import { ManagementHelper } from '../management-helper';
import { ManagementWFType } from '../management.model';
import { FileDto } from './../../core/models/file.model';
import { HeadOfficeAssignmentService } from '../head-office-assignment/head-office-assignment.service';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { ManagementWFStatus } from 'app/management/management.model';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-head-office-assignment-detail',
  templateUrl: './head-office-assignment-detail.component.html',
  styleUrls: ['./head-office-assignment-detail.component.scss']
})
export class HeadOfficeAssignmentDetailComponent implements OnInit {

  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('assign') assignmentDialog: IbmDialogComponent;

  public collapsed: boolean = true;
  public assignment: any;
  public BOLlist: any[] = [];
  public reviewList: any[] = [];
  public attachedFiles: FileDto[] = [];
  public WFType = ManagementWFType.HEADOFFFICEASSIGNMENT;
  public Permissions = Permissions;

  private caseNo: string;

  constructor(
    private managementService: ManagementService,
    private route: ActivatedRoute,
    private headOfficeService: HeadOfficeAssignmentService
  ) { }

  ngOnInit() {
    this.caseNo = this.route.snapshot.params['id'];
    this.getHeadOfficeDetail(this.caseNo);
    // this.managementService.getHeadOfficeAssignmentByCaseNo(caseNo)
    //   .subscribe( (resp) => {
    //     this.assignment = ManagementHelper.handleManagementDisplayData(resp.value);
    //   });
    // this.managementService.getHeadOfficeAssignmentBOLListByCaseNo(caseNo)
    // .subscribe( (resp) => {
    //   this.BOLlist = resp.value.map(el => {
    //     return _.assign(el['CaseDetail'], (el['ProcessLogs'] && el['ProcessLogs'].length > 0) ? {subRow: el['ProcessLogs']} : {});
    //   });
    // });

  }

  get enableReviewBtn(): boolean {
    if (this.assignment) {
      return this.assignment.status === ManagementWFStatus.STAGE_REVIEW;
    }
    return false;
  }

  public getCustLink(row: any): any[] {
    const overview = _.result(row, 'IdentityCardNumber.length') === 8 ? 'comp-overview' : 'cust-overview';
    return ['/clients', 'client', row.IdentityCardNumber, overview];

  }

  public handleAfterReviewAction() {
    this.getHeadOfficeDetail(this.caseNo);
  }

  public onReviewActionClick(reviewType: string) {
    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.HEADOFFFICEASSIGNMENT)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  public assignmentDialogOpen() {
    this.assignmentDialog.open();
  }

  private getHeadOfficeDetail(caseNo) {
    combineLatest(
      this.managementService.getHeadOfficeAssignmentByCaseNo(caseNo),
      this.managementService.getHeadOfficeAssignmentFilesByCaseNo(caseNo),
      this.headOfficeService.getHeadOfficeAssignmentBOLListByCaseNo(caseNo)
    ).subscribe(
      ([assignmentResp, fileResp, bolListResp]) => {
        this.assignment = ManagementHelper.handleManagementDisplayData(assignmentResp.value);
        this.reviewList = [this.assignment];
        this.attachedFiles = fileResp.value.sData ? fileResp.value.sData : fileResp.value.oData;
        this.BOLlist = bolListResp;
      }
    );
  }
}
