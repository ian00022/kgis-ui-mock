import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ControlBase } from '../../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { SystemSettingsService } from './system-settings.service';
import { SystemSettingControls } from './system-settings.controls';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material';
import {
  ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper
} from 'app/management/management.model';
import * as _ from 'lodash';
import { Permissions } from 'app/core/models/permissions';
import { ManagementService, AuthService } from 'app/core/services';
import { Router } from '@angular/router';
import { ManagementHelper } from '../management-helper';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { ISelectOptionModel } from 'app/core/models/comm-data';
import { NzNotificationService } from 'ng-zorro-antd';

@Component({
  selector: 'esun-system-settings',
  templateUrl: './system-settings.component.html',
  styleUrls: ['./system-settings.component.scss'],
  providers: [SystemSettingsService]
})
export class SystemSettingsComponent implements OnInit {

  public reviewSource = [];
  public reviewFrom;

  public basicParams: any[] = [];
  public paramType: any[] = [];
  public paramsControls: ControlBase<any>[] = [];
  public paramTypeControls: ControlBase<any>[] = [];
  public statusEnum = ManagementWFStatus;
  public paramModelChanges;
  public paramTypeModelChanges;
  public activeParamId;
  public workingParam;
  public workingParamType;
  public workingParamTypeOUUID;
  public paramDialogMode;
  public paramTypeDialogMode;
  public Permissions = Permissions;
  public WFType: ManagementWFType = ManagementWFType.PROP;
  public managementStatusOptions: ISelectOptionModel[] = [];
  public isDiscardCancelCheck = false;

  // dropdown
  public dropdownControls: ControlBase<any>[] = [];
  public dropdownItemControls: ControlBase<any>[] = [];
  public dropdownSettings: MatTreeNestedDataSource<any>;
  public dropdownTreeControl: NestedTreeControl<any>;
  public activeDropdownSetting;
  public workingDropdownSetting;
  public workingDropdownItem;
  public dropdownItems = [];
  public dropdownSettingDialogMode;
  public dropdownItemDialogMode;
  public dropdownModelChanges;
  public dropdownItemModelChanges;

  // file
  public addFileItemControls: ControlBase<any>[] = [];
  public editFileItemControls: ControlBase<any>[] = [];
  public fileItems = [];
  public activeFileItem;
  get activeFileItemId() {
    if (this.activeFileItem) {
      return this.activeFileItem.UUID;
    }
    return null;
  }
  public editingFileItem;
  public viewingFileItem;
  public uploadFileName;




  public managerMode: boolean = true;
  get isManager() {
    return this.managerMode;
  }

  @ViewChild('chooseMgr') chooseMgr: IbmDialogComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;

  @ViewChild('approveDialog') approveDialog: IbmDialogComponent;
  @ViewChild('returnDialog') returnDialog: IbmDialogComponent;

  @ViewChild('paramsDialog') paramsDialog: IbmDialogComponent;
  @ViewChild('paramForm') paramForm: DynamicFormComponent;

  @ViewChild('paramTypeDialog') paramTypeDialog: IbmDialogComponent;
  @ViewChild('paramTypeForm') paramTypeForm: DynamicFormComponent;

  @ViewChild('dropdownDialog') dropdownDialog: IbmDialogComponent;
  @ViewChild('dropdownForm')   dropdownForm: DynamicFormComponent;

  @ViewChild('dropdownItemDialog') dropdownItemDialog: IbmDialogComponent;
  @ViewChild('dropdownItemForm')   dropdownItemForm: DynamicFormComponent;

  @ViewChild('addFileItemDialog') addFileItemDialog: IbmDialogComponent;
  @ViewChild('addFileItemForm')   addFileItemForm: DynamicFormComponent;

  @ViewChild('editFileItemDialog') editFileItemDialog: IbmDialogComponent;
  @ViewChild('editFileItemForm')   editFileItemForm: DynamicFormComponent;

  constructor(private systemSettingService: SystemSettingsService,
    private managementService: ManagementService,
    private router: Router,
    private auth: AuthService,
    private options: SelectOptionsService,
    private notification: NzNotificationService,
  ) {
    this.prepareControls();

    this.dropdownTreeControl = new NestedTreeControl<any>(this.getChildren);
    this.dropdownSettings = new MatTreeNestedDataSource();

    const option = this.options.getOptions(
      [
        'managementStatus'
      ]);
    this.managementStatusOptions = option['managementStatus'];
  }

  hasNestedChild = (__: number, node: any) => node.children && node.children.length > 0 ;

  public isAppliedEmpEqualCurrentEmp(selectedItem): boolean {
    console.log(selectedItem.ApplyEmpId, this.auth.getLoginUser().loginEmpId);
    return selectedItem.ApplyEmpId === this.auth.getLoginUser().loginEmpId;
  }

  public cancelCheckSave() {
    let discardUUID;
    if (this.reviewFrom === 'paramType') {
      discardUUID = this.workingParamType.UUID;
    }
    if (this.isDiscardCancelCheck) {
      this.isDiscardCancelCheck = false;
      this.discard(discardUUID);
    } else {
      // this.onSaveClick('temp');
      switch (this.reviewFrom) {
        case 'paramType':
          this.paramTypeForm.submit();
          break;

        default:
          break;
      }
    }
  }

  public cancelCheckUnSave() {
    // this.dialog.close();
    switch (this.reviewFrom) {
      case 'paramType':
        this.paramTypeDialog.close();
        break;

      default:
        break;
    }
  }

  public canDiscard(selectedItem): boolean {
    // oData.ModifyStatus = '1' 一定是新增，新增的資料不可被復原
    return selectedItem.Status === ManagementWFStatus.STAGE &&
      (selectedItem.oData || { ModifyStatus: '' }).ModifyStatus !== '1';
  }

  public onCancelClick(type?: string) {
    switch (this.reviewFrom) {
      case 'paramType':
        if (this.paramTypeForm.form.dirty || (type === 'discard')) {
          if (type === 'discard') { this.isDiscardCancelCheck = true; }
          this.cancelCheckDialog.open();
        } else {
          this.paramTypeDialog.close();
        }
        break;
      default:
        break;
    }
  }

  /**
   * btn 還原至最後生效狀態
   * sData.UUID
   */
  public discard(discardUUID) {
    this.managementService
      .discard(discardUUID, this.WFType)
      .subscribe((data) => {
        console.log(`sData.UUID: ${discardUUID} 還原至最後生效狀態 discardOverdue: `, data);
        if (data.isOk) {
          this.notification.success('已還原至最後生效狀態', '');
          switch (this.reviewFrom) {
            case 'paramType':
              this.updateList();
              // reload this dialog
              this.paramTypeDialog.close();
              this.paramTypeDialog.open();
              break;

            default:
              break;
          }
        }
      });
  }

  public formInputsFromData(obj, keys) {
    const InputsFromData = {};
    _.forEach(obj, (value, key) => {
      if (_.includes(keys, key)) {
        InputsFromData[key] = value;
      }
    });
    return InputsFromData;
  }

  public setParamChanged(keys: Array<String>, oriData, saveData) {
    const formKeys = keys;
    const oData = this.formInputsFromData(oriData, formKeys);
    const sData = this.formInputsFromData(saveData, formKeys);
    const differenceArr = [];

    // this.logger.debug('setParamChanged: ', oData, sData);
    console.log('setParamChanged: ', oData, sData);
    // this.paramModelChanges = [];

    if (!_.isEqual(oData, sData)) {
      _.forEach(sData, (value, key) => {
        if (!_.isEqual(oData[key], sData[key])) {
          differenceArr.push({
            key: key,
            valueBefore: oData[key],
            valueAfter: sData[key]
          });
        }
      });
    }
    return differenceArr;
  }

  public handleAfterReviewAction() {
    if (this.reviewFrom === 'param') {
    } else if (this.reviewFrom === 'paramType') {
      // this.systemSettingService.approveParamType(this.workingParamType.UUID).subscribe(() => {
      //   this.approveDialog.close();
      // });
      if (this.paramTypeDialog.isOpen) {
        this.paramTypeDialog.close();
      }
      this.updateList();
    }
  }

  public sendToReview(fromTarget) {
    this.reviewFrom = fromTarget;
    this.chooseMgr.open();
  }

  public afterChooseWFApprMgr(mgrId) {
    const submitWF = (UUID) => {
      this.managementService.submitWF(this.setReviewSubmitData(
        [UUID],
        mgrId
      ), this.WFType).subscribe(() => {
        this.updateList();
      });
    };

    this.systemSettingService
      .updateSystemParamType(this.generateUpdateParamType)
      .subscribe(() => {
        // 存檔後重新打才拿得到oData & sData
        this.systemSettingService
          .getSystemParamsTypeList(this.activeParamId).subscribe((data) => {
            this.paramType = data.value.map(d => {
              const reData = d.sData || d.oData;
              return { ...reData, oData: d.oData };
            });
            const currnetUUID = (this.paramType.find(pt => this.workingParamType.oData.UUID === pt.oData.UUID) || { UUID: '' }).UUID;
            if(this.paramTypeDialog.isOpen) {
              this.paramTypeDialog.close();
            }
            submitWF(currnetUUID);
          });
      });
  }

  public setReviewSubmitData(selectedRowId, mgrId, updateData?) {
    const options: any = {
      UUIDs: selectedRowId,
      WFApprMgrEmpId: mgrId,
      ApplyEmp: this.auth.getLoginUser(),
      // UpdateData: {},
      BaseUrl: this.router.url,
      WFObjectName: this.managementService.getWFObjectName()
    };

    if (!_.isEmpty(updateData)) { options.UpdateData = updateData; }

    return options;
  }

  get generateUpdateParamType() {
    return {
      UUID: this.workingParamType.oData.UUID,
      Value: this.paramTypeForm.form.controls['Value'].value,
      Description: this.paramTypeForm.form.controls['Description'].value,
      ActiveCode: ManagementWFStatus.ACTIVE
    };
  }

  public updateList() {
    if (this.reviewFrom === 'paramType') {
      this.showParamType({ UUID: this.activeParamId });
    }
  }

  public return(from, closeDialog = true) {
    this.reviewFrom = from;
    if (this.reviewFrom === 'param') {
      this.reviewSource = [{
        applicantId: this.workingParam.applicantId,
        applyDate: this.workingParam.applyDate,
        applicant: this.workingParam.applicant,
      }];
      this.paramsDialog.close();
      this.returnDialog.open();
    } else if (this.reviewFrom === 'paramType') {
      this.reviewSource = [{
        applicantId: this.workingParamType.applicantId,
        applyDate: this.workingParamType.applyDate,
        applicant: this.workingParamType.applicant,
      }];
      if (closeDialog) {
        this.paramTypeDialog.close();
      }
      this.returnDialog.open();
    }else if (this.reviewFrom === 'dropdown') {
      this.reviewSource = [{
        applicantId: this.workingDropdownSetting.applicantId,
        applyDate: this.workingDropdownSetting.applyDate,
        applicant: this.workingDropdownSetting.applicant,
      }];
      if (closeDialog) {
        this.dropdownDialog.close();
      }
      this.returnDialog.open();
    }else if (this.reviewFrom === 'dropdownItem') {
      this.reviewSource = [{
        applicantId: this.workingDropdownItem.applicantId,
        applyDate: this.workingDropdownItem.applyDate,
        applicant: this.workingDropdownItem.applicant,
      }];
      if (closeDialog) {
        this.dropdownItemDialog.close();
      }
      this.returnDialog.open();
    }
  }

  public approve(from, closeDialog = true) {
    this.reviewFrom = from;
    if (this.reviewFrom === 'param') {
      this.reviewSource = [{
        applicantId: this.workingParam.applicantId,
        applyDate: this.workingParam.applyDate,
        applicant: this.workingParam.applicant,
      }];
      this.paramsDialog.close();
      this.approveDialog.open();
    }else if (this.reviewFrom === 'paramType') {
      this.reviewSource = [{
        applicantId: this.workingParamType.applicantId,
        applyDate: this.workingParamType.applyDate,
        applicant: this.workingParamType.applicant,
      }];
      if (closeDialog) {
        this.paramTypeDialog.close();
      }
      this.approveDialog.open();
    }else if (this.reviewFrom === 'dropdown') {
      this.reviewSource = [{
        applicantId: this.workingDropdownSetting.applicantId,
        applyDate: this.workingDropdownSetting.applyDate,
        applicant: this.workingDropdownSetting.applicant,
      }];
      if (closeDialog) {
        this.dropdownDialog.close();
      }
      this.approveDialog.open();
    }else if (this.reviewFrom === 'dropdownItem') {
      this.reviewSource = [{
        applicantId: this.workingDropdownItem.applicantId,
        applyDate: this.workingDropdownItem.applyDate,
        applicant: this.workingDropdownItem.applicant,
      }];
      if (closeDialog) {
        this.dropdownItemDialog.close();
      }
      this.approveDialog.open();
    }
  }


  public showParamType(param) {
    this.activeParamId = param.UUID;
    this.systemSettingService.getSystemParamsTypeList(param.UUID).subscribe((data) => {
      this.paramType = data.value.map(d => {
        const reData = d.sData || d.oData;
        return { ...reData, oData: d.oData };
      });
    });
  }

  public getLabelClass(status) {
    if (status) {
      return ManagementHelper.headerTagStatusClass(status);
    }
    return '';
  }

  public getLableText(status) {
    if (_.includes([this.statusEnum.STAGE_REVIEW, this.statusEnum.STAGE], status)) {
      return ManagementWFStatusHelper.ManagementWFStatusLabelMap[status];
    }
    return '';
  }

  public approveOrReturnDropdownItem(item, acceptOrReject) {
    this.systemSettingService.getDropdownItem(item.UUID).subscribe((data) => {
      this.workingDropdownItem = data;
      if (acceptOrReject === 'approve') {
        this.approve('dropdownItem', false);
      }else {
        this.return('dropdownItem', false);
      }
    });
  }

  public approveOrReturnParamType(pType, reviewType) {
    // this.systemSettingService.getSystemParamsType(pType.UUID).subscribe((data) => {
    //   this.workingParamType = data;
    //   if (acceptOrReject === 'approve') {
    //     this.approve('paramType', false);
    //   }else {
    //     this.return('paramType', false);
    //   }
    // });
    const rl = _.cloneDeep(pType);
    delete rl.oData;
    this.reviewSource = [rl];
    this.managementService.checkoutWF({
      UUIDs: this.reviewSource,
      WFObjectName: this.managementService.getWFObjectName()
    }, this.WFType)
      .subscribe(resp => {
        if (resp.isOk) {
          if (reviewType === 'approve') {
            this.approveDialog.open();
          } else {
            this.returnDialog.open();
          }}
      });
  }

  public isDropdownNodeActive(id): boolean {
    if(!this.activeDropdownSetting) {
      return false;
    }else {
      return this.activeDropdownSetting.UUID === id;
    }
  }

  public onDropdownNodeClick(dropdownSetting) {
    this.activeDropdownSetting = dropdownSetting;
    this.systemSettingService.getChildrenOfDropdownSetting(dropdownSetting.UUID).subscribe((data) => {
      this.dropdownItems = data;
    });
  }

  public openParamsDialog(mode, param?) {
    this.reviewFrom = 'param';
    this.paramDialogMode = mode;
    this.paramForm.reset();
    if (this.paramDialogMode === 'add') {
      this.workingParam = null;
      this.paramForm.form.controls['Description'].enable();
      this.paramForm.form.controls['Code'].enable();
      this.paramsDialog.open();
    } else if (this.paramDialogMode === 'edit' || this.paramDialogMode === 'view') {
      const data = param;
      // this.systemSettingService.getSystemParam(param.UUID).subscribe((data) => {
        this.paramModelChanges = data.changes || [];
        this.workingParam = data;
        this.paramForm.patchValue({
          Description: data.Description,
          Code: data.Code
        });
        if (this.paramDialogMode === 'edit') {
          this.paramForm.form.controls['Description'].enable();
          this.paramForm.form.controls['Code'].disable();
        } else if (this.paramDialogMode === 'view') {
          this.paramForm.form.controls['Description'].disable();
          this.paramForm.form.controls['Code'].disable();
        }
        this.paramsDialog.open();
      // });
    }
  }

  public onParamFormSubmit(formValue) {
    if (this.paramDialogMode === 'add') {
      this.systemSettingService.addSystemParams(formValue).subscribe(() => {
        this._getSystemParams();
        this.paramsDialog.close();
      });
    } else if (this.paramDialogMode === 'edit') {
      this.systemSettingService.updateSystemParams(this.workingParam.Code, formValue).subscribe(() => {
        this._getSystemParams();
        this.paramsDialog.close();
      });
    }
  }

  // 參數類別
  get paramDialogHeader() {
    if (this.paramDialogMode === 'add') {
      return '新增參數';
    }else if (this.paramDialogMode === 'edit') {
      return '編輯參數';
    }else if (this.paramDialogMode === 'view') {
      return '檢視參數';
    }
    return '';
  }

  // 參數類別
  get paramTypeDialogHeader() {
    if (this.paramTypeDialogMode === 'add') {
      return '新增參數類別';
    }else if (this.paramTypeDialogMode === 'edit') {
      return '編輯參數類別';
    }else if (this.paramTypeDialogMode === 'view') {
      return '檢視參數類別';
    }
    return '';
  }

  public openParamTypeDialog(mode, paramType?) {
    this.reviewFrom = 'paramType';
    this.paramTypeForm.reset();
    this.paramTypeDialogMode = mode;
    if (this.paramTypeDialogMode === 'add') {
      this.workingParamType = null;
      this.paramTypeForm.form.controls['Description'].enable();
      this.paramTypeForm.form.controls['Code'].enable();
      this.paramTypeForm.form.controls['Value'].enable();
      this.paramTypeDialog.open();
    } else if (this.paramTypeDialogMode === 'edit' || this.paramTypeDialogMode === 'view') {
      // this.systemSettingService.getSystemParamsType(paramType.UUID).subscribe((data) => {
        // this.paramTypeModelChanges = [];
        this.paramTypeModelChanges = this.setParamChanged(['Value', 'Description'], paramType.oData, paramType);
        this.workingParamType = paramType;
        this.paramTypeForm.patchValue({
          Description: paramType.Description,
          Code: paramType.Code,
          Value: paramType.Value
        });

        if (this.paramTypeDialogMode === 'edit' &&
          !_.includes([this.statusEnum.INACTIVE, this.statusEnum.STAGE_REVIEW], paramType.Status)) {
          this.paramTypeForm.form.controls['Description'].enable();
          this.paramTypeForm.form.controls['Code'].disable();
          this.paramTypeForm.form.controls['Value'].enable();
        } else if (this.paramTypeDialogMode === 'view' ||
          _.includes([this.statusEnum.INACTIVE, this.statusEnum.STAGE_REVIEW], paramType.Status)) {
          this.paramTypeForm.form.controls['Description'].disable();
          this.paramTypeForm.form.controls['Code'].disable();
          this.paramTypeForm.form.controls['Value'].disable();
        }
        this.paramTypeDialog.open();
      // });
    }
  }

  public onParamTypeFormSubmit(formValue) {
    console.log(formValue, this.paramTypeDialogMode);
    if (this.paramTypeDialogMode === 'add') {
      this.systemSettingService.addSystemParamType({
        SysPropUUID: this.activeParamId,
        ...formValue,
        ActiveCode: ManagementWFStatus.ACTIVE
      }).subscribe(() => {
        this.showParamType({ UUID: this.activeParamId });
        this.paramTypeDialog.close();
      });
    } else if (this.paramTypeDialogMode === 'edit') {
      this.systemSettingService.updateSystemParamType(this.generateUpdateParamType).subscribe(()=>{
        this.paramTypeDialog.close();
        this.showParamType({ UUID: this.activeParamId });
      });
    }
  }


    // 下拉選單
    get dropdownDialogHeader() {
      if (this.dropdownSettingDialogMode === 'add') {
        return '新增下拉選單';
      }else if (this.dropdownSettingDialogMode === 'edit') {
        return '編輯下拉選單';
      }else if (this.dropdownSettingDialogMode === 'view') {
        return '檢視下拉選單';
      }
      return '';
    }

    // 下拉選單項目
    get dropdownITemDialogHeader() {
      if (this.dropdownItemDialogMode === 'add') {
        return '新增下拉選單項目';
      }else if (this.dropdownItemDialogMode === 'edit') {
        return '編輯下拉選單項目';
      }else if (this.dropdownItemDialogMode === 'view') {
        return '檢視下拉選單項目';
      }
      return '';
    }

  public onDropdownFormSubmit(formValue) {
    if (this.dropdownSettingDialogMode === 'add') {
      this.systemSettingService.addDropdownSetting(formValue).subscribe(() => {
        this._getDropdownSettings();
        this.dropdownDialog.close();
      });
    }else if (this.dropdownSettingDialogMode === 'edit') {
      this.systemSettingService.updateDropdownSetting(this.workingDropdownSetting.UUID, formValue).subscribe(() => {
        this._getDropdownSettings();
        this.dropdownDialog.close();
      });
    }
  }

  public openDropdownDialog(mode, dropdownSetting?) {
    this.dropdownSettingDialogMode = mode;
    if (this.dropdownSettingDialogMode === 'add') {
      this.workingDropdownSetting = null;
      this.dropdownForm.reset();
      this.dropdownForm.form.controls['Description'].enable();
      this.dropdownForm.form.controls['Code'].enable();
      this.dropdownDialog.open();
    }else if (this.dropdownSettingDialogMode === 'edit' || this.dropdownSettingDialogMode === 'view') {
      this.dropdownForm.reset();
      this.systemSettingService.getDropdownSetting(dropdownSetting.UUID).subscribe((data) => {
        this.dropdownModelChanges = data.changes;
        this.workingDropdownSetting = data;
        this.dropdownForm.patchValue({
          Description: data.Description,
          Code: data.Code
        });
        if (this.dropdownSettingDialogMode === 'edit') {
          this.dropdownForm.form.controls['Description'].enable();
          this.dropdownForm.form.controls['Code'].disable();
        }else if (this.dropdownSettingDialogMode === 'view') {
          this.dropdownForm.form.controls['Description'].disable();
          this.dropdownForm.form.controls['Code'].disable();
        }
        this.dropdownDialog.open();
      });

    }
  }

  public openDropdownItemDialog(mode, item?) {
    this.dropdownItemDialogMode = mode;
    if (this.dropdownItemDialogMode === 'add') {
      this.workingDropdownItem = null;
      this.dropdownItemForm.form.controls['Description'].enable();
      this.dropdownItemForm.form.controls['Code'].enable();
      this.dropdownItemForm.form.controls['hasNextLevel'].enable();
      this.dropdownItemForm.reset();
      this.dropdownItemDialog.open();
    }
    if (this.dropdownItemDialogMode === 'edit' || this.dropdownItemDialogMode === 'view') {
      this.systemSettingService.getDropdownItem(item.UUID).subscribe((data) => {
        this.dropdownItemModelChanges = data.changes;
        this.workingDropdownItem = data;
        this.dropdownItemForm.patchValue({
          Description: data.Description,
          Code: data.Code,
          Value: data.Value
        });
        if (this.dropdownItemDialogMode === 'edit') {
          this.dropdownItemForm.form.controls['Description'].enable();
          this.dropdownItemForm.form.controls['Code'].disable();
          this.dropdownItemForm.form.controls['hasNextLevel'].enable();
        }else if (this.dropdownItemDialogMode === 'view') {
          this.dropdownItemForm.form.controls['Description'].disable();
          this.dropdownItemForm.form.controls['Code'].disable();
          this.dropdownItemForm.form.controls['hasNextLevel'].disable();
        }
        this.dropdownItemDialog.open();
      });
    }
  }

  public onDropdownItemFormSubmit(formValue) {
    if (this.dropdownItemDialogMode === 'add') {
      this.systemSettingService.addDropdownItem(formValue).subscribe(() => {
        this._getDropdownSettings();
        this.onDropdownNodeClick(this.activeDropdownSetting);
        this.dropdownItemDialog.close();
      });
    }else if (this.dropdownItemDialogMode === 'edit') {
      this.systemSettingService.updateDropdownItem(this.workingDropdownItem.UUID, formValue).subscribe(() => {
        this._getDropdownSettings();
        this.onDropdownNodeClick(this.activeDropdownSetting);
        this.dropdownItemDialog.close();
      });
    }
  }

  public openAddFileItemDialog() {
    this.addFileItemForm.reset();
    this.addFileItemDialog.open();
  }

  public onAddFileItemFormSubmit(formValue) {
    this.systemSettingService.addFileItem(formValue).subscribe(() => {
      this.addFileItemDialog.close();
      this._getFileItems();
    });
  }

  public onEditFileItemClick(file) {
    this.systemSettingService.getFileItem(file.UUID).subscribe((data) => {
      this.editingFileItem = data;
      this.editFileItemForm.patchValue({
        Code: data.Code,
        Description: data.Description
      });
      this.editFileItemDialog.open();
    });
  }

  public onEditFileItemFormSubmit(formValue) {
    this.systemSettingService.updateFileItem(this.editingFileItem.UUID, formValue).subscribe(() => {
      this._getFileItems();
      this.editFileItemDialog.close();
    });
  }


  public onFileItemClick(file) {
    this.activeFileItem = file;
    this.systemSettingService.getFileItem(file.UUID).subscribe((data) => {
      this.viewingFileItem = data;
    });
  }

  fileChangeEvent(fileInput: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      let file = fileInput.target.files[0];
      this.systemSettingService.uploadFile(file).subscribe(() => {
        this.uploadFileName = file.name;
      });
    }
  }

  public isFormValid(form) {
    if (!form) {
      return false;
    }else {
      return form.valid;
    }
  }

  ngOnInit() {
    this._getSystemParams();
    this._getDropdownSettings();
    this._getFileItems();
  }

  private prepareControls() {
    this.paramsControls = SystemSettingControls.getParamControls();
    this.paramTypeControls = SystemSettingControls.getParamTypeControls();

    this.dropdownControls = SystemSettingControls.getDropdownControls();
    this.dropdownItemControls = SystemSettingControls.getDropdownItemControls();

    this.addFileItemControls = SystemSettingControls.getAddFileItemControls();
    this.editFileItemControls = SystemSettingControls.getEditFileItemControls();
  }

  private _getSystemParams() {
    this.systemSettingService.getSystemParams().subscribe((data) => {
      this.basicParams = data.value.filter(d => d.SystemPropertyType === '1');
      console.log(this.basicParams);
    });
  }

  private _getDropdownSettings() {
    this.systemSettingService.getDropdownSettings().subscribe((data) => {
      this.dropdownSettings.data = data;
    });
  }

  private _getFileItems() {
    this.systemSettingService.getFileItems().subscribe((data) => {
      this.fileItems = data;
    });
  }

  private getChildren = (node: any) => node.children;

}
