import { SingleCheckboxControl } from './../../shared/components/dynamic-form/controls/single-checkbox';
import { TextControl } from '../../shared/components/dynamic-form/controls';

export class SystemSettingControls {
    static getParamControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '參數中文說明',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '參數系統代碼',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            })
        ];
    }

    static getParamTypeControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '參數中文說明',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '參數系統代碼',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Value',
                label: '參數值',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            })
        ];
    }

    static getDropdownControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '項目名稱',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '項目系統代碼',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            })
        ];
    }

    static getDropdownItemControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '項目名稱',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '項目系統代碼',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new SingleCheckboxControl({
                key: 'hasNextLevel',
                label: '是否有下一層',
                required: true,
                columnClasses: ['12'],
            }),
        ];
    }

    static getAddFileItemControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '項目名稱',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '項目系統代碼',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
        ];
    }

    static getEditFileItemControls() {
        return [
            new TextControl({
                key: 'Description',
                label: '項目名稱',
                required: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
            new TextControl({
                key: 'Code',
                label: '項目系統代碼',
                required: true,
                disabled: true,
                columnClasses: ['12'],
                placeholder: '請輸入...',
            }),
        ];
    }
}
