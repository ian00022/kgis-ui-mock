export enum Status {
    REVIEWING = 'Reviewing',
    NORMAL = 'Normal',
    ACCEPTED = 'Accepted',
    REJECTED = 'Rejected'
  }