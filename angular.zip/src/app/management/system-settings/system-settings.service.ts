import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Status } from './system-settings.model';
import * as _ from 'lodash';
import { ApiService } from 'app/core/services';

// should be deleted after integrate with back-end
let paramExtraAttrType1 = {
  reject: false,
  status: Status.REVIEWING
};

let paramExtraAttrType2 = {
  reject: true,
  rejectReason: '確認後重寫',
  rejecterName: '提王',
  status: Status.NORMAL
};

let paramTypeExtraType1 = {
  reject: false,
  status: Status.REVIEWING
};

let paramTypeExtraType2 = {
  reject: true,
  rejectReason: '確認後重寫',
  rejecterName: '提王',
  status: Status.NORMAL
};

let dropdownSettingExtraType1 = {
  status: Status.REVIEWING,
};

@Injectable()
export class SystemSettingsService {

  public SystemPropertyType = {
    Value: '1',
    Domain: '2',
    File: '3',
    Link: '4',
  };

  private systemParams = [
    Object.assign({Description: '成效管理', Code: '1', id: 1}, _.cloneDeep(paramExtraAttrType1)),
    Object.assign({Description: '信件發送權限設定', Code: '2', id: 2}, _.cloneDeep(paramExtraAttrType2)),
    Object.assign({Description: '相關專區連結', Code: '3', id: 3}, _.cloneDeep(paramExtraAttrType2)),
  ];

  private systemParamType = [
    Object.assign({Description: '成效管理匯出筆數上限',Code: 'AA0', value: '1000', id: 1}, _.cloneDeep(paramTypeExtraType1)),
    Object.assign({Description: '成效管理匯入筆數上限',Code: 'AA1', value: '1500', id: 2}, _.cloneDeep(paramTypeExtraType2)),
  ];

  private fileItems = [
    Object.assign({Description: '房貸壽險試算表',Code: 'AA0', id: 1, edit: true}, {}),
    Object.assign({Description: '統計表',Code: 'A75', id: 2, edit: true}, {}),
  ];

  private dropdownSettings = [
    _.assign({Description: '名單狀態', Code: 'A1', value: 9, id:1, children: [
      {Description: '待審核', Code: 'A5', value: 8, id:5, status: Status.REVIEWING, children: [
        {Description: 'aaa', Code: 'A7', value: 7, id:7, status: Status.REVIEWING},
        {Description: 'bbb', Code: 'A7', value: 6, id:8, status: Status.REVIEWING}
      ]},
      {Description: '已完成', Code: 'A6', value: 5, id:6, children: [

      ]},
    ]}, dropdownSettingExtraType1),
    _.assign({Description: '總行案件狀態', Code: 'A2', value: 4, id:2}, dropdownSettingExtraType1),
  ];

  constructor(
    private api: ApiService
  ) { }

  public getSystemParam(id): Observable<any> {
    let hit = _.find(_.cloneDeep(this.systemParams), {id: id});
    let rs = Object.assign(hit, {
      changes: [
        {
          key: 'Description',
          valueBefore: hit.Description + '_before',
          valueAfter: hit.Description
        }
      ],
      applicant: '李俊仁',
      applicantId: '75',
      applyDate: '2018/03/21',
    });

    return asyncReturn(rs);
  }

  public getSystemParams(): Observable<any> {
    // return asyncReturn(this.systemParams);
    return this.api.get('Prop/list', {});
  }

  public addSystemParams(systemParam: any): Observable<any> {
    // this.systemParams.push(Object.assign(systemParam, {id: this.systemParams.length + 1, reject: false}));
    // return asyncReturn(null);
    return this.api.post(`Prop`, { SystemPropertyType: this.SystemPropertyType.Value, ...systemParam}, {});
  }

  public updateSystemParams(SysCode, formData: any): Observable<any> {
    // let matchIdx = _.findIndex(this.systemParams, {id: id});
    // _.merge(this.systemParams[matchIdx], formData);
    // return asyncReturn(null);
    return this.api.patch(`Prop/${SysCode}`, formData);
  }

  public getSystemParamsType(id): Observable<any> {
    let hit = _.find(this.systemParamType, {id: id});
    let rs = _.assign(hit, {
      changes: [
        {
          key: 'Description',
          valueBefore: hit.Description + '_before',
          valueAfter: hit.Description
        },
        {
          key: 'Code',
          valueBefore: hit.Code + '_before',
          valueAfter: hit.Code
        }
      ],
      applyDate: '2018/05/04',
      applicant: '李俊仁',
      applicantId: '75',
      reviewer: 'Jessi Jereemy',
      reviewDate: '2018/07/12'});
    return asyncReturn(rs);
  }

  public getSystemParamsTypeList(id): Observable<any> {
    // return asyncReturn(_.cloneDeep(this.systemParamType));
    return this.api.get(`Prop/Value/${id}`, {});
  }

  public addSystemParamType(formData): Observable<any> {
    // this.systemParamType.push(Object.assign(formData, {id: this.systemParamType.length + 1, reject: false}));
    // return asyncReturn(null);
    return this.api.post(`Prop/Value`, formData, {});
  }

  public updateSystemParamType(formData): Observable<any> {
    // let matchIdx = _.findIndex(this.systemParamType, {id: id});
    // _.merge(this.systemParamType[matchIdx], formData);
    // return asyncReturn(null);
    return this.api.patch(`Prop/Value`, formData);
  }

  public getDropdownSettings():  Observable<any> {
    let rs = _.cloneDeep(this.dropdownSettings);
    rs = rs.map((d) => {
      return _.assign(d, {isRoot: true});
    });
    return asyncReturn(rs);
  }

  public addDropdownSetting(formData): Observable<any> {
    this.dropdownSettings.push(_.assign(formData, {
      id: 1000 + this.dropdownSettings.length
    }));
    return asyncReturn(null);
  }

  public getDropdownSetting(id): Observable<any> {
    let rs = _.find(this.dropdownSettings, {id: id});
    rs = _.assign(rs, {
      changes: [
        // {
        //   key: 'Description',
        //   valueBefore: rs.Description + '_before',
        //   valueAfter: rs.Description
        // },
        // {
        //   key: 'Value',
        //   valueBefore: rs.Value + '_before',
        //   valueAfter: rs.Value
        // }
      ],
      applicantId: '75',
      applicant: '陳俊停',
      applyDate: '2018/05/04',
      reviewer: 'Jessi Jereemy',
      reviewDate: '2018/07/12'});
    return asyncReturn(_.cloneDeep(rs));
  }

  public updateDropdownSetting(id, formData): Observable<any> {
    let matchIdx = _.findIndex(this.dropdownSettings, {id: id});
    _.merge(this.dropdownSettings[matchIdx], formData);
    return asyncReturn(null);
  }

  public getChildrenOfDropdownSetting(id): Observable<any> {
    let matchIdx = _.findIndex(this.dropdownSettings, {id: id});
    if (matchIdx === -1) {
      matchIdx = 1;
    }
    return asyncReturn(this.dropdownSettings[matchIdx]['children']);
  }

  public addDropdownItem(formData): Observable<any> {
    this.dropdownSettings[0]['children'].push(_.assign(formData, {id: 2000 + this.dropdownSettings[0]['children'].length}));
    return asyncReturn(null);
  }

  public getDropdownItem(id): Observable<any> {
    let rs = this.dropdownSettings[0];
    return asyncReturn(_.cloneDeep(
      _.assign(rs,
      {
        changes: [
          {
            key: 'Description',
            valueBefore: rs.Description + '_before',
            valueAfter: rs.Description
          },
          {
            key: 'Code',
            valueBefore: rs.Code + '_before',
            valueAfter: rs.Code
          }
        ],
        applicantId: '75', applicant: '陳俊停', applyDate: '2018/05/04', reviewer: 'Jessi Jereemy', reviewDate: '2018/07/12'
      })
    ));
  }

  public getFileItems(): Observable<any> {
    return asyncReturn(_.cloneDeep(this.fileItems));
  }

  public addFileItem(formData): Observable<any> {
    this.fileItems.push(_.assign(formData, {id: this.fileItems.length + 1}));
    return asyncReturn(null);
  }

  public getFileItem(id): Observable<any> {
    let hit = _.find(this.fileItems, {id: id});
    let rs;
    if (id === 1) {
      rs = _.assign(hit, {
        fileName: 'abc.xml',
        changed: true,
        beforeChange: 'abc_before.xml',
        beforeLink: 'www.google.com',
        afterChange: 'abc.xml',
        afterLink: 'www.yahoo.com',
        status: 'reviewing'
      });
    }else {
      rs = _.assign(hit, {
        fileName: 'ddd.xml',
        changed: false,
        status: 'normal'
      });
    }
    return asyncReturn(rs);
  }

  public updateFileItem(id, formData: any): Observable<any> {
    let matchIdx = _.findIndex(this.fileItems, {id: id});
    _.merge(this.fileItems[matchIdx], formData);
    return asyncReturn(null);
  }

  public updateDropdownItem(id, formData): Observable<any> {
    return asyncReturn(null);
  }

  public uploadFile(file): Observable<any> {
    let formData = new FormData();
    formData.append('file', file);
    // return this.http.post('file/url', file);
    return asyncReturn(null);
  }

  public approveParamType(id): Observable<any> {
    let matchIdx = _.findIndex(this.systemParamType, {id: id});
    _.merge(this.systemParamType[matchIdx], {status: Status.ACCEPTED});
    return asyncReturn(null);
  }

  public returnParamType(id): Observable<any> {
    let matchIdx = _.findIndex(this.systemParamType, {id: id});
    _.merge(this.systemParamType[matchIdx], {status: Status.REJECTED});
    return asyncReturn(null);
  }

  public approveParam(id): Observable<any> {
    let matchIdx = _.findIndex(this.systemParams, {id: id});
    _.merge(this.systemParams[matchIdx], {status: Status.ACCEPTED});
    return asyncReturn(null);
  }

  public returnParam(id): Observable<any> {
    let matchIdx = _.findIndex(this.systemParams, {id: id});
    _.merge(this.systemParams[matchIdx], {status: Status.ACCEPTED});
    return asyncReturn(null);
  }
}

function asyncReturn(value) {
  return new Observable((observer) => {
    observer.next(value);
  });
}

