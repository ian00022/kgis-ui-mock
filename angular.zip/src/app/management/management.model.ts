import { OptionsHelper } from '../core/models/comm-data';
export enum ManagementWFStatus {
  // 0 : 停用
  // 1 : 生效
  // 2 : 暫存
  // 3 : 暫存 - 待覆核
  // 4 : 暫存 - 主管退回
  INACTIVE = '0',
  ACTIVE = '1',
  STAGE = '2',
  STAGE_REVIEW = '3',
  STAGE_REJECT = '4'
}

export enum ManagementWFType {
  EMAIL_TEMPLATE = 'MailTemplate',
  OVERDUE = 'Overdue',
  MARKETINGTEAM = 'Team',
  PRODUCTTAG = 'Tag',
  PRODUCTSETTING = 'Product',
  NOTIFICATION = 'Notification',
  HEADOFFFICEASSIGNMENT = 'CaseMgm',
  PROP = 'Prop',
}

export class ManagementWFStatusHelper {
  public static ManagementWFStatusLabelMap = {
    '0': '停用',
    '1': '生效',
    '2': '暫存',
    '3': '待覆核',
    '4': '主管退回',
  };

  public static mapTo(key: ManagementWFStatus): string {
    return OptionsHelper.mapTo(key, this.ManagementWFStatusLabelMap);
  }
  public static getOptionsOf(values: string[]) {
    return OptionsHelper.getOptionsOf(values, this.ManagementWFStatusLabelMap);
  }
  public static getAllOptions() {
    return OptionsHelper.getAllOptions(this.ManagementWFStatusLabelMap);
  }
}

export enum NotificationPublishCategory {
  // 1: 全行行銷人員
  // 2: 分行
  // 3: 區域
  // 4: 消金中心
  // 5: 職系
  ALL = '1',
  BRANCHES = '2',
  AREA = '3',
  CENTER = '4',
  USERROLE = '5'
}

export enum OverdueType {
  ASSIGN_NOT_YET = '1',
  ASSIGN_ALREADY = '2',
  EXECUTE_NOT_YET = '3',
  EXPIRED = '4',
  EXPIRE_NOTIFICATION = '5'
}

export enum OverdueEvent {
  ASSIGN = '1',
  ASSIGN_MAXIMUN = '2',
  REASSIGN = '3',
  REFERRAL = '4',
  APPROVED = '5'
}

export enum OverdueNoticeType {
  EXPIRED_SIGNAL = '1',
  MESSAGE_NOTIFICATION = '2',
  MAIL_CONSOLIDATION = '3',
  MAIL_SINGLE = '4'
}

export enum OverdueNoticeFrequency {
  ONCE = '1',
  DAILY = '2',
  WEEKLY = '3',
  MONTHLY = '4'
}
