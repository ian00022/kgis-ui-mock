import { ManagementWFStatus } from './management.model';
import { DynamicFormComponent } from './../shared/components/dynamic-form/dynamic-form.component';
import { ControlBase } from './../shared/components/dynamic-form/controls/control-base';
import * as _ from 'lodash';

export class ManagementHelper {
  constructor() {}

  public static rowClassNameFunction = (row, index) => {
    switch (row.status) {
      case ManagementWFStatus.INACTIVE:
        return 'markgary';
      case ManagementWFStatus.STAGE_REVIEW:
        return 'markRed';
      default:
        return '';
    }
  }

  public static headerTagStatusClass(status: string): string {
    switch (status) {
      case ManagementWFStatus.STAGE_REVIEW:
      case ManagementWFStatus.INACTIVE:
      case ManagementWFStatus.STAGE_REJECT:
        return 'red';
      case ManagementWFStatus.STAGE:
        return 'orange';
      case ManagementWFStatus.ACTIVE:
        return 'blue';
    }
    return '';
  }

  public static showDirtyFormControl(controls: ControlBase<any>[], form: DynamicFormComponent) {
    let temp = {};
    controls.forEach(
      (el) => {
        if (form.form.controls[el.key].dirty) {
          temp[el.key] = form.form.controls[el.key].value;
        }
      });
    return temp;
  }

  public static handleManagementDisplayData(data: any): any {
    return _.assign({status: data.Status}, data.sData ? data.sData : data.oData);
  }

  public static discardable(data): boolean {
    return data.status === ManagementWFStatus.STAGE || data.status === ManagementWFStatus.STAGE_REJECT;
  }
  public static showDisableBtn(data): boolean {
    return data.status === ManagementWFStatus.ACTIVE;
  }
  public static showEnableBtn(data): boolean {
    return data.status === ManagementWFStatus.INACTIVE;
  }
  public static showSaveBtn(data): boolean {
    return data.status === ManagementWFStatus.ACTIVE ||
           data.status === ManagementWFStatus.STAGE ||
           data.status === ManagementWFStatus.STAGE_REJECT;
  }
  public static showReviewBtn(data): boolean {
    return data.status === ManagementWFStatus.STAGE_REVIEW;
  }
}
