import { Component, OnInit, ViewChild, OnDestroy, ElementRef, ChangeDetectorRef, ViewChildren, QueryList } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { Subject } from 'rxjs';
import { NzNotificationService, UploadXHRArgs, UploadFile, NzUploadComponent } from 'ng-zorro-antd';
import { NgxPermissionsService } from 'ngx-permissions';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmSideDialogComponent } from './../../shared/components/ibm-dialog/ibm-side-dialog/ibm-side-dialog.component';
import { CheckBoxTableHelper } from 'app/shared/helper/table-checkbox-helper';
import { ISelectOptionModel } from './../../core/models/comm-data';
import { IbmTableComponent } from './../../shared/components/ibm-table/ibm-table.component';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { ManagementHelper } from '../management-helper';
import { LoggerService } from '../../shared/logger.service';
import { SelectOptionsService } from '../../shared/services/select-options.service';
import { SingleDropdownControl } from '../../shared/components/dynamic-form/controls/single-dropdown-control';
import { EmailTemplateService } from './email-template.service';
import { EmailTemplateControls } from './email-template.controls';
import { ControlBase, TextControl, DatepickerControl, MultiSelectControl } from './../../shared/components/dynamic-form/controls';
import { Permissions } from 'app/core/models/permissions';
import { emptyStringToNull } from 'app/shared/functions/common';
import { environment } from 'environments/environment';
import { DateIso8601Pipe } from '../../shared/pipes/date-iso-8601.pipe';
import { AuthService } from '../../core/services/auth.service';
import { ManagementWFType, ManagementWFStatus } from 'app/management/management.model';
import * as querystring from 'querystring';
import { ApiService, MarketingService, EmailService, JwtService, ManagementService } from 'app/core/services';

@Component({
  selector: 'esun-email-template',
  templateUrl: './email-template.component.html',
  styleUrls: ['./email-template.component.scss']
})
export class EmailTemplateComponent implements OnInit, OnDestroy {

  @ViewChild('searchForm') searchForm: DynamicFormComponent;
  @ViewChild('marketingTable') marketingTable: IbmTableComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('emailPreviewDialog') emailPreviewDialog: IbmSideDialogComponent;
  @ViewChild('previewIframe') previewIframe: ElementRef;
  @ViewChild('editEmailTemplateForm') editEmailTemplateForm: DynamicFormComponent;
  @ViewChild('addTemplateDialog') addTemplateDialog: IbmDialogComponent;
  @ViewChild('newEmailTemplateForm') newEmailTemplateForm: DynamicFormComponent;
  @ViewChild('confirmEditCloseDialog') confirmEditCloseDialog: IbmDialogComponent;
  @ViewChild('chooseMgr') chooseMgr: IbmDialogComponent;
  @ViewChild('emailToUser') emailToUser: IbmDialogComponent;
  @ViewChild('uploadQRCode') uploadQRCode: IbmDialogComponent;
  @ViewChildren('nzUploader') nzUploader: QueryList<NzUploadComponent>;

  public searchControls: ControlBase<any>[] = [];
  public managementStatusOptions: ISelectOptionModel[];
  public emailTemplateCategoryOptions: ISelectOptionModel[];
  public emailTemplateProductTypeOptions: ISelectOptionModel[];
  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;
  public emailTemplateInfoList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public editTempOriData: any = {};
  public currentEmailTemplateStatus: string;
  public reviewList: any[] = [];
  public Permissions = Permissions;
  public displayEditArea: boolean = false;
  public displayPreviewIframe: boolean = true;
  public newEmailTemplateControl: ControlBase<any>[] = [];
  public editEmailTemplateControl: ControlBase<any>[] = [];
  public editingEmailTemplate;
  public orderTypes = [
    { value: 'TemplateCategoryCode', label: '樣板類別' },
    { value: 'ProductCategoryCode', label: '產品類別' },
    { value: 'MarketDate', label: '上架日期' }
  ];
  public orderType: any = this.orderTypes[0];
  public recipient = '';
  public recipients = [];
  public notAllowStrings = [];
  public uploadQRCodeTextInputs: any = [];
  public uploadQRCodeImgInputs: any = [];
  public WFType: ManagementWFType = ManagementWFType.EMAIL_TEMPLATE;
  public paramModelChanges = [];
  public currentConfirmType = null;
  public shouldExpiredDisabled = false;

  get editEmailModelChanges() {
    if (this.editingEmailTemplate) {
      return this.editingEmailTemplate.changes;
    }
    return {};
  }

  private editEmailSaveMode;
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private router: Router,
    private auth: AuthService,
    private api: ApiService,
    private permissionService: NgxPermissionsService,
    private logger: LoggerService,
    private options: SelectOptionsService,
    private managementService: ManagementService,
    private marketingService: MarketingService,
    private ref: ChangeDetectorRef,
    private emailService: EmailTemplateService,
    private notification: NzNotificationService,
    private email: EmailService,
    private jwt: JwtService
  ) {
    const option = this.options.getOptions(['emailTemplateCategory', 'emailTemplateProductType', 'managementStatus']);
    this.managementStatusOptions = option.managementStatus;
    this.emailTemplateCategoryOptions = option.emailTemplateCategory;
    this.emailTemplateProductTypeOptions = option.emailTemplateProductType;
  }

  ngOnInit() {
    this.prepareControls();
    this.checkPermission();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * 共用
   * fn: isRowSelectable 審核 判定是否可審核資料(非申請人本人&待審核)
   * fn: onReviewActionClick 走審核流程的dialog(退回or放行)
   * fn: isFormValid
   * fn: getLabel 傳入option的value及option list，回傳option的label
   */

  public isRowSelectable(row: any) {
    return row.Status === ManagementWFStatus.STAGE_REVIEW &&
      row.sData.ApplyEmpId !== this.auth.getLoginUser().loginEmpId;
  }

  public onReviewActionClick(dateType: string, reviewType: string) {
    if (dateType === 'single') {
      this.reviewList = [this.selectedRow.sData];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList.map(selectedRow => selectedRow.sData));
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.EMAIL_TEMPLATE)
      .subscribe(resp => {
        if (resp.isOk) {
          if (reviewType === 'approve') {
            this.approveDialog.open();
          } else {
            this.returnDialog.open();
          }}
      });
  }

  public isFormValid(form) {
    if (!form) {
      return false;
    }else {
      return form.valid;
    }
  }

  getLabel(value, type) {
    switch (type) {
      case 'TemplateCategoryCode':
        return (this.emailTemplateCategoryOptions.find(opt => opt.value === value) || {label: ''}).label;
      case 'ProductCategoryCode':
        return (this.emailTemplateProductTypeOptions.find(opt => opt.value === value) || {label: ''}).label;
      case 'managementStatus':
        return (this.managementStatusOptions.find(opt => opt.value === value) || {label: ''}).label;
      default:
        return '';
    }
  }


  /**
   * review/reject dialog
   * fn: handleAfterReviewAction 在user approve or reject之後
   */

  public handleAfterReviewAction() {
    this.closeEmailPreviewDialog();
    this.searchForm.submit();
    // this.editEmailTemplateForm.reset();
  }


  /**
   * List
   * fn: isSearchValid list頁的搜尋是否皆有效
   * fn: isAnySelected 審核 打勾數量 > 0
   * fn: handleSelectAllCheckboxClick 審核 全選
   * fn: handleCheckboxClick 審核 單筆打勾
   * fn: handleSearchSubmit list頁的搜尋提交 生成列表
   * fn: chooseOrderType 變更排序 會重新搜尋 生成列表
   * fn: openReviewMenu list的下拉選單，打開後會把selectedRow匯入
   * fn: displayTemplateEditingButtons
   */

  /**
   * whether all search inputs valid or not
   */
  get isSearchValid(): boolean {
    return this.searchForm.form.valid;
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.marketingTable) {
      return this.marketingTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.marketingTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList =  CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public handleSearchSubmit(value: any) {
    const newValue = emptyStringToNull(_.cloneDeep(value));
          newValue.OrderByCol = this.orderType.value;

    this.logger.debug('handleSearchSubmit: ', value, newValue);

    this.managementService.getEmailTemplateInfoList(newValue).subscribe(
      (emailTemplateInfoList) => {
        this.emailTemplateInfoList = emailTemplateInfoList.value;
        this.emailTemplateInfoList.map(list => {
          if (list.Status) { list.status = list.Status; }
          return list;
        });
        this.logger.debug('getEmailTemplateInfoList: ', this.emailTemplateInfoList);
      }
    );
  }

  public chooseOrderType(menu) {
    this.orderType = menu;
    this.searchForm.submit();
  }

  public openReviewMenu(row: any) {
    this.selectedRow = row;
  }

  previewHref(UUID) {
    return `${environment.api_url}MarketingDM/${UUID}/preview`;
  }

  getStatus(row) {
    return ManagementHelper.handleManagementDisplayData(row);
  }

  getExpired(row) {
    return (row.sData || row.oData).TemplateCategoryCode === '1' ?
      new DateIso8601Pipe().transform((row.sData || row.oData).Expired) : '';
  }

  // anyMenuPermission(row): boolean {
  //   const permissions = this.permissionService.getPermissions();
  //   return (
  //     (_.has(permissions, Permissions.EMAIL_TEMPLATE_APPROVE_UPDATE) && this.isRowSelectable(row)) ||
  //     _.has(permissions, Permissions.EMAIL_TEMPLATE_UPDATE)
  //   );
  // }

  /**
   * create dialog
   * fn: createEmailTemplate
   * fn: onNewEmailTemplateSubmit
   * fn: setCreateData 新增的form data
   */

  public createEmailTemplate() {
    this.newEmailTemplateForm.reset();
    this.addTemplateDialog.open();
  }

  /**
   * 新增E-mail樣板
   */
  public onNewEmailTemplateSubmit() {
    const payload = this.setCreateData();
    this.logger.debug('新增E-mail樣板 onNewEmailTemplateSubmit: ', payload);
    this.emailService.addEmailTemplate(payload).subscribe((res) => {
      if (res.isOk) { this.notification.success('新增E-mail樣板成功', ''); }
      this.addTemplateDialog.close();
      this.searchForm.reset();
      this.searchForm.submit();
    });
  }

  public setCreateData() {
    const Expired = this.newEmailTemplateForm.form.controls['Expired'].value;
    const options: any = {
      TemplateCategoryCode: this.newEmailTemplateForm.form.controls['TemplateCategoryCode'].value,
      ProductCategoryCode: this.newEmailTemplateForm.form.controls['ProductCategoryCode'].value,
      ProductName: this.newEmailTemplateForm.form.controls['ProductName'].value,
      MarketDate: this.newEmailTemplateForm.form.controls['MarketDate'].value,
      ActiveCode: '1',
      HTML: this.newEmailTemplateForm.form.controls['Html'].value,
      LoginUser: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType,
      }
    };
    if (Expired) {
      options.Expired = Expired;
    }
    return options;
  }


  /**
   * edit dialog
   * fn: displayTemplateEditingButtons 取得可以被編輯的資格(可以被編輯的狀態及權限)
   * fn: onEditEmailTemplate init 編輯dialog 的資料
   * fn: formInputsFromData 用以提取oData及sData的key (指定特定的key出來)
   * fn: setParamChanged 如果sData及oData有差異，會直接顯示在介面
   * fn: setDisable 在特定狀態下disable掉所有input
   * fn: previewURL 預覽iframe的網址
   * fn: setUpdateData 暫存提交的form data
   * fn: setEditSubmitData 送審的form data
   * fn: canDiscard 可以被還原的暫存(新增的暫存不可被還原)
   * fn: canSubmitEditDialog 可以送審的狀態(有暫存資料or表單有異動hasChangedEmailPreview)
   * fn: hasChangedEmailPreview 表單有異動
   * fn: afterChooseWFApprMgr 選擇可審核的主管後送審，如果目前的異動資料未暫存，會先跑暫存後，取得新的sData.UUID送審
   * fn: checkBeforeEditedClose 如果沒有暫存 關閉dialog時會提示
   * fn: refreshPreview 先暫存，再刷新preview iframe ※目前並沒有重新取得該筆record，所以可能會有資料不同步的問題
   * fn: onEditEmailTemplateFormSubmit 暫存或送審提交
   * fn: saveEmailTemplateTemp 提交暫存
   * fn: saveEmailTemplate 提交送審
   * fn: closeEmailPreviewDialog 關閉編輯的dialog，並清除此dialog的資料
   * fn: sendTestMail 開啟寄送測試信的dialog，並進入寄送填表流程
   * fn: getLatestValidState 還原至最後生效狀態
   */

  get displayTemplateEditingButtons() {
    const permissions = this.permissionService.getPermissions();
    const hasEditPermission = _.has(permissions, Permissions.EMAIL_TEMPLATE_UPDATE);
    // 有選擇到的項目
    // 有編輯權限
    // 在生效 & 暫存的狀態
    if (this.selectedRow &&
      hasEditPermission &&
      _.includes([ManagementWFStatus.ACTIVE, ManagementWFStatus.STAGE, ManagementWFStatus.STAGE_REJECT], this.currentEmailTemplateStatus)) {
      // this.logger.debug(this.selectedRow);
        return true;
    }
    return false;
  }

  public onEditEmailTemplate(row?: any, showForm?: boolean) {
    if (row) {
      // this.selectedRow = row;
      this.logger.debug('onEditEmailTemplate:', row, row.oData.UUID);
      this.displayPreviewIframe = false;
      this.emailService.getEmailTemplate(row.oData.UUID).subscribe((data) => {
        this.logger.debug(`emailService.getEmailTemplate UUID:${row.oData.UUID}: `, data);
        // 以新的資料為主要顯示
        const edm = data.value.sData || data.value.oData;
        this.currentEmailTemplateStatus = data.value.Status;
        this.selectedRow = _.cloneDeep(data.value);
        this.editingEmailTemplate = edm;
        // 用來比對inputs是否有異動
        this.editTempOriData = {
          TemplateCategoryCode: edm.TemplateCategoryCode,
          ProductCategoryCode: edm.ProductCategoryCode,
          MarketDate: new DateIso8601Pipe().transform(edm.MarketDate),
          Expired: new DateIso8601Pipe().transform(edm.Expired),
          ProductName: edm.ProductName,
          Html: edm.Html,
        };
        // 賦值
        this.editEmailTemplateForm.patchValue(_.cloneDeep(this.editTempOriData));
        // 顯示異動
        this.setParamChanged();
        if (!this.emailPreviewDialog.isOpen) {
          this.emailPreviewDialog.open();
        }
        // for header
        this.previewReady();
        // 判定是否disable inputs
        this.setDisable();
        if (showForm) {
          this.displayEditArea = true;
        }
      });
    }
  }

  public formInputsFromData(obj, keys) {
    const InputsFromData = {};
    _.forEach(obj, (value, key) => {
      if (_.includes(keys, key)) {
        InputsFromData[key] = value;
      }
    });
    return InputsFromData;
  }

  public setParamChanged() {
    const formKeys = ['TemplateCategoryCode','ProductCategoryCode','MarketDate','Expired','ProductName','Html'];
    const oData = this.formInputsFromData(this.selectedRow.oData, formKeys);
    const sData = this.formInputsFromData(this.selectedRow.sData, formKeys);

    this.logger.debug('setParamChanged: ', oData, sData);
    this.paramModelChanges = [];

    if (!_.isEqual(oData, sData)) {
      _.forEach(sData, (value, key) => {
        if (!_.isEqual(oData[key], sData[key])) {
          this.paramModelChanges.push({
            key: key,
            valueBefore: oData[key],
            valueAfter: sData[key]
          });
        }
      });
    }

  }

  public setDisable(isSubmit?) {
    const permissions = this.permissionService.getPermissions();
    const canInputHTML = _.has(permissions, Permissions.EMAIL_TEMPLATE_HTML_UPDATE);
    // 當dialog狀態不同的時候，會讓他無法異動內容(如送審or停用) 或沒有編輯權限的時候
    // 下拉選單會受到disable的影響，disabled時不會提交值出去
    if (this.displayTemplateEditingButtons || isSubmit) {
      _.forIn(this.editEmailTemplateForm.form.controls, (value, key) => {
        if ((key === 'Html' && !canInputHTML) && !isSubmit) {
          this.editEmailTemplateForm.form.controls[key].disable();
          this.shouldExpiredDisabled = true;
        } else {
          this.editEmailTemplateForm.form.controls[key].enable();
          this.shouldExpiredDisabled = false;
        }
      });
    } else {
      _.forIn(this.editEmailTemplateForm.form.controls, (value, key) => {
        this.editEmailTemplateForm.form.controls[key].disable();
        this.shouldExpiredDisabled = true;
      });
    }
  }

  previewURL(uuid) {
    return `${environment.api_url}MailTemplate/${uuid}/preview`;
  }

  public setUpdateData(activeCode?) {
    const options = {
      UUID: (this.selectedRow.sData|| this.selectedRow.oData).UUID,
      TemplateCategoryCode: this.editEmailTemplateForm.form.controls['TemplateCategoryCode'].value,
      ProductCategoryCode: this.editEmailTemplateForm.form.controls['ProductCategoryCode'].value,
      ProductName: this.editEmailTemplateForm.form.controls['ProductName'].value,
      MarketDate: this.editEmailTemplateForm.form.controls['MarketDate'].value,
      Expired: this.editEmailTemplateForm.form.controls['Expired'].value,
      ActiveCode: activeCode || (this.selectedRow.sData || this.selectedRow.oData).ActiveCode,
      HTML: this.editEmailTemplateForm.form.controls['Html'].value,
      LoginUser: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType,
      }
    };
    return options;
  }

  public setEditSubmitData(selectedRowId, mgrId, updateData?) {
    const options: any = {
      UUIDs: selectedRowId,
      WFApprMgrEmpId: mgrId,
      ApplyEmp: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType,
      },
      // UpdateData: {},
      BaseUrl: this.router.url,
      WFObjectName: this.managementService.getWFObjectName()
    };

    if (!_.isEmpty(updateData)) { options.UpdateData = updateData; }

    return options;
  }

  get canDiscard(): boolean {
    // oData.ModifyStatus = '1' 一定是新增，新增的資料不可被復原
    return this.currentEmailTemplateStatus === ManagementWFStatus.STAGE &&
      (this.selectedRow.oData || { ModifyStatus: '' }).ModifyStatus !== '1';
  }

  get canSubmitEditDialog(): boolean {
    // 暫存 or 表單有異動都可以直接送出
    return this.currentEmailTemplateStatus === ManagementWFStatus.STAGE || this.hasChangedEmailPreview;
  }

  get hasChangedEmailPreview(): boolean {
    this.setDisable(true);
    const hasChangedEmailPreview = !_.isEqual(this.editTempOriData, this.editEmailTemplateForm.form.value);
    this.setDisable();
    return hasChangedEmailPreview;
  }

  public afterChooseWFApprMgr(mgrId) {
    const submitWF = (UUID?) => {
      this.managementService.submitWF(this.setEditSubmitData(
        [UUID || this.selectedRow.sData.UUID],
        mgrId
      ), ManagementWFType.EMAIL_TEMPLATE).subscribe(() => {
        this.closeEmailPreviewDialog();

        this.searchForm.submit();
      });
    };

    if (this.hasChangedEmailPreview) {
      this.emailService
        .saveEmailTemplateTemp(this.setUpdateData())
        .subscribe(() => {
          // 存檔後重新打才拿得到oData & sData
          this.emailService
            .getEmailTemplate(this.selectedRow.oData.UUID)
            .subscribe((data) => {
              submitWF(data.value.sData.UUID);
            });
        });
    } else {
      submitWF();
    }
  }

  /**
   * form input 跟 原始載入的時候有差異，則關閉的時候會confirm user
   */
  public checkBeforeEditedClose() {
    this.logger.debug('checkBeforeEditedClose: ', this.editTempOriData, this.editEmailTemplateForm.form.value);
    if (this.hasChangedEmailPreview) {
      this.confirmEditCloseDialog.open();
    } else {
      this.closeEmailPreviewDialog();
    }
  }

  // public confirmEditCloseDialogSubmit() {
  //   this.closeEmailPreviewDialog();
  //   this.confirmEditCloseDialog.close();
  // }

  public previewReady() {
    const that = this;
    function handler() {
      if (this.readyState === this.DONE) {
        if (this.status === 200) {
          // this.response is a Blob, because we set responseType above
          const dataUrl = URL.createObjectURL(this.response);
          that.previewIframe.nativeElement.src = dataUrl;
        } else {
          console.error('no data :(');
        }
      }
    }
    let xhr = new XMLHttpRequest();

    xhr.open('GET', this.previewURL(this.editingEmailTemplate.UUID));
    xhr.onreadystatechange = handler;
    xhr.responseType = 'blob';
    xhr.setRequestHeader('authorization', this.jwt.getAuthToken());
    xhr.send();
    this.displayPreviewIframe = true;
  }

  public refreshPreview() {
    // this.ref.detectChanges();
    this.displayPreviewIframe = false;

    const config = this.setUpdateData();
    this.logger.debug('refreshPreview: ', config);
    this.emailService.saveEmailTemplateTemp(config).subscribe(res => {
      this.logger.debug('refreshPreview saveEmailTemplateTemp: ', res);
      this.onEditEmailTemplate({ oData: this.editingEmailTemplate }, false);
      this.searchForm.submit();
    });
  }

  public onEditEmailTemplateFormSubmit() {
    if(this.editEmailSaveMode === 'temp') {
      this.emailService.saveEmailTemplateTemp(this.setUpdateData()).subscribe(() => {
        this.closeEmailPreviewDialog();
        // 已暫存 init 暫存button
        this.editTempOriData = _.cloneDeep(this.editEmailTemplateForm.form.value);
        this.searchForm.submit();
      });
    } else {
      this.chooseMgr.open();
    }
  }

  public saveEmailTemplateTemp() {
    if (this.currentConfirmType) {
      this.discard();
      this.currentConfirmType = null;
    } else {
      this.editEmailSaveMode = 'temp';
      this.editEmailTemplateForm.submit();
    }
  }

  public saveEmailTemplate() {
    this.editEmailSaveMode = 'notTemp';
    this.editEmailTemplateForm.submit();
  }

  public closeEmailPreviewDialog() {
    this.editEmailTemplateForm.reset();
    if (this.emailPreviewDialog.isOpen) {
      this.emailPreviewDialog.close();
    }
  }

  public sendTestMail() {
    this.marketingService.getEDMInputs(this.editingEmailTemplate.UUID, {})
      .subscribe((response) => {
        this.uploadQRCodeTextInputs = response.value.filter(i => i.FieldType === 'txt');
        this.uploadQRCodeImgInputs = response.value.filter(i => i.FieldType === 'img');
        this.uploadQRCode.open();
      });
  }
  public checkDiscard() {
    this.currentConfirmType = 'discard';
    this.confirmEditCloseDialog.open();
  }
  /**
   * btn 還原至最後生效狀態
   * sData.UUID
   */
  public discard() {
    this.emailService.getLatestValidState(this.selectedRow.sData.UUID).subscribe((data) => {
      this.logger.debug(`sData.UUID: ${this.selectedRow.sData.UUID} 還原至最後生效狀態 getLatestValidState: `, data);
      if (data.isOk) {
        this.notification.success('已還原至最後生效狀態', '');
        this.onEditEmailTemplate({ oData: this.selectedRow.oData }, true);
        this.searchForm.submit();
      }
    });
  }

  get getDialogHeaderStatusClass(): string {
    return ManagementHelper.headerTagStatusClass(this.selectedRow.Status);
  }

  // public handleReviewAction(isApprove: boolean) {
  //   if (isApprove) {
  //     this.onReviewActionClick('single', 'approve');
  //   } else {
  //     this.onReviewActionClick('single', 'reject');
  //   }
  // }



  /**
   * 電子DM的所有跟信件有關的function
   * 有時間要整合...
  */

  /**
   * 確認寄出
   * fn: emailToUserOpen
   * fn: removeRecipient
   * fn: addRecipient
   * fn: autoCompleteRecipients
   * fn: closeErrorAlert
   * fn: notFinishYetFields
   * fn: sendable
   * fn get: sendable
   * fn: sendEmail
   */
  public emailToUserOpen() {
    // this data is maybe from customer sendMail
    if (this.email.getRecipient().length > 0) {
      // this.recipient = this.email.getRecipient().join('，');
      this.recipients = this.email.getRecipient();
    }
    this.emailToUser.open();
  }

  public removeRecipient(recipient: string) {
    this.email.removeRecipient(recipient);
  }

  public addRecipient(recipients: string) {
    const tmpRecipients = recipients.split(/,|，|;|；|\s|<|>/);
    if (tmpRecipients.length > 0) {
      this.notAllowStrings = this.email.illegalOrDuplicate([...tmpRecipients, ...this.email.getRecipient()]);
      const safeRecipients = tmpRecipients.filter(r => this.email.isEmail(r));
      this.email.setRecipients(safeRecipients);
      this.recipients = this.email.getRecipient();
    }
  }

  public autoCompleteRecipients(event: any) {
    // if (event) { event.preventDefault(); }

    const eventTrigger = () => {
      return (
        // blur
        event.type === 'blur' ||
        // space or ; or ,
        _.includes([32, 186, 188], event.keyCode) ||
        // ctrl + v
        event.type === 'paste'
      );
    };

    const addValue = () => {
      const value = event.target.value;
      event.target.value = '';
      this.addRecipient(value);
    };

    if (eventTrigger() && event.target.value) {
      // async after event trigger (for paste event)
      if (event.type === 'paste') {
        setTimeout(() => {
          addValue();
        }, 500);
      } else { addValue(); }
    }
  }

  public closeErrorAlert(event) {
    this.notAllowStrings = [];
  }

  get notFinishYetFields(): string {
    return [...this.uploadQRCodeTextInputs, ...this.uploadQRCodeImgInputs]
      .filter(inputModel => _.isEmpty(inputModel.FieldValue))
      .map(inputsModel => inputsModel.FieldName).join('，');
  }

  get sendable(): boolean {
    return this.recipients.length > 0 && !this.notFinishYetFields;
  }

  get generateSendFields() {
    return [...this.uploadQRCodeTextInputs, ...this.uploadQRCodeImgInputs].map(field => {
      return {
        FieldName: field.FieldName,
        FieldType: field.FieldType,
        FieldValue: field.FieldValue
      };
    });
  }

  public sendEmail() {
    const body = {
      EmailTemplateUUID: this.editingEmailTemplate.UUID,
      Subject: this.editingEmailTemplate.ProductName,
      EmpId: this.auth.getLoginUser().loginEmpId,
      Priority: 'string',
      MailTo: this.recipients.join(','),
      Fields: this.generateSendFields,
      ActionEmp: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType
      }
    };
    if (_.isEmpty(body.Fields)) {
      delete body.Fields;
    }
    this.marketingService.sendMail(body).subscribe(res => {
      if (res.isOk) {
        this.notification.success('成功', '已發送信件');
        this.emailToUser.close();
      }
    });
  }

  /**
   * 聯絡資訊輸入
   * fn: uploadQRCodeOpen
   * fn: dmInputSubmit
   * fn: setParams
   * fn: beforeUpload
   * fn: handleUploadChange
   */
  public uploadQRCodeOpen() {
    this.uploadQRCode.open();
  }
  public dmInputSubmit(f: NgForm) {
    const urlParams = this.setParams();
    // const newURL = this.sanitizer.bypassSecurityTrustResourceUrl(this.selectedDM.src + urlParams);
    // this.dmPreviewSrc = newURL;
    this.uploadQRCode.close();
    this.emailToUser.open();
  }

  public setParams() {
    const escapeSeparator = (value: string) => value.replace(/\|/g, '｜');
    const hasValueInputs = [
      ...this.uploadQRCodeTextInputs.filter(inputs => !_.isEmpty(inputs.FieldValue)),
      ...this.uploadQRCodeImgInputs.filter(inputs => !_.isEmpty(inputs.FieldValue))
    ];
    const valuesStringArr = hasValueInputs.map(inputs => `${escapeSeparator(inputs.FieldType)}|${escapeSeparator(inputs.FieldName)}|${escapeSeparator(inputs.FieldValue)}`);

    return !_.isEmpty(valuesStringArr) ? `?${querystring.stringify({ data: valuesStringArr })}` : '';
  }

  beforeUpload = (file: File) => {
    this.logger.debug('beforeUpload: ', this);
    const isImage =  _.includes(['image/jpeg', 'image/png', 'image/gif'], file.type);
    if (!isImage) {
      this.notification.error('錯誤', '只能上傳gif、png、jpg。');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      this.notification.error('錯誤', '檔案大小必須小於2MB。');
    }
    return isImage && isLt2M;
  }

  handleUploadChange = (item: UploadXHRArgs) => {
    this.logger.debug('handleUploadChange: ', this);

    let formData = new FormData();

    // tslint:disable-next-line:no-any
    formData.append('file', item.file as any);
    formData.append('fileInfo', JSON.stringify({
      LoginUser: {
        LoginEmpId: this.auth.getLoginUser().loginEmpId,
        AgentEmpId: this.auth.getLoginUser().agentEmpId,
        UnitId: this.auth.getLoginUser().unitId,
        UseType: this.auth.getLoginUser().useType
      }
    }));

    // disabled upload before send to api
    this.uploadQRCodeImgInputs.map(inp => {
      if (inp.FieldName === item.name) {
        inp.isUploading = true;
      }
      return inp;
    });

    // success
    item.onSuccess = (ret: any, file: UploadFile, xhr: any) => {
      this.logger.debug('handleUploadChange onSuccess:', ret, item);
      this.uploadQRCodeImgInputs.map(inp => {
        if (inp.FieldName === item.name) {
          if (ret.IsOk) {
            inp.FieldValue = ret.Value.FileDownloadPath;
          } else {
            this.notification.error('上傳失敗', JSON.stringify(ret.Messages), { nzDuration: 30 * 1000 });
            console.error(ret);
          }
          inp.isUploading = false;
        }
        return inp;
      });
    };

    return this.marketingService.uploadQRcode(formData, item);
  }


  /**
   * initControls
   */
  private prepareControls() {
    this.searchControls = [
      new SingleDropdownControl({
        key: 'TemplateCategoryCode',
        label: '樣板類別',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇...',
        options: this.emailTemplateCategoryOptions
      }),
      new MultiSelectControl({
        key: 'ProductCategoryCode',
        label: '產品類別',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇...',
        options: this.emailTemplateProductTypeOptions
      }),
      new TextControl({
        key: 'ProductName',
        label: '名稱',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new DatepickerControl({
        key: 'MarketDate',
        label: '上架日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        singleDatePicker: true,
        placeholder: '請選擇日期...'
      })
    ];

    const options = this.options.getOptions(['emailTemplateCategory', 'emailTemplateProductType', 'managementStatus']);
    this.newEmailTemplateControl = EmailTemplateControls.getEmailTemplateControls(options);
    this.editEmailTemplateControl = EmailTemplateControls.getEmailTemplateControls(options, this.shouldExpiredDisabled);
  }

  /**
   * check permission
   */
  private checkPermission() {
    this.permissionService.hasPermission(this.Permissions.EMAIL_TEMPLATE_UPDATE)
        .then( (editable) => {} )
        .catch ( (err) => this.logger.debug('checkPermission error: ', err ) );
  }
}
