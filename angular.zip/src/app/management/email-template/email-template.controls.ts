import { FormGroup } from '@angular/forms';
import { TextControl, SingleDropdownControl, DatepickerControl, TextareaControl } from '../../shared/components/dynamic-form/controls';

export class EmailTemplateControls {
    static getEmailTemplateControls(dropdownOptions: any, shouldExpiredDisabled?) {
        return [
            new SingleDropdownControl({
                key: 'TemplateCategoryCode',
                label: '樣板類別',
                required: true,
                columnClasses: ['6'],
                options: dropdownOptions.emailTemplateCategory,
                placeholder: '請選擇...'
            }),
            new SingleDropdownControl({
              key: 'ProductCategoryCode',
              label: '產品類別',
              required: true,
              columnClasses: ['6'],
              options: dropdownOptions.emailTemplateProductType,
              placeholder: '請選擇...'
            }),
            new DatepickerControl({
              key: 'MarketDate',
              label: '上架日期',
              singleDatePicker: true,
              columnClasses: ['6'],
              placeholder: '請選擇...',
              required: true
            }),
            new DatepickerControl({
              key: 'Expired',
              label: '有效期限',
              singleDatePicker: true,
              columnClasses: ['6'],
              placeholder: '請選擇...',
              required: true,
              condition: (form: FormGroup) => {
                // if it's EDM, Expired is required.
                return form.controls['TemplateCategoryCode'].value === '1';
              },
              disabled: () => shouldExpiredDisabled
            }),
            new TextControl({
              key: 'ProductName',
              label: '名稱',
              required: true,
              columnClasses: ['12'],
              placeholder: '請輸入...'
            }),
            new TextareaControl({
              key: 'Html',
              label: 'HTML',
              // 待確認isWordCount是否影響下方maxlength
              isWordCount: true,
              maxlength: 1000000,
              // ---
              required: true,
              columnClasses: ['12'],
              placeholder: '請輸入...'
            })
        ];
    }
}
