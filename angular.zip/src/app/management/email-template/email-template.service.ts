import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'app/core/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class EmailTemplateService {

  constructor(private api: ApiService) { }

  public getEmailTemplate(uuid, query?): Observable<any> {
    // return asyncReturn({
    //   templateType: '電子DM',
    //   productType: '信貸',
    //   upDate: '2017/06/23',
    //   validDate: '2018/06/23',
    //   name: 'a funny name',
    //   html: '<div>a funny text<div>',
    //   status: 'temp',
    //   previewUrl: 'http://www.ibm.com',
    //   changes: {
    //     name: 'it was a funny text',
    //   }
    // });
    return this.api.get(`MailTemplate/${uuid}`, query);
  }

  public refreshPreview(config): Observable<any> {
    return this.api.patch(`MailTemplate`, config);
  }

  public preview(uuid): Observable<any> {
    return this.api.get(`MailTemplate/${uuid}/preview`);
  }

  public getLatestValidState(uuid): Observable<any> {
    return this.api.get(`MailTemplate/${uuid}/discard`);
  }

  public addEmailTemplate(config): Observable<any> {
    return this.api.post(`MailTemplate`, config);
  }

  public sendTestMail(id) {
    return asyncReturn(null);
  }

  public saveEmailTemplate(config): Observable<any> {
    return this.api.post(`MailTemplate/wf/submit`, config);
  }

  public saveEmailTemplateTemp(config): Observable<any> {
    return this.api.patch(`MailTemplate`, config);
  }

}

function asyncReturn(value) {
  return new Observable((observer) => {
    setTimeout(() => {
      observer.next(value);
    }, 50);
  });
}
