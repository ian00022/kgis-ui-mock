import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

import { ExpiryNotificationDialogComponent } from './shared-components/expiry-notification-dialog/expiry-notification-dialog.component';
import { HeadOfficeAssignmentDialogComponent } from './shared-components/head-office-assignment-dialog/head-office-assignment-dialog.component';
import { ProductSettingsDialogComponent } from './shared-components/product-settings-dialog/product-settings-dialog.component';
import { ManagementMarketingTeamDialogComponent } from './shared-components/management-marketing-team-dialog/management-marketing-team-dialog.component';
import { NotificationDialogComponent } from './shared-components/notification-dialog/notification-dialog.component';
import { EmployeeManagementDialogComponent } from './shared-components/employee-management-dialog/employee-management-dialog.component';
import { ManagementReturnDialogComponent } from './shared-components/management-return-dialog/management-return-dialog.component';
import { RoleManagementDialogComponent } from './shared-components/role-management-dialog/role-management-dialog.component';
import { ManagementApproveDialogComponent } from './shared-components/management-approve-dialog/management-approve-dialog.component';
import { ManagementCancelCheckDialogComponent } from './shared-components/management-cancel-check-dialog/management-cancel-check-dialog.component';
import { ManagementStatusInfoDialogComponent } from './shared-components/management-status-info-dialog/management-status-info-dialog.component';
import { ChooseApproveManagerDialogComponent } from './shared-components/choose-approve-manager-dialog/choose-approve-manager-dialog.component';
import { ManagementStatusColumnComponent } from './shared-components/management-status-column/management-status-column.component';

import { EmailTemplateComponent } from './email-template/email-template.component';
import { HeadOfficeAssignmentComponent } from './head-office-assignment/head-office-assignment.component';
import { HeadOfficeAssignmentDetailComponent } from './head-office-assignment-detail/head-office-assignment-detail.component';
import { ProductSettingsComponent } from './product-settings/product-settings.component';
import { MarketingTeamDetailComponent } from './marketing-team-detail/marketing-team-detail.component';
import { SystemSettingsComponent } from './system-settings/system-settings.component';
import { ManagementNotificationComponent } from './management-notification/management-notification.component';
import { ManagmentProdTagComponent } from './managment-prod-tag/managment-prod-tag.component';
import { RoleComponent } from './role/role.component';
import { MarketingTeamComponent } from './marketing-team/marketing-team.component';
import { ExpiryNotificationComponent } from './expiry-notification/expiry-notification.component';
import { StatusCellComponent } from './role/components/status-cell/status-cell.component';

import { HeadOfficeAssignmentResponseService } from './head-office-assignment/head-office-assignment-response.service';
import { RoleService } from './role/role.service';
import { UserRoleResponseService } from './role/user-role-response.service';
import { UserRoleStatusService } from './role/role-status.service';
import { RolesMappingService } from 'app/management/role/services/roles-mapping.service';
import { HeadOfficeAssignmentService } from 'app/management/head-office-assignment/head-office-assignment.service';
import { Permissions } from '../core/models/permissions';
import { NgxPermissionsGuard } from 'ngx-permissions';


const sharedComponents = [
    ManagementStatusInfoDialogComponent,
    NotificationDialogComponent,
    EmployeeManagementDialogComponent,
    RoleManagementDialogComponent,
    ManagementApproveDialogComponent,
    ManagementReturnDialogComponent,
    ManagementCancelCheckDialogComponent,
    ManagementMarketingTeamDialogComponent,
    ExpiryNotificationDialogComponent,
    ProductSettingsDialogComponent,
    HeadOfficeAssignmentDialogComponent,
    ChooseApproveManagerDialogComponent,
    ManagementStatusColumnComponent,
    StatusCellComponent
];

const viewComponents = [
    ManagmentProdTagComponent,
    ManagementNotificationComponent,
    SystemSettingsComponent,
    RoleComponent,
    MarketingTeamComponent,
    MarketingTeamDetailComponent,
    ExpiryNotificationComponent,
    EmailTemplateComponent,
    ProductSettingsComponent,
    HeadOfficeAssignmentComponent,
    HeadOfficeAssignmentDetailComponent
];

const services = [
  UserRoleResponseService,
  UserRoleStatusService,
  RoleService,
  UserRoleResponseService,
  UserRoleStatusService,
  RoleService,
  RolesMappingService,
  HeadOfficeAssignmentService,
  HeadOfficeAssignmentResponseService,
];

@NgModule({
  imports: [
    SharedModule,
    // NgxPermissionsModule.forChild(),
    RouterModule.forChild([
      {
        path: 'role',
        component: RoleComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '角色權限設定',
          permissions: {
            only: ['UserRole_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'marketing-team',
        component: MarketingTeamComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '行銷團隊設定',
          permissions: {
            only: ['MarketingTeam_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'marketing-team/:id',
        component: MarketingTeamDetailComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '行銷團隊資訊',
          permissions: {
            only: ['MarketingTeam_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'email-template',
        component: EmailTemplateComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: 'E-mail 樣板設定',
          permissions: {
            only: ['EmailTemplate_F'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'notification',
        component: ManagementNotificationComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '推播通知',
          permissions: {
            only: ['Notification_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'head-office-assignment',
        component: HeadOfficeAssignmentComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '總行案件設定',
          permissions: {
            only: ['HeadOfficeBOL_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'head-office-assignment/:id',
        component: HeadOfficeAssignmentDetailComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '總行案件設定詳細',
          permissions: {
            only: ['HeadOfficeBOL_F'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'expiry-notificaiton',
        component: ExpiryNotificationComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '名單/案件逾期通知設定',
          permissions: {
            only: ['OverdueNotification_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'product-tag',
        component: ManagmentProdTagComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '推薦產品標籤',
          permissions: {
            only: ['RecommendProducts_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'product-setting',
        component: ProductSettingsComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '產品參數設定',
          permissions: {
            only: ['ProductParameter_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      {
        path: 'system-setting',
        component: SystemSettingsComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '系統參數設定',
          permissions: {
            only: ['SystemProperty_S', 'SystemPropertyDomain_S'],
            redirectTo: '/dashboard'
          }
        }
      },
      { path: '', redirectTo: 'role', pathMatch: 'full' },
    ])
  ],
  declarations: [
    ...viewComponents,
    ...sharedComponents
  ],
  providers: [
    ...services
  ]
})
export class ManagementModule { }
