import { isNullOrUndefined } from 'util';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ControlBase, SingleCheckboxControl, TextareaControl, TextControl } from 'app/shared/components/dynamic-form/controls';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from './../../shared/components/ibm-table/ibm-table.component';
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { LoggerService } from './../../shared/logger.service';
import { Subject } from 'rxjs';
import { ManagementHelper } from '../management-helper';
import { NgxPermissionsService } from '../../../../node_modules/ngx-permissions';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { ManagementService } from '../../core/services/management.service';
import { ManagementWFStatus, ManagementWFType, ManagementWFStatusHelper } from '../management.model';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-managment-prod-tag',
  templateUrl: './managment-prod-tag.component.html',
  styleUrls: ['./managment-prod-tag.component.scss']
})
export class ManagmentProdTagComponent implements OnInit, OnDestroy {

  @ViewChild('tagTable') tagTable: IbmTableComponent;
  @ViewChild('editTagDialog') editTagDialog: IbmDialogComponent;
  @ViewChild('approve') approveDialog: IbmDialogComponent;
  @ViewChild('return') returnDialog: IbmDialogComponent;
  @ViewChild('editTagForm') editTagForm: DynamicFormComponent;
  @ViewChild('cancelCheck') cancelCheckDialog: IbmDialogComponent;
  @ViewChild('chooseMgr') chooseMgrDialog: IbmDialogComponent;

  public tagSearchForm: FormGroup;
  public tagList = [];
  public rowClassNameFunction = ManagementHelper.rowClassNameFunction;

  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public reviewList: any[] = [];
  public reviewPermission = 'REVIEW_TAG';
  public editPermission = 'EDIT_TAG';
  public editTagFormEditable = false;
  public editTagControls: ControlBase<any>[] = [];
  public editTagModelChanges;

  public orderTypes = [
    { label: '代碼', value: 'TagId' },
    { label: '名稱', value: 'TagDesc' },
    { label: '標籤名稱', value: 'MarsDesc' }
  ];
  public currentOrderType = this.orderTypes[0];
  public WFType: ManagementWFType = ManagementWFType.PRODUCTTAG;
  public Permissions = Permissions;

  private ngUnSubscribe: Subject<any> = new Subject();
  private currentPermissions = 'REVIEW_TAG';
  private currentProdTag: any = {};

  constructor(
    private logger: LoggerService,
    private permissionService: NgxPermissionsService,
    private managementService: ManagementService,
    private router: Router
  ) { }

  ngOnInit() {
    this.prepareControls();
    this.permissionService.addPermission(this.currentPermissions);
    this.checkPermission();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * return or approvement selection handler
   */
  get isAnySelected(): boolean {
    if (this.tagTable) {
      return this.tagTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.tagTable.getcurrentPageRows().filter((el) => {
        if (this.isRowSelectable(el)) {
          return el;
        }
      }),
      this.selectedRowList
    );
    this.logger.debug('selectAll length: ', this.selectedRowList.length);
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public isRowSelectable(row: any) {
    return row.status === ManagementWFStatus.STAGE_REVIEW;
  }

  public onReviewActionClick(dateType: string, reviewType: string) {
    if (dateType === 'single') {
      this.reviewList = [this.selectedRow];
    } else {
      this.reviewList = _.cloneDeep(this.selectedRowList);
    }

    this.managementService.checkoutWF({
      UUIDs: this.reviewList.map(el => el.UUID),
      WFObjectName: this.managementService.getWFObjectName()
    }, ManagementWFType.PRODUCTTAG)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            if (reviewType === 'approve') {
              this.approveDialog.open();
            } else {
              this.returnDialog.open();
            }
          }
        }
      );
  }

  /**
   * user has review permission or not
   */

  public changeFakePermission() {

    this.permissionService.removePermission(this.currentPermissions);
    if (this.currentPermissions === this.editPermission) {
      this.currentPermissions = this.reviewPermission;
    } else {
      this.currentPermissions = this.editPermission;
    }
    this.permissionService.addPermission(this.currentPermissions);
    this.checkPermission();
  }



  /**
   * search helper
   */
  public handleSearchClick() {
    let model = _.assign({
      orderCol: this.currentOrderType.value
    }, this.tagSearchForm.value);
    this.logger.debug(model);

    this.managementService.getProductTagList(model).subscribe(
      (resp) => {
        this.tagList = resp.value.map( el => ManagementHelper.handleManagementDisplayData(el));
      }
    );
  }
  public handleClearClick() {
    this.tagSearchForm.reset();
  }

  /**
   * table row action handler
   */
  public openMenu(row: any) {
    this.selectedRow = _.cloneDeep(row);
  }

  public onViewClick(row: any) {
    this.selectedRow = _.cloneDeep(row);
    this.managementService.getProductTagByTagId(this.selectedRow.TagId).subscribe(
      (resp) => {
        console.log(resp);
        this.editTagForm.reset();
        this.currentProdTag = ManagementHelper.handleManagementDisplayData(resp.value);
        this.setEditTagFormValue(this.currentProdTag);
        this.checkPermission();
        this.editTagDialog.open();
      }
    );

  }

  /**
   * action buttons by status
   */
  get discardable(): boolean {
    return ManagementHelper.discardable(this.currentProdTag);
  }
  get showDisableBtn(): boolean {
    return ManagementHelper.showDisableBtn(this.currentProdTag);
  }
  get showEnableBtn(): boolean {
    return ManagementHelper.showEnableBtn(this.currentProdTag);
  }
  get showSaveBtn(): boolean {
    return ManagementHelper.showSaveBtn(this.currentProdTag);
  }
  get showReviewBtn(): boolean {
    return ManagementHelper.showReviewBtn(this.currentProdTag);
  }
  get enableSaveBtn(): boolean {
    if (isNullOrUndefined(this.currentProdTag.status)) {
      return this.editTagForm.form.valid;
    } else {
      if (this.currentProdTag.status === ManagementWFStatus.STAGE) {
        return this.editTagForm.form.valid;
      } else if (this.currentProdTag.status === ManagementWFStatus.STAGE_REJECT || this.currentProdTag.status === ManagementWFStatus.ACTIVE) {
        return this.editTagForm.form.valid && this.editTagForm.form.dirty;
      } else {
        return false;
      }
    }
  }
  get enableTempSaveBtn(): boolean {
    return this.enableSaveBtn && this.editTagForm.form.dirty;
  }

  /**
   * editTag Dialog actions
   */
  public roleActivationClick(active: boolean) {
    this.managementService.updateProductTag(_.assign( _.cloneDeep(this.currentProdTag),
      { ActiveCode: active ? ManagementWFStatus.ACTIVE : ManagementWFStatus.INACTIVE }
    )).subscribe(
      (resp) => {
        this.editTagDialog.close();
        this.handleSearchClick();
      }
    );
  }

  public onSaveClick(type: string) {
    if (type === 'temp') {
      let body = _.assign({}, this.currentProdTag, this.editTagForm.form.value);
      this.managementService.updateProductTag(body)
      .subscribe(
        (resp) => {
          this.handleSearchClick();
          this.editTagDialog.close();
        }
      );
    } else {
      this.editTagDialog.close();
      this.chooseMgrDialog.open();
    }
  }

  public onCancelClick() {
    if (this.editTagForm.form.dirty) {
      this.cancelCheckDialog.open();
    } else {
      this.editTagDialog.close();
    }
  }

  public onRejectClick() {
  }

  public onApproveClick() {
  }

  public cancelCheckSave() {
    this.onSaveClick('temp');
  }

  public cancelCheckUnSave() {
    this.editTagDialog.close();
  }

  /**
   * EditTag form
   */

  // editTag Dialog heleper
  get getDialogHeaderStatusClass(): string {
    return ManagementHelper.headerTagStatusClass(this.selectedRow.status);
  }

  public discardChange() {
    this.managementService.discard(this.currentProdTag.UUID, ManagementWFType.PRODUCTTAG)
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            this.editTagDialog.close();
            this.handleSearchClick();
          }
        }
      );
  }

  public getManagementWFStatusLabel(status) {
    return ManagementWFStatusHelper.mapTo(status);
  }

  public afterChooseWFApprMgr(mgrId) {
    let body = {
      UUIDs: [this.currentProdTag.UUID],
      WFApprMgrEmpId: mgrId,
      WFObjectName: this.managementService.getWFObjectName(),
      BaseUrl: this.router.url,
    };

    if (this.editTagForm.form.dirty) {
      this.managementService.updateProductTag(_.assign({}, this.currentProdTag , this.editTagForm.form.value))
      .subscribe(
        (resp) => {
          if (resp.isOk) {
            console.log(resp);
            this.managementService.submitWF(body, ManagementWFType.PRODUCTTAG)
            .subscribe(
              (resp2) => {
                this.handleSearchClick();
              }
            );
          }
        }
      );

    } else {
      console.log('not dirty');
      this.managementService.submitWF(body, ManagementWFType.PRODUCTTAG)
      .subscribe(
        (resp) => {
          this.handleSearchClick();
        }
      );
    }
  }

  private setEditTagFormValue(value) {
    this.editTagControls.forEach(
      (el) => {
        if (value[el.key] !== null && value[el.key] !== undefined ) {
          this.editTagForm.form.controls[el.key].setValue(value[el.key]);
        }
      }
    );
  }

  private setEditTagFormEditable(editable: boolean) {
    for ( const key of Object.keys(this.editTagForm.form.controls)) {
      if (editable && key !== 'TagName') {
        this.editTagForm.form.controls[key].enable();
      } else {
        this.editTagForm.form.controls[key].disable();
      }
    }
  }

  private prepareControls() {
    this.editTagControls = [
      new TextControl({
        key: 'TagDesc',
        label: '名稱',
        // required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      }),
      new TextareaControl({
        key: 'MarsDesc',
        label: '標籤名稱',
        // required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...',
        isWordCount: true,
        maxlength: 100
      }),
      new SingleCheckboxControl({
        key: 'IsSensitive',
        label: '敏感標籤',
        columnClasses: ['12'],
      })
    ];

    this.tagSearchForm = new FormGroup({
      TagDesc: new FormControl('', Validators.required),
    });
  }

  /**
   * check permission
   */
  private checkPermission() {
    this.permissionService.hasPermission(this.editPermission)
        .then( (edit) =>  {
          if(edit && _.includes([ManagementWFStatus.INACTIVE, ManagementWFStatus.STAGE_REVIEW], this.selectedRow.status)) {
            this.setEditTagFormEditable(false);
          } else {
            this.setEditTagFormEditable(edit);
          }
        })
        .catch ( (err) => this.logger.debug('checkPermission error: ', err ) );
  }
}
