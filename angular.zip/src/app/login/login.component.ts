import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ControlBase, TextControl } from '../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { NgxPermissionsService } from 'ngx-permissions';
import { AuthService } from '../core/services/auth.service';
import { PermissionResponseDto, SimplePermissionDto } from '../core/models/permissions';
import { JwtService } from './../core/services/jwt.service';

@Component({
  selector: 'esun-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('loginForm') loginForm: DynamicFormComponent;
  public controls: ControlBase<any>[] = [];

  constructor(
    private permissionsService: NgxPermissionsService,
    private router: Router,
    private auth: AuthService,
    private jwt: JwtService
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  get disableLogin(): boolean {
    return !this.loginForm.form.valid;
  }

  public handleSubmit(value: any) {
    this.auth.loadPermissionsByUserId(value.account).subscribe((data: PermissionResponseDto) => {
      if (data) {
        const permissions = data.Permissions.map((p: SimplePermissionDto) => p.Code);
        this.permissionsService.loadPermissions(permissions);
        this.permissionsService.addPermission(['LOGIN_SUCCESS']);
        this.router.navigate(['/dashboard']);
        this.jwt.saveToken(data.TokenId);
      }
    });
  }

  public login() {
    if (this.disableLogin) {
      return;
    }
    this.loginForm.submit();
  }

  public clear() {
    this.loginForm.reset();
  }

  private prepareControls() {
    this.controls = [
      new TextControl({
        key: 'account',
        label: '帳號',
        columnClasses: ['12'],
        placeholder: '請輸入員工編號...'
      }),
      // new TextControl({
      //   key: 'password',
      //   label: '密碼',
      //   required: true,
      //   columnClasses: ['12'],
      //   type: 'password',
      //   value: this.mockUser.password
      // })
    ];
  }

}
