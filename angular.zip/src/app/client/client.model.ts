import { BaseSearchParams, BaseResponseDto } from 'app/core/models/comm-data';

export enum PotentialCustomerType {
  COMP = 1,
  CUST = 2,
}

export interface SpecificMemberSearchParams extends BaseSearchParams {

  /// 查詢者員工編號
  inquirerEmpId: string;

  /// 被查詢者統編
  beInquirerCircikey: string;

  /// 被查詢者戶名
  beInquirerName: string;

  /// 查詢日期
  inquiryDate: string;
}

export interface SpecificMemberResponseDto extends BaseResponseDto {
  /// Guid
  UUID: string;

  /// 查詢者員工編號
  InquirerEmpId: string;

  /// 查詢者員工姓名
  InquirerEmpName: string;

  /// 查詢者單位代碼
  InquirerUnitCode: string;

  /// 查詢者單位名稱
  InquirerUnitName: string;

  /// 被查詢者統編
  BeInquirerCircikey: string;

  /// 被查詢者戶名
  BeInquirerName: string;

  /// 查詢日期
  InquiryDate: string;

  /// 查詢時間
  InquiryTime: string;
}

export interface SpecificMemberTableRowDto {

  /// 被查詢者統編
  beInquirerCircikey: string;

  /// 被查詢者戶名
  beInquirerName: string;

  /// 查詢日期
  inquiryDate: string;

  /// 查詢時間
  inquiryTime: string;

  /// 查詢者員工編號 + 員工姓名
  inquirerEmp: string;

  /// 查詢者單位代碼 + 單位名稱
  inquirerUnit: string;
}
