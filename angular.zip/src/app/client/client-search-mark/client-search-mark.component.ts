// angular module
import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Subject } from 'rxjs';
// model
import { SpecificMemberSearchParams, SpecificMemberTableRowDto } from '../client.model';
// component
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { ControlBase, TextControl, SingleDropdownControl, DatepickerControl } from '../../shared/components/dynamic-form/controls';
// service
import { ClientService } from 'app/core/services';


@Component({
  selector: 'esun-client-search-mark',
  templateUrl: './client-search-mark.component.html',
  styleUrls: ['./client-search-mark.component.scss']
})
export class ClientSearchMarkComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('clientMarkSearchForm') clientMarkSearchForm: DynamicFormComponent;

  public clientMarkList: SpecificMemberTableRowDto[] = [];
  public clientMarkSearchControls: ControlBase<any>[] = [];

  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private client: ClientService
  ) { }

  public handleClientMarkSearchFormSubmit(filters: any) {
    let searchParams: SpecificMemberSearchParams = {
      inquirerEmpId: filters.inquirerEmpId,
      beInquirerCircikey: filters.beInquirerCircikey,
      beInquirerName: filters.beInquirerName,
      inquiryDate: filters.inquiryDate,
      orderCol: filters.orderCol,
      pf: {
        skip: 0,
        take: 10000
      }
    };
    this.client.querySpecificMemberLog(searchParams).subscribe(
      (data) => {
        this.clientMarkList = data;
      }
    );

  }

  ngOnInit() {
    this.prepareControls();

  }

  ngAfterViewInit() {
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  private prepareControls() {
    this.clientMarkSearchControls = [
      new SingleDropdownControl({
        key: 'inquirerEmpId',
        label: '查詢者',
        placeholder: '請選擇',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        options: [
          { value: '01234', label: '01234 李玉山' },
          { value: '01235', label: '01235 李寶山' },
          { value: '01236', label: '01236 李山山' },
          { value: '00362', label: '00362 王妍彤' }
        ]
      }),
      new TextControl({
        key: 'beInquirerCircikey',
        label: '被查詢者統編',
        placeholder: 'e.g. A123456789',
        columnClasses: ['12', 'md-4', 'lg-3'],
      }),
      new TextControl({
        key: 'beInquirerName',
        label: '被查詢者戶名',
        placeholder: 'e.g. 王小明',
        columnClasses: ['12', 'md-4', 'lg-3'],
      }),
      new DatepickerControl({
        key: 'inquiryDate',
        label: '查詢日期',
        singleDatePicker: true,
        placeholder: '請選擇日期...',
        columnClasses: ['12', 'md-4', 'lg-3'],
      }),
    ];
  }

}
