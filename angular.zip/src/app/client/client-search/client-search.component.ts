// angular module
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { ClientType, SearchHistoryKey } from '../../core/models/comm-data';
import { Permissions } from 'app/core/models/permissions';
// component
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { ControlBase, TextControl } from '../../shared/components/dynamic-form/controls';
// service
import { LoggerService } from './../../shared/logger.service';
import { AuthService, ClientService } from 'app/core/services/';
import { SearchHistoryService } from './../../core/services/search-history.service';
import { ApiService } from 'app/core/services/api.service';
// helper
import { DateHelper } from './../../shared/helper/date-helper';

import { ClientListConfig } from '../../core/models/client-list-config';


@Component({
  selector: 'esun-client-search',
  templateUrl: './client-search.component.html',
  styleUrls: ['./client-search.component.css']
})
export class ClientSearchComponent implements OnInit, OnDestroy, AfterViewInit {

  /**
   * search form
   *
   * @type {DynamicFormComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('clientSearchForm') clientSearchForm: DynamicFormComponent;

  /**
   * 新增自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;

  /**
   * 特殊註記對象提醒 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('spetialConfirm') spetialConfirmDialog: IbmDialogComponent;

  /**
   * 商機轉介 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('createReferral') createReferralDialog: IbmDialogComponent;

  /**
   * 新增行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;

  /**
   * 潛在顧客維護中 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ClientSearchComponent
   */
  @ViewChild('potentialMaintain') potentialMaintainDialog: IbmDialogComponent;

  public clientList: any[] = [];
  public clientSearchControls: ControlBase<any>[] = [];
  public clientListConfig: ClientListConfig;

  public boDefault: any;
  public referralDefault: any;
  public menus: any[] = [];
  public menuMap = {
    createBo: {
      label: '新增自建名單',
    },
    createSchedule: {
      label: '新增行程',
    },
    edm: {
      label: '寄送電子 DM',
    },
    referral: {
      label: '商機轉介',
    }
  };

  public selectedRowData: any;
  public requiredAnyKeys = ['circiKey', 'contactPhone', 'customerName'];
  public editingMessage = '';
  public Permissions = Permissions;
  private ngUnSubscribe: Subject<any> = new Subject();
  private searchHistoryKey = SearchHistoryKey.CLIENTSEARCH;

  constructor(
    private clientService: ClientService,
    private logger: LoggerService,
    private route: ActivatedRoute,
    private router: Router,
    private auth: AuthService,
    private history: SearchHistoryService,
    private api: ApiService
  ) {
    this.clientListConfig = {
      pf: { skip: 0, take: this.api.getLimitTake()}
    };
  }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit(): void {
    let history = this.history.getHistoryOf(this.searchHistoryKey);
    if (history) {
      this.clientSearchForm.form.patchValue(history);
      this.clientSearchForm.submit();
    }
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isSearchFormValid(): boolean {
    return this.clientSearchForm.form.valid;
  }

  public handleClientSearchFormSubmit(filters: any) {
    this.logger.debug('clientConfig: ', filters);
    let searchModel = _.assign({}, this.clientListConfig, filters);
    this.history.storeHistory(this.searchHistoryKey ,searchModel);
    this.clientService.query(searchModel)
    .subscribe((clientList) => {
      this.clientList = clientList;
    });
  }

  public openMenu(value: any) {
    this.selectedRowData = value;
  }

  public menuClick(dialogType: string) {
    switch (dialogType) {
      case 'createBo':
        this.boDefault = _.cloneDeep(this.selectedRowData);
        if (this.boDefault['customerAttribute'] === '3') {
          this.boDefault['customerType'] = 1; // 潛在顧客
        } else {
          this.boDefault['customerType'] = 2; // 既有顧客
        }
        this.createBoDialog.open();
        break;
      case 'createSchedule':
        this.createScheduleDialog.open();
        break;
      case 'edm':
        break;
      case 'referral':
        this.referralDefault = {
          identityCardNo: this.selectedRowData.circiKey,
          contactPhone: this.selectedRowData.contactPhone,
          customerName: this.selectedRowData.customerName,
          referralEmpId: this.auth.getLoginUser().loginEmpId,
          referralUnit: this.auth.getLoginUser().unitId
        };
        this.createReferralDialog.open();
        break;
    }
  }

  public openSpetialDialog(value: any) {
    this.spetialConfirmDialog.open();
    this.selectedRowData = value;
  }

  public handleSpetialDialogConfirm() {
    let currentUser = this.auth.getLoginUser();
    let addMark = {
      inquirerEmpId: currentUser.loginEmpId,
      inquirerEmpName: currentUser.name,
      inquirerUnitCode: currentUser.unitId,
      inquirerUnitName: currentUser.unitName,
      beInquirerCircikey: this.selectedRowData.circiKey,
      beInquirerName: this.selectedRowData.customerName,
      loginUser: currentUser
    };
    this.clientService.addSpecificMemberLog(addMark).subscribe(
      (resp) => {
        this.spetialConfirmDialog.close();
        this.routeTo(this.selectedRowData);
      }
    );
  }

  public handleSpetialDialogCancel() {
    this.spetialConfirmDialog.close();
    this.selectedRowData = {};
  }

  public routeTo(rowData: any) {
    console.log(rowData);
    if (rowData.customerAttribute === ClientType.POTENTIAL) {
      if (rowData.isEditing) {
        this.editingMessage = rowData.editingMessage;
        this.potentialMaintainDialog.open();
      } else {
        this.router.navigate(['/business-op', 'detail', rowData.BOLNo]);
      }
    } else {
      const overview = rowData.customerAttribute === ClientType.CUST ? 'cust-overview' : 'comp-overview';
      this.router.navigate(['../client', rowData.circiKey, overview], {relativeTo: this.route});
    }
  }

  public displayClientTypeText(rowData: any): string {
    switch (rowData.customerAttribute) {
      case ClientType.CUST:
        return '個人戶';
      case ClientType.COMP:
        return '公司戶';
      case ClientType.POTENTIAL:
        // return `潛在顧客 (${rowData.operator})`;
        return '潛在顧客 (王小圖)';
      default:
        return '';
    }
  }

  public displayDepartmentText(rowData: any): string {
    return `${rowData.performanceDptCode} ${rowData.performanceDptName}`;
  }

  public displayBirthDayText(row: any): string {
    if (row.customerBirthday) {
      return DateHelper.formatDate(row.customerBirthday);
    }
    return '-';
  }

  public circiKeyValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
    if (control.value) {
      let isCustID = /^[A-Z][12][0-9]{8}$/.test(control.value);
      let isCompID = /^[0-9]{8}$/.test(control.value);
      if (!isCompID && !isCustID) {
        return {
          circiKey: true
        };
      }
    }
  }

  public phoneValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
    if (control.value) {
      let isValid = /^[0][9][0-9]{8}$/.test(control.value);
      if (!isValid) {
        return {
          contactPhone: true
        };
      }
    }
  }

  private prepareControls() {
    this.clientSearchControls = [
      new TextControl({
        key: 'circiKey',
        label: '身分證字號/統一編號',
        placeholder: 'e.g. A123456789',
        columnClasses: ['12', 'md-4', 'lg-3'],
        validators: [this.circiKeyValidator]
      }),
      new TextControl({
        key: 'contactPhone',
        label: '手機號碼',
        placeholder: 'e.g. 0988123123',
        columnClasses: ['12', 'md-4', 'lg-3'],
        validators: [this.phoneValidator]
      }),
      new TextControl({
        key: 'customerName',
        label: '戶名',
        placeholder: 'e.g. 王小明',
        columnClasses: ['12', 'md-4', 'lg-3'],
      })
    ];
  }


}
