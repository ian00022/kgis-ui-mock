// angular module
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
// 3rd party module
import { NgxPermissionsGuard } from 'ngx-permissions';
// model
import { Permissions } from '../core/models/permissions';
// esb module
import { SharedModule } from '../shared/shared.module';
// component
import { ClientSearchComponent } from './client-search/client-search.component';
import { ClientSearchMarkComponent } from './client-search-mark/client-search-mark.component';

/**
 * 顧客 360 module
 */
@NgModule({
  imports: [
    RouterModule.forChild([
       { path: '', redirectTo: 'search', pathMatch: 'full' },
       {
          path: 'search',
          component: ClientSearchComponent,
          canActivate: [NgxPermissionsGuard],
          data: {
            breadcrumb: '顧客查詢',
            permissions: {
              only: [
                Permissions.PERSONAL_SEARCH,
                Permissions.PERSONAL_SPECIAL_MEMBER_SEARCH
              ],
              redirectTo: '/no-auth',
            }
          }
       },
      {
        path: 'client/:id',
        canLoad: [NgxPermissionsGuard],
        loadChildren: 'app/client/customer-detail/customer-detail.module#CustomerDetailModule',
        data: {
          breadcrumb: '顧客360',
          permissions: {
            only: [
              Permissions.PERSONAL_FIND
            ],
            redirectTo: '/no-auth',
          }
        }
      },
      {
        path: 'searchMark',
        component: ClientSearchMarkComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '特殊註記對象查詢',
          permissions: {
            only: [
              Permissions.PERSONAL_SPECIAL_MEMBER_SEARCH
            ],
            redirectTo: '/no-auth'
          }
        }
      }
      ]
    ),
    SharedModule
  ],
  declarations: [
    ClientSearchComponent,
    ClientSearchMarkComponent
  ]
})
export class ClientModule { }
