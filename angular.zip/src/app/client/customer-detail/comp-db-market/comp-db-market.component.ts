import {Component, OnDestroy, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {ClientService} from '../../../core/services/client.service';
import {Subject} from 'rxjs';
import { ScrollToHelper } from '../../../shared/helper/scroll-to-helper';


@Component({
  selector: 'esun-comp-db-market',
  templateUrl: './comp-db-market.component.html',
  styleUrls: ['./comp-db-market.component.css']
})
export class CompDbMarketComponent implements OnInit, OnDestroy {

  public tableData: any[] = [];
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    let circiKey = this.route.parent.snapshot.params['id'];

    this.clientService.getDBMarket(circiKey).subscribe(
      (resp) => {
        this.tableData = resp.value.map( (el) => {
          return {
            productType: el['PRODUCT'],
            projectName: el['LEAD_NAME'],
            amount: el['CREDIT_LIMIT'],
            rate: el['INTEREST_RATE'],
            months: el['TERM'],
            fee: el['CHARGE_FEE'],
            earlyProject: el['EARLY_BIRD_OFFER'],
            earlyProjectDueDate: el['EARLY_BIRD_EXPIRE_DT'],
            projectDueDate: el['PROJECT_EXPIRE_DT'],
            note: el['Remark']
          };
        });
      }
    );
  }

  ngOnDestroy() {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }

}
