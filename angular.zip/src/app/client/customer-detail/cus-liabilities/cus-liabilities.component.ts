import { ActivatedRoute } from '@angular/router';
import { ScrollToHelper } from './../../../shared/helper/scroll-to-helper';
import {Component, OnDestroy, OnInit, AfterViewInit} from '@angular/core';
import {Subject} from 'rxjs';
import {ClientService} from '../../../core/services/client.service';

@Component({
  selector: 'esun-cus-liabilities',
  templateUrl: './cus-liabilities.component.html',
  styleUrls: ['./cus-liabilities.component.css']
})
export class CusLiabilitiesComponent implements OnInit, OnDestroy, AfterViewInit {
  public liabilities = {
    account: {} as any,
    credit: {} as any,
    promise: {} as any,
    record: {} as any,
    accident: {} as any,
    creditcard:  {} as any,
    comprehensiveCredit: {} as any
  };
  public isAccountSettled = false;

  private ngUnsubscribe: Subject<any> = new Subject();
  private scrollOffset = 0;
  private fragment;

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    let circiKey = this.route.parent.snapshot.params['id'];
    this.clientService.getLiabilities(circiKey).subscribe(
      (resp) => {
        this.liabilities = this.clientService.transferLiability(resp.value);
      }
    );
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  ngAfterViewInit() {
    if (this.fragment) {
      ScrollToHelper.scrollSelectorTo('.mat-drawer-content', this.fragment, this.scrollOffset);
    }
  }

  get isAccountSettledTitle() {
    return this.isAccountSettled ? '顯示結清帳號' : '顯示結清帳號';
  }

  get accountDisplayData() {
    if (!this.liabilities.account.rowData) {
      return [];
    }
    return this.isAccountSettled ? this.liabilities.account.rowData : this.liabilities.account.rowData.filter(
      (data) => {
        return data;
      }
    );
  }

  public setScrollTo(fragment, offset) {
    this.scrollOffset = offset;
    this.fragment = fragment;
  }

  public loanHeader(title: string): string {
    return '貸款 | ' + title;
  }

  public switchChange(value) {
    this.isAccountSettled = value;
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }
}
