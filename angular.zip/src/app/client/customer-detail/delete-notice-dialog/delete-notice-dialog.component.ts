import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { ControlBase, TextareaControl } from '../../../shared/components/dynamic-form/controls';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from './../../../shared/components/dynamic-form/dynamic-form.component';
import { LoggerService } from '../../../shared/logger.service';
import { ApiService, AuthService } from 'app/core/services';

@Component({
  selector: 'esun-delete-notice-dialog',
  templateUrl: './delete-notice-dialog.component.html',
  styleUrls: ['./delete-notice-dialog.component.scss']
})
export class DeleteNoticeDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;
  @Input('notice') notice: any;
  @Output('updateNotice') updateNotice: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];

  constructor(
    private logger: LoggerService,
    private api: ApiService,
    private auth: AuthService
  ) { }


  ngOnInit() {
    this.prepareControls();
  }

  get isValid(): boolean {
    return this.form.form.valid;
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    this.form.submit();
    this.dialog.close();
  }

  public cancel() {
    this.form.reset();
    this.dialog.close();
  }

  public handleSubmit(value: any) {
    this.logger.debug('delete reason:', value);
    let notice = _.assign(_.cloneDeep(this.notice), value);
    let user = this.auth.getLoginUser();
    notice.updateEmpId = user.loginEmpId;
    notice.updateEmpName = user.name;
    this.api.delete('MarketingNotice', notice).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.updateNotice.emit();
          this.dialog.close();
        }
      }
    );

  }

  private prepareControls() {
    this.controls = [
      new TextareaControl({
        key: 'deletedReason',
        label: '原因',
        required: true,
        isWordCount: true,
        maxlength: 20,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }
}
