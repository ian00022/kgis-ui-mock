import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { ClientService } from '../../../core/services/client.service';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { ScrollToHelper } from '../../../shared/helper/scroll-to-helper';
import { BOLSource } from './../../../business-opportunity/business-opportunity.model';


@Component({
  selector: 'esun-comp-overview',
  templateUrl: './comp-overview.component.html',
  styleUrls: ['./comp-overview.component.css']
})
export class CompOverviewComponent implements OnInit, OnDestroy {

  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;

  public compOverView = {
    custInfo: {} as any,
    marketingLogs: {} as any,
    bussinessReg: [],
    povertyChart: {} as any,
    liabilitiesChart: [],
    productService: [],
    spectialData: [],
  };

  public remarkInfo: any;
  public newNote = {
    text: '',
    count: 0
  };
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    let circiKey = this.route.parent.snapshot.params['id'];
    this.clientService.getOverView(circiKey).subscribe(
      (resp) => {
        this.compOverView = this.clientService.transferCompOverview(resp.value);
      }
    );
  }

  ngOnDestroy() {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  public onSliceClick(value) {
  }

  public onCreateNoteClick(data) {
    this.remarkInfo = {
      generalBOLUUID: data.remarks[0].generalBOLUUID,
      bolNo: data['BOLNo']
    };
    this.createNoteDialog.open();
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }

  public displayLessName(name) {
    return name.slice(0, 4) + '...';
  }

  public getBOLLink(row) {
    return ['/business-op', 'detail', row.BOLNo];
  }

  public getBOLSourceLabel(row) {
    return BOLSource[row.BOLSource];
  }
}
