import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject, forkJoin } from 'rxjs';
import * as _ from 'lodash';
import { IbmDialogComponent } from './../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ClientService } from '../../../core/services/client.service';
import { ScrollToHelper } from './../../../shared/helper/scroll-to-helper';
import { Permissions } from 'app/core/models/permissions';
declare var moment: any;

@Component({
  selector: 'esun-cus-market-mark',
  templateUrl: './cus-market-mark.component.html',
  styleUrls: ['./cus-market-mark.component.css']
})
export class CusMarketMarkComponent implements OnInit, OnDestroy {
  @ViewChild('deleteNotice') deleteNoticeDialog: IbmDialogComponent;


  public cusMarketMark = {
    creditRiskBlock: [] as any,
    amlBlock: [] as any,
    creditNotice: {} as any,
    alertBlock: {} as any,
    noticeBlock: [] as any,
  };

  public defaultNotice: any = {};
  public deleteReason = '';
  public cusDetail: any = {};
  public selectedNotice: any = {};
  public Permissions = Permissions;

  private ngUnsubscribe: Subject<any> = new Subject();
  private circiKey;
  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.circiKey = this.route.parent.snapshot.params['id'];
    forkJoin(
      this.clientService.getMarketMark(this.circiKey),
      this.clientService.getCustomerDetail(this.circiKey)
    ).subscribe(([marketMark, detail]) => {
        this.cusMarketMark = this.clientService.transferMarketMark(marketMark.value);
        let hasExIndex = _.findIndex(this.cusMarketMark.creditRiskBlock, {key: 'HasEx'});
        if (this.cusMarketMark.creditRiskBlock[hasExIndex].markRed) {
          this.cusMarketMark.creditRiskBlock[hasExIndex]['link'] = '../cust-liabilities';
          this.cusMarketMark.creditRiskBlock[hasExIndex]['fragment'] = 'accident';
          this.cusMarketMark.creditRiskBlock[hasExIndex]['contentType'] = 'link';
        }
        this.cusDetail = detail;
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  public openModal(modal: IbmDialogComponent, data: any = null) {
    // 編輯
    if (data) {
      this.defaultNotice = {
        UUID: data['UUID'],
        marketingNotice360UUID: data['MarketingNotice360UUID'],
        remark:  data['Remark'],
        note: data['Note'],
        circiKey: this.cusDetail.circiKey,
        customerName: this.cusDetail.name,
      };
    } else {
    // 新增
      this.defaultNotice = {
        circiKey: this.cusDetail.circiKey,
        customerName: this.cusDetail.name,
      };
    }

    modal.open();
  }

  public showTag(show: string) {
    return show === 'Y';
  }

  public displayTitle(data): string {
    return `${moment(data['UpdateDate']).format('YYYY/MM/DD')} | ${data['UpdateEmpName']} ${data['UpdateEmpId']}`;
  }

  public displayContent(data): string {
    return `${data['Note']}，${data['Remark']}`;
  }


  public onDeleteNoticeClick(data) {
    this.selectedNotice = data;
    this.deleteNoticeDialog.open();
  }

  public updateNotice() {
    this.clientService.getMarketingNotice(this.circiKey).subscribe(
      (notice) => {
        this.cusMarketMark.noticeBlock = notice;
      }
    );
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }

}
