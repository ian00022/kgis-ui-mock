import { Permissions } from './../../core/models/permissions';
import { Component, OnDestroy, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { ClientDetail, ClientType } from '../../core/models/comm-data';
import { ClientService } from '../../core/services/client.service';
import { ScrollToHelper } from '../../shared/helper/scroll-to-helper';
import { getScrollbarWidth } from 'app/shared/functions/screen';
import { EmailService } from '../../core/services/email.service';
import { LoggerService } from './../../shared/logger.service';
import { AuthService } from '../../core/services/auth.service';

declare var moment: any;

@Component({
  selector: 'esun-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css']
})
export class CustomerDetailComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('assets') assetsDialog: IbmDialogComponent;
  @ViewChild('topContanier') topContanier: ElementRef;
  @ViewChild('breadcreumbEl') breadcreumbEl: ElementRef;
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;
  @ViewChild('createReferral') createReferralDialog: IbmDialogComponent;

  get scrollOffset() {
    return this.tabContentPaddingTop + this.cardGutter + this.breadcreumbEl.nativeElement.offsetHeight;
  }

  public tabContentPaddingTop = 0;
  public customerDetail: ClientDetail = {} as ClientDetail;
  public overView: any;
  public boDefault: any;
  public referralDefault: any;
  public topContanierRight: number;
  public ClientType = ClientType;
  public Permissions = Permissions;

  private ngUnsubscribe: Subject<any> = new Subject();
  private currentFragment: string;
  private cardGutter = 10;
  private headerHeight = 60;

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute,
    private router: Router,
    private email: EmailService,
    private logger: LoggerService,
    private auth: AuthService,
    private ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    const circiKey = this.route.snapshot.params['id'];
    this.clientService.getCustomerDetail(circiKey)
      .subscribe( (detail) => {
          this.customerDetail = detail;
          // this.referralDefault = {
          //   identityCardNo: this.customerDetail.circiKey,
          //   contactPhone: this.customerDetail.phone,
          //   customerName: this.customerDetail.name,
          //   referralEmpId: this.auth.getLoginUser().loginEmpId,
          //   referralUnit: this.auth.getLoginUser().unitId
          // };
          this.clientService.getOverView(circiKey).subscribe(
            (resp) => {
              if (this.customerDetail.customerAttribute === ClientType.COMP) {
                this.overView = this.clientService.transferCompOverview(resp.value);
              } else {
                this.overView = this.clientService.transferCusOverview(resp.value);
              }
          });

          this.detecTtabContentPaddingTop();
        });

    this.route.fragment.subscribe(
      (fragment) => {
        this.currentFragment = fragment;
      }
    );
  }

  ngAfterViewInit() {
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  get detailMode(): ClientType {
    return this.customerDetail.customerAttribute;
  }

  get isCompMode(): boolean {
    return this.detailMode === ClientType.COMP;
  }

  get headTitle(): string {
    // return this.isCompMode ? this.customerDetail.companyInfo360Block.customerName : this.customerDetail.personalInfo360Block.customerName;
    return this.customerDetail.name;
  }

  get assetsDialogHeader(): string {
    // const header = this.customerDetail.name || '';
    return this.headTitle + ' | 資產分配圖';
  }

  get liablityPath(): string {
    return this.isCompMode ? 'comp-liabilities' : 'cust-liabilities';
  }

  get assetPath(): string {
    return this.isCompMode ? 'comp-assets' : 'cust-assets';
  }

  public showTag(show: string) {
    return show === 'Y';
  }

  public sendEDM() {
    this.email.setRecipients(this.customerDetail.email);
    this.router.navigate(['/marketing', 'edm']);
  }

  public customerAge(birthDay: string | Date): number {
    const currentYear = moment().get('year');
    const birthYear = moment(birthDay).get('year');
    return currentYear - birthYear;
  }

  public handleToggle(state: any) {
    if (!state.collapsed) {
      this.tabContentPaddingTop -= state.height;
    } else {
      this.tabContentPaddingTop += state.height;
    }
  }

  public openChartModal() {
    this.assetsDialog.open();
  }

  public onSliceClick(data) {
    this.logger.debug(data);
  }

  public onCreateBoClick() {
    this.boDefault = {
      customerType: this.customerDetail.customerAttribute,
      customerName: this.customerDetail.name,
      circiKey: this.customerDetail.circiKey,
      productType: '',
      caseSourceDesc: '',
    };
    this.createBoDialog.open();
  }

  public getChipsClass(bool: boolean): string {
    return bool ? 'text-success' : 'text-danger';
  }

  public getChipsIconClass(bool: boolean): string {
    return bool ? 'fa-check' : 'fa-ban';
  }

  public superGoto(target, routeName) {

    this.router.navigate([`./${routeName}`], {relativeTo: this.route, fragment: target});
    const path = this.route.snapshot.firstChild.url[0].path;
    if ( path === routeName ) {
      ScrollToHelper.scrollSelectorTo('.mat-drawer-content', target, this.scrollOffset);
    }
  }

  public onActivate(component: any) {
    if (component.setScrollTo) {
      // component has setScrollTo function
      component.setScrollTo(this.currentFragment, this.scrollOffset);
    } else {
      component.scrollTop();
    }

    if (component.trackProd) {
      component.trackProd.subscribe( recommandProd => {

        switch(recommandProd.prodType){
          case '貸款':
            this.boDefault = {
              customerName: this.customerDetail.name,
              circiKey: this.customerDetail.circiKey,
              productType: recommandProd['OfferId'],
              caseSourceDesc: recommandProd['CaseSourceDesc'] || '7',
              customerType: this.customerDetail.customerAttribute,
              data: recommandProd
            };
            this.createBoDialog.open();
            break;
          case '整合行銷':
            this.createReferralDialog.open();
            break;
          default:
            break;
        }
        this.logger.debug('prodType: ', recommandProd);
      });
    }
  }

  /**
   * createFixedTopContainerStyle
   */
  public createFixedTopContainerStyle() {
    this.topContanierRight = getScrollbarWidth();
  }

  public openCreateReferral() {
    this.referralDefault = {
      identityCardNo: this.customerDetail.circiKey,
      contactPhone: this.customerDetail.phone,
      customerName: this.customerDetail.name,
      referralEmpId: this.auth.getLoginUser().loginEmpId,
      referralUnit: this.auth.getLoginUser().unitId
    };
    this.createReferralDialog.open();
  }

  private detecTtabContentPaddingTop() {
    this.ref.detectChanges();
    this.tabContentPaddingTop = this.topContanier.nativeElement.offsetHeight - this.breadcreumbEl.nativeElement.offsetHeight - this.headerHeight;
    this.createFixedTopContainerStyle();
  }
}
