import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import { forkJoin ,  Subject } from 'rxjs';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ClientService } from '../../../core/services/client.service';
import { ScrollToHelper } from './../../../shared/helper/scroll-to-helper';
import { Permissions } from 'app/core/models/permissions';
declare var moment: any;


@Component({
  selector: 'esun-comp-market-mark',
  templateUrl: './comp-market-mark.component.html',
  styleUrls: ['./comp-market-mark.component.css']
})
export class CompMarketMarkComponent implements OnInit, OnDestroy {
  @ViewChild('deleteNotice') deleteNoticeDialog: IbmDialogComponent;

  public compMarketMark = {
    creditRiskBlock: [] as any,
    amlBlock: [] as any,
    creditNotice: {} as any,
    alertBlock: {} as any,
    noticeBlock: [] as any,
  };

  public defaultNotice: any = {};
  public deleteReason = '';
  public compDetail: any = {};
  public selectedNotice: any = {};
  public Permissions = Permissions;

  private ngUnSubscribe: Subject<any> = new Subject();
  private circiKey;

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.circiKey = this.route.parent.snapshot.params['id'];

    forkJoin(
      this.clientService.getMarketMark(this.circiKey),
      this.clientService.getCustomerDetail(this.circiKey)
    ).subscribe(([marketMark, detail]) => {
        this.compMarketMark = this.clientService.transferMarketMark(marketMark.value);
        let hasExIndex = _.findIndex(this.compMarketMark.creditRiskBlock, {key: 'HasEx'});
        if (this.compMarketMark.creditRiskBlock[hasExIndex].markRed) {
          this.compMarketMark.creditRiskBlock[hasExIndex]['link'] = '../comp-liabilities';
          this.compMarketMark.creditRiskBlock[hasExIndex]['fragment'] = 'accident';
          this.compMarketMark.creditRiskBlock[hasExIndex]['contentType'] = 'link';
        }
        this.compDetail = detail;
      });
  }

  ngOnDestroy() {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  public openModal(modal: IbmDialogComponent, data: any = null) {
    // 編輯
    if (data) {
      this.defaultNotice = {
        UUID: data['UUID'],
        marketingNotice360UUID: data['MarketingNotice360UUID'],
        remark: data['Remark'],
        note: data['Note'],
        circiKey: this.compDetail.circiKey,
        customerName: this.compDetail.name,
      };
    } else {
    // 新增
      this.defaultNotice = {
        circiKey: this.compDetail.circiKey,
        customerName: this.compDetail.name,
      };
    }

    modal.open();
  }

  public showTag(show: string) {
    return show === 'Y';
  }

  public displayTitle(data): string {
    return `${moment(data['UpdateDate']).format('YYYY/MM/DD')} | ${data['UpdateEmpName']} ${data['UpdateEmpId']}`;
  }

  public displayContent(data): string {
    return `${data['Note']}，${data['Remark']}`;
  }

  public onDeleteNoticeClick(data) {
    this.selectedNotice = data;
    this.deleteNoticeDialog.open();
  }

  public updateNotice() {
    this.clientService.getMarketingNotice(this.circiKey).subscribe(
      (notice) => {
        this.compMarketMark.noticeBlock = notice;
      }
    );
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }
}
