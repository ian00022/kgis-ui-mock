import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { SharedModule } from '../../shared/shared.module';

import { CompDbMarketComponent } from './comp-db-market/comp-db-market.component';
import { CompLiabilitiesComponent } from './comp-liabilities/comp-liabilities.component';
import { CompOverviewComponent } from './comp-overview/comp-overview.component';
import { CompMarketMarkComponent } from './comp-market-mark/comp-market-mark.component';
import { CompAssetsComponent } from './comp-assets/comp-assets.component';

import { CustomerDetailComponent } from './customer-detail.component';
import { CusAssetsComponent } from './cus-assets/cus-assets.component';
import { CusMarketMarkComponent } from './cus-market-mark/cus-market-mark.component';
import { CusOverviewComponent } from './cus-overview/cus-overview.component';
import { CusLiabilitiesComponent } from './cus-liabilities/cus-liabilities.component';
import { CusDbMarketComponent } from './cus-db-market/cus-db-market.component';

import { DeleteNoticeDialogComponent } from './delete-notice-dialog/delete-notice-dialog.component';
import { CreateNoticeDialogComponent } from './create-notice-dialog/create-notice-dialog.component';
import { Permissions } from '../../core/models/permissions';

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild([
        {
          path: '',
          component: CustomerDetailComponent,
          children: [
            {
              path: 'cust-overview',
              component: CusOverviewComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '資訊總覽',
                permissions: {
                  only: [Permissions.PERSONAL_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'cust-marketMark',
              component: CusMarketMarkComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '註記與注意事項',
                permissions: {
                  only: [Permissions.PERSONAL_MARKETING_NOTICE_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'cust-assets',
              component: CusAssetsComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '資產類',
                permissions: {
                  only: [Permissions.PERSONAL_ACCOUNT_INFO_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'cust-liabilities',
              component: CusLiabilitiesComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '負債類',
                permissions: {
                  only: [Permissions.PERSONAL_DEBT_INFO_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'cust-dbMarket',
              component: CusDbMarketComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '專屬行銷專案',
                permissions: {
                  only: [Permissions.PERSONAL_EXCLUSIVE_MARKETING_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'comp-overview',
              component: CompOverviewComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '資訊總覽',
                permissions: {
                  only: [Permissions.PERSONAL_FIND],
                  redirectTo: ''
                }
              },
            },
            {
              path: 'comp-marketMark',
              component: CompMarketMarkComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '註記與注意事項',
                permissions: {
                  only: [Permissions.COMPANY_MARKETING_NOTICE_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'comp-assets',
              component: CompAssetsComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '資產類',
                permissions: {
                  only: [Permissions.COMPANY_ACCOUNT_INFO_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'comp-liabilities',
              component: CompLiabilitiesComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '負債類',
                permissions: {
                  only: [Permissions.COMPANY_DEBT_INFO_FIND],
                  redirectTo: ''
                }
              }
            },
            {
              path: 'comp-dbMarket',
              component: CompDbMarketComponent,
              canActivate: [NgxPermissionsGuard],
              data: {
                breadcrumb: '專屬行銷專案',
                permissions: {
                  only: [Permissions.COMPANY_EXCLUSIVE_MARKETING_FIND],
                  redirectTo: ''
                }
              }
            },
            { path: '', redirectTo: '/clients/search', pathMatch: 'full' },
          ]
        },
    ]),
  ],
  declarations: [
    CustomerDetailComponent,
    CusAssetsComponent,
    CusMarketMarkComponent,
    CusDbMarketComponent,
    CusOverviewComponent,
    CusLiabilitiesComponent,
    CompOverviewComponent,
    CompMarketMarkComponent,
    CompAssetsComponent,
    CompLiabilitiesComponent,
    CompDbMarketComponent,
    DeleteNoticeDialogComponent,
    CreateNoticeDialogComponent
]
})
export class CustomerDetailModule { }
