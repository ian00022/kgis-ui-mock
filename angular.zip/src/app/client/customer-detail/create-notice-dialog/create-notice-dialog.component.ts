import { Component, OnInit, OnDestroy, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { DynamicFormComponent } from './../../../shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { LoggerService } from '../../../shared/logger.service';
import { ControlBase, TextareaControl, TextControl, SingleDropdownControl } from '../../../shared/components/dynamic-form/controls';
import { ApiService, AuthService } from 'app/core/services';

@Component({
  selector: 'esun-create-notice-dialog',
  templateUrl: './create-notice-dialog.component.html',
  styleUrls: ['./create-notice-dialog.component.scss']
})
export class CreateNoticeDialogComponent implements OnInit, OnDestroy {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;

  @Input('defaultValue')
  set defaultValue(value: any) {
    if (value && Object.keys(value).length !== 0) {
      this.defaultNotice = value;
      this.setDefalutValue();
      if (value['note']) {
        this.editMode = true;
      } else {
        this.editMode = false;
      }
    }
  }

  @Output('updateNotice') updateNotice: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];

  private ngUnSubscribe: Subject<any> = new Subject();
  private editMode: boolean = false;
  private defaultNotice: any = {};

  // 需與後端確認 value
  private options = [
    {value: '1', label: '疑似代辦'},
    {value: '2', label: '疑似人頭戶'},
    {value: '3', label: '聯絡偏好(例如：聯絡時間/稱謂)'},
    {value: '4', label: '特殊要求'},
    {value: '5', label: '特殊身份/關係'},
    {value: '6', label: '其他'}
  ];

  constructor(
    private logger: LoggerService,
    private api: ApiService,
    private auth: AuthService
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get getHeader(): string {
    return this.editMode ? '編輯行銷應注意事項' : '新增行銷應注意事項';
  }

  get isValid(): boolean {
    return this.form.form.valid;
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    this.form.submit();
    this.dialog.close();
  }

  public cancel() {
    this.form.reset();
    this.dialog.close();
  }

  public handleSubmit(value: any) {
    this.logger.debug('notice value:', value);
    let notice = _.cloneDeep(this.defaultNotice);
    notice.note = value.note;
    notice.remark = value.remark;

    let user = this.auth.getLoginUser();
    notice.updateEmpId = user.loginEmpId;
    notice.updateEmpName = user.name;

    if (this.editMode){
      this.api.patch('MarketingNotice', notice).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.updateNotice.emit();
            this.dialog.close();
          }
        }
      );
    } else {
      this.api.post('MarketingNotice', notice).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.updateNotice.emit();
            this.dialog.close();
          }
        }
      );
    }
  }

  private prepareControls() {
    this.controls = [
      new TextControl({
        key: 'circiKey',
        label: '顧客統一編號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        disabled: true
      }),
      new TextControl({
        key: 'customerName',
        label: '顧客姓名',
        columnClasses: ['6'],
        placeholder: 'e.g. 李大名',
        disabled: true
      }),
      new SingleDropdownControl({
        key: 'note',
        label: '注意事項內容',
        columnClasses: ['12'],
        options: this.options,
        placeholder: '請選擇...',
        required: true
      }),
      new TextareaControl({
        key: 'remark',
        label: '備註',
        isWordCount: true,
        maxlength: 20,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }

  private setDefalutValue() {
    for (const control of this.controls) {
      this.form.form.get(control.key).setValue(this.defaultNotice[control.key]);
    }
  }
}
