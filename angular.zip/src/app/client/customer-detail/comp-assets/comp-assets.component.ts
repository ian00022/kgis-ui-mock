// angular module
import { Component, OnDestroy, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
// service
import { ClientService } from '../../../core/services/client.service';
// helper
import { ScrollToHelper } from '../../../shared/helper/scroll-to-helper';

/**
 * 公司戶資產類 component
 */
@Component({
  selector: 'esun-comp-assets',
  templateUrl: './comp-assets.component.html',
  styleUrls: ['./comp-assets.component.css']
})
export class CompAssetsComponent implements OnInit, OnDestroy, AfterViewInit {

  /**
   * 資產類 Data
   *
   * @memberof CompAssetsComponent
   */
  public assets = {
    twDeposit: {
      current: [],
      fixed: []
    },
    overseaDeposit: {
      current: [],
      fixed: []
    },
    insurances: [],
    fund: []
  };

  /**
   * unSubscribe all subscription when ngOnDestroy call
   *
   * @private
   * @type {Subject<any>}
   * @memberof CompAssetsComponent
   */
  private ngUnsubscribe: Subject<any> = new Subject();

  /**
   * 捲動 offser
   *
   * @private
   * @memberof CompAssetsComponent
   */
  private scrollOffset = 0;

  /**
   * 個別資產類 section id 錨點
   *
   * @private
   * @memberof CompAssetsComponent
   */
  private fragment;

  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    let circiKey = this.route.parent.snapshot.params['id'];
    this.clientService.getAssets(circiKey).subscribe(
      (resp) => {
        this.assets = this.clientService.transferAsset(resp.value);
      }
    );
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /**
   * afterViewInit will check if have fragment,
   * then scroll to fragment section
   *
   * @memberof CompAssetsComponent
   */
  ngAfterViewInit() {
    if (this.fragment) {
      ScrollToHelper.scrollSelectorTo('.mat-drawer-content', this.fragment, this.scrollOffset);
    }
  }

  /**
   * customer detail component will call this method to scroll
   *
   * @param {*} fragment
   * @param {*} offset
   * @memberof CompAssetsComponent
   */
  public setScrollTo(fragment, offset) {
    this.scrollOffset = offset;
    this.fragment = fragment;
  }

  /**
   * 回到頂端
   *
   * @memberof CompAssetsComponent
   */
  public scrollTop() {
    ScrollToHelper.scrollTop();
  }
}
