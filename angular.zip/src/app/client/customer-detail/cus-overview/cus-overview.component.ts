import { Component, OnInit, OnDestroy, Output, EventEmitter, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { IbmDialogComponent } from './../../../shared/components/ibm-dialog/ibm-dialog.component';
import { ClientService } from '../../../core/services/client.service';
import { LoggerService } from '../../../shared/logger.service';
import { ScrollToHelper } from './../../../shared/helper/scroll-to-helper';
import { BOLSource } from './../../../business-opportunity/business-opportunity.model';
import { Permissions } from 'app/core/models/permissions';


@Component({
  selector: 'esun-cus-overview',
  templateUrl: './cus-overview.component.html',
  styleUrls: ['./cus-overview.component.css']
})
export class CusOverviewComponent implements OnInit, OnDestroy {

  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;
  @Output('trackProd') trackProd: EventEmitter<any> = new EventEmitter();

  public cusOverView = {
    custInfo: {} as any,
    marketingLogs: {} as any,
    recommend: {} as any,
    povertyChart: {} as any,
    liabilitiesChart: [] as any
  };
  public remarkInfo: any;
  public Permissions = Permissions;

  private ngUnsubscribe: Subject<any> = new Subject();
  constructor(
    private clientService: ClientService,
    private logger: LoggerService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    let circiKey = this.route.parent.snapshot.params['id'];
    this.clientService.getOverView(circiKey).subscribe(
      (resp) => {
        this.cusOverView = this.clientService.transferCusOverview(resp.value);
      });
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();

  }

  public onSliceClick(value) {

  }

  public helpInfo(data, ans) {
    this.logger.debug(data, ans);
    data.isGivenFeedback = true;
  }

  public onTrackClick(type: string, data: any, track: boolean) {
    if (track) {
      this.trackProd.emit(_.assign({prodType: type}, data));
      // need to check should update after createBo or createReferral
      this.clientService.updateProductRecommand(data, track);
    } else {
      this.clientService.updateProductRecommand(data, track);
    }
    this.logger.debug('trackData: ', data);
  }

  public onCreateNoteClick(data) {
    this.remarkInfo = {
      generalBOLUUID: data.remarks[0].generalBOLUUID,
      bolNo: data['BOLNo']
    };
    this.createNoteDialog.open();
  }

  public scrollTop() {
    ScrollToHelper.scrollTop();
  }

  public getBOLLink(row) {
    return ['/business-op', 'detail', row.BOLNo];
  }

  public getBOLSourceLabel(row) {
    return BOLSource[row.BOLSource];
  }
}
