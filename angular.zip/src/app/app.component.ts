import { Component, ViewChild } from '@angular/core';
import { environment } from '../environments/environment';
import { NgxPermissionsService } from 'ngx-permissions';
import { ApiService, AuthService, BreadcrumbService } from './core/services';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { LoggerService, LOGGER_LEVEL } from './shared/logger.service';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import * as _ from 'lodash';

@Component({
  selector: 'esun-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  @ViewChild('errorMsg') errorMsgDialog: IbmDialogComponent;
  public errMessage = '';
  public show = false;

  constructor(
    private logger: LoggerService,
    public breadcrumbService: BreadcrumbService,
    private permissionsService: NgxPermissionsService,
    private api: ApiService,
    private auth: AuthService,
    private options: SelectOptionsService
  ) {
    if (environment.production) {
      this.logger.setLevel(LOGGER_LEVEL.OFF);
    } else {
      this.logger.setLevel(LOGGER_LEVEL.DEBUG);
    }

    breadcrumbService.loadRouting();

    // const permissions = ['VIEW_BUTTON_1', 'VIEW_CLIENTS_SEARCH', 'VIEW_CLIENTS', 'VIEW_MANAGEMENT',
    //   Permissions.ROLE_SEARCH, Permissions.USER_ROLE_SEARCH];

    // this.auth.loadPermissions('0001').subscribe((data: PermissionResponseDto) => {
    //   const permissions = data.Permissions.map((p: SimplePermissionDto) => p.Code);
    //   this.permissionsService.loadPermissions(permissions);
    // });

    // if (sessionStorage.getItem('userID')) {
    //   this.auth.loadPermissions(sessionStorage.getItem('userID')).subscribe((data: PermissionResponseDto) => {
    //     const permissions = data.Permissions.map((p: SimplePermissionDto) => p.Code);
    //     this.permissionsService.loadPermissions(permissions);
    //     this.permissionsService.addPermission(['LOGIN_SUCCESS']);
    //   });
    // }

    // this.permissionsService.loadPermissions(permissions);
    this.api.errorMessage.subscribe(
      (error) => {
        if (error.show) {
          this.errMessage = _.result(error.msg, '0', '');
          if (this.errorMsgDialog && !this.errorMsgDialog.isOpen) {
            this.errorMsgDialog.open();
          }
        }
      }
    );
    this.permissionsService.permissions$.subscribe(
      (observ) => {
        if (observ['LOGIN_SUCCESS'] || observ['NEED_LOGIN']) {
          this.show = true;
        }
      }
    );
    // this.options.getAllSelectOptions();
  }
}
