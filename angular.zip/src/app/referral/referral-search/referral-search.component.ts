import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { ClientType, ISelectOptionModel, IEmployee } from './../../core/models/comm-data';
import { BaseListConfig } from './../../core/models/base-list-config';
import { Referral } from './../../core/models/referral.model';
import { DynamicFormComponent } from './../../shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { LoggerService } from '../../shared/logger.service';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { SharedService } from '../../shared/services/shared.service';
import { SelectOptionsService } from '../../shared/services/select-options.service';
import { SingleDropdownControl, TextControl, DatepickerControl, MultiSelectControl } from '../../shared/components/dynamic-form/controls';
import { DateHelper } from '../../shared/helper/date-helper';
import { ApiService, ReferralService, AuthService } from 'app/core/services';
import { Permissions } from 'app/core/models/permissions';
import { ControlBase } from 'app/shared/components/dynamic-form/controls';

declare var moment: any;

@Component({
  selector: 'esun-referral-search',
  templateUrl: './referral-search.component.html',
  styleUrls: ['./referral-search.component.scss'],
  providers: [DatePipe]
})
export class ReferralSearchComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('referralInfoDialog') referralInfoDialog: IbmDialogComponent;
  @ViewChild('editReferralInfoDialog') editReferralInfoDialog: IbmDialogComponent;
  @ViewChild('referralListTable') referralListTable: IbmTableComponent;
  @ViewChild('searchFormContainer') searchFormContainer: DynamicFormComponent;
  @ViewChild('exportReferralListDialog') exportReferralListDialog: IbmDialogComponent;

  /**
   * permissions enum property for template
   *
   * @memberof ReferralSearchComponent
   */
  public Permissions = Permissions;
  /**
   * 商機轉介列表
   *
   * @type {Referral[]}
   * @memberof ReferralSearchComponent
   */
  public referralList: Referral[] = [];

  /**
   * searchForm controls
   *
   * @type {ControlBase<any>[]}
   * @memberof ReferralSearchComponent
   */
  public searchControls: ControlBase<any>[];

  /**
   * query config
   *
   * @type {any}
   * @memberof ReferralSearchComponent
   */
  public listConfig: any = {};

  /**
   * referralData
   *
   * @type {*}
   * @memberof ReferralSearchComponent
   */
  public referralData: any = {};
  public isRefferalEdit: boolean = false;

  /**
   * 轉介產品選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof ReferralSearchComponent
   */
  public referralProdOptions: ISelectOptionModel[] = [];

  /**
   * 分行選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof ReferralSearchComponent
   */
  public bankBranchesOptions: ISelectOptionModel[] = [];

  /**
   * 經辦選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof ReferralSearchComponent
   */
  public employeeOptions: ISelectOptionModel[] = [];

  public orderTypes = [
    { label: '轉介時間', value: 'referralDate' },
    { label: '處理狀態', value: 'processStatusCode' },
    { label: '統一編號', value: 'identityCardNo' },
    { label: '戶名', value: 'customerName' },
    { label: '產品別', value: 'productCode' },
    { label: '轉介單位', value: 'referralUnit' },
    { label: '轉介人員', value: 'referralEmpId' },
    { label: '受理轉介單位', value: 'acceptedReferralUnit' },
    { label: '受理轉介人員', value: 'acceptedReferralEmpId' },
  ];

  public currentOrderType = this.orderTypes[0];

  /**
   * unsbscribe when lifecycle run ngOnDestroy
   *
   * @private
   * @type {Subject<any>}
   * @memberof EffectReportComponent
   */
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private logger: LoggerService,
    private referralService: ReferralService,
    private sharedService: SharedService,
    private options: SelectOptionsService,
    private datePipe: DatePipe,
    private auth: AuthService,
    private api: ApiService
  ) {
    const option = this.options.getOptions([
      'referralProd',
      'bankBranches',
      'employee'
    ]);

    this.referralProdOptions = option['referralProd'];
    this.bankBranchesOptions = option['bankBranches'];
    this.employeeOptions = option['employee'];
  }

  ngOnInit() {
    this.prepareContorls();
  }

  ngAfterViewInit() {
    let products = this.referralProdOptions.map( (el) => el.value);
    let startDate = DateHelper.formatDate(moment().subtract(1, 'months'));
    let endDate = DateHelper.formatDate(moment());
    let date = DateHelper.combineDate(startDate, endDate);
    this.searchFormContainer.form.patchValue({
      referralDate: date,
      productCode: products,
    });

    let searchParams = {
      referralStartDate: startDate,
      referralEndDate: endDate,
      productCode: null
    };
    this.handleFormSubmit(searchParams);
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get orderTypeLabel(): string {
    return this.currentOrderType.label;
  }

  public chooseOrderType(type) {
    this.currentOrderType = type;
  }

  public getCustLink(row: any): any[] {
    const overview = row.clientType === ClientType.COMP ? 'comp-overview' : 'cust-overview';
    return ['/clients', 'client', row.id, overview];
  }

  public handleFormSubmit(value) {
    let searchParams = _.assign(this.referralListTable.pageFilter, {
      orderCol: this.currentOrderType.value
    }, _.cloneDeep(value));
    if (searchParams.referralDate) {
      let date = DateHelper.divideDate(searchParams.referralDate);
      searchParams.referralStartDate = date.startTime;
      searchParams.referralEndDate = date.endTime;
    }
    if (searchParams.productCode) {
      searchParams.productCode = searchParams.productCode.join(',');
    }
    this.logger.debug('referral searchParams: ', searchParams);

    this.referralService.query(searchParams)
      .subscribe(
        (referralList) => {
          this.referralList = referralList;
        }
      );
  }

  public onReferralInfoDialogOpen(data?: any) {
    this.referralData = {
      referralEmpId: this.auth.getLoginUser().loginEmpId,
      referralUnit: this.auth.getLoginUser().unitId
    };
    if (data) {
      this.referralData.UUID = data.UUID;
      this.referralData.identityCardNo= data.identityCardNo;
      this.referralData.customerName= data.customerName;
      this.referralData.contactPhone= data.contactPhone;
      this.referralData.referralEmpId= data.referralEmpId;
      this.referralData.productCode= data.productCode;
      this.referralData.productRemark= data.productRemark;
      this.referralData.creditNumber= data.creditNumber;
      this.referralData.cuerrency= data.cuerrency;
      this.referralData.acceptedReferralUnit= data.acceptedReferralUnit;
      this.referralData.acceptedReferralEmpId= data.acceptedReferralEmpId;
      this.referralData.otherDescription= data.otherDescription;

      this.isRefferalEdit = true;
    } else {
      this.isRefferalEdit = false;
    }
    this.referralInfoDialog.open();
  }

  public onExportDialogOpen() {
    let value = _.cloneDeep(this.searchFormContainer.form.value);
    if (value['productCode']) {
      value['productCode'] = value['productCode'].map( (prodValue) => {
        return _.find(this.referralProdOptions, {value: prodValue})['label'];
      });
    }
    if (value['referralUnit']) {
      value['referralUnit'] = _.find(this.bankBranchesOptions, {value: value['referralUnit']})['label'];
    }
    if (value['referralEmpId']) {
      value['referralEmpId'] = _.find(this.employeeOptions, {value: value['referralEmpId']})['label'];
    }
    // export dialog display value & label
    this.listConfig = value;
    this.exportReferralListDialog.open();
  }

  public onExportConfirmed(exportType: any, dialog: IbmDialogComponent) {
    let searchParams = _.cloneDeep(this.searchFormContainer.form.value);
    if (exportType === 'all') {
      searchParams['skip'] = 0;
      searchParams['take'] = this.api.getLimitTake();
      this.referralService.export(searchParams, true).subscribe(
        (resp) => {
          this.exportToExcel(resp.value);
          dialog.close();
        }
      );
    } else {
      searchParams['skip'] = (this.referralListTable.currentPage - 1) * this.referralListTable.pageSize;
      searchParams['take'] = this.referralListTable.pageSize;
      this.referralService.export(searchParams, false).subscribe(
        (resp) => {
          this.exportToExcel(resp.value);
          dialog.close();
        }
      );
    }
  }

  public onExportCanceled(config: BaseListConfig , dialog: IbmDialogComponent) {
    dialog.close();
  }

  public displayProdText(prodCode) {
    let prodValue = _.find(this.referralProdOptions, {value: prodCode});
    if (prodValue) {
      return prodValue['label'];
    } else {
      return `無此產品編號：${prodCode}`;
    }
  }

  public displayLessProdText(prodCode) {
    return this.displayProdText(prodCode).slice(0, 4) + '...';
  }

  get displayProductCode(): string {
    if (!this.searchFormContainer.form.controls['productCode'].value) {
      return '';
    }
    return this.searchFormContainer.form.controls['productCode'].value.map((el) => {
      return this.options.getOptionLabel('referralProd', el);
    }).join('、');
  }

  public needHover(prodCode) {
    return this.displayProdText(prodCode).length > 4;
  }

  // todo delete
  // public objectToString(object: Object, connector: string = ' '): string {
  //   return Object.values(object).join(connector);
  // }

  private exportToExcel(rowDatas) {
    const tableData = _.cloneDeep(rowDatas).map( (data) => {
      const result = _.pick(data, _.keys(this.referralService.getReferralTableHeader()));
      // todo combine id & name
      result['ReferralUnit'] =  `${result['ReferralUnit']} ${result['ReferralUnitName']}`;
      result['ReferralEmpId'] = `${result['ReferralEmpId']} ${result['ReferralEmpName']}`;
      result['AcceptedReferralUnit'] = `${result['AcceptedReferralUnit']} ${result['AcceptedReferralUnitName']}`;
      result['AcceptedReferralEmpId'] = `${result['AcceptedReferralEmpId']} ${result['AcceptedReferralEmpName']}`;
      result['ProcessStatusCode'] = result['ProcessStatusCode'].text;
      result['ReferralDate'] = this.datePipe.transform(result['ReferralDate'], 'yyyy/MM/dd HH:mm');
      return result;
    });
    const sheetData = this.sharedService.convertToSheetData(tableData, this.referralService.getReferralTableHeader());
    const sheetName = '分頁1';
    const fileName = '轉介案件';

    this.sharedService.writeToSheet(sheetData, fileName, sheetName);

  }

  private prepareContorls() {
    this.searchControls = [
      new DatepickerControl({
        key: 'referralDate',
        label: '轉介時間',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new TextControl({
        key: 'identityCardNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789'
      }),
      new MultiSelectControl({
        key: 'productCode',
        label: '產品別',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.referralProdOptions,
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'referralUnit',
        label: '轉介單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        options: this.bankBranchesOptions,
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'referralEmpId',
        label: '轉介人員',
        enableAutocomplete: true,
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.employeeOptions,
        placeholder: '請選擇...'
      }),
    ];
  }
}
