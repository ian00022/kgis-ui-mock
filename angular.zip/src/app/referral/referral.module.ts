import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { ReferralSearchComponent } from './referral-search/referral-search.component';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { Permissions } from '../core/models/permissions';

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild([
      {
        path: 'list',
        component: ReferralSearchComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '商機轉介查詢',
          permissions: {
            only: [ Permissions.REFERRAL_SEARCH ],
            redirectTo: '/no-auth'
          }
        }
      },
      { path: '', redirectTo: 'list', pathMatch: 'full' },
    ])
  ],
  declarations: [ ReferralSearchComponent ]
})
export class ReferralModule { }
