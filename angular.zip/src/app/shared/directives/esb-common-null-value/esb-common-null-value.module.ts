import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsbCommonNullValueDirective } from './esb-common-null-value.directive';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [
    EsbCommonNullValueDirective
  ],
  exports: [
    EsbCommonNullValueDirective
  ]
})
export class EsbCommonNullValueModule { }
