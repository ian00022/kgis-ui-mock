import { NgControl } from '@angular/forms';
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[esb-common-null-value]'
})
export class EsbCommonNullValueDirective {

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('input', ['$event.target'])
  onEvent(target: HTMLInputElement){
    if (target.value === '') {
      this.control.control.setValue(null);
    }
  }
}
