import { OnInit } from '@angular/core';
import { Directive, ElementRef, Input, HostListener, HostBinding, Renderer2 } from '@angular/core';

@Directive({
  selector: '[esunBtnToggle]'
})
export class BtnToggleDirective implements OnInit {
  @HostBinding('class.active') active: boolean = false;
  @Input() defaultActive: boolean;
  @Input() url: string;
  
  constructor(private el: ElementRef, private renderer: Renderer2) { }
  
  @HostListener('click') onClick() {
    this.active = !this.active;
  }

  ngOnInit() {
    if (this.defaultActive) {
      this.active = this.defaultActive;
    }

    if (!this.el.nativeElement.classList.contains('btn-outline-primary')) {
      this.renderer.addClass(this.el.nativeElement, 'btn-outline-primary');
    }
  }

}
