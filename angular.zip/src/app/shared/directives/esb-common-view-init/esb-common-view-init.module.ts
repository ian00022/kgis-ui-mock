import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsbCommonViewInitDirective } from './esb-common-view-init.directive';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    EsbCommonViewInitDirective
  ],
  exports: [
    EsbCommonViewInitDirective
  ]
})
export class EsbCommonViewInitModule { }
