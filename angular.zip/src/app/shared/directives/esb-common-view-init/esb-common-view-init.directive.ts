import { Directive, AfterViewInit, EventEmitter, Output } from '@angular/core';

@Directive({
  selector: '[esb-common-view-init]'
})
export class EsbCommonViewInitDirective implements AfterViewInit {

  @Output() onAfterViewInit: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngAfterViewInit() {
    this.onAfterViewInit.emit();
  }
}
