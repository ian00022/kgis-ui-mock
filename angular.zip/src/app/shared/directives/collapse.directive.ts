import {
  AfterViewInit,
  Directive,
  ElementRef,
  HostBinding,
  Input
} from '@angular/core';

@Directive({
  selector: '[esunCollapse]'
})
export class CollapseDirective implements AfterViewInit {
  @HostBinding('style.height')
  height: string;

  private h: number = 0;
  private finishInit = false;
  
  @Input()
  set heightSetter(newHeight: number) {
    if (newHeight !== 0) {
      this.h = newHeight;
      this.height = newHeight + 'px';
    }
  }
  
  @Input()
  set collapsed(value: boolean) {
    if (value !== undefined) {
      if (!this.finishInit) {
        this.measureHeight();
        if (!value) {
          this.hide();
        }
        return;
      }
      
      if (value) {
        this.show();
      } else {
        this.hide();
      }
    }
  }
  
  constructor(private el: ElementRef) {
    this.el.nativeElement.classList.add('block');
  }
  
  ngAfterViewInit() {
    this.measureHeight();
  }
  
  show() {
    setTimeout(() => {
      this.height = this.h + 'px';
      setTimeout( () => {
        this.height = '';
      }, 500);
    }, 1);
  }
  
  hide() {
    this.height = this.h === 0 ? '' : this.h + 'px';
    setTimeout(() => {
      this.height = '0px';
    }, 1);
  }
  
  measureHeight() {
    this.finishInit = true;
    const elem = this.el.nativeElement;
    this.h = elem.offsetHeight;
  }
  
}
