import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';
import { esbCommonDatePickerDirective } from './ibm-date-picker.directive';

declare var moment;

@Component({
  template: `
    <input 
      type="text" 
      [singleDatePicker]="singleDatepicker"
      [(ngModel)]="data" 
      esb-common-date-picker>
  `,
  providers: [LoggerService]
  })
  export class DatePickerTestComponent {

    @ViewChild(esbCommonDatePickerDirective) datepicker: esbCommonDatePickerDirective;

    public singleDatepicker = true;
    public data;

    constructor() { }
}

describe('IbmClockPickerDirective', () => {
  let fixture: ComponentFixture<DatePickerTestComponent>;
  let component: DatePickerTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DatePickerTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatePickerTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should be blur after focusing', async(() => {
    const inputEl = fixture.debugElement.query(By.css('input'));
    inputEl.triggerEventHandler('focus', null);
    const focusedElements = fixture.debugElement.queryAll(By.css(':focus'));
    fixture.detectChanges();
    expect(focusedElements.length).toEqual(0);
  }));

  it('testing single date picker', async(() => {
    component.data = '2014/06/05';
    fixture.detectChanges();
  }));

  it('testing date range picker', async(() => {
    component.data = '2014/06/05 - 2016/06/05';
    component.singleDatepicker = false;
    fixture.detectChanges();
  }));

  it('testing single date picker callback', async(() => {
    component.datepicker.callback(moment('2014/06/05', 'YYYY/MM/DD'));
    fixture.detectChanges();
  }));

  it('testing date range picker call back', async(() => {
    component.singleDatepicker = false;
    fixture.detectChanges();
    component.datepicker.callback(moment('2014/06/05', 'YYYY/MM/DD'), moment('2016/06/05', 'YYYY/MM/DD'));
    fixture.detectChanges();
  }));
});
