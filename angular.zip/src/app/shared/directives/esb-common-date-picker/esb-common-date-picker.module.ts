import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsbCommonDatePickerDirective } from 'app/shared/directives/esb-common-date-picker/esb-common-date-picker.directive';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  declarations: [EsbCommonDatePickerDirective],
  exports: [
    EsbCommonDatePickerDirective
  ]
})
export class EsbCommonDatePickerModule { }
