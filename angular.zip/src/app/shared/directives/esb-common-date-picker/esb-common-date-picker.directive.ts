import { AfterViewInit, Output, HostListener, OnChanges, SimpleChanges } from '@angular/core';
import { Directive, Input, ElementRef, EventEmitter } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as _ from 'lodash';
import { DateHelper } from '../../helper/date-helper';

declare var $: any;
declare var moment: any;


/**
 * see [Daterangepicker]{@link http://www.daterangepicker.com/}
 */
@Directive({
  selector: '[esb-common-date-picker]',
})
export class EsbCommonDatePickerDirective implements AfterViewInit, OnChanges {

  @Input() singleDatePicker: Boolean = false;
  @Input() formatter: string = 'YYYY/MM/DD';
  @Input() minDate: string;
  @Input() maxDate: string;

  @Output() selected = new EventEmitter();
  
  public currentDatePicker;
  constructor(private input: ElementRef, private control: NgControl) {}

  @HostListener('focus') onfocus() {
    this.input.nativeElement.blur();
  }

  ngAfterViewInit() {
    const dateConfig = {
      autoApply: true,
      singleDatePicker: this.singleDatePicker,
      minDate: this.minDate,
      maxDate: this.maxDate,
      ranges: {
        '今天': [moment(), moment()],
        '昨天': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        '近7天': [moment().subtract(6, 'days'), moment()],
        '近30天': [moment().subtract(29, 'days'), moment()],
        '本月': [moment().startOf('month'), moment().endOf('month')],
        '上個月': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      },
      showCustomRangeLabel: false,
      locale: {
        format: this.formatter
      }
    };
    if (this.control.control.value) {
      if (this.singleDatePicker) {
        dateConfig['startDate'] = moment(this.control.control.value, this.formatter);
      } else {
        const date = DateHelper.divideDate(this.control.control.value);
        dateConfig['startDate'] = moment(date.startTime, this.formatter);
        dateConfig['endDate'] = moment(date.endTime, this.formatter);
      }
    } else {
      dateConfig['startDate'] = moment();
    }

    $(this.input.nativeElement)
      .daterangepicker(dateConfig, this.callback.bind(this))
      .on('apply.daterangepicker', this.applyEvent.bind(this));

    this.currentDatePicker = $(this.input.nativeElement).data('daterangepicker');
  }

  ngOnChanges(changes: SimpleChanges): void {
    if(!_.isEmpty(this.currentDatePicker)) {
      let changess;
      if (changes.minDate && (changes.minDate.previousValue !== changes.minDate.currentValue)) {
        changess = changes.minDate.currentValue;
      }
      this.currentDatePicker.minDate = changess ? moment(changess, this.formatter) : false;
    }
  }

  public callback(start?: any, end?: any, label?: any): void {
    start = start.format(this.formatter);
    if (end) {
      end = end.format(this.formatter);
    }

    if (this.singleDatePicker) {
      this.control.control.setValue(`${start}`);
    } else {
      const date = DateHelper.combineDate(start, end);
      this.control.control.setValue(date);
    }

  }
  public applyEvent(ev: any, picker: any) {
    const start = picker.startDate.format(this.formatter);

    // it won't set value when it's singledatepicker and client select today
    if (this.singleDatePicker && _.isEmpty(this.control.control.value)) {
      this.control.control.setValue(start);
    }
  }
}
