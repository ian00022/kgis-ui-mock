import { AfterViewInit, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Directive, ElementRef } from '@angular/core';

declare var $;

@Directive({
  selector: '[ibmClockPicker]'
})
export class IbmClockPickerDirective implements AfterViewInit{
  
  constructor(private input: ElementRef, private control: NgControl) { }

  @HostListener('focus') onfocus() {
    this.input.nativeElement.blur();
  }


  ngAfterViewInit() {
    $(this.input.nativeElement).clockpicker({
      autoclose: true,
      afterDone: () => {
        let val = $(this.input.nativeElement).val();
        this.control.control.setValue(val);
      }
    });
  }
}
