import { IbmClockPickerDirective } from './ibm-clock-picker.directive';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
    <input 
      type="text" 
      [(ngModel)]="data" 
      ibmClockPicker>
  `,
  providers: [LoggerService]
  })
  export class ClockPickerTestComponent {

    @ViewChild(IbmClockPickerDirective) clockpicker: IbmClockPickerDirective;

    public data;

    constructor() { }
}

describe('IbmClockPickerDirective', () => {
  let fixture: ComponentFixture<ClockPickerTestComponent>;
  let component: ClockPickerTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ClockPickerTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClockPickerTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should be blur after focusing', async(() => {
    const inputEl = fixture.debugElement.query(By.css('input'));
    inputEl.triggerEventHandler('focus', null);
    const focusedElements = fixture.debugElement.queryAll(By.css(':focus'));
    fixture.detectChanges();
    expect(focusedElements.length).toEqual(0);
  }));
});
