import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IbmClockPickerDirective } from './ibm-clock-picker.directive';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  declarations: [IbmClockPickerDirective],
  exports: [
    IbmClockPickerDirective
  ]
})
export class IbmClockPickerModule { }
