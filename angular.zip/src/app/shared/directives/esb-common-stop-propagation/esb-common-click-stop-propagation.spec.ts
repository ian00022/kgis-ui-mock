import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';

@Component({
  template: `
    <div (click)="handleDivClick()">
      <button class="button1" (click)="handleButtonClick()"></button>
    </div>

    <div (click)="handleDivClick()">
      <button class="button2" esb-common-click-stop-propagation (click)="handleButtonClick()"></button>
    </div>
  `,
  providers: [LoggerService]
  })
  export class StopPropagationTestComponent {
    constructor() { }

    public handleDivClick() {}
    public handleButtonClick() {}
}

describe('IbmClockPickerDirective', () => {
  let fixture: ComponentFixture<StopPropagationTestComponent>;
  let component: StopPropagationTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        StopPropagationTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StopPropagationTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should the click event should propagate without directive', async(() => {
    spyOn(component, 'handleDivClick');
    fixture.debugElement.query(By.css('.button1')).nativeElement.click();
    expect(component.handleDivClick).toHaveBeenCalled();
  }));

  it('should the click event should not propagate with directive', async(() => {
    spyOn(component, 'handleDivClick');
    fixture.debugElement.query(By.css('.button2')).nativeElement.click();
    expect(component.handleDivClick).not.toHaveBeenCalled();
  }));

});
