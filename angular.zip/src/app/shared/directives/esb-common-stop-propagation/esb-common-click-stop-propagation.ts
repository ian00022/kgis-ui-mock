import {Directive, HostListener} from '@angular/core';

@Directive({
    selector: '[esb-common-click-stop-propagation]'
})
export class EsbCommonStopPropagationDirective {
    @HostListener('click', ['$event'])
    public onClick(event: any): void {
        event.stopPropagation();
    }
}