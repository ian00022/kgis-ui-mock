import { EsbCommonStopPropagationDirective } from './esb-common-click-stop-propagation';
import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  declarations: [EsbCommonStopPropagationDirective],
  exports: [
    EsbCommonStopPropagationDirective
  ]
})
export class EsbCommonClickStopPropagationModule { }
