import { ProgressChartComponent } from './components/progress-chart/progress-chart.component';
import { CardFileContentComponent } from './components/card-file-content/card-file-content.component';
import { AssetsLiabilitiesDialogComponent } from './components/assets-liabilities-dialog/assets-liabilities-dialog.component';
import { CreateScheduleDialogComponent } from './components/create-schedule-dialog/create-schedule-dialog.component';
import { SlickModule } from 'ngx-slick';
import { CreateNoteDialogComponent } from './components/create-note-dialog/create-note-dialog.component';
import { CreatePotentialDialogComponent } from './components/create-potential-dialog/create-potential-dialog.component';
import { StatusInfoDialogComponent } from './components/status-info-dialog/status-info-dialog.component';
import { BtnToggleDirective } from './directives/btn-toggle.directive';
import { IbmTabsModule } from './components/ibm-tabs/ibm-tabs.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MaterialsModule } from './materials.module';
import { IbmTableModule } from './components/ibm-table/ibm-table.module';
import { IbmCollapseModule } from './components/ibm-collapse/ibm-collapse.module';
import { IbmSwitchModule } from './components/ibm-switch/ibm-switch.module';
import { IbmDialogModule } from './components/ibm-dialog/ibm-dialog.module';
import { PieChartModule } from './components/pie-chart/pie-chart.module';
import { ProgressBarModule } from './components/progress-bar/progress-bar.module';
import { ReactiveFormsModule } from '@angular/forms';

import { CardWrapperComponent } from './components/card-wrapper/card-wrapper.component';
import { DetailMainComponent } from './components/detail-main/detail-main.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { SearchMainComponent } from './components/search-main/search-main.component';

import { CollapseDirective } from './directives/collapse.directive';

import { ObjToArrPipe } from './pipes/obj-to-arr.pipe';
import { PieChartTooltipPipe } from './pipes/pie-chart-tooltip.pipe';
import { MdePopoverModule } from '@material-extended/mde';
import { DynamicFormModule } from './components/dynamic-form/dynamic-form.module';
import { SharedService } from './services/shared.service';
import { LightboxModule } from 'ngx-lightbox';
import { IbmReadMoreComponent } from './components/ibm-read-more/ibm-read-more.component';
import { CardContentComponent } from './components/card-content/card-content.component';
import { HttpClientModule } from '@angular/common/http';
import { IbmClockPickerModule } from './directives/ibm-clock-picker/ibm-clock-picker.module';
import { IbmSingleSelectModule } from './components/ibm-single-select/ibm-single-select.module';
import { ExportReportDialogComponent } from './components/export-report-dialog/export-report-dialog.component';
import { CreateBoDialogComponent } from './components/create-bo-dialog/create-bo-dialog.component';
import { CreateReferralDialogComponent } from './components/create-referral-dialog/create-referral-dialog.component';
import { FullCalendarModule } from '../../ng-fullcalendar';
import { AddressSelectComponent } from './components/address-select/address-select.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { FileUploadModule } from 'ng2-file-upload';
import {MatTreeModule} from '@angular/material/tree';
import {MatIconModule} from '@angular/material/icon';
import { SafePipe } from './pipes/safe.pipe';
import { SelectedOptionsModule } from './components/selected-options/selected-options.module';
import { YesNoPipe } from 'app/shared/pipes/yes-no.pipe';
import { DateIso8601Pipe } from './pipes/date-iso-8601.pipe';
import { JoinPipe } from 'app/shared/pipes/join.pipe';
import { LabelsFromOptionPipe } from 'app/shared/pipes/labels-from-option.pipe';
import { EsbCommonClickStopPropagationModule } from 'app/shared/directives/esb-common-stop-propagation/esb-common-click-stop-propagation.module';
import { EsbCommonMultiSelectModule } from 'app/shared/components/esb-common-multi-select/esb-common-multi-select.module';
import { EsbCommonDatePickerModule } from 'app/shared/directives/esb-common-date-picker/esb-common-date-picker.module';
import { NgZorroAntdModule, NZ_I18N, en_US } from 'ng-zorro-antd';
import { DisplayModalChangeComponent } from './components/display-modal-change/display-modal-change.component';
import { EsbCommonViewInitModule } from './directives/esb-common-view-init/esb-common-view-init.module';
import { EsbCommonNullValueModule } from './directives/esb-common-null-value/esb-common-null-value.module';
import { EsbCommonTreeSelectModule } from './components/esb-common-tree-select/esb-common-tree-select.module';

const sharedComponents = [
  CardWrapperComponent,
  DetailMainComponent,
  BreadcrumbComponent,
  SearchMainComponent,
  IbmReadMoreComponent,
  CardContentComponent,
  StatusInfoDialogComponent,
  ExportReportDialogComponent,
  CreatePotentialDialogComponent,
  CreateNoteDialogComponent,
  CreateBoDialogComponent,
  CreateReferralDialogComponent,
  CreateScheduleDialogComponent,
  AddressSelectComponent,
  AssetsLiabilitiesDialogComponent,
  CardFileContentComponent,
  ProgressChartComponent,
  DisplayModalChangeComponent,
];

const sharedDirectivesAndPipes = [
  CollapseDirective,
  ObjToArrPipe,
  PieChartTooltipPipe,
  YesNoPipe,
  BtnToggleDirective,
  SafePipe,
  DateIso8601Pipe,
  JoinPipe,
  LabelsFromOptionPipe
];

const sharedModules = [
  CommonModule,
  FormsModule,
  MaterialsModule,
  IbmTableModule,
  IbmCollapseModule,
  IbmSwitchModule,
  IbmDialogModule,
  IbmTabsModule,
  PieChartModule,
  ProgressBarModule,
  MdePopoverModule,
  ReactiveFormsModule,
  DynamicFormModule,
  EsbCommonDatePickerModule,
  LightboxModule,
  IbmClockPickerModule,
  EsbCommonMultiSelectModule,
  EsbCommonClickStopPropagationModule,
  EsbCommonViewInitModule,
  IbmSingleSelectModule,
  SlickModule,
  FullCalendarModule,
  NgxPermissionsModule,
  FileUploadModule,
  MatTreeModule,
  MatIconModule,
  SelectedOptionsModule,
  /** import ng-zorro-antd root module，you should import NgZorroAntdModule instead in sub module **/
  NgZorroAntdModule,
  EsbCommonTreeSelectModule,
  EsbCommonNullValueModule
];

@NgModule({
  imports: [
    HttpClientModule,
    RouterModule,
    ...sharedModules
  ],
  declarations: [
    ...sharedComponents,
    ...sharedDirectivesAndPipes
  ],
  exports: [
    ...sharedModules,
    ...sharedComponents,
    ...sharedDirectivesAndPipes
  ],
  providers: [
    /** config ng-zorro-antd i18n **/
    { provide: NZ_I18N, useValue: en_US },
    SharedService
  ]
})
export class SharedModule { }
