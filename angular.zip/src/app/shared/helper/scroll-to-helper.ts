declare var $;

export class ScrollToHelper {
  constructor() {}

  public static scrollSelectorTo(selector: string, target: string, offsetTop: number) {
    $($(selector)).scrollTo(`#${target}`, 400, {
      offset: {
        top: -offsetTop
      }
    });
  }

  public static scrollWindowTo(target: string, offsetTop: number) {
    $(window).scrollTo(`#${target}`, 400, {
      offset: {
        top: -offsetTop
      }
    });
  }

  public static scrollTop(selector: string = '.mat-drawer-content') {
    $(selector).scrollTo(0, 400);
  }
}
