import { DateHelper } from './date-helper';
import { async } from '@angular/core/testing';

describe('DateHelperClass', () => {

  it('test combine date', async(() => {
    const rs = DateHelper.combineDate('2012/05/06', '2012/07/06');
    expect(rs).toEqual('2012/05/06 - 2012/07/06');
  }));

  it('test divide date', async(() => {
    const rs = DateHelper.divideDate('2012/05/06 - 2012/07/06');
    expect(rs.startTime).toEqual('2012/05/06');
    expect(rs.endTime).toEqual('2012/07/06');
  }));
});
