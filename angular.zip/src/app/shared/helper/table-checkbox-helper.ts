import * as _ from 'lodash';

export class CheckBoxTableHelper {
  constructor() {}

  /**
   * handle table row checked
   * when checkbox clicked, checkorUncheck will get a boolean value
   * then check selectedRows have same 'id' row or not,
   * if true, then remove row from rows
   * else add row to rows
   *
   * @static
   * @param {boolean} checkOrUncheck
   * @param {*} row
   * @param {any[]} selectedRows
   * @param {string} [key='id']
   * @returns {any[]}
   * @memberof CheckBoxTableHelper
   */
  public static handleSelected(checkOrUncheck: boolean, row: any, selectedRows: any[], key: string = 'id'): any[] {
    row.checked = checkOrUncheck;

    const rows = _.cloneDeep(selectedRows);
    if (!checkOrUncheck) {
      _.remove(rows, (el) => {
        return el[key] === row[key];
      });
    } else {
      rows.push(row);
    }
    return rows;
  }

  /**
   * handle table row checked all
   * if table row has any selected row, then uncheck all
   * else check all
   *
   * @static
   * @param {boolean} anySelected
   * @param {any[]} dataSource
   * @param {any[]} selectedRows
   * @param {string} [key='id']
   * @returns
   * @memberof CheckBoxTableHelper
   */
  public static handleSelectAll(anySelected: boolean, dataSource: any[], selectedRows: any[], key: string = 'id') {
    let rows = _.cloneDeep(selectedRows);
    if (anySelected) {
      dataSource.filter( (row) => row.checked ).forEach( (row) => {
        rows = this.handleSelected(false, row, rows, key);
      });
    } else {
      dataSource.filter( (row) => !row.checked ).forEach( (row) => {
        rows = this.handleSelected(true, row, rows, key);
      });
    }
    return rows;
  }
}
