import * as _ from 'lodash';
import { DateRange } from 'app/core/models/comm-data';
declare var moment: any;

export class DateHelper {
  public static seperator = ' - ';
  public static defaultFormat = 'YYYY/MM/DD';

  constructor() {}

  public static getLastThreeMonths(): string {
    return `${this.momentToFormattedString(moment().subtract(3,'months'))}${this.seperator}${this.momentToFormattedString(moment())}`;
  }

  public static getLastOneMonths(): string {
    return `${this.momentToFormattedString(moment().subtract(1,'months'))}${this.seperator}${this.momentToFormattedString(moment())}`;
  }

  public static combineDate(start: any, end: any): string {
    return `${start}${this.seperator}${end}`;
  }

  public static divideDate(date: string): DateRange {
    const arr = _.split(date, this.seperator);
    const startDate = arr[0];
    let endDate;
    if (arr.length > 1) {
      endDate = arr[1];
    }

    return {
      startTime: startDate,
      endTime: endDate
    };
  }

  public static formatDate(dateString: string, formatter: string = '', format: string = 'YYYY/MM/DD'): string {
    const momentDate = moment(dateString, formatter);
    if (!momentDate.isValid()) {
      return '';
    }
    return momentDate.format(format);
  }

  public static formatTime(dateString: string, formatter: string = '', format: string = 'HH:mm'): string {
    const momentTime = moment(dateString, formatter);
    if (!momentTime.isValid()) {
      return '';
    }
    return momentTime.format(format);
  }

  public static momentToFormattedString(momentObj): string {
    return momentObj.format(this.defaultFormat);
  }

}
