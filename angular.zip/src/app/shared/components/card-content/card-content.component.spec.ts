import { CardContentComponent } from './card-content.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
    <esun-card-content #card [header]="header" [data]="data"></esun-card-content>
  `,
  providers: [LoggerService]
  })
  export class CardTestComponent {

    @ViewChild('card') card: CardContentComponent;

    public header = 'a funny header';

    public data: any[] = [
      {
        title: 'title 01',
        content: 'content 01'
      },
      {
        title: 'title 02',
        content: 'content 02'
      },
    ];

    constructor() { }
}

describe('CardContentComponent', () => {
  let fixture: ComponentFixture<CardTestComponent>;
  let component: CardTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CardTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should see the header', async(() => {
    expect(fixture.debugElement.query(By.css('.cardInside-sub-tit')).nativeElement.innerText).toEqual(component.header);
  }));

  it('should see the title', async(() => {
    expect(fixture.debugElement.query(By.css('.div-table-th--title')).nativeElement.innerText).toEqual(component.data[0].title);
  }));

  it('should see the content', async(() => {
    expect(fixture.debugElement.query(By.css('.div-table-td')).nativeElement.innerText).toEqual(component.data[0].content);
  }));
});
