import { LoggerService } from './../../logger.service';
import { Component, OnInit, Input } from '@angular/core';
import { ContentRowModel } from '../../../core/models/comm-data';

export interface CardContentModel {
  header: string;
  data: ContentRowModel[];
  iconClass?: string;
}

@Component({
  selector: 'esun-card-content',
  templateUrl: './card-content.component.html',
  styleUrls: ['./card-content.component.scss']
})
export class CardContentComponent implements OnInit, CardContentModel {
  @Input() iconClass: string;
  @Input() data: ContentRowModel[];
  @Input() header: string;

  constructor(private logger: LoggerService) { }

  ngOnInit() {
    this.logger.log(this.iconClass);
  }

  public isArray(data: any) {
    return data instanceof Array;
  }
}