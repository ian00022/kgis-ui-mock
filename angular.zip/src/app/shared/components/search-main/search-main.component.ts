import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'esun-search-main',
  templateUrl: './search-main.component.html',
  styleUrls: ['./search-main.component.css']
})
export class SearchMainComponent implements OnInit {

  @Input('searchHeader') searchHeader = '';

  constructor() { }

  ngOnInit() {
  }

}
