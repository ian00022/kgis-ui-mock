import {InjectionToken} from '@angular/core';
import {Subject} from 'rxjs';

export const IbmDialogRef = new InjectionToken<any>('ls-dialog-ref');
export const IBM_DIALOG_DATA = new InjectionToken<any>('ls-dialog-data');

export interface IbmDialogModel {
  submitSubject: Subject<any>;
  confirm(data?: any);
  emitConfirm(data?: any);
  open();
  close(data?: any);
  create(any);
}
