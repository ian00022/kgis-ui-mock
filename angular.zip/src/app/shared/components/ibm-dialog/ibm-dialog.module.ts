import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IbmDialogComponent } from './ibm-dialog.component';
import {PortalModule} from '@angular/cdk/portal';
import { DialogBaseComponent } from './dialog-base/dialog-base.component';
import { IbmSideDialogComponent } from './ibm-side-dialog/ibm-side-dialog.component';
import { IbmConfirmDialogComponent } from './ibm-confirm-dialog/ibm-confirm-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    PortalModule
  ],
  declarations: [IbmDialogComponent, DialogBaseComponent, IbmSideDialogComponent, IbmConfirmDialogComponent],
  exports: [
    IbmDialogComponent,
    IbmSideDialogComponent,
    IbmConfirmDialogComponent
  ]
})
export class IbmDialogModule { }
