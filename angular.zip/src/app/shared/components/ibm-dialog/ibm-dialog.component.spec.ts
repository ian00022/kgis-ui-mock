import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { IbmDialogComponent } from './ibm-dialog.component';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('IbmDialogComponent', () => {
  let fixture: ComponentFixture<IbmDialogComponent>;
  let component: IbmDialogComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IbmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the dialog', async(() => {
    const dialogComponent = fixture.debugElement.componentInstance;
    expect(dialogComponent).toBeTruthy();
  }));

  it('should the header of the dialog be set', async(() => {
    const headerText = 'a test header';
    component.header = headerText;
    component.open();

    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.dialog-title')).nativeElement.innerText).toEqual(headerText);
  }));

});

@Component({
  template: `
  <ibm-dialog #dialog header="a header" (afterCanceled)="handleAfterCanceled()" (afterConfirmed)="handleAfterConfirm()" [disableConfirm]="disableConfirm">
    123
  </ibm-dialog>
  `
  })
  export class DialogTestComponent {
    public tableData = [];
    public rowClassNameFunction;
    public disableConfirm = false;

    @ViewChild('dialog') dialog: IbmDialogComponent;

    handleAfterConfirm(){}
    handleAfterCanceled(){}

    constructor() { 
    }
}
describe('IbmDialogTestComponent', () => {
  let fixture: ComponentFixture<DialogTestComponent>;
  let component: DialogTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DialogTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the dialog', async(() => {
    const dialogComponent = fixture.debugElement.componentInstance;
    expect(dialogComponent).toBeTruthy();
  }));

  it('should the header of the dialog be set', async(() => {
    component.dialog.open();
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.dialog-title')).nativeElement.innerText).toEqual('a header');
  }));

  it('should the dialog been opened', async(() => {
    component.dialog.open();
    fixture.detectChanges();
    expect(component.dialog.isOpen).toEqual(true);
  }));

  it('should the dialog been closed', async(() => {
    component.dialog.open();
    fixture.detectChanges();
    component.dialog.close();
    fixture.detectChanges();
    expect(component.dialog.isOpen).toEqual(false);
  }));

  it('should the dialog not open at begining', async(() => {
    expect(component.dialog.isOpen).toEqual(false);
  }));

  it('should afterConfirm been called', async(() => {
    component.dialog.open();
    fixture.detectChanges();
    spyOn(fixture.debugElement.componentInstance, 'handleAfterConfirm');
    let btn = fixture.debugElement.query(By.css('.confirm-btn')).nativeElement;
    btn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.handleAfterConfirm).toHaveBeenCalled();
  }));

  it('should afterConfirm not been called if it\'s disabled', async(() => {
    component.disableConfirm = true;
    fixture.detectChanges();
    component.dialog.open();
    fixture.detectChanges();
    spyOn(fixture.debugElement.componentInstance, 'handleAfterConfirm');
    let btn = fixture.debugElement.query(By.css('.confirm-btn')).nativeElement;
    btn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.handleAfterConfirm).not.toHaveBeenCalled();
  }));

  it('should afterCancel been called', async(() => {
    component.dialog.open();
    fixture.detectChanges();
    spyOn(fixture.debugElement.componentInstance, 'handleAfterCanceled');
    let btn = fixture.debugElement.query(By.css('.cancel-btn')).nativeElement;
    btn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.handleAfterCanceled).toHaveBeenCalled();
  }));

});