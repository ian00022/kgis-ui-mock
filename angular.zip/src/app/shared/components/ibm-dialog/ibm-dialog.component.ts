import { ContentChild } from '@angular/core';
import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  TemplateRef,
  Output,
  EventEmitter,
  Input,
  OnDestroy
} from '@angular/core';
import { Portal } from '@angular/cdk/portal';
import { ComponentType } from '@angular/cdk/portal';
import { Subject } from 'rxjs';
import { DialogBaseComponent } from './dialog-base/dialog-base.component';


/**
 *
 *
 * @example
 * <ibm-dialog header="dialog header" (afterClosed)="afterClose()" (afterConfirmed)="handleDeleteConfirm()" (afterCanceled)="handleDeleteCancel()">
    <p>確定刪除「{{ selectedFile?.fileName }}」嗎？</p>
   </ibm-dialog>
 */
@Component({
  selector: 'ibm-dialog',
  templateUrl: './ibm-dialog.component.html',
  styleUrls: ['./ibm-dialog.component.css']
})
export class IbmDialogComponent implements OnInit, AfterViewInit, OnDestroy {

  /**
   * header of the dialog
   */
  @Input('header') header = '';

  /**
   * whether to disable confirm button
   */
  @Input('disableConfirm') disableConfirm = false;

  /**
   * whether to disable confirm button
   */
  @Input('disableCancel') disableCancel = false;

  /**
   * whether to hide footer
   */
  @Input('hideFooter') hideFooter = false;

  /**
   * whether to hide confirm button
   */
  @Input('hideConfirm') hideConfirm = false;

  /**
   * whether to hide confirm button
   */
  @Input('hideCancel') hideCancel = false;

  /**
   * set the padding 0 to modal body, used when the body has something like table which is better look when expand to both sides.
   *
   * @type {boolean} true for no padding
   */
  @Input('noBodyPadding') noBodyPadding = false;

  @Input('size') size = 'meduim';

  /**
   * emit when the dialog is closed
   */
  @Output()
  afterClosed = new EventEmitter();

  /**
   * emit when push close btn
   */
  @Output()
  afterCanceled = new EventEmitter();

  /**
   * @todo
   * not implemented yet
   *
   * in some cases that the dialog pass data to the parent component with data
   */
  @Output()
  afterConfirmed = new EventEmitter<any>();

  dialogContentPotal: Portal<any>;
  /**
   * the dialog content is from ngContent in the parent template or from a Component Class
   */
  
  @ViewChild('dialogBase') dialogBase: DialogBaseComponent;
  componentOrTemplateRef: ComponentType<any> | TemplateRef<any>;


  /**
   * customize header of dialog with html
   */
  @ContentChild('dialogHeaderSlot') dialogHeaderSlot: TemplateRef<any>;

  /**
   * use to notify child component that the confirm btn is clicked
   */
  submitSubject: Subject<any>;

  /**
   * use to notify child component that the cancel btn is clicked
   */
  cancelSubject: Subject<any>;

  // private mode: DialogMode = DialogMode.TEMPLATE;

  constructor() {
    this.submitSubject = new Subject();
    this.cancelSubject = new Subject();
  }

  /**
   * create the injector that is going to pass to the child component, the data is the ref of the dialog component
   */
  // private _createInjector(data?: any): PortalInjector {
  //   const injectionTokens = new WeakMap();
  //   injectionTokens.set(IbmDialogRef, this);
  //   injectionTokens.set(IBM_DIALOG_DATA, data);
  //   return new PortalInjector(this.injector, injectionTokens);
  // }

  /**
   * called when confirm btn is clicked, child component can know by subribing to submitSubject
   */
  confirm(data?: any) {
    // if (this.mode === DialogMode.COMPONENT) {
    //   this.submitSubject.next();
    // } else {
    //   this.emitConfirm();
    // }

    this.emitConfirm();
  }

  emitConfirm(data?: any) {
    this.afterConfirmed.next(data);
  }

  /**
   * called when cancel btn is clicked, child component can know by subribing to cancelSubject
   */
  cancel(data?: any) {
    // if (this.mode === DialogMode.COMPONENT) {
    //   this.cancelSubject.next();
    // } else {
    //   this.emitCancel();
    // }

    this.emitCancel();
  }

  emitCancel(data?: any) {
    this.afterCanceled.next(data);
  }

  /**
   * open the dialog
   */
  open() {
    this.dialogBase.open();
    document.querySelector('body').classList.add('dialog-open');
  }

  /**
   * close the dialog
   */
  close(data?: any) {
    this.dialogBase.close();
    // clear subject prevent undestroy component listen to it.
    // this.submitSubject = new Subject();
    this.afterClosed.emit(data);

    document.querySelector('body').classList.remove('dialog-open');
  }

  get isOpen(): boolean {
    return this.dialogBase.overlayRef ? this.dialogBase.overlayRef.hasAttached() : false;
  }

  /**
   * create component from dynamic component ref
   * @param {(ComponentType<T> | TemplateRef<T>)} componentOrTemplateRef
   */
  // public create<T>(componentOrTemplateRef: ComponentType<T> | TemplateRef<T>, data?: any) {
  //   this.attachDialogCointent(componentOrTemplateRef, data);
  //   this.mode = DialogMode.COMPONENT;
  // }

  public hasHeaderTemplate(): boolean {
    return typeof this.dialogHeaderSlot === 'object';
  }

  // private attachDialogCointent<T>(componentOrTemplateRef: ComponentType<T> | TemplateRef<T>, data?: any) {
  //   if (componentOrTemplateRef instanceof TemplateRef) {
  //     this.dialogContentPotal = new TemplatePortal(componentOrTemplateRef, this.viewContainerRef);
  //   } else {
  //     const componentPortal = new ComponentPortal(componentOrTemplateRef, undefined, this._createInjector(data));
  //     this.dialogContentPotal = componentPortal;
  //   }
  // }

  ngOnInit() {
  }

  ngAfterViewInit(){

  }

  ngOnDestroy(){
  }

}

