import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { DialogBaseComponent } from '../dialog-base/dialog-base.component';

@Component({
  selector: 'ibm-side-dialog',
  templateUrl: './ibm-side-dialog.component.html',
  styleUrls: ['./ibm-side-dialog.component.scss']
})
export class IbmSideDialogComponent implements OnInit {
  @ViewChild('dialogBase') dialogBase: DialogBaseComponent;

  @Input('size') size = 'meduim';

  strategy;

  constructor(private overlay: Overlay) {
    this.strategy = this.overlay.position().global().top('0px').right('0px').bottom('0');
  }

  public open() {
    this.dialogBase.open();
  }

  close(data?: any) {
    this.dialogBase.close();
  }

  get isOpen(): boolean {
    return this.dialogBase.overlayRef ? this.dialogBase.overlayRef.hasAttached() : false;
  }

  ngOnInit() {
    this.dialogBase.size = this.size;
  }

}
