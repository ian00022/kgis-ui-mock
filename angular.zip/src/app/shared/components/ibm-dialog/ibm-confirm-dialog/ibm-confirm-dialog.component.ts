import { EventEmitter, ViewChild } from '@angular/core';
import { Component, OnInit, Output } from '@angular/core';
import { DialogBaseComponent } from '../dialog-base/dialog-base.component';

@Component({
  selector: 'ibm-confirm-dialog',
  templateUrl: './ibm-confirm-dialog.component.html',
  styleUrls: ['./ibm-confirm-dialog.component.scss']
})
export class IbmConfirmDialogComponent implements OnInit {
  @ViewChild('dialogBase') dialogBase: DialogBaseComponent;

  @Output()
  afterConfirmed = new EventEmitter();

  @Output()
  afterCancel = new EventEmitter();

  constructor() { }

  public open() {
    this.dialogBase.open();
  }

  public close() {
    this.dialogBase.close();
  }

  public cancel() {
    this.dialogBase.close();
    this.afterCancel.emit();
  }

  public confirm() {
    this.dialogBase.close();
    this.afterConfirmed.emit();
  }

  ngOnInit() {
  }

}
