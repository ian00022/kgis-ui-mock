import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  ViewContainerRef,
  Output,
  EventEmitter,
  Input
} from '@angular/core';
import { Overlay, OverlayRef, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { ComponentType } from '@angular/cdk/portal';

@Component({
  selector: 'dialog-base',
  templateUrl: './dialog-base.component.html',
  styleUrls: ['./dialog-base.component.scss']
})
export class DialogBaseComponent implements OnInit {
  @Input('strategy') strategy = null;

  @Input('size') size = 'meduim';

  @Input('closeOnBackdrop') closeOnBackdrop: boolean = false;

  /**
   * @todo
   * not implemented yet
   *
   * in some cases that the dialog pass data to the parent component with data
   */
  @Output()
  afterConfirmed = new EventEmitter<any>();

  @ViewChild('dialogPanel') dialogPanel: TemplateRef<any>;
  overlayRef: OverlayRef;
  componentOrTemplateRef: ComponentType<any> | TemplateRef<any>;

  constructor(private overlay: Overlay,
    private viewContainerRef: ViewContainerRef) {
  }

  /**
   * return the width of the component
   */
  get dialogWidth() {

    const sizeMap = {
      'small': '40vw',
      'meduim': '50vw',
      'large': '70vw',
    };

    if (!sizeMap.hasOwnProperty(this.size)) {
      this.size = 'meduim';
    }

    return sizeMap[this.size];
  }

  /**
   * open the dialog
   */
  open() {
    // If create overlay on ngAfterViewInit(),
    // It will be appended many dialog overlay containters in the dom tree.
    // In order to create body scrolling when dialog is overflow the screen,
    // I move _createOverlay to open() function.
    // It will create just one overlay while dialog is opened.

    this._createOverlay();

    this.overlayRef.backdropClick().subscribe(() => {
      if (this.closeOnBackdrop) {
        this.close();
      }
    });

    this.overlayRef.attach(new TemplatePortal(this.dialogPanel, this.viewContainerRef));
  }

  /**
   * close the dialog
   */
  close(data?: any) {
    if (this.overlayRef.hasAttached) {
      this.overlayRef.detach();
      // It will clean the overlay after dialog close.
      this.overlayRef.dispose();
    }
  }

  ngOnInit() {
  }

  // ngAfterViewInit() {
    // this._createOverlay();
    // this.overlayRef.backdropClick().subscribe(() => {
    //   if (this.closeOnBackdrop) {
    //     this.close();
    //   }
    // });
  // }

  /**
   * create the overlay with config and position positionStrategy
   *
   * @private
   */
  private _createOverlay() {
    let strategy = this.strategy? this.strategy : this.overlay
      .position()
      .global()
      .centerHorizontally()
      .top('30px');

    const config = new OverlayConfig({
      hasBackdrop: true,
      // minWidth: this.dialogWidth,
      // maxWidth: this.dialogWidth,
      panelClass: 'dialog-' + this.size || 'dialog-' + 'meduim',
      positionStrategy: strategy
    });
    this.overlayRef = this.overlay.create(config);
  }

}
