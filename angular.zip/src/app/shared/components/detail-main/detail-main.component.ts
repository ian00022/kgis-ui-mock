import { AfterViewInit } from '@angular/core';
import { Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import {Component, Input, OnInit} from '@angular/core';
import { CollapseDirective } from '../../directives/collapse.directive';

@Component({
  selector: 'esun-detail-main',
  templateUrl: './detail-main.component.html',
  styleUrls: ['./detail-main.component.scss']
})
export class DetailMainComponent implements OnInit, AfterViewInit {

  @Input() openTitle: string = '';
  @Input() closeTitle: string = '';
  @Input() custData: any = {};
  @Input()
  set source(text: string) {
    this.displayText = text;
  }

  @Output() onToggle: EventEmitter<any> = new EventEmitter();
  @ViewChild('content') content: ElementRef;
  @ViewChild('collapse') collapsedirective: CollapseDirective;

  public displayText = '';
  public collapsed = true;
  public contentHeight = 0;
  public heightOnClose = 0;
  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
    if (this.content.nativeElement.offsetHeight !== 0) {
      this.contentHeight = this.content.nativeElement.offsetHeight;
    }
  }

  public updateHeight() {
    if (this.content.nativeElement.offsetHeight !== 0) {
      this.contentHeight = this.content.nativeElement.offsetHeight;
      this.heightOnClose = this.content.nativeElement.offsetHeight;
    }
  }

  public onToggleCollapse() {
    this.updateHeight();
    this.collapsed = !this.collapsed;
    let state = {
      height: this.contentHeight,
      collapsed: this.collapsed
    };
    this.onToggle.emit(state);
  }
}
