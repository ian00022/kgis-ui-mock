import { DetailMainComponent } from './detail-main.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
  <esun-detail-main
      [closeTitle]="title"
      [openTitle]="title"
      [source]="title"
      #detailMain
      (onToggle)="handleToggle($event)">
    <ng-container dm-tr-actions>
      123
    </ng-container>
    <ng-container dm-header>
      456
    </ng-container>
    <div dm-content class="listinfoarea row no-gutters">
      789
    </div>
  </esun-detail-main>
  `,
  providers: [LoggerService]
  })
  export class DetailMainTestComponent {

    @ViewChild('detailMain') detailMain: DetailMainComponent;

    public title = 'a funny title';

    public handleToggle(event){
    }

    constructor() { }
}

describe('DetailMainComponent', () => {
  let fixture: ComponentFixture<DetailMainTestComponent>;
  let component: DetailMainTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DetailMainTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailMainTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should see the actions', async(() => {
    expect(fixture.debugElement.query(By.css('.actions')).nativeElement.innerText)
      .toEqual('123');
  }));

  it('should see the header', async(() => {
    expect(fixture.debugElement.query(By.css('.info-area')).nativeElement.innerText)
      .toContain('456');
  }));

  it('should see the header', async(() => {
    expect(fixture.debugElement.query(By.css('.info-area')).nativeElement.innerText)
      .toContain('789');
  }));

  it('should see the content', async(() => {
    expect(fixture.debugElement.query(By.css('.info-area')).nativeElement.innerText)
      .toContain('456');
  }));

  it('should see the source', async(() => {
    expect(fixture.debugElement.query(By.css('.caseFrom span')).nativeElement.innerText)
      .toEqual('a funny title');
  }));

  it('should be able to toggle', async(() => {
    spyOn(component, 'handleToggle');
    component.detailMain.onToggleCollapse();
    expect(component.handleToggle)
      .toHaveBeenCalled();
  }));
});
