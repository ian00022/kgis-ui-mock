import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

import { BreadcrumbService } from '../../../core/services/breadcrumb.service';

@Component({
  selector: 'esun-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {
  public breadcrumbs = [];
  constructor(private breadcrumbService: BreadcrumbService,
              private router: Router) {
  }

  ngOnInit() {
    this.breadcrumbService.history$.subscribe(() => {
      this.getBreadcrumbData();
    });
    this.getBreadcrumbData();
  }

  
  public handleBreadcrumbClick(index) {
    this.breadcrumbService.removeAfter(index);
    this.router.navigate([this.breadcrumbs[index].url]);
  }
  
  private getBreadcrumbData() {
    this.breadcrumbs = this.breadcrumbService.getHistory();
  }
}
