import { BreadcrumbService } from './../../../core/services/breadcrumb.service';
import { BreadcrumbComponent } from './breadcrumb.component';
import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { By } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';

describe('BreadCrumbComponent', () => {
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let component: BreadcrumbComponent;
  let fakeBreadCrumbservice;
  const router = jasmine.createSpyObj('FakeRouter', ['navigate']);

  beforeEach(async(() => {
    fakeBreadCrumbservice = new BreadcrumbServieStub();
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule
      ],
      providers: [
        { provide: BreadcrumbService, useValue:fakeBreadCrumbservice },
        { provide: Router, useValue: router },
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const breadcrumbComponent = fixture.debugElement.componentInstance;
    expect(breadcrumbComponent).toBeTruthy();
  }));

  it('should see the breadcrumb items', async(() => {
    const breadcrumbComponent = fixture.debugElement.componentInstance;
    expect(fixture.debugElement.query(By.css('.breadcrumb-item>a')).nativeElement.innerText).toEqual('a funny page');
  }));

  it('navigate should be called after item is clicked', async(() => {
    fixture.debugElement.componentInstance.handleBreadcrumbClick(0);
    expect(router.navigate).toHaveBeenCalled();
  }));

});

class BreadcrumbServieStub {
    public history$: Observable<any>;
    public historySubject: Subject<any>;
    constructor() {
      this.historySubject = new Subject<boolean>();
        this.history$ = (this.historySubject).asObservable();
        this.historySubject.next(this.getHistory());
    }

    public getHistory() {
        return [{
            url: 'funny.url',
            name: 'a funny page'
        },
        {
            url: 'funny.url2',
            name: 'a funny page2'
        }];
    }

    public removeAfter() {

    }
}