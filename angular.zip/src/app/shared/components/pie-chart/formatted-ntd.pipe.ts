import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formattedNtd'
})
export class FormattedNtdPipe implements PipeTransform {

  transform(value: any, args?: any) {
    return 'NTD ' + value;
  }

}
