import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PieChartComponent } from './pie-chart.component';
import { FormattedNtdPipe } from './formatted-ntd.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PieChartComponent,
    FormattedNtdPipe],
  exports: [
    PieChartComponent,
    FormattedNtdPipe
  ]
})
export class PieChartModule { }
