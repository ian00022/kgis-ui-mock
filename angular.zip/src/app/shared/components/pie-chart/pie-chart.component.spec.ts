import { PieChartComponent } from './pie-chart.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
  <pie-chart 
    (onSliceClick)="onSliceClick($event)" 
    [data]="data">
  </pie-chart>
  `,
  providers: [LoggerService]
  })
  export class PieChartTestComponent {

    @ViewChild('pie') pie: PieChartComponent;

    public data = [
      {
        label: 'label1',
        value: 10
      },
      {
        label: 'label2',
        value: 20
      },
      {
        label: 'label3',
        value: 25
      },
    ];

    public onSliceClick(){}

    constructor() { }
}

describe('IbmSwitchComponent', () => {
  let fixture: ComponentFixture<PieChartTestComponent>;
  let component: PieChartTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PieChartTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieChartTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  // it('should see the title', async(() => {
  //   expect(fixture.debugElement.query(By.css('.ut-content')).nativeElement.innerText)
  //     .toContain(component.title);
  // }));

  // it('should be able to switch', async(() => {
  //   spyOn(component, 'switchChange');
  //   component.switch.switchChange();
  //   expect(component.switchChange).toHaveBeenCalled();
  // }));
});
