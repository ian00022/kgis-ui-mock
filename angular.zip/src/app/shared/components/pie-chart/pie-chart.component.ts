import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { PercentPipe } from '@angular/common';
import * as d3 from 'd3';
import { LoggerService } from './../../logger.service';
import { PieSetting } from './pie-chart.model';

@Component({
  selector: 'pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css'],
  providers: [PercentPipe]
})
export class PieChartComponent implements OnInit, AfterViewInit {
  @ViewChild('containerPieChart') container: ElementRef;
  @Input() data: any;
  @Input() colors: Array<string>;
  @Input() width = 400;
  @Input() height = 400;
  /**
   * direction: horizon, vertical
   *
   * @memberof PieChartComponent
   */
  @Input() displayDirection = 'horizon';

  @Output() onSliceClick: EventEmitter<any> = new EventEmitter();

  host: d3.Selection;
  svg: d3.Selection;
  radius: number;
  htmlElement: HTMLElement;
  pieColors: any;
  arcHover: any;
  arcGenerator: any;
  selectedSlice: any;
  tooltip: any;

  slices: Array<any>;
  values: Array<any>;

  constructor(
    private elRef: ElementRef,
    private percent: PercentPipe,
    private logger: LoggerService
  ) { }

  ngOnInit() {
    this.setup();
  }

  ngAfterViewInit() {
    this.htmlElement = this.container.nativeElement;
    this.host = d3.select(this.htmlElement);
    this.buildSVG();
    this.buildPie();
  }

  mouseover = (datum, index) => {
    this.selectedSlice = JSON.parse(JSON.stringify(this.slices[index]));

    d3.select(d3.event.currentTarget).transition()
      .duration(200)
      .attr('d', this.arcHover)
      .style('cursor', 'pointer');

    // Tooltip
    this.tooltip.style.visibility = 'visible';
    this.tooltip.style.opacity = 0.9;
    this.tooltip.style.top = (d3.event.pageY) + 'px';
    this.tooltip.style.left = (d3.event.pageX) + 'px';
  }

  mouseout = () => {

    // this.selectedSlice = null;

    d3.select(d3.event.currentTarget).transition()
      .duration(100)
      .attr('d', this.arcGenerator)
      .style('cursor', 'default');

    // Tooltip
    this.tooltip.style.visibility = 'hidden';
    this.tooltip.style.opacity = 0;
  }

  click = (dataum) => {
    this.logger.debug('dataum: ', dataum);
    this.onSliceClick.emit(dataum);
  }

  get getLegendClass(): string {
    return this.displayDirection === 'horizon' ? 'col-4' : 'col-12';
  }

  get getPieClass(): string {
    return this.displayDirection === 'horizon' ? 'col' : 'col-12';
  }

  private setup(): void {
    this.radius = Math.min(this.width, this.height) / 2;
    this.tooltip = this.elRef.nativeElement.querySelector('.tooltip');
    this.pieColors = this.colors ? d3.scaleOrdinal().range(this.colors) : d3.scaleOrdinal().range(PieSetting.defaultColors);
    this.logger.debug('data', this.data);
    this.values = [];
    this.slices = [];
    this.data.forEach((data, index) => {
      this.slices.push({
        value: data.value,
        label: data.label,
        color: this.pieColors(index),
        // formattedText: data.formattedText
      });
      this.values.push(data.value);
    });
  }

  private buildSVG(): void {
    this.host.html('');
    this.svg = this.host.append('svg')
      .attr('viewBox', `0 0 ${this.width} ${this.height}`)
      .append('g')
      .attr('transform', `translate(${this.width / 2},${this.height / 2})`);
  }

  private buildPie(): void {
    const pie = d3.pie();
    const arcSelection = this.svg.selectAll('.arc')
      .data(pie(this.values))
      .enter()
      .append('g')
      .attr('class', 'arc');

    this.populatePie(arcSelection);
  }

  private populatePie(arcSelection: d3.Selection<d3.pie.Arc>): void {
    const innerRadius = this.radius - this.radius / 2;
    const outerRadius = this.radius - 20;
    const hoverRadius = this.radius - 5;
    this.arcGenerator = d3.arc()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius);

    this.arcHover = d3.arc()
      .innerRadius(innerRadius)
      .outerRadius(hoverRadius);

    arcSelection.append('path')
      .attr('d', this.arcGenerator)
      .on('mouseover', this.mouseover)
      .on('mouseout', this.mouseout)
      .on('click', this.click)
      .attr('fill', (datum, index) => this.pieColors(index));

    arcSelection.append('text')
      .attr('transform', (datum: any) => {
        datum.innerRadius = 0;
        datum.outerRadius = outerRadius;
        return 'translate(' + this.arcGenerator.centroid(datum) + ')';
      })
      .text((datum, index) => {
        return this.percent.transform( this.values[index] / this.total(), '0.1-1');
      })
      .style('text-anchor', 'middle');
  }

  private total(): number {
    return this.values.reduce((sum, value) => sum + value);
  }
}
