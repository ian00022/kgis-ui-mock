export interface PieChart {
  colors?: Array<any>;
  data: Array<PieData>;
  onClick(data: any);
}

export interface PieData {
  label: string;
  value: any;
}

export class PieSetting {
  public static defaultColors = [
    '#4ca8e0',
    '#2382bc',
    '#6ddefa',
    '#d8ecfa'
  ];
}
