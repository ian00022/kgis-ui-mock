import { AddressSelectComponent } from './address-select.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@Component({
  template: `
    <esun-address-select #address></esun-address-select>
  `
  })
  export class AddressSelectTestComponent {

    @ViewChild('address') address: AddressSelectComponent;

    constructor() { }
}

describe('AddressSelectComponent', () => {
  let fixture: ComponentFixture<AddressSelectTestComponent>;
  let component: AddressSelectTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AddressSelectTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressSelectTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should be able to get selected result', async(() => {
    component.address.country = '台北市';
    component.address.district = '信義區';
    component.address.address = '中山路二段45號';
    
    const addr = component.address.getAddress();
    expect(addr.country).toEqual('台北市');
  }));

  it('should be able to select an city', async(() => {
    let cityButton = fixture.debugElement.queryAll(By.css('.single-select-button'))[0].nativeElement;
    cityButton.click();
    fixture.detectChanges();
    let option = fixture.debugElement.queryAll(By.css('.single-select-option'))[0].nativeElement;
    option.click();
    fixture.detectChanges();
    
    let displayText = fixture.debugElement.queryAll(By.css('.ut-display-text'))[0].nativeElement.innerText;
    expect(displayText).toEqual('基隆市');
  }));
});
