// angular module
import { Component, OnInit, OnDestroy, ViewChild, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { BOLSelfCreateDto } from 'app/business-opportunity/business-opportunity.model';
import { SourceDescription, ProductHelper, ClientType } from 'app/core/models/comm-data';
// component
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { ControlBase, TextControl, SingleDropdownControl, TextareaControl } from '../dynamic-form/controls';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';
// service
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';
// helper
import FormatChecker from 'app/shared/functions/formatChecker';

/**
 * 新增自建名單
 */
@Component({
  selector: 'esun-create-bo-dialog',
  templateUrl: './create-bo-dialog.component.html',
  styleUrls: ['./create-bo-dialog.component.scss'],
  providers: []
})

export class CreateBoDialogComponent implements OnInit, OnDestroy {
  /**
   * 自建名單 dialog header
   *
   * @type {string}
   * @memberof CreateBoDialogComponent
   */
  @Input('header') header: string;

  /**
   * after create BOL
   *
   * @type {EventEmitter<any>}
   * @memberof CreateBoDialogComponent
   */
  @Output('afterSelfCreateBOL') afterSelfCreateBOL: EventEmitter<any> = new EventEmitter();

  /**
   * 自建名單預設帶入顧客姓名、統一編號
   *
   *
   * @memberof CreateBoDialogComponent
   */
  @Input('defaultValue')
  set defaultValue(value: BOLSelfCreateDto) {
    if (value) {
      this.createBoData = value;
      if (this.form.form) {
        this.clientType = FormatChecker.isTaiwanId(value.circiKey) ? ClientType.CUST : ClientType.COMP ;
        this.changeProductOptions();
        this.form.form.patchValue({
          customerName: this.createBoData.customerName,
          circiKey: this.createBoData.circiKey
        });
      }
    }
  }

  /**
   * 自建名單 input form
   *
   * @type {DynamicFormComponent}
   * @memberof CreateBoDialogComponent
   */
  @ViewChild('form') form: DynamicFormComponent;

  /**
   * 自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof CreateBoDialogComponent
   */
  @ViewChild('dialog') dialog: IbmDialogComponent;

  /**
   * 自建名單 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof CreateBoDialogComponent
   */
  public controls: ControlBase<any>[] = [];

  /**
   * 自建名單擇一必填欄位,
   * 介紹人姓名, 介紹人統一編號
   *
   * @memberof CreateBoDialogComponent
   */
  public requiredAnyKeys = ['introducerName', 'introducerId'];

  /**
   * unSubscribe all subscription when ngOnDestroy call
   *
   * @private
   * @type {Subject<any>}
   * @memberof CreateBoDialogComponent
   */
  private ngUnSubscribe: Subject<any> = new Subject();

  /**
   * 自建名單輸入參數
   *
   * @private
   * @type {BOLSelfCreateDto}
   * @memberof CreateBoDialogComponent
   */
  private createBoData: BOLSelfCreateDto;

  /**
   * 產品別選項
   *
   * @private
   * @type {any[]}
   * @memberof CreateBoDialogComponent
   */
  private prodOptions: any[] = [];

  /**
   * 來源說明選項
   *
   * @private
   * @type {any[]}
   * @memberof CreateBoDialogComponent
   */
  private sourceOptions: any[] = [];

  /**
   * 自建名單顧客類別,
   * 個人戶: 1
   * 公司戶: 2
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private clientType = ClientType.CUST;

  /**
   * 個人戶可選擇產品別列表
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private custProdOptions = ProductHelper.getOptionsOf([
      ProductHelper.CodeEnum.CREDIT,
      ProductHelper.CodeEnum.GUARANTEE,
      ProductHelper.CodeEnum.HOUSE,
      ProductHelper.CodeEnum.CARD,
      ProductHelper.CodeEnum.INSURENCE,
  ]);

  /**
   * 公司戶可選擇產品別列表
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private compProdOptions = ProductHelper.getOptionsOf([
    ProductHelper.CodeEnum.SB,
  ]);

  constructor(
    private boService: BusinessOppotunityService,
    private ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * check 自建名單 form valid
   *
   * @readonly
   * @memberof CreateBoDialogComponent
   */
  get isValid() {
    return this.form.form.valid;
  }

  /**
   * handle 自建名單 form submit,
   *
   * @param {*} value
   * @memberof CreateBoDialogComponent
   */
  public handleFormSubmit(value) {
    let data = _.assign({
      identityCardNumber: this.createBoData.circiKey,
      customerType: this.clientType,
    }, this.createBoData, value);

    this.boService.selfCreateBOL(data).subscribe(
      (resp) => {
        this.form.reset();
        this.dialog.close();
        this.afterSelfCreateBOL.emit();
      }
    );
  }

  /**
   * 打開自建名單 dialog
   *
   * @memberof CreateBoDialogComponent
   */
  public open() {
    this.ref.detectChanges();
    this.dialog.open();
  }

  /**
   * 確認自建名單
   *
   * @memberof CreateBoDialogComponent
   */
  public onConfirmClick() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }

  /**
   * 取消自建名單
   *
   * @memberof CreateBoDialogComponent
   */
  public onCancelClick() {
    this.form.reset();
    this.dialog.close();
  }

  /**
   * 變更產品別選項
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private changeProductOptions() {
    this.prodOptions.splice(0, this.prodOptions.length);
    if (this.clientType === ClientType.CUST) {
      this.custProdOptions.forEach( el => this.prodOptions.push(el));
    } else {
      this.compProdOptions.forEach( el => this.prodOptions.push(el));
    }
  }

  /**
   * 取得下拉選單選項
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private getDropdownOptions() {
    // todo
    this.prodOptions = ProductHelper.getOptionsOf([
      ProductHelper.CodeEnum.CREDIT,
      ProductHelper.CodeEnum.GUARANTEE,
      ProductHelper.CodeEnum.HOUSE,
      ProductHelper.CodeEnum.SB,
      ProductHelper.CodeEnum.CARD,
      ProductHelper.CodeEnum.INSURENCE,
    ]);
    this.sourceOptions = [
      { value: '1', label: '主動進線' },
      { value: '2', label: '自來件(既有顧客)' },
      { value: '3', label: '自來件(非既有顧客)' },
      { value: '4', label: '聯行轉介' },
      { value: '5', label: '客服轉介' },
      { value: '6', label: '總行指派' },
      { value: '7', label: '推薦產品' },
      { value: '8', label: '顧客介紹' },
      { value: '9', label: '代書或房仲轉介' },
      { value: '10', label: 'ISMS雙向簡訊' },
      { value: '11', label: 'EDM行銷' },
      { value: '12', label: '其他' }
    ];
  }

  /**
   * init form controls
   *
   * @private
   * @memberof CreateBoDialogComponent
   */
  private prepareControls() {
    this.getDropdownOptions();
    this.controls = [

      // 顧客姓名
      new TextControl({
        key: 'customerName',
        label: '顧客姓名',
        required: true,
        disabled: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 李大名'
      }),

      // 統一編號
      new TextControl({
        key: 'circiKey',
        label: '身分證字號/統一編號',
        required: true,
        disabled: true,
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789'
      }),

      // 產品別
      new SingleDropdownControl({
        key: 'productType',
        label: '產品別',
        required: true,
        columnClasses: ['6'],
        options: this.prodOptions,
        placeholder: '請選擇...'
      }),

      // 來源說明
      new SingleDropdownControl({
        key: 'caseSourceDesc',
        label: '來源說明',
        required: true,
        columnClasses: ['6'],
        options: this.sourceOptions,
        value: '6',
        placeholder: '請選擇...'
      }),

      // 介紹人姓名
      new TextControl({
        key: 'introducerName',
        label: '介紹人姓名',
        columnClasses: ['6'],
        placeholder: 'e.g. 李大名',
        condition: function(form: FormGroup) {
          return form.controls['caseSourceDesc'].value === SourceDescription.CUSTINTRO;
        },
      }),

      // 介紹人統一編號
      new TextControl({
        key: 'introducerId',
        label: '介紹人統一編號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: function(form: FormGroup) {
          return form.controls['caseSourceDesc'].value === SourceDescription.CUSTINTRO;
        },
      }),

      // 備註
      new TextareaControl({
        key: 'remark',
        label: '備註',
        columnClasses: ['12'],
        required: true,
        isWordCount: true,
        placeholder: '請輸入...',
        condition: function(form: FormGroup) {
          return form.controls['caseSourceDesc'].value === SourceDescription.OTHER;
        }
      })
    ];
  }

}
