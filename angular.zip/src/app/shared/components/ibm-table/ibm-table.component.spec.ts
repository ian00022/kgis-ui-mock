import { ApiService } from './../../../core/services/api.service';
import { IbmTableModule } from './ibm-table.module';
import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IbmTableComponent } from './ibm-table.component';
import { CalculateType } from './ibm-table.model';


@Component({
  template: `
    <ibm-table
      #table
      [dataSource]="tableData"
      [expandableTable]="true"
      [rowClassName]="rowClassNameFunction"
      [pagination]="true">
      <ibm-table-column [sortable]="true" header="Name & age" name="name">
        <ng-template #headerSlot>
          我是header template 1+1 = {{ 1 + 1 }} <i class="fa fa-search"></i>
        </ng-template>
        <ng-template #slot let-scope="scope" let-index="index">
          [{{ index }}] {{ scope.name }} is {{ scope.age }}
        </ng-template>
      </ibm-table-column>
      <ibm-table-column header="Age" [sortable]="true" name="age">
      </ibm-table-column>
      <ibm-table-column header="Age2" [sortable]="true" name="age2">
      </ibm-table-column>
      <ibm-table-column header="link">
        <ng-template>
            <esun-link-column link="notImportant" [label]="'notImportant'">
            </esun-link-column>
        </ng-template>
      </ibm-table-column>
      <!-- expand -->
      <ng-template #expand let-scope="scope">
        --- {{ scope.name }} ---
      </ng-template>
    </ibm-table>
  `
  })
  export class TableTestComponent {
    public tableData = [];
    public rowClassNameFunction;

    @ViewChild('table') table: IbmTableComponent;

    constructor() {
      for (let i = 0; i < 120; i++) {
        let k = i%20;
        let j = i%10;
        this.tableData.push(
          {name: 'albert' + k, age: 64 - i, age2: 12, sex: 'M', subRow: true},
        );
      }

      this.rowClassNameFunction = (row, index) => {
        if (index === 3) {
          return 'red-row';
        }
        if (row.name === 'albert5') {
          return 'blue-row';
        }
      };
    }

    ngOnInit() {
    }

    ngAfterViewInit() {
    }
}

describe('IbmTableComponent', () => {
  let fixture: ComponentFixture<TableTestComponent>;
  let component: TableTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TableTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
        BrowserAnimationsModule,
        IbmTableModule
      ],
      providers: [
        ApiService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const c = fixture.debugElement.componentInstance;
    expect(c).toBeTruthy();
  }));

  it('Test table row count method', async(() => {
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.SUM});
    fixture.detectChanges();
    expect(ageCount).toEqual('1,975');
  }));

  it('Test table row count method with less than a page', async(() => {
    fixture.debugElement.componentInstance.tableData = fixture.debugElement.componentInstance.tableData.slice(0, 10);
    fixture.detectChanges();
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.SUM});
    fixture.detectChanges();
    expect(ageCount).toEqual('595');
  }));

  it('Test table row count method with none type', async(() => {
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.NONE});
    fixture.detectChanges();
    expect(ageCount).toEqual('');
  }));

  it('Test table row count method get the result from map', async(() => {
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.RATE});
    fixture.detectChanges();

    const ageCount2 = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.RATE});
    fixture.detectChanges();
    expect(ageCount2).toEqual('3,950%');
  }));

  it('Test table row count method with empty row', async(() => {
    fixture.debugElement.componentInstance.tableData = [];
    fixture.detectChanges();
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'age', calculateType: CalculateType.SUM});
    expect(ageCount).toEqual('');
  }));

  it('Test table row count method with unknown key', async(() => {
    fixture.detectChanges();
    const ageCount = fixture.debugElement.componentInstance.table.getCount({name: 'someFunnyName', calculateType: CalculateType.SUM});
    expect(ageCount).toEqual(null);
  }));

  it('Try to sort with col that cannot be sort', async(() => {
    const rs = fixture.debugElement.componentInstance.table.handleSort({name: 'notImportant', sortable: false});
    expect(rs).toEqual(undefined);
  }));

  it('Test getcurrentPageRows method', async(() => {
    const source = fixture.debugElement.componentInstance.table.dataSource;
    expect(source[0].age).toEqual(64);
  }));

  it('Test get datasource method', async(() => {
    const rows = fixture.debugElement.componentInstance.table.getcurrentPageRows();
    expect(rows[0].age).toEqual(64);
  }));

  it('Should row class is empty string if row class name is not set', async(() => {
    const rows = fixture.debugElement.componentInstance.rowClassNameFunction = null;
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tr'))[0].nativeElement.classList.length).toEqual(0);
  }));

  it('should sort by age after header is clicked', async(() => {
    let ageCol = fixture.debugElement.queryAll(By.css('.sortable-col'))[1].nativeElement;
    ageCol.click();
    ageCol.click();
    ageCol.click();
    ageCol.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tr td'))[1].nativeElement.innerText).toEqual('-55');
  }));

  it('test sort by more than one col', async(() => {
    let col1 = fixture.debugElement.queryAll(By.css('.sortable-col'))[0].nativeElement;
    let col2 = fixture.debugElement.queryAll(By.css('.sortable-col'))[1].nativeElement;
    col1.click();
    col2.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tr td'))[1].nativeElement.innerText).toEqual('-36');
  }));

  it('test sortint priority reset', async(() => {
    let col1 = fixture.debugElement.queryAll(By.css('.sortable-col'))[0].nativeElement;
    let col2 = fixture.debugElement.queryAll(By.css('.sortable-col'))[1].nativeElement;
    col1.click();
    fixture.detectChanges();
    col2.click();
    fixture.detectChanges();
    col1.click();
    fixture.detectChanges();
    col1.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table thead th'))[1].nativeElement.innerText).toEqual('Age (1)');
  }));

  it('test next page button', async(() => {
    let nextBtn = fixture.debugElement.queryAll(By.css('.next-btn'))[0].nativeElement;
    nextBtn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tr td'))[1].nativeElement.innerText).toEqual('14');
  }));

  it('test prev page button', async(() => {
    let nextBtn = fixture.debugElement.queryAll(By.css('.next-btn'))[0].nativeElement;
    nextBtn.click();
    fixture.detectChanges();
    let prevBtn = fixture.debugElement.queryAll(By.css('.prev-btn'))[0].nativeElement;
    prevBtn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tr td'))[1].nativeElement.innerText).toEqual('64');
  }));

  it('test row expand', async(() => {
    let expandBtn = fixture.debugElement.queryAll(By.css('.btn-expand'))[0].nativeElement;
    expandBtn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tbody tr'))[1].nativeElement.innerText).toEqual('--- albert0 ---');
  }));

  it('test row expand and close again', async(() => {
    let expandBtn = fixture.debugElement.queryAll(By.css('.btn-expand'))[0].nativeElement;
    expandBtn.click();
    fixture.detectChanges();
    expandBtn.click();
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('table tbody tr'))[1].nativeElement.innerText).not.toEqual('--- albert0 ---');
  }));
});
