import { Component, OnInit, ContentChild, TemplateRef, Input } from '@angular/core';
import { IIbmTableColumn, SortType, CalculateType } from '../ibm-table.model';

@Component({
  selector: 'ibm-table-column',
  templateUrl: './ibm-table-column.component.html',
  styleUrls: ['./ibm-table-column.component.css']
})
export class IbmTableColumnComponent implements OnInit, IIbmTableColumn {
  @Input() name;
  @Input() header = '';
  @Input() sortable = false;
  @Input() footer = '';
  @Input() calculateType = CalculateType.NONE;
  @Input() thClass;
  @Input() tdClass;
  public sort = SortType.NONE;
  public sortPriority: number;

  @ContentChild('headerSlot') headerSlot: TemplateRef<any>;
  @ContentChild('slot') slot: TemplateRef<any>;
  
  constructor() { }

  public changeSort(priority: number): SortType {
    switch(this.sort) {
      case SortType.NONE:
        this.sort = SortType.ASC;
        break;
      case SortType.ASC:
        this.sort = SortType.DESC;
        break;
      case SortType.DESC:
        this.sort = SortType.NONE;
        break;
      default:
        break;
    }

    this.sortPriority = priority;

    return this.sort;
  }

  ngOnInit() {
  }

}
