import { MdePopoverModule } from '@material-extended/mde';
import { FormsModule } from '@angular/forms';
import { IbmTableComponent } from './ibm-table.component';
import { NgModule } from '@angular/core';
import { CommonModule, PercentPipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { IbmTableColumnComponent } from './ibm-table-column/ibm-table-column.component';
import { StatusColumnComponent } from './status-column/status-column.component';
import { LinkColumnComponent } from './link-column/link-column.component';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MdePopoverModule
  ],
  declarations: [
    IbmTableComponent,
    IbmTableColumnComponent,
    StatusColumnComponent,
    LinkColumnComponent
  ],
  exports: [
    IbmTableComponent,
    IbmTableColumnComponent,
    StatusColumnComponent,
    LinkColumnComponent
  ],
  providers: [ PercentPipe, DecimalPipe, CurrencyPipe ]
})
export class IbmTableModule { }
