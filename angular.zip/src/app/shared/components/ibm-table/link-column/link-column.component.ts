import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'esun-link-column',
  templateUrl: './link-column.component.html',
  styleUrls: ['./link-column.component.scss']
})
export class LinkColumnComponent implements OnInit {

  @Input('link') link: any[] = ['/'];
  @Input('label') label: string = '';
  @Input('target') target: string = '_self';
  @Input('queryParams') queryParams: any = {};
  constructor() { }

  ngOnInit() {
  }

}
