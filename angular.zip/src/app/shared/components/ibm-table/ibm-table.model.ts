export interface IIbmTableColumn {
  sortable: boolean;
  header: string;
  name: string;
  thClass: string;
  tdClass: string;
  sort: SortType;
  sortPriority: number;
  changeSort(priority: number): SortType;
}

export enum SortType {
  ASC = 'asc',
  DESC = 'desc',
  NONE = 'none'
}

export interface StatusColumn {
  light: StatusLight; // 逾期燈號
  frontTooltip?: StatusTooltip; // 逾期燈號 tooltip
  text: string; // 名單狀態
  detailTooltip?: StatusTooltip; // 狀態細項 tooltip
  detailTooltipType?: StatusTooltip; // 細項類別 tooltip
  process: StatusProcess; // 流程燈號
  backTooltip?: StatusTooltip; // 流程燈號 tooltip
  otherData?: any;
}

export interface StatusTooltip {
  show: boolean;
  text: string;
}

export enum StatusLight {
  // icon class
  GRAY = 'light-gary',
  RED = 'light-red',
  NONE = ''
}

export enum StatusProcess {
  // icon class
  WAIT = 'fa-clock-o',
  REJECT = 'fa-ban',
  DUPLICATE = 'fa-clone',
  NCSPROCESSING = 'fa-cloud-upload',
  NONE = ''
}

export enum CalculateType {
  SUM = 'sum',
  RATE = 'rate',
  CURRENCY = 'currency',
  NONE = 'none'
}
