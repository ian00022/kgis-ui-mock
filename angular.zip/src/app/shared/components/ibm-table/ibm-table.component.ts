import { Component, OnInit, QueryList, AfterViewInit, ContentChildren, Input, ContentChild, TemplateRef } from '@angular/core';
import { PercentPipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { IbmTableColumnComponent } from './ibm-table-column/ibm-table-column.component';
import { IIbmTableColumn, SortType, CalculateType } from './ibm-table.model';
import { ApiService } from '../../../core/services/api.service';
import * as _ from 'lodash';

@Component({
  selector: 'ibm-table',
  templateUrl: './ibm-table.component.html',
  styleUrls: ['./ibm-table.component.css']
})
export class IbmTableComponent implements OnInit, AfterViewInit {

  @Input() pagination: boolean = false;
  @Input() expandableTable: boolean = false;
  @Input() expandActionHeader: string = '展開';
  @Input() shadow: boolean = false;
  @Input() enableSummary: boolean = false;
  @Input() serverPaging: boolean = false;
  @Input() url: string;
  @Input() searchParams: any;
  @Input() rowClassName: (row: any, index: number) => string;

  @ContentChild('expand') expand: TemplateRef<any>;

  public pageSizeOptions = [30, 50, 80, 150];
  public pageSize: number = 50;
  public currentPage = 1;
  public isChanged = false; // 點搜尋前應是空白

  @ContentChildren(IbmTableColumnComponent) columns: QueryList<IbmTableColumnComponent>;

  private totalCountFormServer = 0;
  private tableDataSource: any[] = [];
  private totalMap: any = {};
  @Input()
  set dataSource(datasource: any[]) {
    if (datasource && datasource.length > 0) {
      this.isChanged = true;
    }
    if (!this.serverPaging) {
      this.tableDataSource = datasource;
    }
    this.totalMap = {};
  }

  constructor(
    private percent: PercentPipe,
    private number: DecimalPipe,
    private currency: CurrencyPipe,
    private api: ApiService
  ) { }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

  get showSummary(): boolean {
    return this.displayData.length !== 0 && this.enableSummary;
  }

  get dataSource(): any[] {
    return this.tableDataSource;
  }

  get disablePrev(): boolean {
    return this.currentPage === 1;
  }

  get disableNext(): boolean {
    return this.currentPage === this.totalPage;
  }

  get totalPage(): number {
    if (this.serverPaging){
      return Math.ceil(this.totalCountFormServer / this.pageSize) || 1;
    }
    return Math.ceil(this.tableDataSource.length / this.pageSize) || 1;
  }

  get pageFilter(): any {
    return {
      skip: (this.currentPage - 1) * this.pageSize,
      take: this.pageSize
    };
  }

  /**
   * return cols which sort is not none, and order by sort priority
   */
  get sortCols(): IIbmTableColumn[] {
    let sortCols = this.columns.filter((col: IIbmTableColumn) => {
      return col.sort !== SortType.NONE;
    });
    sortCols = _.orderBy(sortCols, ['sortPriority'], ['asc']);
    return sortCols;
  }

  /**
   * return names of colums which has sort
   */
  get sortColNames(): string[] {
    return this.sortCols.map( (col: IIbmTableColumn) => {
      return col.name;
    });
  }

  /**
   * return sort types of colums which has sort
   */
  get sortTypes(): string[] {
    return this.sortCols.map( (col: IIbmTableColumn) => {
      return col.sort;
    });
  }

  /**
   * get the sorted and paginated table data
   * if use serverPaging,
   * the table data from backend will be sorted and paginated
   */
  get displayData(): any[] {
    if (this.serverPaging) {
      return this.tableDataSource;
    }
    let current = this.currentPage - 1;
    let displayData = _.orderBy(this.tableDataSource, this.sortColNames, this.sortTypes);

    return displayData.slice(current * this.pageSize, (current + 1) * this.pageSize);
  }

  public clearData() {
    this.tableDataSource = [];
    this.isChanged = false;
  }

  /**
   * return className for the given row
   *
   * @param {*} row
   * @param {number} rowIndex
   * @returns {string}
   */
  public makeRowClass(row: any, rowIndex: number): string {
    const className: string = this.rowClassName ? this.rowClassName(row, rowIndex) : '';
    return className;
  }

  public getCellValue(row, name) {
    return _.result(row, name, '');
  }

  public isTemplate(val): boolean {
    return typeof val === 'object';
  }

  public prevPage() {
    this.currentPage--;
    if (this.serverPaging && !this.disablePrev) {
      this.getData();
    }
  }

  public nextPage() {
    this.currentPage++;
    if (this.serverPaging && !this.disableNext ) {
      this.getData();
    }
  }

  public sortIconClass(col: IIbmTableColumn) {
    switch(col.sort) {
      case SortType.NONE:
        return 'fa-sort';
      case SortType.ASC:
        return 'fa-sort-up';
      case SortType.DESC:
        return 'fa-sort-down';
    }
  }

  public handleSort(col: IIbmTableColumn) {
    if (!col.sortable) {
      return;
    }

    let sortPriority = this.sortCols.length;

    // add sort priority if it's a new sort condiction
    if (col.sort === SortType.NONE) {
      sortPriority++;
    }else {
      sortPriority = col.sortPriority;
    }

    const newSortType = col.changeSort(sortPriority);

    // update sort priority
    if (newSortType === SortType.NONE) {
      this.columns.forEach((column: IIbmTableColumn) => {
        if (column.sort !== SortType.NONE && column.sortPriority > sortPriority) {
          column.sortPriority--;
        }
      });
    }
  }

  public expandRow(row) {
    if(!row.expand) {
      row.expand = true;
    }else {
      row.expand = !row.expand;
    }
  }

  public getCount(col: any): any {
    let colName = col.name;
    let key = colName + '-' + this.currentPage + '-' + this.pageSize;
    if (this.tableDataSource.length === 0 ) {
      return '';
    } else if (typeof this.totalMap[key] !== 'undefined') {
      return this.totalMap[key];
    }
    const start = (this.currentPage - 1) * this.pageSize;
    const end = this.currentPage * this.pageSize > this.tableDataSource.length ?
                  this.tableDataSource.length : this.currentPage * this.pageSize;

    let result = 0;
    for (let i = start; i < end; i++ ) {
      result = result + +this.tableDataSource[i][colName];
    }
    let formatResult = '';

    switch (col.calculateType) {
      case CalculateType.RATE:
        const rage = end - start;
        result = result / rage;
        formatResult = this.percent.transform(result);
        break;
      case CalculateType.SUM:
        formatResult = this.number.transform(result);
        break;
      case CalculateType.CURRENCY:
        formatResult = this.currency.transform(result, '' ,'symbol', '1.0-0');
      case CalculateType.NONE:
      default:
        break;
    }
    this.totalMap[key] = formatResult;
    return formatResult;
  }

  public getcurrentPageRows(): any[] {
    return this.displayData;
  }

  public getData() {
    let params = _.assign(_.cloneDeep(this.searchParams),{
      pf: this.pageFilter
    });
    this.api.post(this.url, params).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.tableDataSource = resp.value;
          // todo check backend property
          this.totalCountFormServer = 500;
        }
      }
    );
  }

  public onPageSizeChange(newPagesize) {
    if (this.serverPaging) {
      let skipData = (this.currentPage - 1) * this.pageSize;
      this.currentPage = Math.ceil(skipData / newPagesize) || 1;
      this.pageSize = newPagesize;
      this.getData();
    } else {
      this.pageSize = newPagesize;
    }
  }
}
