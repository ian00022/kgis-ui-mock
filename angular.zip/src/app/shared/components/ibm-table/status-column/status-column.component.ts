import { Component, OnInit, Input } from '@angular/core';
import { StatusColumn, StatusProcess, StatusLight } from '../ibm-table.model';
import * as _ from 'lodash';

@Component({
  selector: 'status-column',
  templateUrl: './status-column.component.html',
  styleUrls: ['./status-column.component.css']
})
export class StatusColumnComponent implements OnInit {

  /**
   * column data
   *
   * @type {StatusColumn}
   * @memberof StatusColumnComponent
   */
  @Input() data: StatusColumn;

  @Input() noBackToolTip: boolean = false;

  /**
   * enum instance for template
   *
   * @memberof StatusColumnComponent
   */
  public StatusProcess = StatusProcess;

  constructor() { }

  ngOnInit() {
  }

  get displayText(): string {
    if (this.data.text) {
      return this.data.text.replace('(送件處理中)', '');
    }
    return '';
  }

  get backIconColorClass(): string {
    switch (this.data.process) {
      case StatusProcess.WAIT:
        return 'iconyellow';
      case StatusProcess.REJECT:
        return 'markRed';
      case StatusProcess.DUPLICATE:
      case StatusProcess.NONE:
      default:
        return '';
    }
  }
}
