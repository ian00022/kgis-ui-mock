import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'esun-display-modal-change',
  templateUrl: './display-modal-change.component.html',
  styleUrls: ['./display-modal-change.component.scss']
})
export class DisplayModalChangeComponent implements OnInit {

  @Input() displayModelChange;
  @Input() popover;

  constructor() { }

  ngOnInit() {
  }

}
