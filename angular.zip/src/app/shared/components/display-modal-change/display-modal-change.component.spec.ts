import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayModalChangeComponent } from './display-modal-change.component';

describe('DisplayModalChangeComponent', () => {
  let component: DisplayModalChangeComponent;
  let fixture: ComponentFixture<DisplayModalChangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayModalChangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayModalChangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
