import { isNullOrUndefined } from 'util';
import { Component, OnInit, ViewChild, OnDestroy, Input } from '@angular/core';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { NzNotificationService } from 'ng-zorro-antd';
import { ISelectOptionModel, ReferralProd } from './../../../core/models/comm-data';
import { IbmDialogComponent } from './../ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { LoggerService } from '../../logger.service';
import { SelectOptionsService } from '../../services/select-options.service';
import { ControlBase, TextControl, TextareaControl, SingleDropdownControl, MultiSelectControl } from './../dynamic-form/controls';
import { ApiService, ReferralService } from 'app/core/services';

@Component({
  selector: 'esun-create-referral-dialog',
  templateUrl: './create-referral-dialog.component.html',
  styleUrls: ['./create-referral-dialog.component.scss']
})

export class CreateReferralDialogComponent implements OnInit, OnDestroy {

  @Input('edit')
  set edit(value: any) {
    if (value) {
      this.header = '編輯商機轉介';
    } else {
      this.header = '新增商機轉介';
    }
    this.isEditMode = value;
  }

  @Input('defalutValue')
  set defalutValue(value: any) {
    if (value) {
      this.defaultReferralData = value;
      if (this.form.form) {
        this.setDefaultValue();
      }
    }
  }

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;
  public controls: ControlBase<any>[] = [];
  public header = '新增商機轉介';

  public referralProdOptions: ISelectOptionModel[] = [];
  public bankBranchesOptions: ISelectOptionModel[] = [];
  public employeeOptions: ISelectOptionModel[] = [];
  public currencyTypeOptions: ISelectOptionModel[] = [];

  private isEditMode: boolean;
  private ngUnSubscribe: Subject<any> = new Subject();
  private defaultReferralData: any = {};
  private referralModel = {
    'identityCardNo': '',
    'customerName': '',
    'contactPhone': '',
    'referralUnit': '',
    'referralEmpId': '',
    'productCode': '',
    'cuerrency': [],
    'acceptedReferralUnit': '',
    'acceptedReferralEmpId': '',
    'productRemark': '',
    'otherDescription': ''
  };
  private getDefaultRefferal = false;

  constructor(
    private logger: LoggerService,
    private options: SelectOptionsService,
    private referral: ReferralService,
    private api: ApiService,
    private notification: NzNotificationService
  ) {
    const option = this.options.getOptions([
      'referralProd',
      'bankBranches',
      'employee',
      'currencyType'
    ]);

    this.referralProdOptions = option['referralProd'];
    this.bankBranchesOptions = option['bankBranches'];
    this.employeeOptions = option['employee'];
    this.currencyTypeOptions = option['currencyType'];
  }

  ngOnInit() {
    this.prepareControls();
  }


  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  public validators: ValidatorFn = (form: FormGroup): { [key: string]: any } => {
    let unitIndex = _.findIndex(this.controls, ['key', 'acceptedReferralUnit']);
    let empIndex = _.findIndex(this.controls, ['key', 'acceptedReferralEmpId']);
    let descIndex = _.findIndex(this.controls, ['key', 'otherDescription']);
    if (_.parseInt(form.controls['productCode'].value) <= 6) {
      if (!form.controls['acceptedReferralUnit'].value
      || !form.controls['acceptedReferralEmpId'].value) {
        return { requiredReferralUnitOrEmpId: true };
      }
    }
    if (this.isMarsProduct(form.controls['productCode'].value )) {
      // 顯示 required 紅點
      this.controls[unitIndex].required = true;
      this.controls[empIndex].required = true;
      // acceptedReferralUnit, acceptedReferralEmpId 為必填
      if (!form.controls['acceptedReferralUnit'].value || !form.controls['acceptedReferralEmpId'].value) {
        return { requiredReferral: true};
      }
    } else {
      // 關閉 required 紅點
      this.controls[unitIndex].required = false;
      this.controls[empIndex].required = false;
    }

    if (form.controls['productCode'].value === ReferralProd.OTHER) {
      this.controls[descIndex].required = true;
      if (!form.controls['otherDescription'].value) {
        return {requiredOtherDescription: true};
      }
    } else {
      this.controls[descIndex].required = false;
    }
  }

  get isValid(): boolean {
    return this.form.form.valid;
  }

  public open() {
    this.dialog.open();
  }

  public handleSubmit(value) {
    // handle undefined value
    let data = _.cloneDeep(value);
    Object.keys(value).forEach( (el) => {
      if (isNullOrUndefined(data[el])) {
        data[el] = '';
      }
    });

    if (this.defaultReferralData['productCode'] === ReferralProd.FUND || data['productCode'] === ReferralProd.FUND) {
      data['productRemark'] = data['creditNumber'];
    }

    const referralData = _.assign(_.cloneDeep(this.referralModel), _.cloneDeep(this.defaultReferralData), data);
    this.logger.debug('create referralData: ', referralData);
    this.referral.save(referralData).subscribe(
      (resp) => {
        if (resp.isOk) {
          if (!this.isEditMode) {
            this.showMessage(referralData);
          } else {
            this.dialog.close();
          }
        } else {
          // do nothing
        }
      }
    );
  }

  public cancel() {
    this.dialog.close();
  }
  public confirm() {
    this.form.submit();
  }

  public afterClose() {
    this.reset();
  }

  private showMessage(data) {
    if (this.isMarsProduct(data.productCode)) {
      let unit = this.form.form.controls['acceptedReferralUnit'].value;
      let unitName = _.find(this.bankBranchesOptions, {value: unit})['label'] || '';
      let emp = this.form.form.controls['acceptedReferralEmpId'].value;
      let empNAme = _.find(this.employeeOptions, {value: emp})['label'] || '';
      this.notification.success('', `系統已將此筆商機轉予${unitName}分行 ${empNAme} 後續處理。`);
    } else {
      this.notification.success('', '儲存轉介紀錄成功');
    }

    this.dialog.close();
  }

  private prepareControls() {
    this.controls = [
      new TextControl({
        key: 'identityCardNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12'],
        required: true,
        placeholder: 'e.g. A123456789'
      }),
      new TextControl({
        key: 'customerName',
        label: '戶名',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 王大明'
      }),
      new TextControl({
        key: 'contactPhone',
        label: '電話',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 09123456789'
      }),
      new SingleDropdownControl({
        key: 'referralEmpId',
        label: '轉介經辦',
        columnClasses: ['6'],
        disabled: true,
        placeholder: '請選擇...',
        options: this.employeeOptions
      }),
      new SingleDropdownControl({
        key: 'productCode',
        label: '轉介產品',
        columnClasses: ['6'],
        required: true,
        options: this.referralProdOptions,
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'productRemark',
        label: '保單流水編號',
        columnClasses: ['12'],
        placeholder: '請輸入保單流水編號',
        condition: (form: FormGroup) => {
          return form.controls['productCode'].value === ReferralProd.OTHERINSURENCE;
        }
      }),
      new TextControl({
        key: 'creditNumber',
        label: '轉介產品備註',
        columnClasses: ['12'],
        placeholder: '請輸入信託憑證編號',
        condition: (form: FormGroup) => {
          return form.controls['productCode'].value === ReferralProd.FUND;
        }
      }),
      new MultiSelectControl({
        key: 'cuerrency',
        label: '轉介產品備註',
        columnClasses: ['12'],
        required: true,
        options: this.currencyTypeOptions,
        placeholder: '請選擇幣別...',
        value: [],
        condition: (form: FormGroup) => {
          return form.controls['productCode'].value === ReferralProd.FORDEP;
        }
      }),
      new SingleDropdownControl({
        key: 'acceptedReferralUnit',
        label: '受理轉介單位',
        columnClasses: ['6'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.bankBranchesOptions,
        requireCondition: function(form: FormGroup) {
          return _.parseInt(form.controls['productCode'].value) <= 6;
        },
      }),
      new SingleDropdownControl({
        key: 'acceptedReferralEmpId',
        label: '受理轉介人員',
        columnClasses: ['6'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.employeeOptions,
        requireCondition: function(form: FormGroup) {
          return _.parseInt(form.controls['productCode'].value) <= 6;
        },
      }),
      new TextareaControl({
        key: 'otherDescription',
        label: '其他說明',
        isWordCount: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }

  private setDefaultValue() {
    this.logger.debug('defaultReferralData: ', this.defaultReferralData);
    this.logger.debug('edit: ', this.isEditMode);
    if (this.isEditMode) {
      for (const control of this.controls) {
        switch(control.key) {
          case 'productRemark':
          case 'creditNumber':
          case 'cuerrency':
          case 'otherDescription':
            this.form.form.controls[control.key].enable();
            break;
          default:
            this.form.form.controls[control.key].disable();
            break;
        }
        if (!this.getDefaultRefferal) {
          this.getDefaultRefferal = true;
          this.api.get('Referral', {UUID: this.defaultReferralData.UUID}).subscribe(
            (resp) => {
              this.defaultReferralData = {
                UUID: resp.value['UUID'],
                identityCardNo: resp.value['IdentityCardNo'],
                customerName: resp.value['CustomerName'],
                contactPhone: resp.value['ContactPhone'],
                referralEmpId: resp.value['ReferralEmpId'],
                productCode: resp.value['ProductCode'],
                acceptedReferralEmpId: resp.value['AcceptedReferralEmpId'],
                acceptedReferralUnit: resp.value['AcceptedReferralUnit'],
                productRemark: resp.value['ProductRemark'],
                FCProducts: resp.value['FCProducts'],
                otherDescription: resp.value['OtherDescription'],
              };
              this.patchFormValue();
            }
          );
        }
      }
    } else {
      if (this.defaultReferralData.identityCardNo) {
        this.form.form.controls['identityCardNo'].disable();
        this.form.form.controls['contactPhone'].disable();
        this.form.form.controls['customerName'].disable();
      }
      this.form.form.controls['referralEmpId'].disable();
      this.patchFormValue();
    }
  }

  private patchFormValue() {
    this.form.form.patchValue({
      identityCardNo: this.defaultReferralData.identityCardNo,
      customerName: this.defaultReferralData.customerName,
      contactPhone: this.defaultReferralData.contactPhone,
      referralEmpId: this.defaultReferralData.referralEmpId,
      productCode: this.defaultReferralData.productCode,
      productRemark: this.defaultReferralData.productRemark,
      creditNumber: this.defaultReferralData.productRemark,
      cuerrency: this.defaultReferralData.FCProducts,
      acceptedReferralUnit: this.defaultReferralData.acceptedReferralUnit,
      acceptedReferralEmpId: this.defaultReferralData.acceptedReferralEmpId,
      otherDescription: this.defaultReferralData.otherDescription,
    });
  }

  private isMarsProduct(productCode) {
    switch (productCode) {
      case ReferralProd.CREDIT:
      case ReferralProd.GUARANTEE:
      case ReferralProd.HOUSE:
      case ReferralProd.SB:
      case ReferralProd.CARD:
      case ReferralProd.INSURENCE:
        return true;
      default:
        return false;
    }
  }

  private reset() {
    this.form.reset();
    for (const control of this.controls) {
      this.form.form.get([control.key]).enable();
    }
    this.getDefaultRefferal = false;
  }
}
