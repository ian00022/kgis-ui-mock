import { Component, OnInit, ViewChild, Input, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { ControlBase, SingleDropdownControl, TextControl, DatepickerControl, RadioControl } from './../dynamic-form/controls';
import { ApiService, AuthService } from 'app/core/services/';
import { SourceDescription, ProductHelper } from '../../../core/models/comm-data';
import { TextareaControl } from 'app/shared/components/dynamic-form/controls';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-create-potential-dialog',
  templateUrl: './create-potential-dialog.component.html',
  styleUrls: ['./create-potential-dialog.component.scss']
})
export class CreatePotentialDialogComponent implements OnInit, OnDestroy {

  @Input('header') header: string;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;

  public requiredAnyKeys = ['introducerName', 'introducerId'];
  public controls: ControlBase<any>[] = [];

  private ngUnSubscribe: Subject<any> = new Subject();
  private prodOptions: any[] = [];
  private sourceOptions: any[] = [];
  private custProdOptions: any[] = [];
  private compProdOptions: any[] = [];

  constructor(
    private api: ApiService,
    private auth: AuthService
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isValid() {
    return this.form.form.valid;
  }

  public onSubmit(value) {
    if (value.customerType === '2') {
      // todo remove unused property
      value.customerName = value.compCustomerName;
      value.personCertNo = value.compPersonCertNo;
      value.contactPhone = value.compContactPhone;
      value.bDate = value.compBDate;
      value.contactAddress = value.compContactAddress;
      value.email = value.compEmail;
    }

    this.api.post('PotentialCustomer', _.assign(value, { loginUser: this.auth.getLoginUser() })).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.dialog.close();
        }
      }
    );
  }

  public open() {
    this.dialog.open();
  }

  confirm() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }
  cancel() {
    this.form.reset();
    this.dialog.close();
  }

  private getDropdownOptions() {
    // todo
    this.custProdOptions = ProductHelper.getOptionsOf([
      ProductHelper.CodeEnum.CREDIT,
      ProductHelper.CodeEnum.GUARANTEE,
      ProductHelper.CodeEnum.HOUSE,
      ProductHelper.CodeEnum.CARD,
      ProductHelper.CodeEnum.INSURENCE,
    ]);

    this.compProdOptions = ProductHelper.getOptionsOf([
      ProductHelper.CodeEnum.SB,
    ]);
    this.prodOptions = _.cloneDeep(this.custProdOptions);

    this.sourceOptions = [
      { value: '1', label: '主動進線' },
      { value: '2', label: '自來件(既有顧客)' },
      { value: '3', label: '自來件(非既有顧客)' },
      { value: '4', label: '聯行轉介' },
      { value: '5', label: '客服轉介' },
      { value: '6', label: '總行指派' },
      { value: '7', label: '推薦產品' },
      { value: '8', label: '顧客介紹' },
      { value: '9', label: '代書或房仲轉介' },
      { value: '10', label: 'ISMS雙向簡訊' },
      { value: '11', label: 'EDM行銷' },
      { value: '12', label: '其他' }
    ];
  }

  private prepareControls() {
    this.getDropdownOptions();
    this.controls = [

      new RadioControl({
        key: 'customerType',
        label: '潛在顧客類別',
        value: '1',
        columnClasses: ['12'],
        required: true,
        options: [
          {value: '1', label: '個人戶'},
          {value: '2', label: '公司戶'}
        ],
        condition: (form: FormGroup) => {
          if (form.controls['customerType'].value === '1' && this.prodOptions.length !== this.custProdOptions.length) {
            this.prodOptions.splice(0, this.prodOptions.length);
            this.custProdOptions.forEach( (el) => {
              this.prodOptions.push(el);
            });
            form.controls['productCategory'].setValue('');
          } else if (form.controls['customerType'].value === '2' && this.prodOptions.length !== this.compProdOptions.length) {
            this.prodOptions.splice(0, this.prodOptions.length);
            this.compProdOptions.forEach( (el) => {
              this.prodOptions.push(el);
            });
            form.controls['productCategory'].setValue('');
          }
          return true;
        }
      }),
      // 1
      // 姓名
      new TextControl({
        key: 'customerName',
        label: '顧客姓名',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 陳大明',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 身分證字號
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 聯繫用手機
      new TextControl({
        key: 'contactPhone',
        label: '聯繫用手機',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 09123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 生日
      new DatepickerControl({
        key: 'bDate',
        label: '生日',
        columnClasses: ['6'],
        singleDatePicker: true,
        placeholder: '請選擇日期...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 通訊地址
      new TextControl({
        key: 'contactAddress',
        label: '通訊地址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // E-mail
      new TextControl({
        key: 'email',
        label: 'E-mail',
        columnClasses: ['12'],
        placeholder: 'e.g. abc@abc.com',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),

      // 2
      // 公司名稱
      new TextControl({
        key: 'companyName',
        label: '公司名稱',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. XX有限公司',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司統編
      new TextControl({
        key: 'companyCertNo',
        label: '公司統編',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司住址
      new TextControl({
        key: 'companyAddress',
        label: '公司住址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 負責人姓名
      new TextControl({
        key: 'compCustomerName',
        label: '負責人姓名',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 陳大明',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 負責人統一編號
      new TextControl({
        key: 'compPersonCertNo',
        label: '負責人統一編號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 聯繫用手機
      new TextControl({
        key: 'compContactPhone',
        label: '聯繫用手機',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 09123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司成立日期
      new DatepickerControl({
        key: 'compBDate',
        label: '公司成立日期',
        columnClasses: ['6'],
        singleDatePicker: true,
        placeholder: '請選擇日期...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),

      new TextControl({
        key: 'compContactAddress',
        label: '通訊地址',
        columnClasses: ['12'],
        placeholder: '請輸入',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),

      // E-mail
      new TextControl({
        key: 'compEmail',
        label: 'E-mail',
        columnClasses: ['12'],
        placeholder: 'e.g. abc@abc.com',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),

      // 產品別
      new SingleDropdownControl({
        key: 'productCategory',
        label: '產品別',
        required: true,
        warningBeforeText: '下列選項用於自建名單',
        columnClasses: ['6'],
        placeholder: '請選擇',
        options: this.prodOptions
      }),

      // 來源說明
      new SingleDropdownControl({
        key: 'source',
        label: '來源說明',
        required: true,
        columnClasses: ['6'],
        placeholder: '請選擇',
        options: this.sourceOptions
      }),

      new TextControl({
        key: 'introducerName',
        label: '介紹人姓名',
        columnClasses: ['6'],
        placeholder: 'e.g. 李大名',
        condition: function(form: FormGroup) {
          return form.controls['source'].value === SourceDescription.CUSTINTRO;
        },
      }),

      new TextControl({
        key: 'introducerId',
        label: '介紹人統一編號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: function(form: FormGroup) {
          return form.controls['source'].value === SourceDescription.CUSTINTRO;
        },
      }),

      new TextareaControl({
        key: 'remark',
        label: '備註',
        columnClasses: ['12'],
        isWordCount: true,
        placeholder: '請輸入...',
        condition: function(form: FormGroup) {
          return form.controls['source'].value === SourceDescription.OTHER;
        },
      })
    ];
  }
}
