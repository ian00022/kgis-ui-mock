import { IbmDialogComponent } from './../ibm-dialog/ibm-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'esun-status-info-dialog',
  templateUrl: './status-info-dialog.component.html',
  styleUrls: ['./status-info-dialog.component.scss']
})
export class StatusInfoDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  public description: any;
  constructor() { }

  ngOnInit() {
    this.initStatusDescription();
  }

  public open() {
    this.dialog.open();
  }

  public close() {
    this.dialog.close();
  }

  private initStatusDescription() {
    this.description =  {
      red: '紅色燈號，當此燈亮起閃爍時代表該名單即將逾期，原因包含如下：(1)未分派(限主管) (2)未執行 (3)追蹤逾期 (4)到期通知',
      gray: '灰色燈號，該名單尚未逾期',
      success: '當顯示此標示時，即代表該名單待主管放行',
      reject: '當顯示此標示時，即代表該名單遭主管退回',
      duplicate: '當顯示此標示時，即代表該名單為重複商機',
      handling: '當顯示此標示時，即代表該名單為進件處理中',
    };
  }
}
