import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsbCommonTreeSelectComponent } from './esb-common-tree-select.component';

describe('EsbCommonTreeSelectComponent', () => {
  let component: EsbCommonTreeSelectComponent;
  let fixture: ComponentFixture<EsbCommonTreeSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsbCommonTreeSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsbCommonTreeSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
