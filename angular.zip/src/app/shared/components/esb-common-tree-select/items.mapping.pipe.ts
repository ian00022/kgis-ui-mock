import { TreeviewItem } from 'ngx-treeview';
import { Pipe, PipeTransform } from '@angular/core';
import { isNil, result } from 'lodash';

@Pipe({
    name: 'treeItemsMapping'
})
export class TreeItemsPipe implements PipeTransform {
    transform(objects: any[]): TreeviewItem[] {
        if (isNil(objects)) {
            return undefined;
        }
        return mapTree(objects);
    }
}

function mapTree(originalTree) {
    return originalTree.map(({ Children, ...data }) => ({
        // data,
        text: result(data, 'Data.Description', ''),
        children: mapTree(Children)
    }));
}