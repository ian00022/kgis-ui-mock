import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsbCommonTreeSelectComponent } from './esb-common-tree-select.component';
import { TreeviewModule } from 'ngx-treeview/src/treeview.module';
import { TreeItemsPipe } from './items.mapping.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TreeviewModule.forRoot(),
  ],
  declarations: [
    TreeItemsPipe,
    EsbCommonTreeSelectComponent
  ],
  exports: [
    TreeItemsPipe,
    EsbCommonTreeSelectComponent
  ]
})
export class EsbCommonTreeSelectModule { }
