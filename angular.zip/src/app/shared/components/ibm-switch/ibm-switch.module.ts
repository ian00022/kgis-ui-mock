import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IbmSwitchComponent } from './ibm-switch.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [IbmSwitchComponent],
  exports: [IbmSwitchComponent]
})
export class IbmSwitchModule { }
