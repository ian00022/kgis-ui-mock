import { IbmSwitchComponent } from './ibm-switch.component';
import { IbmSwitchModule } from './ibm-switch.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
  <ibm-switch
    #switch
    [title]="title"
    [switchOn]="checked"
    (switch)="switchChange($event)">
  </ibm-switch>
  `,
  providers: [LoggerService]
  })
  export class SwitchTestComponent {

    @ViewChild('switch') switch: IbmSwitchComponent;

    public title = 'a funny title';
    public checked = true;

    public switchChange(){}

    constructor() { }
}

describe('IbmSwitchComponent', () => {
  let fixture: ComponentFixture<SwitchTestComponent>;
  let component: SwitchTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        SwitchTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        IbmSwitchModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwitchTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should see the title', async(() => {
    expect(fixture.debugElement.query(By.css('.ut-content')).nativeElement.innerText)
      .toContain(component.title);
  }));

  it('should be able to switch', async(() => {
    spyOn(component, 'switchChange');
    component.switch.switchChange();
    expect(component.switchChange).toHaveBeenCalled();
  }));
});
