import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'ibm-switch',
  templateUrl: './ibm-switch.component.html',
  styleUrls: ['./ibm-switch.component.css']
})
export class IbmSwitchComponent implements OnInit {

  @Input() title: string = '';
  @Input() switchOn: boolean = false;
  @Output('switch') switch: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  switchChange() {
    this.switchOn = !this.switchOn;
    this.switch.emit(this.switchOn);
  }

}
