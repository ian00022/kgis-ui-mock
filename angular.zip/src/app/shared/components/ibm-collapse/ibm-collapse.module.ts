import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IbmCollapseComponent } from './ibm-collapse.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    IbmCollapseComponent
  ],
  exports: [
    IbmCollapseComponent
  ]
})
export class IbmCollapseModule { }
