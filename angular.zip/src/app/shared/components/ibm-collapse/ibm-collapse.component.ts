import {AfterViewInit, Component, ContentChild, Input, OnInit, TemplateRef} from '@angular/core';

@Component({
  selector: 'ibm-collapse',
  templateUrl: './ibm-collapse.component.html',
  styleUrls: ['./ibm-collapse.component.css']
})
export class IbmCollapseComponent implements OnInit, AfterViewInit {
  @Input() header: string = '';
  @Input() datasource: any[];
  @Input() collapsed = false;
  @Input() decline = false;

  @ContentChild('expand') expand: TemplateRef<any>;

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }
}
