import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { IbmCollapseModule } from './ibm-collapse.module';

@Component({
    selector: 'collapse-test-component',
    template: `
        <ibm-collapse
            [header]="'a funny title'"
            [collapsed]="true">
            <ng-template #expand>
                some funny content
            </ng-template>
        </ibm-collapse>
    `
    })
    export class CollapseTestComponent {
    constructor() { }

    ngOnInit() {
    }

    ngAfterViewInit() {
    }
}

describe('IbmCollapseComponent', () => {
  let fixture: ComponentFixture<CollapseTestComponent>;
  let component: CollapseTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CollapseTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
        IbmCollapseModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollapseTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('the title should be correct', async(() => {
    expect(fixture.debugElement.query(By.css('.card-header h5 span')).nativeElement.innerText).toEqual('a funny title');
  }));

  it('the content should be correct', async(() => {
    expect(fixture.debugElement.query(By.css('.card')).nativeElement.innerText).toContain('some funny content');
  }));

});



  