import { EventEmitter, ViewChild } from '@angular/core';
import { Input, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ControlBase } from '../dynamic-form/controls/control-base';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-export-report-dialog',
  templateUrl: './export-report-dialog.component.html',
  styleUrls: ['./export-report-dialog.component.scss']
})
export class ExportReportDialogComponent implements OnInit {

  /**
   * display search params title
   *
   * @type {ControlBase<any>[]}
   * @memberof ExportReportDialogComponent
   */
  @Input('searchControls') searchControls: ControlBase<any>[] = [];

  /**
   * display search params value
   *
   * @memberof ExportReportDialogComponent
   */
  @Input() listConfig;

  /**
   * input header from parent component
   *
   * @memberof ExportReportDialogComponent
   */
  @Input('header') header = '';

  /**
   * emit event after confrim export
   *
   * @type {EventEmitter<any>}
   * @memberof ExportReportDialogComponent
   */
  @Output('afterConfirmed') afterConfirmed: EventEmitter<any> = new EventEmitter();

  /**
   * emit event after cancel export
   *
   * @type {EventEmitter<any>}
   * @memberof ExportReportDialogComponent
   */
  @Output('afterCanceled') afterCanceled: EventEmitter<any> = new EventEmitter();

  /**
   * template instance
   *
   * @type {IbmDialogComponent}
   * @memberof ExportReportDialogComponent
   */
  @ViewChild('dialog') dialog: IbmDialogComponent;

  /**
   * data binding to export type,
   * value: all, page
   *
   * @memberof ExportReportDialogComponent
   */
  public exportType = 'page';

  constructor() { }

  ngOnInit() {
  }

  // public getControlText(control: ControlBase<any>): string {
  //   if (this.config && this.config[control.key]) {
  //     if (this.config[control.key] instanceof Array) {
  //       return this.config[control.key].join(',');
  //     } else if (typeof this.config[control.key] === 'object') {
  //       return this.config[control.key].label;
  //     } else if (typeof this.config[control.key] === 'string') {
  //       return this.config[control.key];
  //     }
  //   }
  //   return '-';
  // }

  /**
   * click confirm button
   *
   * @memberof ExportReportDialogComponent
   */
  public onExportConfirmed() {
    this.afterConfirmed.emit(this.exportType);
  }

  /**
   * click cancel button
   *
   * @memberof ExportReportDialogComponent
   */
  public onExportCanceled() {
    this.afterCanceled.emit();
  }

  /**
   * open dialog
   *
   * @memberof ExportReportDialogComponent
   */
  public open() {
    this.dialog.open();
  }

  /**
   * close dialog
   *
   * @memberof ExportReportDialogComponent
   */
  public close() {
    this.dialog.close();
  }
}
