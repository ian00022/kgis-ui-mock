import { ControlBase } from './../dynamic-form/controls/control-base';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'esun-selected-options',
  templateUrl: './selected-options.component.html',
  styleUrls: ['./selected-options.component.scss']
})
export class SelectedOptionsComponent implements OnInit {
  @Input() form: DynamicFormComponent;
  @Input() key: string;

  constructor() { }

  get hideComponent(): boolean {
    return this.selectedOptionsLabel === '' || !this.getTheControl().condition(this.form.form) || this.getTheControl().disabled;
  }

  get label(): string {
    if (this.form) {
      const theControl = this.getTheControl();
      if (theControl) {
        return theControl.label;
      }
    }
    return '';
  }

  get selectedOptionsLabel(): string {
    const value = _.result(this.form, `form.controls[${this.key}].value`, []);
    if (!value) {
      return '';
    }
    const theControl = this.getTheControl();
    return value.map((el) => {
      return _.find(theControl['options'], {value: el})['label'];
    }).join('、');
  }
  
  ngOnInit() {
  }

  private getTheControl(): ControlBase<any> {
    return this.form.controls.filter(c => c.key === this.key)[0];
  }


}
