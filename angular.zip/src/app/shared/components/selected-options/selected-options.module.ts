import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectedOptionsComponent } from './selected-options.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SelectedOptionsComponent],
  exports: [
    SelectedOptionsComponent
  ]
})
export class SelectedOptionsModule { }
