import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IbmTabsComponent } from './ibm-tabs.component';
import { IbmTabComponent } from './ibm-tab/ibm-tab.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    IbmTabsComponent,
    IbmTabComponent
  ],
  exports: [
    IbmTabsComponent,
    IbmTabComponent
  ]
})
export class IbmTabsModule { }
