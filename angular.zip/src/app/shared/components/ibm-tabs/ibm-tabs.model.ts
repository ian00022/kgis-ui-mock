export interface IIbmTab {
  tabTitle: string;
}
