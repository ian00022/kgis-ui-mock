import { IbmTabComponent } from './ibm-tab/ibm-tab.component';
import { Component, OnInit, ContentChildren, QueryList, AfterContentInit, EventEmitter, Output, DoCheck} from '@angular/core';
@Component({
  selector: 'ibm-tabs',
  templateUrl: './ibm-tabs.component.html',
  styleUrls: ['./ibm-tabs.component.css']
})
export class IbmTabsComponent implements OnInit, AfterContentInit, DoCheck {

  @Output() doTabChange:  EventEmitter<any> = new EventEmitter();
  @Output() tabClicked:  EventEmitter<any> = new EventEmitter();
  public selectedTab: IbmTabComponent;
  public isFirstChange = true;
  @ContentChildren(IbmTabComponent) tabs: QueryList<IbmTabComponent>;

  constructor() { }

  public selectTab(index: number) {
    this.onSelect(this.tabs.toArray()[index]);
  }

  public onSelect(tab: IbmTabComponent) {
    this.select(tab);
    this.doTabChange.emit({
      tab: tab, 
      index: tab.index
    });
    this.tabClicked.emit({
      tab: tab, 
      index: tab.index
    });
  }

  public isTemplate(val): boolean {
    return typeof val === 'object';
  }

  public getSelectedTab(): IbmTabComponent {
    return this.selectedTab;
  }

  public initTabs() {
    this.tabs.forEach( (tab, index) => {
      tab.index = index;
    });
    if (this.tabs.length > 0) {
      this.select(this.tabs.first);
      this.doTabChange.emit(this.tabs.first);
    }
  }

  ngOnInit() {
  }

  ngDoCheck() {
    if (this.tabs && this.tabs.length > 0 && this.isFirstChange) {
      this.isFirstChange = false;
      this.initTabs();
    }
  }

  ngAfterContentInit() {
    this.initTabs();
  } 

  private select(tab: IbmTabComponent) {
    this.tabs.forEach((item) => {
      item.show = false;
    });

    this.selectedTab = tab;
    this.selectedTab.show = true;
  }
}
