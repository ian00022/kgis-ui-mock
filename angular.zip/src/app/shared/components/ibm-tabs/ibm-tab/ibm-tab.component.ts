import { TemplateRef, AfterViewInit } from '@angular/core';
import { IIbmTab } from './../ibm-tabs.model';
import { Component, OnInit, Input, ContentChild } from '@angular/core';

@Component({
  selector: 'ibm-tab',
  templateUrl: './ibm-tab.component.html',
  styleUrls: ['./ibm-tab.component.css']
})
export class IbmTabComponent implements OnInit, IIbmTab, AfterViewInit {

  @Input() tabTitle: string;

  @ContentChild('custom') custom: TemplateRef<any>;

  public show: boolean = false;
  public index: number;

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

}
