import { IbmTabsComponent } from './ibm-tabs.component';
import { IbmTabsModule } from './ibm-tabs.module';
import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';


@Component({
  template: `
  <ibm-tabs
    #tabs>
    <ibm-tab tabTitle="tab1">
      tab content 1
    </ibm-tab>
    <ibm-tab tabTitle="tab2">
      tab content 2
    </ibm-tab>
  </ibm-tabs>
  `
  })
  export class TabsTestComponent {
    @ViewChild('tabs') tabs: IbmTabsComponent;
    constructor() { }
}

describe('ProgressBarComponent', () => {
  let fixture: ComponentFixture<TabsTestComponent>;
  let component: TabsTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TabsTestComponent
      ],
      imports: [
        CommonModule,
        SharedModule,
        IbmTabsModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabsTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create the component', async(() => {
  //   const component = fixture.debugElement.componentInstance;
  //   expect(component).toBeTruthy();
  // }));

  it('should see the second tab content after clicking the second tab', async(() => {
    setTimeout(() => {
      let tab2 = fixture.debugElement.queryAll(By.css('.ut-tab'))[1].nativeElement;
      tab2.click();
      fixture.detectChanges();
      expect(component.tabs.selectedTab.tabTitle).toEqual('tab2');
    }, 50);
    // expect(fixture.debugElement.query(By.css('.tab-content')).nativeElement.innerText).toContain('tab2');
  }));
});
