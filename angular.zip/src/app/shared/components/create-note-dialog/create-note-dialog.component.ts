import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { LoggerService } from './../../logger.service';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';
import { ControlBase, TextareaControl } from '../dynamic-form/controls';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';
import * as _ from 'lodash';

@Component({
  selector: 'esun-create-note-dialog',
  templateUrl: './create-note-dialog.component.html',
  styleUrls: ['./create-note-dialog.component.scss']
})
export class CreateNoteDialogComponent implements OnInit {

  @ViewChild('form') form: DynamicFormComponent;
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @Input('header') header: string = '新增備註';
  @Input('remarkInfo') remarkInfo: any;
  @Output('afterCreateNote') afterCreateNote: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];
  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService
  ) { }

  get isValid() {
    return this.form.form.valid;
  }

  public handleFormSubmit(value) {

    let data = _.assign({
      generalBOLUUID: this.remarkInfo.generalBOLUUID,
      bolNo: this.remarkInfo.bolNo,
    }, value);
    this.boService.createBOLRemark(data).subscribe(
      (resp) => {
        this.logger.debug(resp);
        this.dialog.close();
        this.afterCreateNote.emit(resp.isOk);
      }
    );
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }
  public afterClosed() {
    this.form.reset();
  }

  ngOnInit() {
    this.prepareControls();
  }

  private prepareControls() {
    this.controls = [
      new TextareaControl({
        key: 'remark',
        label: '備註',
        required: true,
        columnClasses: ['12'],
        isWordCount: true,
        placeholder: '請輸入...'
      }),
    ];
  }

}
