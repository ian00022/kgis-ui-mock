import { ControlBase } from './control-base';

export class TextareaControl extends ControlBase<string> {
    controlType = 'textarea';
    rows: number;
    maxlength: number;
    isWordCount: boolean;

    constructor(options: {} = {}) {
        super(options);
        this.rows = options['rows'] || 5;
        this.maxlength = options['maxlength'] || 250;
        this.isWordCount = options['isWordCount'] || false;
    }
}
