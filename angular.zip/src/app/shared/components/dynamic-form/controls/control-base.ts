import { FormGroup, ValidatorFn } from '@angular/forms';

export class ControlBase<T> {
    value: T;
    key: string;
    label: string;
    required: boolean;
    controlType: string;
    columnClasses: string[];
    offsetClasses: string[];
    customizeClasses: string[];
    disabled: boolean;
    breakAfter: boolean;
    breakBefore: boolean;
    dividerBefore: boolean;
    warningBeforeText: string;
    placeholder: string;
    isWordCount: any;
    validators: ValidatorFn[];
    minDate: string;
    maxDate: string;
    condition: (form: FormGroup) => boolean;
    requireCondition: (form: FormGroup) => boolean;

    constructor(options: {
        value?: T,
        key?: string,
        label?: string,
        required?: boolean,
        order?: number,
        controlType?: string,
        columnClasses?: string[],
        offsetClasses?: string[],
        customizeClasses?: string[],
        disabled?: boolean,
        breakAfter?: boolean,
        breakBefore?: boolean,
        dividerBefore?: boolean,
        warningBeforeText?: string;
        placeholder?: string,
        validators?: ValidatorFn[],
        minDate?: string,
        maxDate?: string,
        condition?: (form: FormGroup) => boolean,
        requireCondition?: (form: FormGroup) => boolean,
      } = {}) {
      this.value = options.value;
      this.key = options.key || '';
      this.label = options.label || '';
      this.required = !!options.required;
      this.controlType = options.controlType || '';
      this.condition = options.condition || function() { return true; };
      this.columnClasses = options.columnClasses || [];
      this.offsetClasses = options.offsetClasses || [];
      this.customizeClasses = options.customizeClasses || [];
      this.disabled = !!options.disabled;
      this.breakAfter = options.breakAfter || false;
      this.breakBefore = options.breakBefore || false;
      this.dividerBefore = options.dividerBefore || false;
      this.placeholder = options.placeholder || '';
      this.warningBeforeText = options.warningBeforeText || null;
      this.validators = options.validators || [];
      this.requireCondition = options.requireCondition || function() { return false; };
    }
}
