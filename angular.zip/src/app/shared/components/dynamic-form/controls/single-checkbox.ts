import { ControlBase } from './control-base';

export class SingleCheckboxControl extends ControlBase<string> {
    controlType = 'single-checkbox';

    constructor(options: {} = {}) {
        super(options);
    }
}
