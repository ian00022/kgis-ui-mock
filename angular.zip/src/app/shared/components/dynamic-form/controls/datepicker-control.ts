import { ControlBase } from './control-base';

export class DatepickerControl extends ControlBase<string> {
    controlType = 'datepicker';
    formatter;
    singleDatePicker;
    minDate;
    maxDate;

    constructor(options: {} = {}) {
        super(options);
        this.formatter = options['formatter'] || 'YYYY/MM/DD';
        this.singleDatePicker = options['singleDatePicker'];
        this.minDate = options['minDate'];
        this.maxDate = options['maxDate'];
    }
}
