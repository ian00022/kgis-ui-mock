import { ControlBase } from './control-base';

export class SingleDropdownControl extends ControlBase<string> {
    controlType = 'dropdown';
    options: {key: string, value: string}[] = [];
    placeholder: string;
    enableAutocomplete: boolean;

    constructor(options: {} = {}) {
        super(options);
        this.options = options['options'] || [];
        this.placeholder = options['placeholder'] || '';
        this.enableAutocomplete = options['enableAutocomplete'] || false;
    }
}
