import { ControlBase } from './control-base';

export class TextControl extends ControlBase<string> {
    controlType = 'textbox';
    type: string; // email, password, number...
    addonString: string;
    maxlength: number;
    min: number;
    max: number;
    isWordCount: boolean;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
        this.addonString = options['addonString'] || '';
        this.maxlength = options['maxlength'] || '';
        this.min = options['min'] === 0 ? 0 : (options['min'] || '');
        this.max = options['max'] === 0 ? 0 : (options['max'] || '');
        this.isWordCount = options['isWordCount'] || false;
    }
}
