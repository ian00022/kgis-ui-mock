import { ControlBase } from './control-base';

export class MultiSelectTreeControl extends ControlBase<string> {
    controlType = 'multi-select-tree';
    items = [];

    constructor(options: {} = {}) {
        super(options);
        this.items = options['items'] || [];
    }
}