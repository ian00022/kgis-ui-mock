import { ControlBase } from './control-base';

export class ClockpickerControl extends ControlBase<string> {
    controlType = 'clockpicker';

    constructor(options: {} = {}) {
        super(options);
    }
}