import { EventEmitter, ElementRef, ViewChild, OnChanges, SimpleChanges, AfterContentChecked } from '@angular/core';
import { DynamicFormService } from './dynamic-form.service';
import { Component, OnInit, Input, Output } from '@angular/core';
import { ControlBase } from './controls/control-base';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit, OnChanges, AfterContentChecked {
    @Input() controls: ControlBase<any>[] = [];
    @Input() submitFromOutside: boolean = true;
    @Input() requiredAnyKeys: string[];
    @Input() modelChanges: any;
    @Input() validators: any[] = [];
    @Output() onSubmit: EventEmitter<any> = new EventEmitter();
    @Output() afterFirstControlsInit: EventEmitter<any> = new EventEmitter();


    @ViewChild('resetButton') resetButton: ElementRef;
    @ViewChild('submitButton') submitButton: ElementRef;

    form: FormGroup;
    payLoad = '';
    defaultValue;

    private isFirstControlInit = false;
    private isFirstEmit = true;
    constructor(private dynamicFormService: DynamicFormService) { }

    // 是否為擇一必填
    public isOptionalRequired(key: string): boolean {
      if (this.requiredAnyKeys) {
        return this.requiredAnyKeys.indexOf(key) !== -1;
      }
      return false;
    }

    ngOnInit() {
        this.form = this.dynamicFormService.toFormGroup(this.controls, this.validators, this.requiredAnyKeys);
        this.defaultValue = this.form.value;
    }

    ngOnChanges(changes: SimpleChanges): void {
      if (changes.controls) {
        if (changes.controls.isFirstChange() && changes.controls.currentValue) {
          this.isFirstControlInit = true;
        }
      }
    }

    ngAfterContentChecked() {
      if (this.isFirstControlInit && this.isFirstEmit) {
        this.isFirstEmit = false;
        this.afterFirstControlsInit.emit();
      }
    }

    public reset() {
      this.form.reset(this.defaultValue);
    }

    public patchValue(value: any) {
      if (this.form) {
        this.form.patchValue(value);
      }
    }

    public submit() {
      this.handleOnSubmit();
    }

    public handleOnSubmit() {
      this.onSubmit.emit(this.form.value);
    }

    public getGridClass(control: ControlBase<any>) {
      return control.columnClasses.map( colClass => `col-${colClass}` ).join(' ') + ' ' +
             control.offsetClasses.map( offsetClass => `offset-${offsetClass}` ).join(' ') +
             control.customizeClasses.map( custClass => custClass ).join(' ');
    }
}
