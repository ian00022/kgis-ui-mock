import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ControlBase } from './controls/control-base';
import { requiredAny } from '../../functions/validators';

@Injectable()
export class DynamicFormService {

    constructor() { }

    toFormGroup(controls: ControlBase<any>[], customValidators: any[], requiredAnyKeys?): FormGroup {
        let group: any = {};

        controls.forEach(control => {
            group[control.key] = control.required ? new FormControl(control.value, [...control.validators ,Validators.required])
                                                  : new FormControl(control.value, [...control.validators]);
        });

        let validators = [];
        if (requiredAnyKeys) {
            validators.push(requiredAny(requiredAnyKeys));
        }

        if (customValidators && customValidators.length > 0) {
            validators = [...validators, ...customValidators];
        }

        return new FormGroup(group, {
            validators: validators
        });
    }
}
