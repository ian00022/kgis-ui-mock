import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { SingleDropdownControl, SingleCheckboxControl, RadioControl, TextControl, TextareaControl, MultiSelectControl } from './controls';
import { DynamicFormModule } from './dynamic-form.module';
import { SharedModule } from '../../shared.module';


@Component({
  template: `
      <dynamic-form #dynamicForm [controls]="testControls"
        (onSubmit)="handleSubmit($event)">
      </dynamic-form>
  `
  })
  export class DynamicFormTestComponent {
    public options = [
      {value: 1, label: 'option1'},
      {value: 2, label: 'option2'}
    ];
    public singleDropdownOptions = [
      {value: 'solid',  label: 'Solid'},
      {value: 'great',  label: 'Great'},
      {value: 'good',   label: 'Good'},
      {value: 'unproven', label: 'Unproven'},
    ];
    public testControls = [
      new SingleDropdownControl({
        key: 'brave',
        label: 'Bravery Rating',
        enableAutocomplete: true,
        placeholder: 'test place holder',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: this.singleDropdownOptions,
        required: true,
        disabled: false
      }),

      new SingleCheckboxControl({
        key: 'checkboxSamdple',
        dividerBefore: true,
        label: 'i am checkbox',
        warningBeforeText: '下列選項用於自建名單',
        breakBefore: true,
        breakAfter: true,
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
      }),

      new RadioControl({
        key: 'gender',
        dividerBefore: true,
        label: 'Gender',
        value: 'm',
        breakBefore: true,
        breakAfter: true,
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: [
          {value: 'm',  label: 'male'},
          {value: 'f',  label: 'female'},
        ],
        disabled: true
      }),

      new TextControl({
        key: 'firstName',
        label: 'First name',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        required: false,
        disabled: true,
        placeholder: 'placeholder from sample'
      }),

      new TextControl({
        key: 'lastName',
        label: 'last Name',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        required: false,
        disabled: true,
        placeholder: 'placeholder from sample'
      }),

      new TextControl({
        key: 'emailAddress',
        label: 'Email',
        columnClasses: ['3'],
        offsetClasses: ['lg-4', 'md-3', '6'],
        type: 'email',
        required: true,
        value: '',
        // condition: (form: FormGroup) => {
        //   return form.controls['brave'].value === 'solid';
        // },
        disabled: true,
      }),

      new TextareaControl({
        key: 'testTextArea',
        label: 'Textarea',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        offsetClasses: ['lg-4', 'md-3', '6'],
        value: 'some funny text',
        disabled: false,
        rows: 10,
        isWordCount: true,
      }),

      new MultiSelectControl({
        key: 'multiSelect',
        label: 'multi-select',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: this.options,
        enableAutocomplete: true,
        breakBefore: true,
        placeholder: 'test place holder',
        disabled: true,
      }),

      new MultiSelectControl({
        key: 'multiSelect2',
        label: 'multi-select WithoutValue',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: this.options,
        enableAutocomplete: true,
        breakBefore: true,
        placeholder: 'test place holder',
      }),
    ];

    public formValue;

    @ViewChild('dynamicForm') dynamicForm: DynamicFormComponent;

    handleSubmit(formValue) {
      this.formValue = formValue;
    }

    constructor() { }
}

describe('EsbCommonMultiSelectComponent', () => {
  let fixture: ComponentFixture<DynamicFormTestComponent>;
  let component: DynamicFormTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DynamicFormTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
        DynamicFormModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFormTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const c = fixture.debugElement.componentInstance;
    expect(c).toBeTruthy();
  }));

  it('should be able to patch value to the form', async(() => {
    let component = fixture.debugElement.componentInstance;
    component.dynamicForm.patchValue({
      brave: 'solid'
    });
    expect(component.dynamicForm.form.value['brave']).toEqual('solid');
  }));

  it('should be able get value after submit', async(() => {
    let component = fixture.debugElement.componentInstance;
    component.dynamicForm.submit();
    fixture.detectChanges();
    expect(component.formValue['testTextArea']).toEqual('some funny text');
  }));

  it('should reset form value after calling reset', async(() => {
    let component = fixture.debugElement.componentInstance;
    component.dynamicForm.patchValue({
      brave: 'solid'
    });
    component.dynamicForm.reset();
    fixture.detectChanges();
    expect(component.dynamicForm.form.value['brave']).toEqual(null);
  }));

  it('should be able to add select options dynamically', async(() => {
    component.singleDropdownOptions.push({
      value: 'someValue', 
      label: 'another option'
    });
    fixture.detectChanges();
    component.dynamicForm.patchValue({
      brave: 'someValue'
    });
    fixture.detectChanges();
    expect(component.dynamicForm.form.value['brave']).toEqual('someValue');
  }));
});
