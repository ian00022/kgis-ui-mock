import { IbmSingleSelectModule } from './../ibm-single-select/ibm-single-select.module';
import { IbmClockPickerModule } from './../../directives/ibm-clock-picker/ibm-clock-picker.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DynamicFormControlComponent } from './dynamic-form-control/dynamic-form-control.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicFormComponent } from './dynamic-form.component';
import { DynamicFormService } from './dynamic-form.service';
import { MatCheckboxModule, MatDividerModule } from '@angular/material';
import { MdePopoverModule } from '@material-extended/mde';
import { EsbCommonMultiSelectModule } from 'app/shared/components/esb-common-multi-select/esb-common-multi-select.module';
import { EsbCommonDatePickerModule } from 'app/shared/directives/esb-common-date-picker/esb-common-date-picker.module';
import { EsbCommonTreeSelectModule } from '../esb-common-tree-select/esb-common-tree-select.module';
import { EsbCommonNullValueModule } from '../../directives/esb-common-null-value/esb-common-null-value.module';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    EsbCommonDatePickerModule,
    EsbCommonMultiSelectModule,
    IbmClockPickerModule,
    IbmSingleSelectModule,
    MatCheckboxModule,
    EsbCommonTreeSelectModule,
    MatDividerModule,
    MdePopoverModule,
    EsbCommonNullValueModule
  ],
  declarations: [DynamicFormComponent, DynamicFormControlComponent],
  providers: [DynamicFormService],
  exports: [
    DynamicFormComponent,
    DynamicFormControlComponent,
    ReactiveFormsModule
  ]
})
export class DynamicFormModule { }
