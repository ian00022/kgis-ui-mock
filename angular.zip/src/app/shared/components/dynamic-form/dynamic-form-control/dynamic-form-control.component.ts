import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ControlBase } from '../controls/control-base';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';

import * as _ from 'lodash';

@Component({
  selector: 'dynamic-form-control',
  templateUrl: './dynamic-form-control.component.html',
  styleUrls: ['./dynamic-form-control.component.scss']
})
export class DynamicFormControlComponent implements OnInit, OnDestroy {
  @Input() control: ControlBase<any>;
  @Input() form: FormGroup;
  @Input() isOptionalRequired: boolean;
  @Input() modelChanges: any;

  @Input()
  set disabled(disabled: boolean) {
    if (disabled) {
      this.form.controls[this.control.key].disable();
    } else {
      this.form.controls[this.control.key].enable();
    }
    this.ref.detectChanges();
  }

  get controlIsRequired(): boolean {
    return this.control.required || this.control.requireCondition(this.form);
  }

  get hideLabel() {
    return this.control.controlType === 'single-checkbox';
  }
  get isValid() { return this.form.controls[this.control.key].valid; }
  get isControlDisabled() {
    return this.form.controls[this.control.key].disabled;
  }

  get displayModelChange() {
    if ( _.isNull(this.modelChanges) ) {
      return false;
    } else {
      if (this.selfModelChange) {
        return true;
      }
      return false;
    }
  }

  get selfModelChange() {
    return _.find(this.modelChanges, {key: this.control.key});
  }

  get showErrorText(): boolean {
    return this.form.controls[this.control.key].hasError(this.control.key) && this.form.controls[this.control.key].dirty;
  }

  get showFormatErrorText(): boolean {
    return this.form.controls[this.control.key].hasError('formatError') && this.form.controls[this.control.key].dirty;
  }

  public textCount = 0;
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(private ref: ChangeDetectorRef) { }

  ngOnInit() {
    if (this.control.isWordCount) {
      if (this.control.controlType === 'textarea' || this.control.controlType === 'textbox') {
        this.form.controls[this.control.key].valueChanges

        .subscribe((changes: string) => {
          this.textCount = changes ? changes.length : 0;
        });
      }
    }
  }
  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

}
