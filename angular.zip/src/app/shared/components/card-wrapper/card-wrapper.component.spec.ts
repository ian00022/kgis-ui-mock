import { CardWrapperComponent } from './card-wrapper.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../../shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerService } from '../../logger.service';


@Component({
  template: `
    <esun-card-wrapper #card [cardTitle]="header">
    </esun-card-wrapper>
  `,
  providers: [LoggerService]
  })
  export class CardWrapperTestComponent {

    @ViewChild('card') card: CardWrapperComponent;

    public header = 'a funny header';

    constructor() { }
}

describe('CardWrapperComponent', () => {
  let fixture: ComponentFixture<CardWrapperTestComponent>;
  let component: CardWrapperTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CardWrapperTestComponent
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardWrapperTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should see the header', async(() => {
    expect(fixture.debugElement.query(By.css('.card-title span')).nativeElement.innerText).toEqual(component.header);
  }));
});
