import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'esun-card-wrapper',
  templateUrl: './card-wrapper.component.html',
  styleUrls: ['./card-wrapper.component.css']
})
export class CardWrapperComponent implements OnInit {

  @Input() cardTitle = '';

  constructor() { }

  ngOnInit() {
  }
}
