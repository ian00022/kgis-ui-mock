import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.css']
})
export class ProgressBarComponent implements OnInit {

  @Input() value: number;
  constructor() { }

  ngOnInit() {
  }

  get progressValue() {
    if (this.value) {
      if (this.value < 1) {
        return this.value*100 + '%';
      } else {
        return this.value + '%';
      }
    }
    return '0%';
  }
}
