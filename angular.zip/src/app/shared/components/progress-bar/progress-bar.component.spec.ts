import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { ProgressBarModule } from './progress-bar.module';


@Component({
  template: `
    <progress-bar [value]="progress"></progress-bar>
  `
  })
  export class ProgressBarTestComponent {
    public progress: number = 0;
    constructor() { }
}

describe('ProgressBarComponent', () => {
  let fixture: ComponentFixture<ProgressBarTestComponent>;
  let component: ProgressBarTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ProgressBarTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
        ProgressBarModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressBarTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should the progress updates after value changed', async(() => {
    component.progress = 50;
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.progress-value')).nativeElement.style.width).toEqual('50%');
  }));
});
