import { Component, Input, forwardRef, ViewChild, ViewEncapsulation, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatSelectionList, MatListOption, MatMenuTrigger } from '@angular/material';


export const SELECT_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  // tslint:disable-next-line
  useExisting: forwardRef(() => EsbCommonMultiSelectComponent),
  multi: true
};
@Component({
  selector: 'esb-common-multi-select',
  templateUrl: './esb-common-multi-select.component.html',
  styleUrls: ['./esb-common-multi-select.component.scss'],
  providers: [SELECT_VALUE_ACCESSOR, ChangeDetectorRef],
  encapsulation: ViewEncapsulation.None
})
export class EsbCommonMultiSelectComponent implements ControlValueAccessor, AfterViewInit {

  @Input()
  placeholder: string = '';

  @Input()
  options: any[] = [];

  @Input()
  labelKey: String = 'label';

  @Input()
  valueKey: String = 'value';

  @Input()
  enableAutocomplete: boolean = false;

  @ViewChild('selectList') selectList: MatSelectionList;
  @ViewChild('input') input: ElementRef;
  @ViewChild('menuTrigger') menuTrigger: MatMenuTrigger;

  public filterText = '';
  public inputWidth = 0;
  public value: any[];
  private controlDisabled: boolean = false;

  constructor(private ref: ChangeDetectorRef) {
  }

  // the material2 selection list is ready
  ngAfterViewInit() {
    this.writeValue(this.value);
  }

  get isDisabled(): boolean {
    return this.controlDisabled;
  }

  get isPlaceholderColor(): boolean {
    return this.displayText === this.placeholder;
  }

  public controlOnChange = (_: any) => {};

  public get displayText() {
    if (this.selectList.selectedOptions.selected.length === 0) {
      return this.placeholder;
    }else {
      let selectedItemLabels = this.selectList.selectedOptions.selected.map((selectedItem: MatListOption) => selectedItem._getHostElement().innerText);
      let firstSelectedItemLabel = selectedItemLabels[0];
      if ( selectedItemLabels.length > 1 ) {
        return `${firstSelectedItemLabel}, + ${selectedItemLabels.length - 1}`;
      }else {
        return `${firstSelectedItemLabel}`;
      }
    }
  }

  public hideOption(optionLabel: string) {
    return optionLabel.toString().toLowerCase().indexOf(this.filterText) === -1;
  }

  /**
   * implements ControlValueAccessor
   */
  writeValue(value: any): void {
    if (!value) {
      value = [];
    }
    if (value) {
      this.value = value;
      if (this.selectList.options) {
        this.selectList.options.forEach( (option: MatListOption) => {
          if ( this.value.includes(option.value)) {
            option.selected = true;
          }else {
            option.selected = false;
          }
        });
      }
      this.ref.detectChanges();
    }
  }
  registerOnChange(fn: any): void {
    this.controlOnChange = fn;
  }
  registerOnTouched(fn: any): void {
  }
  setDisabledState?(isDisabled: boolean): void {
    this.controlDisabled = isDisabled;
  }

  public updateInputWidth() {
    this.inputWidth = this.input.nativeElement.clientWidth;
  }

  public selectAll() {
    this.selectList.selectAll();
    this.onSelectionChange();
  }

  public deselectAll() {
    this.selectList.deselectAll();
    this.onSelectionChange();
  }

  public onSelectionChange() {
    this.value = this.selectList.selectedOptions.selected.map((selectedItem: MatListOption) => selectedItem.value);
    this.controlOnChange(this.value);
  }

}
