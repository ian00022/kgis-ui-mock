import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialsModule } from '../../materials.module';
import { FilterPipeModule } from '../../pipes/filter/filter-pipe.module';
import { EsbCommonClickStopPropagationModule } from 'app/shared/directives/esb-common-stop-propagation/esb-common-click-stop-propagation.module';
import { EsbCommonMultiSelectComponent } from 'app/shared/components/esb-common-multi-select/esb-common-multi-select.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialsModule,
    ReactiveFormsModule,
    EsbCommonClickStopPropagationModule,
    FilterPipeModule
  ],
  declarations: [EsbCommonMultiSelectComponent],
  exports: [
    EsbCommonMultiSelectComponent
  ]
})
export class EsbCommonMultiSelectModule { }
