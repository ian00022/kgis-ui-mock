import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EsbCommonMultiSelectComponent } from 'app/shared/components/esb-common-multi-select/esb-common-multi-select.component';
import { EsbCommonMultiSelectModule } from 'app/shared/components/esb-common-multi-select/esb-common-multi-select.module';


@Component({
  template: `
      <esb-common-multi-select 
        #multiSelectComponent
        [enableAutocomplete]="true"
        [options]="options"
        [placeholder]="placeholder"
        [(ngModel)]="model">
      </esb-common-multi-select>
  `
  })
  export class MultiselectTestComponent {
    public options = [
      {value: 1, label: 'label 01'},
      {value: 2, label: 'label 02'}
    ];
    public model;
    public placeholder = '';

    @ViewChild('multiSelectComponent') multiSelectComponent: EsbCommonMultiSelectComponent;

    constructor() { }
}

describe('EsbCommonMultiSelectComponent', () => {
  let fixture: ComponentFixture<MultiselectTestComponent>;
  let component: MultiselectTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MultiselectTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
        BrowserAnimationsModule,
        EsbCommonMultiSelectModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const c = fixture.debugElement.componentInstance;
    expect(c).toBeTruthy();
  }));

  it('The placeholder should display', async(() => {
    const placeholder = 'a funny placeholder';
    fixture.debugElement.componentInstance.placeholder = placeholder;
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.displayText')).nativeElement.innerText).toEqual(placeholder);
  }));

  it('The component should display the selected value', async(() => {
    fixture.debugElement.componentInstance.model = [1, 2];
    fixture.detectChanges();
    setTimeout(() => {
      expect(fixture.debugElement.query(By.css('.displayText')).nativeElement.innerText).toEqual('label 01, + 1');
    }, 50);
  }));

  it('should see the options after click', async(() => {
    let button = fixture.debugElement.nativeElement.querySelector('.multi-select-button');
    button.click();
    fixture.detectChanges();
    
    expect(fixture.debugElement.queryAll(By.css('.multi-select-option'))[0].nativeElement.innerText.replace(/[^a-z 0-9A-Z]/g, '')).toEqual('label 01');
  }));

  it('should select all options', async(() => {
    fixture.debugElement.componentInstance.multiSelectComponent.selectAll();
    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.model).toEqual([1,2]);
  }));

  it('should deselect all options', async(() => {
    fixture.debugElement.componentInstance.multiSelectComponent.selectAll();
    fixture.debugElement.componentInstance.multiSelectComponent.deselectAll();
    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.model).toEqual([]);
  }));
  
  it('should change the model value after option clicked', async(() => {
    let button = fixture.debugElement.nativeElement.querySelector('.multi-select-button');
    button.click();
    fixture.detectChanges();
    
    let option = fixture.debugElement.queryAll(By.css('.multi-select-option'))[0].nativeElement;
    option.click();

    fixture.detectChanges();
    expect(fixture.debugElement.componentInstance.model).toEqual([1]);
  }));
});
