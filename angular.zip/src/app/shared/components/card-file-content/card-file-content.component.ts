import { Permissions } from 'app/core/models/permissions';
import { ReferralProd } from './../../../core/models/comm-data';
import { BOLFileType } from './../../../business-opportunity/business-opportunity.model';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import * as _ from 'lodash';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-card-file-content',
  templateUrl: './card-file-content.component.html',
  styleUrls: ['./card-file-content.component.scss']
})
export class CardFileContentComponent implements OnInit {

  @Input('files') files: any[] = [];
  @Input('productType') productType: ReferralProd;
  @ViewChild('edit') editDialog: IbmDialogComponent;
  @ViewChild('delete') deleteDialog: IbmDialogComponent;
  @ViewChild('preview') previewDialog: IbmDialogComponent;
  public selectedFile: any = {};
  public Permissions = Permissions;

  public options = [
    {value: BOLFileType.IDCARD, label: '身分證'},
    {value: BOLFileType.INCOME_PROOF, label: '所得證明'},
    {value: BOLFileType.APPLY_DOC, label: '申請書'},
    {value: BOLFileType.WORK_PROOF, label: '工作證明'},
    {value: BOLFileType.COLLATERAL, label: '擔保品資料'},
    {value: BOLFileType.COMP_PROOF, label: '公司證明文件'},
    {value: BOLFileType.TREASURY_PROOF, label: '財資歷證明'},
    {value: BOLFileType.REVENUE_REPORT, label: '營收報表'},
    {value: BOLFileType.LOCATION_PHOTO, label: '營業地點照片'},
    {value: BOLFileType.OTHER, label: '其他'}
  ];


  private custFileTypeOptions = [
    {value: BOLFileType.IDCARD, label: '身分證'},
    {value: BOLFileType.INCOME_PROOF, label: '所得證明'},
    {value: BOLFileType.APPLY_DOC, label: '申請書'},
    {value: BOLFileType.WORK_PROOF, label: '工作證明'},
    {value: BOLFileType.COLLATERAL, label: '擔保品資料'},
    {value: BOLFileType.OTHER, label: '其他'}
  ];

  private compFileTypeOptions = [
    {value: BOLFileType.APPLY_DOC, label: '申請書'},
    {value: BOLFileType.COMP_PROOF, label: '公司證明文件'},
    {value: BOLFileType.TREASURY_PROOF, label: '財資歷證明'},
    {value: BOLFileType.REVENUE_REPORT, label: '營收報表'},
    {value: BOLFileType.LOCATION_PHOTO, label: '營業地點照片'},
    {value: BOLFileType.OTHER, label: '其他'}
  ];
  constructor(
    private shared: SharedService,
    private boService: BusinessOppotunityService
  ) { }

  ngOnInit() {
  }

  public isFileEditable(file): boolean {
    return file.BOLFileProviderType === '2'; // 行員上傳文件
  }

  public getFileTagLabel(tag: any): string {
    const index = _.findIndex(this.options, {value: tag});
    return index === -1 ? '' : this.options[index].label;
  }

  public onDeleteClick(file: any) {
    this.selectedFile = _.cloneDeep(file);
    this.options = this.filterOptions(this.productType);
    this.deleteDialog.open();
  }

  public handleDeleteConfirm() {
    this.boService.deleteBOLAttachments(this.selectedFile.UUID).subscribe( (resp) => {
      console.log(resp);
      this.deleteDialog.close();
    });
  }

  public handleDeleteCancel() {
    this.deleteDialog.close();
  }

  public onEditClick(file: any) {
    this.selectedFile = _.cloneDeep(file);
    this.options = this.filterOptions(this.productType);
    this.editDialog.open();
  }

  public handleEditConfirm() {
    this.boService.updateBOLAttachments({
      UUID: this.selectedFile.UUID,
      BOLFileType: this.selectedFile.BOLFileType
    }).subscribe( (resp) => {
      console.log(resp);
      this.editDialog.close();
    });

  }
  public handleEditCancel() {
    this.editDialog.close();
  }

  public onPreviewClick(file: any) {
    if (file.type === 'image') {
      this.shared.previewImage(file.url);
    } else {
      /**
       * pdf viewer
       */
    }
  }

  public afterClose() {
    this.reset();
  }

  private reset() {
  }

  private filterOptions(productType): any[] {
    if (productType === ReferralProd.SB) {
      return this.compFileTypeOptions;
    } else if (productType === ReferralProd.CREDIT ||
                productType === ReferralProd.GUARANTEE ||
                productType === ReferralProd.HOUSE) {
      return this.custFileTypeOptions;
    } else {
      return [];
    }
  }

}
