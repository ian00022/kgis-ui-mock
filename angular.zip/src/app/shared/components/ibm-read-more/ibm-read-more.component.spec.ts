import { IbmReadMoreComponent } from './ibm-read-more.component';
import { SharedModule } from './../../shared.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';


@Component({
  template: `
      <ibm-read-more
        #readmore
        [maxLength]="maxLength"
        [text]="testText">
      </ibm-read-more>
  `
  })
  export class ReadMoreTestComponent {
    public testText = '123456789';
    public maxLength = 5;
    @ViewChild('readmore') readMoreComponent: IbmReadMoreComponent;

    constructor() { }
}

describe('ReadMoreComponent', () => {
  let fixture: ComponentFixture<ReadMoreTestComponent>;
  let component: ReadMoreTestComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ReadMoreTestComponent
      ],
      imports: [
        CommonModule,
        PortalModule,
        SharedModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadMoreTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', async(() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  }));

  it('should see the first limited characters and ...', async(() => {
    const component = fixture.debugElement.componentInstance;
    const shortenText = component.testText.substring(0, component.maxLength);
    expect(fixture.debugElement.query(By.css('.displayText')).nativeElement.innerText).toEqual(shortenText + '...');
  }));

  it('should see whole text after clicking readmore', async(() => {
    const component = fixture.debugElement.componentInstance;
    let button = fixture.debugElement.nativeElement.querySelector('.see-all');
    button.click();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.displayText')).nativeElement.innerText).toEqual(component.testText);
  }));
});
