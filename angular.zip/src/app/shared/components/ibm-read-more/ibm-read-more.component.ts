import { Component, OnInit, Input } from '@angular/core';
import { SlicePipe } from '@angular/common';

@Component({
  selector: 'ibm-read-more',
  templateUrl: './ibm-read-more.component.html',
  styleUrls: ['./ibm-read-more.component.scss'],
  providers: [SlicePipe]
})
export class IbmReadMoreComponent implements OnInit {
  @Input() text: string = '';
  @Input() maxLength: number = 70;

  public isShowingMore: boolean = false;

  constructor(private slice: SlicePipe) { }

  get isTextTooLong(): boolean {
    if (this.isShowingMore) {
      return false;
    }
    return this.text.length > this.maxLength;
  }

  get displayText() {
    if (this.isTextTooLong) {
      return this.slice.transform(this.text, 0, this.maxLength) + '...';
    }
    return this.text;
  }

  ngOnInit() {
  }

}
