import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialsModule } from '../../materials.module';
import { FilterPipeModule } from '../../pipes/filter/filter-pipe.module';
import { IbmSingleSelectComponent } from './ibm-single-select.component';
import { EsbCommonClickStopPropagationModule } from 'app/shared/directives/esb-common-stop-propagation/esb-common-click-stop-propagation.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialsModule,
    ReactiveFormsModule,
    EsbCommonClickStopPropagationModule,
    FilterPipeModule
  ],
  declarations: [IbmSingleSelectComponent],
  exports: [IbmSingleSelectComponent]
})
export class IbmSingleSelectModule { }
