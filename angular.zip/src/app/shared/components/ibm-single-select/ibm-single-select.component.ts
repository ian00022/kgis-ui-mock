import { Component, OnInit, Input, ViewChild, ElementRef, forwardRef, ViewEncapsulation, AfterViewInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { MatSelectionList, MatListOption, MatSelectionListChange, MatMenuTrigger, MatMenu } from '@angular/material';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

export const SELECT_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  // tslint:disable-next-line
  useExisting: forwardRef(() => IbmSingleSelectComponent),
  multi: true
};
@Component({
  selector: 'ibm-single-select',
  templateUrl: './ibm-single-select.component.html',
  styleUrls: ['./ibm-single-select.component.scss'],
  providers: [SELECT_VALUE_ACCESSOR],
  encapsulation: ViewEncapsulation.None
})
export class IbmSingleSelectComponent implements OnInit, AfterViewInit, ControlValueAccessor {

  @Input()
  placeholder: string = '';

  @Input()
  options: any[] = [];

  @Input()
  labelKey: string = 'label';

  @Input()
  valueKey: string = 'value';

  @Input()
  enableAutocomplete: boolean = false;

  @Output()
  change: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('selectList') selectList: MatSelectionList;
  @ViewChild('input') input: ElementRef;
  @ViewChild('menuTrigger') menuTrigger: MatMenuTrigger;
  @ViewChild('menu') menu: MatMenu;


  public filterText = '';
  public inputWidth = 0;
  public value: any;
  public displayText: string;
  private controlDisabled: boolean = false;

  constructor(private ref: ChangeDetectorRef) { }

  ngOnInit() {
    this.displayText = this.placeholder;
  }

  ngAfterViewInit() {
    this.writeValue(this.value);
  }

  public controlOnChange = (_: any) => {};

  get isDisabled(): boolean {
    return this.controlDisabled;
  }

  get isPlaceholderColor(): boolean {
    return this.displayText === this.placeholder;
  }

  public onSelectionChange(change: MatSelectionListChange) {
    this.selectList.deselectAll();
    change.option.selected = true;
    this.value = change.option.value;
    this.displayText = change.option._getHostElement().innerText;
    this.controlOnChange(this.value);
    this.change.emit(this.value);
  }

  /**
   * implements ControlValueAccessor
   */
  writeValue(value: any): void {
    if (value) {
      this.value = value;

      if (this.selectList.options) {
        this.selectList.deselectAll();
        this.selectList.options.forEach( (option: MatListOption) => {
          if ( this.value === option.value ) {
            option.selected = true;
            this.displayText = option._getHostElement().innerText;
          }
        });
      }
    } else {
      this.displayText = this.placeholder;
    }
    this.ref.detectChanges();
  }
  registerOnChange(fn: any): void {
    this.controlOnChange = fn;
  }
  registerOnTouched(fn: any): void {
  }
  setDisabledState?(isDisabled: boolean): void {
    this.controlDisabled = isDisabled;
  }

  public updateInputWidth() {
    this.inputWidth = this.input.nativeElement.clientWidth;
  }

}
