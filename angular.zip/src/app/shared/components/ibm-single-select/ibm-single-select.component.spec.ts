import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { ISelectOptionModel } from 'app/core/models/comm-data';
import { IbmSingleSelectComponent } from './ibm-single-select.component';
import { IbmSingleSelectModule } from './ibm-single-select.module';
import { IBMClickStopPropagation } from '../../directives/ibm-stop-propagation/esb-common-click-stop-propagation';

describe('IbmSingleSelectComponent', () => {
  let component: IbmSingleSelectComponent;
  let fixture: ComponentFixture<IbmSingleSelectComponent>;
  let debugEl: DebugElement;
  let options: ISelectOptionModel[] = [
    {
      value: 'test1',
      label: 'test1'
    },
    {
      value: 'test2',
      label: 'test2'
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        IbmSingleSelectModule,
        BrowserAnimationsModule
      ],
      providers: [IBMClickStopPropagation, ChangeDetectorRef]
    })
    .compileComponents()
    .then( () => {
      fixture = TestBed.createComponent(IbmSingleSelectComponent);
      component = fixture.componentInstance;
      debugEl = fixture.debugElement;
    });
  }));

  it('should create singleSelect', () => {
    expect(component).toBeTruthy();
  });

  it('should placeholder be set', () => {
    let placeholder = 'test placeholder';
    component.placeholder = placeholder;
    component.ngOnInit();
    fixture.detectChanges();
    expect(debugEl.query(By.css('button .form-control.inputstyle')).nativeElement.textContent.trim()).toEqual(placeholder);
  });

  it('should options be set', () => {
    component.options = options;
    fixture.detectChanges();
    component.menuTrigger.openMenu();
    fixture.whenStable().then( () => {
      expect(debugEl.queryAll(By.css('mat-list-option')).length).toEqual(options.length);
      expect(debugEl.queryAll(By.css('mat-list-option .mat-list-text'))[0].nativeElement.textContent.trim()).toEqual(options[0].label);
    });
  });

  it('should options selected', () => {
    component.options = options;
    fixture.detectChanges();
    component.menuTrigger.openMenu();
    fixture.whenStable().then( () => {
      debugEl.query(By.css('mat-list-option')).nativeElement.click();
      fixture.detectChanges();
      expect(component.value).toEqual(options[0].value);
      expect(component.displayText.trim()).toEqual(options[0].label);
    });

  });

  it('should valueKey & labelKey be set', () => {
    let custom = {
      customValue: 'testValue',
      customLabel: 'testLabel'
    };
    component.labelKey = 'customLabel';
    component.valueKey = 'customValue';
    component.options = [custom];
    fixture.detectChanges();
    component.menuTrigger.openMenu();
    fixture.whenStable().then( () => {
      expect(debugEl.query(By.css('mat-list-option .mat-list-text')).nativeElement.textContent.trim()).toEqual(custom.customLabel);
      debugEl.query(By.css('mat-list-option')).nativeElement.click();

      fixture.detectChanges();

      expect(component.value).toEqual(custom.customValue);
      expect(component.displayText.trim()).toEqual(custom.customLabel);
    });

  });

  it('should getter isDisabled be set', () => {
    const spy = spyOnProperty(component, 'isDisabled', 'get').and.returnValue(true);
    expect(component.isDisabled).toBe(true);
    expect(spy).toHaveBeenCalled();
  });

  it('should enableAutocomplete work', () => {
    component.options = options;
    fixture.detectChanges();
    component.menuTrigger.openMenu();
    fixture.whenStable().then( () => {
      expect(debugEl.queryAll(By.css('mat-list-option')).length).toEqual(options.length);
      expect(debugEl.queryAll(By.css('mat-list-option .mat-list-text'))[0].nativeElement.textContent.trim()).toEqual(options[0].label);
    });
  });

  it('should set default value work', () => {
    component.options = options;
    component.value = options[0].value;
    fixture.detectChanges();
    fixture.whenStable().then( () => {
      expect(debugEl.query(By.css('div .form-control.inputstyle')).nativeElement.textContent.trim()).toEqual(options[0].label);
    });
  });

});
