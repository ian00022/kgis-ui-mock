import { ChartSwitchMode } from './../../../core/models/comm-data';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';

@Component({
  selector: 'esun-assets-liabilities-dialog',
  templateUrl: './assets-liabilities-dialog.component.html',
  styleUrls: ['./assets-liabilities-dialog.component.scss']
})
export class AssetsLiabilitiesDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @Input('assetsData') assetsData: any = [];
  @Input('liabilityData') liabilityData: any = {};
  @Input('header') header: string = '';


  public chartSwitchMode = ChartSwitchMode;
  public switchValue = ChartSwitchMode.ASSET;
  constructor() { }

  public open() {
    this.dialog.open();
  }
  public isChecked(mode: ChartSwitchMode): boolean {
    return this.switchValue === mode;
  }

  public onClickSwitchBtn(mode: ChartSwitchMode) {
    this.switchValue = mode;
  }

  public onSliceClick() {
  }

  ngOnInit() {
  }

}
