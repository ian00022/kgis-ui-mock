import { Component, OnInit, OnDestroy, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { IbmDialogComponent } from '../ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { LoggerService } from '../../logger.service';
import { ControlBase, TextControl, SingleDropdownControl, TextareaControl, DatepickerControl, ClockpickerControl } from '../dynamic-form/controls';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';
import { DashboardService } from './../../../core/services/dashboard.service';
import { DateHelper } from '../../helper/date-helper';
import * as moment from 'moment';

@Component({
  selector: 'esun-create-schedule-dialog',
  templateUrl: './create-schedule-dialog.component.html',
  styleUrls: ['./create-schedule-dialog.component.scss']
})
export class CreateScheduleDialogComponent implements OnInit, OnDestroy {

  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;
  @ViewChild('chooseBoDialog') chooseBoDialog: IbmDialogComponent;
  @ViewChild('createScheduleForm') createScheduleForm: DynamicFormComponent;

  // bolNo, bolName
  @Input('defaultScheduleData')
  set defaultScheduleData(data: any) {
    if (data) {
      this.scheduleData = data;
    }
  }
  get defaultScheduleData(): any {
    return this.scheduleData;
  }

  // 選定顧客，沒選定名單
  @Input('circiKey') circiKey: string = '';
  @Input('header') header: string = '新增行程';
  @Output('afterUpdateSchedule') afterUpdateSchedule: EventEmitter<any> = new EventEmitter();

  public controls: ControlBase<any>[] = [];
  public boOptions: any[] = [
    { value: '1', label: 'EBM - 精彩稅月 - 陳大發' },
  ];
  public scheduleData: any = {};
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private dashboardService: DashboardService
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isValid() {
    return this.createScheduleForm.form.valid;
  }

  get showDelete(): boolean {
    return this.isBOLChoosable;
  }

  // get hasdDefaultBolNo(): boolean {
  //   return this.scheduleData ? true : false;
  // }

  get isEditMode(): boolean {
    return this.scheduleData.hasOwnProperty('UUID');
  }

  // 與名單綁定的行程不能刪除
  get isBOLChoosable(): boolean {
    return this.circiKey !== '';
  }

  public handleSubmit(value) {
    this.logger.debug(value, this.scheduleData);
    let scheduleData;
    if (!this.isEditMode) {
      scheduleData = _.cloneDeep(value);
      if (!this.isBOLChoosable) {
        scheduleData['BOLNo'] = this.scheduleData.bolNo;
        scheduleData['BOLName'] = this.scheduleData.bolName;
      }
      this.dashboardService.addEvent(scheduleData).subscribe(
        (resp) => {
          this.createScheduleDialog.close();
          this.afterUpdateSchedule.emit();
        }
      );
    } else {
      scheduleData = {
        UUID: this.defaultScheduleData.UUID,
        visitDate: value['visitDate'],
        visitTime: value['visitTime'],
        remark: value['remark'],
        BOLNo: this.defaultScheduleData.BOLNo
      };
      this.dashboardService.editEvent(scheduleData).subscribe(
        (resp) => {
          this.createScheduleDialog.close();
          this.afterUpdateSchedule.emit();
        }
      );
    }

    this.logger.debug(scheduleData);

  }

  public open() {

    this.setFormEditMode(this.isEditMode);
    if (this.isEditMode) {
      // 編輯模式
      this.createScheduleForm.patchValue({
        BOLNo: this.scheduleData.BOLNo,
        visitDate: DateHelper.formatDate(this.scheduleData.visitDate),
        visitTime: this.scheduleData.visitTime,
        subject: this.scheduleData.subject,
        visitAddress: this.scheduleData.visitAddress,
        contactPhone: this.scheduleData.contactPhone,
        remark: this.scheduleData.remark,
      });
      this.createScheduleDialog.open();
    } else {
      // 新增模式
      this.boOptions.splice(0, this.boOptions.length);
      if (this.circiKey === '') {
        //無選定顧客，取得行銷人員全部名單
        this.boService.getMarketingPersonAllBOL().subscribe(
          (options) => {
            options.forEach( el => {
              this.boOptions.push(el);
            });
            this.createScheduleDialog.open();
          }
        );

      } else {
        // 選定顧客，取得此顧客名單列表
        this.boService.getCustomerBol(this.circiKey).subscribe(
          (options) => {
            options.forEach( el => {
              this.boOptions.push(el);
            });
            this.createScheduleDialog.open();
          }
        );
      }
    }

  }
  public confirm() {
    if (this.createScheduleForm.form.valid) {
      this.createScheduleForm.submit();
    }
  }
  public cancel() {
    this.createScheduleDialog.close();
  }
  public delete() {
    this.dashboardService.deleteEvent({UUID: this.defaultScheduleData.UUID}).subscribe(
      (resp) => {
        this.createScheduleDialog.close();
      }
    );
  }

  private prepareControls() {
    this.controls = [
      new SingleDropdownControl({
        key: 'BOLNo',
        label: '名單',
        columnClasses: ['12'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.boOptions,
        condition: () => {
          return this.isBOLChoosable;
        }
      }),
      new DatepickerControl({
        key: 'visitDate',
        label: '續訪日期',
        columnClasses: ['6'],
        required: true,
        singleDatePicker: true,
        minDate: moment().format('YYYY/MM/DD'),
        placeholder: '請選擇日期...'
      }),
      new ClockpickerControl({
        key: 'visitTime',
        label: '續訪時間',
        columnClasses: ['6'],
        required: true,
        placeholder: '請選擇時間...'
      }),
      new TextControl({
          key: 'subject',
          label: '主旨',
          columnClasses: ['12'],
          placeholder: 'e.g. 出訪顧客-王大明',
      }),
      new TextControl({
        key: 'visitAddress',
        label: '約訪地址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
      }),
      new TextControl({
        key: 'contactPhone',
        label: '連絡電話',
        columnClasses: ['12'],
        placeholder: 'e.g. 0988125888',
      }),
      new TextareaControl({
        key: 'remark',
        label: '備註',
        isWordCount: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }

  private setFormEditMode(editMode) {
    if (editMode) {
      this.createScheduleForm.form.controls['BOLNo'].disable();
      this.createScheduleForm.form.controls['subject'].disable();
      this.createScheduleForm.form.controls['visitAddress'].disable();
      this.createScheduleForm.form.controls['contactPhone'].disable();
    } else {
      this.createScheduleForm.form.controls['BOLNo'].enable();
      this.createScheduleForm.form.controls['subject'].enable();
      this.createScheduleForm.form.controls['visitAddress'].enable();
      this.createScheduleForm.form.controls['contactPhone'].enable();
    }
  }
}
