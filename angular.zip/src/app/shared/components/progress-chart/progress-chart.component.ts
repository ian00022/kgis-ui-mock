import { Component, OnInit, ViewChild, ElementRef, Input, AfterViewInit } from '@angular/core';
import { PercentPipe } from '@angular/common';
import * as d3 from 'd3';
import { LoggerService } from './../../logger.service';


@Component({
  selector: 'esun-progress-chart',
  templateUrl: './progress-chart.component.html',
  styleUrls: ['./progress-chart.component.scss'],
  providers: [PercentPipe]
})
export class ProgressChartComponent implements OnInit, AfterViewInit {
  @ViewChild('containerPieChart') container: ElementRef;
  @Input() data: any;
  @Input() width = 400;
  @Input() height = 400;
  @Input() remainColor: string = '#F5F7FA';
  @Input() finishColor: string = '#00AD95';


  host: d3.Selection;
  svg: d3.Selection;
  radius: number;
  htmlElement: HTMLElement;
  pieColors: any;
  arcGenerator: any;

  values: Array<any>;

  constructor(
    private logger: LoggerService
  ) { }


  ngOnInit() {
    this.setup();
  }

  ngAfterViewInit() {
    this.htmlElement = this.container.nativeElement;
    this.host = d3.select(this.htmlElement);
    this.buildSVG();
    this.buildPie();
  }

  private setup(): void {
    this.radius = Math.min(this.width, this.height) / 2;
    this.pieColors = d3.scaleOrdinal().range([this.remainColor, this.finishColor]);
    this.logger.debug('data', this.data);
    this.values = [];
    this.data.forEach((data, index) => {
      this.values.push(data.value);
    });
  }

  private buildSVG(): void {
    this.host.html('');
    this.svg = this.host.append('svg')
      .attr('viewBox', `0 0 ${this.width} ${this.height}`)
      .append('g')
      .attr('transform', `translate(${this.width / 2},${this.height / 2})`);
  }

  private buildPie(): void {
    const pie = d3.pie();
    const arcSelection = this.svg.selectAll('.arc')
      .data(pie(this.values))
      .enter()
      .append('g')
      .attr('class', 'arc');

    this.populatePie(arcSelection);
  }

  private populatePie(arcSelection: d3.Selection<d3.pie.Arc>): void {
    const innerRadius = this.radius * 0.5;
    const outerRadius = this.radius;
    this.arcGenerator = d3.arc()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius);

    arcSelection.append('path')
      .attr('d', this.arcGenerator)
      .attr('fill', (datum, index) => this.pieColors(index));
  }
}
