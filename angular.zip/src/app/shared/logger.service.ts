import { Injectable } from '@angular/core';

export enum LOGGER_LEVEL {
  OFF = 0,
  ERROR = 1,
  INFO = 2,
  DEBUG = 3,
  LOG = 4
}

@Injectable()
export class LoggerService {

  private level: LOGGER_LEVEL;

  constructor() {
  }

  public setLevel(level: LOGGER_LEVEL) {
    this.level = level;
  }

  public error(...args) {
    this.writeLog(LOGGER_LEVEL.ERROR, 'ERROR', args);
  }

  public info(...args) {
    this.writeLog(LOGGER_LEVEL.INFO, 'INFO', args);
  }

  public debug(...args) {
    this.writeLog(LOGGER_LEVEL.DEBUG, 'DEBUG', args);
  }

  public log(...args) {
    this.writeLog(LOGGER_LEVEL.LOG, 'LOG', args);
  }


  private writeLog(level, displayString, args) {
    if (this.level === LOGGER_LEVEL.OFF) {
      return;
    }
    if (this.level <= level ) {
      console.log(`[${displayString}]: `, ...args );
    }
  }

}
