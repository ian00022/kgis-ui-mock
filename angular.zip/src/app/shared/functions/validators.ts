import { FormGroup, ValidatorFn, AbstractControl } from '@angular/forms';

export function requiredAny(keys: string[]) {
  return (group: FormGroup): { [key: string]: any } => {
    if ( keys.filter(key => group.controls[key].value).length === 0 ) {
      if ( keys.filter(key => group.controls[key].enabled).length !== 0 ) {
        return {
          requiredAny: true
        };
      }
    }
  };
}

export let PhoneValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (control.value) {
    let isValid = /^[0][9][0-9]{8}$/.test(control.value);
    if (!isValid) {
      return {
        formatError: true
      };
    }
  }
};

export let CirciKeyValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (control.value) {
    let isCustID = /^[A-Z][12][0-9]{8}$/.test(control.value);
    let isCompID = /^[0-9]{8}$/.test(control.value);
    if (!isCompID && !isCustID) {
      return {
        formatError: true
      };
    }
  }
};