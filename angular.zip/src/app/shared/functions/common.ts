import * as _ from 'lodash';

export const emptyStringToNull = (inputObject) => {

  _.forEach(inputObject, function (value, key) {
    if (_.isObject(value) && !_.isEmpty(value) && !_.isArray(value)) {
      return emptyStringToNull(value);
    } else if (
      _.isEmpty(value) ||
      ( _.isString(value) && _.isEmpty(_.trim(value)) )
    ) {
      inputObject[key] = null;
    }
  });

  return inputObject;
};

/**
 * 用以提取oData及sData的key (指定特定的key出來)
 * @param obj sData or oData等來自於api的JSON data
 * @param keys  需要比較的key
 */
export const formInputsFromData = (obj, keys) => {
  const InputsFromData = {};
  _.forEach(obj, (value, key) => {
    if (_.includes(keys, key)) {
      InputsFromData[key] = value;
    }
  });
  return InputsFromData;
}
