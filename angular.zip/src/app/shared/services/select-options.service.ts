import { ProductHelper } from './../../core/models/comm-data';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { ISelectOptionModel } from '../../core/models/comm-data';
import { Observable, Subject } from 'rxjs';
import { NotificationPublishCategory, ManagementWFStatusHelper } from '../../management/management.model';

export class StaticSelectOptionsService {
  public static optionsLabel = {
    prod: ProductHelper.ProductLabelMap,
    referralProd: ProductHelper.ProductLabelMap,
    boStatus: {
      'INIT':  '未執行',
      'INPRG':  '追蹤中',
      'SUBMT':  '已受理',
      'RJECT':  '婉拒',
      'REF':  '轉介其他商品',
    },
    detailStatus: {
      'INIT': '未執行',
      'END': '已結案',
    },
    productType: {
      '1': '信貸',
      '3': '房貸',
      '4': '小型企業(SB)',
    },
    boSource: {
      '1': 'EBM',
      '2': '網路進件',
      '3': '系統轉介',
      '4': '自建名單',
    },
    bolReviewStatus: {
      'INIT': '未執行',
      'INPRG': '追蹤中',
      'SUBMT': '已受理',
      'RJECT': '婉拒',
      'REF': '轉介其他商品',
      'SYCLOS': '系統自動銷案',
      'DUP': '重複商機結案',
    },
    marketingTeamCategory: {
      '1':'空中AO',
      '2':'SBC',
      '3':'消金中心',
    },

  };

  public static getOptionLabel(key, target): string {
    return this.optionsLabel[key][target];
  }
}

@Injectable({
  providedIn: 'root'
})
export class SelectOptionsService {
  /**
   * todo 名單來源 & 名單類型連動
   * i.e.
   * 名單來源為網路進件時，名單類型為
   * 額度利率評估、線上申請、網路留言板
   */
  public option$: Observable<any>;
  public optionSubject: Subject<any>;
  /**
   * Bo - bussiness-opportunity
   * selectOptions of Bo module
   *
   * @private
   * @memberof SelectOptionsService
   */
  private boSource: ISelectOptionModel[] = [
    {label: 'EBM', value: '1'},
    {label: '網路進件', value: '2'},
    {label: '系統轉介', value: '3'},
    {label: '自建名單', value: '4'},
  ];
  private boType: ISelectOptionModel[] = [
    {label: '額度利率評估', value: '1'},
    {label: '線上申請', value: '2'},
    {label: '網路留言板', value: '3'},
  ];

  private boStatus = [
    {label: '未執行', value: '未執行'},
    {label: '追蹤中', value: '追蹤中'},
    {label: '已受理', value: '已受理'},
    {label: '婉拒', value: '婉拒'},
  ];

  /**
   * selectOptions of marketing module
   *
   * @private
   * @memberof SelectOptionsService
   */
  private marketingTeamCategory = [
    { label: '空中AO', value: '1' },
    { label: 'SBC', value: '2' },
    { label: '消金中心', value: '3' }
  ];

  private organizationCode = [
    { label: 'C628消金營運部', value: 'C628' },
    { label: 'A1304消金部', value: 'A1304' },
    { label: 'V1304營運部', value: 'V1304' },
  ];

  private notifyReason = [
    { label: '未分派', value: '1' },
    { label: '已分派', value: '2' },
    { label: '未執行', value: '3' },
    { label: '追蹤逾期', value: '4' },
    { label: '到期通知', value: '5' },
  ];

  private notifyEvent = [
    { label: '分派', value: '1' },
    { label: '已達分派上限', value: '2' },
    { label: '改派', value: '3' },
    { label: '轉介', value: '4' },
    { label: '放行', value: '5' },
  ];

  private prodType = ProductHelper.getOptionsOf([
    ProductHelper.CodeEnum.CREDIT,
    ProductHelper.CodeEnum.GUARANTEE,
    ProductHelper.CodeEnum.HOUSE,
    ProductHelper.CodeEnum.SB,
    ProductHelper.CodeEnum.CARD,
    ProductHelper.CodeEnum.INSURENCE,
  ]);

  private notifyMethod = [
    { label: '逾期燈號', value: '1' },
    { label: '訊息通知', value: '2' },
    { label: 'Mail彙整通知', value: '3' },
    { label: 'Mail單筆通知', value: '4' }
  ];

  private overdueProductType = ProductHelper.getAllOptions('asc');

  private notifyTo = [...[
    { label: '行銷經辦(名單持有者/受理者)', value: '1' },
    { label: '行銷主管(名單持有者主管)', value: '2' }
  ], ...[
    { label: '(0002) 王經理', value: '0002'} ]];

  private dateType = [
    { label: '日', value: '1' },
    { label: '月', value: '2' },
  ];

  private overdueFrequency = [
    { label: '一次性提醒', value: '1' },
    { label: '每月', value: '4' },
    { label: '每週', value: '3' },
    { label: '每日', value: '2' },
  ];

  private buildingType = [
    { label: '住宅大樓(11層含以上有電梯)', value: '住宅大樓(11層含以上有電梯)' },
    { label: '華廈(10層含以下有電梯)', value: '華廈(10層含以下有電梯)' },
    { label: '公寓(5層含以下無電梯)', value: '公寓(5層含以下無電梯)' },
    { label: '辦公商業大樓', value: '辦公商業大樓' },
    { label: '廠辦', value: '廠辦' },
    { label: '工廠', value: '工廠' },
    { label: '透天厝', value: '透天厝' },
    { label: '農舍', value: '農舍' },
    { label: '套房【1房1(廳)1衛】', value: '套房【1房1(廳)1衛】' },
    { label: '店面(店鋪)', value: '店面(店鋪)' },
    { label: '倉庫、其他', value: '倉庫、其他' },
  ];

  private emailTemplateCategory = [
    { label: '電子DM', value: '1' },
    { label: '感謝信', value: '2' }
  ];

  private emailTemplateProductType = ProductHelper.getAllOptions('asc');


  private bankBranches = [
    { label: '01234 板橋分行', value: '01234'},
    { label: '01235 中和分行', value: '01235'},
    { label: '01236 萬華分行', value: '01236'},
    { label: '01237 信義分行', value: '01237'},
    { label: '01111 林口分行', value: '01111'},
  ];

  private bankSearchRange = [
    {label: '全行', value: '1'},
    {label: '分行', value: '2'},
    {label: '總行', value: '3'},
    {label: '消金中心', value: '4'}
  ];

  private employee = [
    { label: '(11234) 王小明', value: '11234'},
    { label: '(21235) 王中明', value: '21235'},
    { label: '(31236) 華小明', value: '31236'},
    { label: '(41237) 黃小明', value: '41237'},
    { label: '(0001) 王小圖', value: '0001'},
  ];

  private referralProd = ProductHelper.getAllOptions();

  private currencyType = [
    { label: 'AUD澳幣', value: 'AUD'},
    { label: 'CNY人民幣', value: 'CNY'},
    { label: 'NZD紐西蘭幣', value: 'NZD'},
    { label: 'USD美元', value: 'USD'},
    { label: 'ZAR南非幣', value: 'ZAR'},

  ];

  private dateSearchType = [
    { label: '建立日期', value: 'buildDate' },
    { label: '指定回覆日期', value: 'replyDate' },
    { label: '結案日期', value: 'closeDate' }
  ];

  private headOfficeAssignmentType = [
    { label: '貸後追蹤', value: '貸後追蹤' },
    { label: '新聞事件', value: '新聞事件' },
    { label: '行銷商機', value: '行銷商機' },
    { label: '其他', value: '其他' }
  ];

  private publishCategory = [
    { label: '全行行銷人員', value: NotificationPublishCategory.ALL},
    { label: '分行', value: NotificationPublishCategory.BRANCHES},
    { label: '區域', value: NotificationPublishCategory.AREA},
    { label: '消金中心', value: NotificationPublishCategory.CENTER},
    { label: '職系', value: NotificationPublishCategory.USERROLE},
  ];

  /**
   * management
   * selectOptions of management status
   *
   * @private
   * @memberof SelectOptionsService
   */
  private get managementStatus() {
    const arr = [];
    _.forIn(ManagementWFStatusHelper.ManagementWFStatusLabelMap, (value, key) => {
      arr.push({
        label: value,
        value: key
      });
    });
    return arr;
  }
  /**
   *{ label: '停用', value: '0' },
    { label: '啟用', value: '1' },
    { label: '暫存', value: '2' },
    { label: '待覆核', value: '3' }, // 暫存 - 待覆核
    { label: '主管退回', value: '4' }, // 暫存 - 主管退回
   *
  */

  /**
   * option type map
   */
  private map = {
    boType: this.boType,
    boSource: this.boSource,
    boStatus: this.boStatus,
    marketingTeamCategory: this.marketingTeamCategory,
    organizationCode: this.organizationCode,
    notifyReason: this.notifyReason,
    notifyEvent: this.notifyEvent,
    prodType: this.prodType,
    notifyMethod: this.notifyMethod,
    notifyTo: this.notifyTo,
    dateType: this.dateType,
    overdueProductType: this.overdueProductType,
    overdueFrequency: this.overdueFrequency,
    buildingType: this.buildingType,
    emailTemplateCategory: this.emailTemplateCategory,
    emailTemplateProductType: this.emailTemplateProductType,
    bankBranches: this.bankBranches,
    bankSearchRange: this.bankSearchRange,
    employee: this.employee,
    referralProd: this.referralProd,
    currencyType: this.currencyType,
    dateSearchType: this.dateSearchType,
    headOfficeAssignmentType: this.headOfficeAssignmentType,
    agentOptions: [],
    managementStatus: this.managementStatus,
    publishCategory: this.publishCategory
  };

  private optionsLabel = StaticSelectOptionsService.optionsLabel;

  constructor() {
    this.optionSubject = new Subject<any>();
    this.option$ = this.optionSubject.asObservable();
  }

  public getAllSelectOptions() {

  }

  public getOptions(type: string | string[]): any {
    const options = {};
    if (type instanceof Array) {
      for (const typeKey of type) {
        options[typeKey] = _.cloneDeep(this.map[typeKey]);
      }
      return options;
    } else {
      return _.cloneDeep(this.map[type]);
    }
  }

  public getOptionLabel(key, target): string {
    return this.optionsLabel[key][target];
  }
}
