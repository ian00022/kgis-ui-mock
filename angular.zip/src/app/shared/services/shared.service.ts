import { Injectable } from '@angular/core';
import { Lightbox } from 'ngx-lightbox';
import * as XLSX from 'xlsx';

@Injectable()
export class SharedService {

  constructor(private lightbox: Lightbox) { }

  /**
   * open a pop up and show the image
   * @param {string} url url of the image to preview
   */
  public previewImage(url: string) {
    this.lightbox.open([{src: url, caption: '', thumb: ''}], 0);
  }

  public convertToSheetData(data: any[], headMap: any): any[][] {

    let sheetData: any[][] = [];
    const sheetHead: any[] = this.getSheetHead(data[0], headMap);
    const keys = this.getSheetHead(data[0]);

    sheetData.push(sheetHead);
    const sheet = data.map( (el) => {
      const row  = [];
      for (const head of keys) {
        row.push(el[head]);
      }
      return row;
    });

    sheetData = sheetData.concat(sheet);

    return sheetData;
  }

  public writeToSheet(sheetData: any[][], fileName: string = '', sheetName: string = '') {
    fileName = fileName + '.xlsx';
    /* generate worksheet */
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(sheetData);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    /* save to file */
    XLSX.writeFile(wb, fileName);
  }

  private getSheetHead(data: any, map?: any): any[] {
    const head = [];
    for (const key of Object.keys(data)) {
      if (map && map.hasOwnProperty(key)) {
        head.push(map[key]);
      } else {
        head.push(key);
      }
    }
    return head;
  }
}
