import { LabelsFromOptionPipe } from './labels-from-option.pipe';

describe('LabelsFromOptionPipe', () => {
  it('create an instance', () => {
    const pipe = new LabelsFromOptionPipe();
    expect(pipe).toBeTruthy();
  });
});
