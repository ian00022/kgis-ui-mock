import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { DateHelper } from 'app/shared/helper/date-helper';
/*
 * Default Format Date ISO_8601 string to 'YYYY/MM/DD'.
 * Or set customize formatter
 * Usage:
 *   value | dateIso8601:custFormat
 * Example:
 *   {{ 2018-09-19T00:00:00 | dateIso8601:'YYYY.MM.DD' }}
 *   formats to: 2018.09.19
 * Example:
 *   {{ 2018-09-19T00:00:00 | dateIso8601 }}
 *   formats to: 2018/09/19
*/
@Pipe({
  name: 'dateIso8601'
})
export class DateIso8601Pipe implements PipeTransform {

  transform(value: string, custFormat?: any): string {
    const format = custFormat || DateHelper.defaultFormat;

    return moment(value, moment.ISO_8601).format(format);
  }

}
