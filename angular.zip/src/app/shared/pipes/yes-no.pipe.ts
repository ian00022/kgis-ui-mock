import { PipeTransform, Pipe } from '@angular/core';
import * as _ from 'lodash';

@Pipe({ name: 'yesNo' })
export class YesNoPipe implements PipeTransform {
  constructor() { }
  transform(value: any): any {
    if (_.toString(value) === '0') {
      return '否';
    }else if (_.toString(value) === '1') {
      return '是';
    }
    return '';
  }
}