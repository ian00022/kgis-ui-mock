import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pieChartTooltip'
})
export class PieChartTooltipPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const result = [];
    for (const i in value) {
      if ( value.hasOwnProperty(i) ) {
        const target = value[i];
        if (!target.hasOwnProperty('formattedText')) {
          target.formattedText = 'NTD ' + target.value;
        }
        result.push(target);
      }
    }
    return result;
  }

}
