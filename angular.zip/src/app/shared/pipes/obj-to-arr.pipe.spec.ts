import { TestBed, async } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ObjToArrPipe } from 'app/shared/pipes/obj-to-arr.pipe';
import { SharedModule } from 'app/shared/shared.module';


describe('ObjToArrPipe', () => {
  let pipe: ObjToArrPipe;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    pipe = new ObjToArrPipe();
  });

  it('should be transformed to array', async(() => {
    const inputObj = {
        name: 'a funny name',
        mail: 'a funny mail'
    };
    expect(pipe.transform(inputObj)[0].key).toEqual('name');
    expect(pipe.transform(inputObj)[0].value).toEqual('a funny name');
  }));
});
