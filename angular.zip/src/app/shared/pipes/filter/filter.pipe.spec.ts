import { FilterPipeModule } from './filter-pipe.module';
import { FilterPipe } from './filter.pipe';
import { TestBed, async } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


describe('FilterPipe', () => {
  let pipe: FilterPipe;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        FilterPipeModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    pipe = new FilterPipe();
  });

  it('should be filtered', async(() => {    
    expect(pipe.transform([
        {name: 'a funny name'},
        {name: 'another funny name'},
        {name: 'bored name'},
    ], 'funny', 'name').length).toEqual(2);
  }));
});
