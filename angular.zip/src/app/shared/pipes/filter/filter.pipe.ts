import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, filterText: string, attribute: string) {
      if (filterText) {
          filterText = filterText.toLowerCase();
          return value.filter(function (el: any) {
              return el[attribute].toLowerCase().indexOf(filterText) > -1;
          });
      }
      return value;
  }

}
