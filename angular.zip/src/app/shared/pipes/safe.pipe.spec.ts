import { SafePipe } from './safe.pipe';
import { TestBed, async, inject } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { DomSanitizer } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from 'app/shared/shared.module';


describe('SafePipe', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  it('should able to transform without failing', inject([DomSanitizer], (domSanitizer: DomSanitizer) => {
      let pipe = new SafePipe(domSanitizer);
      pipe.transform('<div></div>');
      expect(pipe).toBeTruthy();
  }));
});
