import { DateIso8601Pipe } from './date-iso-8601.pipe';

describe('DateIso8601Pipe', () => {
  it('create an instance', () => {
    const pipe = new DateIso8601Pipe();
    expect(pipe).toBeTruthy();
  });
});
