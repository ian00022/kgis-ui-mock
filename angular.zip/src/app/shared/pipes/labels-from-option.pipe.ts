import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';

@Pipe({
  name: 'labelsFromOption'
})
export class LabelsFromOptionPipe implements PipeTransform {

  transform(value: any, option, separator: string = '、'): any {
    if (_.isEmpty(value) || _.isEmpty(option)) { return ''; }
    const formatValue =
      _.isArray(value) ? value :
      _.includes(value, ',') ? value.split(/,/g) : [value];

    return option
      .filter(opt => formatValue.find(v => opt.value === v))
      .map(opt => opt.label)
      .join(separator);
  }

}
