import { TestBed, async } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { PortalModule } from '@angular/cdk/portal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from 'app/shared/shared.module';
import { PieChartTooltipPipe } from './pie-chart-tooltip.pipe';


describe('PieChartTooltipPipe', () => {
  let pipe: PieChartTooltipPipe;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        PortalModule,
        SharedModule
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    pipe = new PieChartTooltipPipe();
  });

  it('should the value be formatted', async(() => {
    const input = [
      {
        label: '台幣存款',
        value: 22.40
      },
      {
        label: '顧客保險',
        value: 89.131
      },
    ];
    expect(pipe.transform(input)[0].formattedText).toEqual('NTD 22.4');

  }));
});
