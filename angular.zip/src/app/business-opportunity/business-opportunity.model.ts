import { StatusColumn } from '../shared/components/ibm-table/ibm-table.model';
import { BaseResponseDto, WFStatus, DateRange } from 'app/core/models/comm-data';
import { CalendarEventResponseDto } from '../dashboard/dashboard.model';
export enum BOLSearchAction {
  NORMAL_SEARCH = 1,
  REVIEW_SEARCH = 2,
  ASSIGN_SEARCH = 3,
  RETURN_TO_HEAD_SEARCH = 4
}

export enum BOLStatus {
  INIT = 'INIT',
  INPRG =	'INPRG',
  SUBMT =	'SUBMT',
  RJECT = 'RJECT',
  REF =	'REF',
  SYCLOS = 'SYCLOS',
  DUP =	'DUP',
}

export enum BOLSource {
  'EBM' = 1,
  '網路進件',
  '系統轉介',
  '自建名單',
}

export enum BOLFileType {
  IDCARD = '1', // 身分證
  INCOME_PROOF = '2', // 所得證明
  APPLY_DOC = '3', //申請書
  WORK_PROOF = '4', // 工作證明
  COLLATERAL = '5', // 擔保品資料
  COMP_PROOF = '6', // 公司證明文件
  TREASURY_PROOF = '7', // 財資歷證明
  REVENUE_REPORT = '8', // 營收報表
  LOCATION_PHOTO = '9', // 營業地點照片
  OTHER = '10' // 其他
}

export enum HeadCaseDetailType {
  REVIEW = 'review',
  ASSIGNMENT = 'assignment',
  SEARCH = 'search',
  NONE = 'none'
}

// 總行案件資訊 Action
export enum HeadCaseAction {
  SAVE = '1',
  CLOSE = '2'
}

export enum BOLCaseType {
  NORMAL = 'normal', // 一般名單
  HEAD_OFFICE = 'headoffice' // 總行指派案件
}

export interface BOLSelfCreateDto {
  /**
   * 顧客姓名
   */
  customerName: string;
  /**
   * 統一編號
   */
  circiKey: string;
  /**
   * 產品別
   */
  productType?: string;
  /**
   * 來源說明
   */
  caseSourceDesc?: string;
  /**
   * 介紹人姓名
   */
  introducerName?: string;
  /**
   * 介紹人統一編號
   */
  introducerId?: string;
  /**
   * 備註
   */
  remark?: string;
}

export interface BOLUploadInfo {
  /**
   * UUID
   */
  UUID: string;
  /**
   * 名單編號
   */
  BOLNo: string;
}

export interface BOLReturnCaseDto {
  /**
   * UUID
   */
  UUID: string;
}

export interface BOLAssignCaseDto {
  /**
   * UUID
   */
  UUID: string;
  /**
   * 名單編號
   */
  BOLNo: string;
  /**
   * 行銷人員名稱
   */
  marketingPerson: string;
  /**
   * 行銷人員ID
   */
  marketingPersonID: string;
  /**
   * 行銷單位名稱
   */
  marketingUnit: string;
  /**
   * 行銷單位ID
   */
  marketingUnitID: string;
}

export interface BOLNormalCaseSearchParams {
  /**
   * 名單狀態
   */
  bolStatus: string;
  /**
   * 指派日期
   */
  assignedDate: DateRange;
  /**
   * 統一編號
   */
  personCertNo: string;
  /**
   * 行銷單位
   */
  marketingUnit?: string;
  /**
   * 行銷人員
   */
  marketingPerson?: string;
  /**
   * 名單來源
   */
  bolSource: string;
  /**
   * 排序
   */
  orderCol: string;
  /**
   * page filter
   */
  pf: {
    skip: number,
    take: number
  };
}

export interface BOLNormalCaseDto {
  /**
   * UUID
   */
  UUID: string;
  /**
   * 指派日期
   */
  assignedDate: string;
  /**
   * 統一編號
   */
  circiKey: string;
  /**
   * 顧客類別
   */
  customerType: string;
  /**
   * 顧客姓名
   */
  customerName: string;
  /**
   * 產品別
   */
  productType: string;
  /**
   * 行銷單位ID
   */
  marketingUnitId: string;
  /**
   * 行銷單位名稱
   */
  marketingUnitName: string;
  /**
   * 行銷人員ID
   */
  marketingPersonId: string;
  /**
   * 行銷人員姓名
   */
  marketingPersonName: string;
  /**
   * 名單來源
   */
  BOLSource: string;
  /**
   * 名單類別
   */
  BOLType: string;
  /**
   * 名單狀態 Label
   */
  BOLStatusLabel: string;
  /**
   * 名單編號
   */
  BOLNo: string;
  /**
   * 是否顯示對應動作選項
   * showSearchBankAcct: 調閱行內帳務資料
   * showCreateBo: 新增自建名單
   * showReturnHeadoff: 退回總行
   * showSearchGroup: 查找群組名單
   *
   */
  actions?: {
    showSearchBankAcct: boolean
    showCreateBo: boolean
    showReturnHeadoff: boolean
    showSearchGroup: boolean
  };
}

export interface BOLNormalCaseResponseDto {
  /**
   * 指派日期
   */
  AssignedDate: string;
  /**
   * 名單編號
   */
  BOLNo: string;
  /**
   * 名單來源
   */
  BOLSource: string;
  /**
   * 名單狀態
   */
  BOLStatus: string;
  /**
   * 名單狀態 - 狀態細項
   */
  BOLStatusDetail: string;
  /**
   * 名單狀態 - 細項類別
   */
  BOLStatusDetailCategory: string;
  /**
   * 名單類別
   */
  BOLType: string;
  /**
   * 統一編號
   */
  CustomerID: string;
  /**
   * 顧客姓名
   */
  CustomerName: string;
  /**
   * 顧客類別
   */
  CustomerType: string;
  /**
   * 是否有重複名單
   */
  HasDuplicateBol: boolean;
  /**
   * 是否加入最愛
   */
  IsFavorite: boolean;
  /**
   * 行銷人員ID
   */
  MarketingPerson: string;
  /**
   * 行銷人員姓名
   */
  MarketingPersonName: string;
  /**
   * 行銷單位ID
   */
  MarketingUnit: string;
  /**
   * 行銷單位名稱
   */
  MarketingUnitName: string;
  /**
   * 大消金NCS送件處理狀態
   */
  NCSProcessingFlag: string;
  /**
   * 產品別
   */
  Product: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 審批狀態
   */
  WFStatus: WFStatus;
  /**
   * 通知燈號
   */
  NoticeLight: string;
  /**
   * 逾期原因
   */
  //DueReason: string;
  /**
   * 是否逾期
   */
  //IsDue: boolean;

}

export interface BOLNormalCaseTableRowDto extends BOLNormalCaseDto {
  /**
   * 名單狀態燈號
   */
  BOLStatus: StatusColumn;
  /**
   * 顧客360資訊總覽 link
   */
  customerLink: Array<string>;
  /**
   * 顧客360資產類 link
   */
  customerAcctLink: Array<string>;
  /**
   * 產品別 Label
   */
  productTypeLabel: string;
  /**
   * 名單來源 Label
   */
  BOLSourceLabel: string;
  /**
   * 名單連結
   */
  BOLLink: Array<string>;
  /**
   * 是否加入最愛
   */
  isFavorite: boolean;
  /**
   * 是否選取
   */
  checked?: boolean;
  /**
   * 行銷單位 display text
   */
  marketingUnit: string;
  /**
   * 行銷人員 display text
   */
  marketingPerson: string;
}

export interface BOLNormalCaseVisitResponsDto extends BOLNormalCaseResponseDto {
  /**
   * 續訪時間
   */
  VisitTime: string;
}

export interface BOLNormalCaseVisitTableRowDto extends BOLNormalCaseTableRowDto {
  /**
   * 續訪時間
   */
  visitTime: string;
}

export interface BOLNormalCaseDuplicateResponseDto extends BOLNormalCaseResponseDto {
  /**
   * 群組主名單 UUID
   */
  MainBOLUUID: string;
  /**
   * 洽談重點摘要
   */
  PointAbstract: string;
}

export interface BOLNormalCaseDuplicateTableRowDto extends BOLNormalCaseTableRowDto {
  /**
   * 群組主名單 UUID
   */
  mainBOLUUID: string;
  /**
   * 洽談重點摘要
   */
  pointAbstract: string;
  /**
   * 可否選取
   */
  selectable: boolean;
}

export interface BOLHeadofficeCaseResponseDto extends BaseResponseDto {
  /**
   * 激活狀態代碼
   */
  ActiveCode: string;
  /**
   * 申請者員工編號
   */
  ApplyEmpId: string;
  /**
   * 指派單位
   */
  AssignedUnit: string;
  /**
   * 指派單位名稱
   */
  AssignedUnitName: string;
  /**
   * 退回總行FLAG
   */
  BackToHeadOfficeFlag: string;
  /**
   * 退回總行原因
   */
  BackToHeadOfficeReason: string;
  /**
   * 案件類別
   */
  CaseCategory: string;
  /**
   * 案件內容
   */
  CaseContent: string;
  /**
   * 案件編號
   */
  CaseNo: string;
  /**
   * 結案日期
   */
  CloseDate: string;
  /**
   * 建立員工姓名
   */
  CreateEmpName: string;
  /**
   * 行銷人員
   */
  MarketingPerson: string;
  /**
   * 異動狀態
   */
  ModifyStatus: string;
  /**
   * ModifyUUID
   */
  ModifyUUID: string;
  /**
   * 退回原因
   */
  RejectReason: string;
  /**
   * 指定回覆日期
   */
  ReplyDate: string;
  /**
   * 主旨
   */
  Subject: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 覆核者員工編號
   */
  VerifyEmpId: string;
  /**
   * 版本
   */
  Version: string;
}

export interface BOLHeadofficeCaseTableRowDto {
  /**
   * 案件編號
   */
  caseNo: string;
  /**
   * 主旨
   */
  subject: string;
  /**
   * 建立者
   */
  createEmp: string;
  /**
   * 指派單位
   */
  assignedUnit: string;
  /**
   * 指定回覆日期
   */
  replyDate: string;
  /**
   * 結案日期
   */
  closeDate: string;
  /**
   * UUID
   */
  UUID: string;
  /**
   * 建立日期
   */
  createDate: string;
  checked?: boolean;
}

export interface MkPersonWorkStatusResponseDto {
  MarketingPerson: string;
  MarketingPersonName: string;
  TodayAssignedCount: number;
  TodayLimit: number;
  NetRate: number;
  NetTodo: number;
  NetDoing: number;
  EbmRate: number;
  EbmTodo: number;
  EbmDoing: number;
  ReferralRate: number;
  ReferralTodo: number;
  ReferralDoing: number;
}

export interface MkPersonWorkStatusDto {
  marketingPerson: string;
  marketingPersonName: string;
  todayAssignedCount: number;
  todayLimit: number;
  netRate: number;
  netRateBarValue: string;
  netTodo: number;
  netDoing: number;
  ebmRate: number;
  ebmRateBarValue: string;
  ebmTodo: number;
  ebmDoing: number;
  referralRate: number;
  referralRateBarValue: string;
  referralTodo: number;
  referralDoing: number;
  progressData: {value: number}[];
}

export interface BOLDetailResponseDto {
  /// 名單資料
  Bol: GeneralBOL;
  /// EBM明細
  EbmDetail?: EBMDetail;
  /// OLPL線上信貸額度利率評估
  OlplDetail?: NetEvaluationCreditLoanDetail;

  /// OLHL線上房貸額度利率評估
  OlhlDetail?: NetEvaluationHouseLoanDetail;

  /// OLPA(線上信貸申請)名單資訊
  OlpaDetail?: NetOnlineCreditLoanDetail;
  /// OLPA平台審核結果
  OlpaDh?: NetOnlineCreditLoanDH;

  /// OLHA(線上房貸申請)名單資訊
  OlhaDetail?: NetOnlineHouseLoanDetail;

  /// Olmbp網路留言板信貸名單資訊
  OlmbpDetail?: NetMessageBoardCreditLoanDetail;

  /// Olmbh網路留言板房貸名單資訊
  OlmbhDetail?: NetMessageBoardHouseLoanDetail;

  /// 系統轉介名單資訊
  SysReferralDetail?: SystemReferralDetail;

  /// 自建名單資訊
  SelfBuiltDetail?: SelfBuiltDetail;

  /// 行銷接觸紀錄
  MarketingLogs: BOLMarketingLogsResponseDto;
  /// 流程紀錄
  FlowLogs: BOLFlowLogsResponseDto;
  /// 行程資料
  Visit: CalendarEventResponseDto;
  /// 行員上傳附件
  EmpAttachments: BOLFileInfoResponseDto[];
  /// 顧客上傳附件
  CustAttachments?: BOLFileInfoResponseDto[];
  /// 審批狀態
  WFStatus: WFStatus;
}

export interface GeneralBOL {

  /// Guid
  UUID: string;

  /// 名單編號
  BOLNo: string;

  /// 主名單編號Guid
  MainBOLUUID: string;

  /// 通知燈號
  NoticeLight: string;

  /// 名單狀態
  BOLStatus: string;

  /// 名單狀態細項
  BOLStatusDetail: string;

  /// 名單狀態細項類別
  BOLStatusDetailCategory: string;

  /// 洽談重點摘要
  PointAbstract: string;

  /// 顧客類別
  CustomerType: string;

  /// 顧客識別碼
  CustomerID: string;

  /// 戶名
  CustomerName: string;

  /// 電話
  Phone: string;

  /// 案件來源
  CaseSource: string;

  /// 案件來源編號
  CaseNumber: string;

  /// 來源的轉介經辦
  SourceReferralEmpId: string;

  /// 來源的轉介單位
  SourceReferralUnit: string;

  /// 其他說明
  OtherDesc: string;

  /// 產品備註
  ProductRemark: string;

  /// 名單備註
  BOLRemark: string;

  /// 分派日期
  AssignedDate: string;

  /// 行銷單位
  MarketingUnit: string;

  /// 行銷人員
  MarketingPerson: string;

  /// 產品
  Product: string;

  /// 名單來源
  BOLSource: string;

  /// 名單類型
  BOLType: string;

  /// 退回總行FLAG
  BackToHeadOfficeFlag: string;

  /// 退回總行原因
  BackToHeadOfficeReason: string;

  /// 大消金NCS送件處理狀態
  NCSProcessingFlag: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

export interface BOLMarketingLogsResponseDto {
  /// 顧客屬性
  CustomerAttribute: string;

  /// 戶名
  CustomerName: string;

  /// 名單編號
  BOLNo: string;

  /// 名單狀態
  BOLStatus: string;

  /// 名單狀態細項
  BOLStatusDetail: string;

  /// 名單狀態細項類別
  BOLStatusDetailCategory: string;

  /// 逾期燈號
  Overdue: string;

  /// 是否有重複名單
  HasDuplicateBol: string;

  /// 審批狀態
  WFStatus: string;

  /// 名單分派日期
  AssignedDate: string;

  /// 產品類別
  Product: string;

  /// 行銷單位代碼
  MarketingUnit: string;

  /// 行銷單位名稱
  MarketingUnitName: string;

  /// 處理經辦員編
  MarketingPerson: string;

  /// 處理經辦
  MarketingPersonName: string;

  /// 名單來源
  BOLSource: string;

  /// 名單類型
  BOLType: string;

  /// 大消金NCS送件處理狀態
  NCSProcessingFlag: string;

  /// 行銷接觸紀錄備註
  Remarks: BOLRemarkResponseDto[];
}

export interface BOLFlowLogsResponseDto {
  /// Guid>
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 日期時間
  ProcessDatetime: string;

  /// 傳送單位
  TransferUnit: string;

  /// 執行人員
  ExecutedEmpId: string;

  /// 執行事項
  ExecutedItem: string;

  /// 動作
  Action: string;

  /// 受理單位
  ReceivedUnitId: string;

  /// 對象
  ReceivedEmpId: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

export interface BOLRemarkResponseDto {
  /// Guid>
  UUID: string;

  /// 一般名單 Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 備註
  Remark: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

export interface BOLFileInfoResponseDto {
  /// UUID
  UUID: string;

  /// FileName
  FileName: string;

  /// BOLFileType
  BOLFileType: string;

  /// BOLFileProviderType
  BOLFileProviderType: string;

  /// File Download Path
  FileDownloadPath: string;
}

/// EBM明細
export interface EBMDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 案件來源
  CaseSource: string;

  /// 行銷活動名稱
  EcampName: string;

  /// 活動開始日期
  EcampStartDt: string;

  /// 活動結束日期
  EcampEndDt: string;

  /// 主要推薦商品
  ProposedProdId: string;

  /// 顧客接觸類別
  ContactTypeCode: string;

  /// 條件
  Condition: string;

  /// 備註
  Memo: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// OLPL線上信貸額度利率評估
export interface NetEvaluationCreditLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 傳入參數〈S: 有報價，R: 拒貸〉
  ApplyStatus: string;

  /// 序號
  SN: string;

  /// 姓名
  NAME: string;

  /// 身分證字號
  ID: string;

  /// 行動電話
  MOBILE: string;

  /// 申請時間
  APPLY_TIME: string;

  /// 住宅電話
  LIVE_TEL: string;

  /// 電子郵件
  EMAIL: string;

  /// 留言
  COMMENT: string;

  /// 活動代碼
  ACTIVITY_NO: string;

  /// 案件來源
  SOURCE: string;

  /// 貸款金額
  LOAN_AMOUNT: string;

  /// 貸款期數
  LOAN_PERIOD: string;

  /// 優惠專案
  PROJECT_CD: string;

  /// 月付金區間
  MONTHLY_PAYMENT: string;

  /// 利率區間
  INTEREST_RANGE: string;

  /// 適用期限
  EXPIRATION_DATE: string;

  /// 是否寄送申請資訊電子郵件
  SENT_EMAIL: string;

  /// UNICA_TREATMENTCODE
  UNICA_TREATMENTCODE: string;

  /// 風險等級
  PD_LEVEL: string;

  /// 違約機率
  PD: string;

  /// 最高可貸額度
  MAX_LIMIT: string;

  /// 最高可款期數
  MAX_PERIOD: string;

  /// 教育程度代碼
  EDUCATION_LEVEL_CD: string;

  /// 行業代碼
  STD_OCCUPATION_CD: string;

  /// 年齡代碼
  AGE_CD: string;

  /// 年收入代碼
  ANNUAL_INCOME_CD: string;

  /// 工作年資代碼
  EMPLOYMENT_YEAR_CD: string;

  /// 居住現況代碼
  RESIDENT_STATUS_CD: string;

  /// 信用卡使用現況代碼
  CREDIT_CARD_STATUS_CD: string;

  /// 最常使用之信用卡額度代碼
  LIMIT_AMT_CD: string;

  /// 近一個月信用卡帳單總金額代碼
  CREDIT_PAYMENT_AMT_CD: string;

  /// 分期使用現況代碼
  PRE_OWNED_STATUS_CD: string;

  /// 信用卡循環家數代碼
  REVOLVING_CNT_CD: string;

  /// 持有幾家銀行的信用卡代碼
  CREDIT_CARD_NUMBER_CD: string;

  /// 循環金額代碼
  REVOLVING_AMT_CD: string;

  /// 銀行貸款狀況代碼
  DEBT_STATUS_CD: string;

  /// 是否有房貸
  MORTGAGE_FLG: string;

  /// 名下房貸最久已還幾年代碼
  MORTGAGE_YEAR_CD: string;

  /// 貸款金額代碼
  DEBT_AMT_CD: string;

  /// 貸款剩餘金額代碼
  BALANCE_AMT_CD: string;

  /// 是否向銀行申辦貸款
  DEBT_FLG: string;

  /// 是否近三個月的繳款有遲繳
  DELINQUENT_FLG: string;

  /// 是否曾經有信貸、預借現金、或動用循環
  EVER_IN_USE_FLG: string;

  /// 近一年是否有新增任何貸款(含房信車貸)
  LOAN_IN_YEAR_FLG: string;

  /// 前三個月平均存款餘額
  AVG3_AUM_TWD_MD: string;

  /// 信貸舊戶現欠餘額
  PRINCIPAL_BALANCE_AMT: string;

  /// 無貸款主因
  NO_RESULT_REASON_MAIN: string;

  /// 無貸款次因
  NO_RESULT_REASON_SUB: string;

  /// 是否已送至Notes系統
  SEND_TO_NOTES: string;

  /// 修改者
  UPDATER: string;

  /// 修改時間
  UPDATE_TIME: string;

  /// 產品代碼
  PRODUCT_CD: string;

  /// 是否已送至目標系統
  SEND_TO_TARGET: string;

  /// 行銷單位
  PROMOTE_BRCH_CD: string;

  /// 行銷專員
  PROMOTER_EMP_ID: string;

  /// 自動分行指派
  ASSIGNED_BU_NAME: string;

  /// 優惠專案敘述
  PROJECT_DESC: string;

  /// 產品行銷策略夥伴代碼
  MK_PARTNER_CD: string;

  /// 產品行銷策略夥伴推薦人員
  MK_PARTNER_PERSON: string;

  /// 產品行銷合作專案代碼
  MK_PROJECT_CD: string;

  /// 客群行銷資訊
  CUSTOMER_SEGMENT: string;

  /// 是否提供不動產作為擔保品
  IS_REAL_ESTATE_FLG: string;

  /// 不動產地址
  REAL_ESTATE_ADDRESS: string;

  /// 方便聯絡時間
  TIME_AVAILABLE: string;

  /// 系統提示
  SYSTEM_ALERT: string;

  /// 小企貸款平台引入資料
  SB_DATA: string;

  /// 客戶端IP
  CLIENT_IP: string;

  /// 貸款費用
  FEE_AMT: string;

  /// 薪轉客註記
  PAYROLL_IND: string;

  /// 薪轉月收入
  PAYROLL_SALARY: string;

  /// 黑名單原因
  BLACK_REASON: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// OLHL線上房貸（副擔保）額度利率評估
export interface NetEvaluationHouseLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 類別
  Category: string;

  /// 提供不動產抵押
  RealEstateFlg: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 申請序號
  SN: string;

  /// 姓名
  NAME: string;

  /// 身分證字號
  ID: string;

  /// 行動電話
  MOBILE: string;

  /// 送件時間
  APPLY_TIME: string;

  /// 聯絡市話
  LIVE_TEL: string;

  /// 電子郵件
  EMAIL: string;

  /// 留言
  COMMENT: string;

  /// 活動簡訊代碼
  ACTIVITY_NO: string;

  /// 案件來源
  SOURCE: string;

  /// 身分認證方式
  AUTH_TYPE: string;

  /// 額度(元)
  LOAN_AMOUNT: string;

  /// 期數(月)
  LOAN_PERIOD: string;

  /// 專案(優惠專案三選一)
  PROJECT_CD: string;

  /// 優惠專案描述
  PROJECT_DESC: string;

  /// 月付金
  MONTHLY_PAYMENT: string;

  /// 利率區間
  INTEREST_RANGE: string;

  /// 適用期限
  EXPIRATION_DATE: string;

  /// 策略聯盟公司代碼
  MkPartnerCD: string;

  /// 策略聯盟專案代碼
  MkProjectCD: string;

  /// 策略聯盟推廣人員
  MkPartnerPerson: string;

  /// 行銷單位代碼
  PROMOTE_BU: string;

  /// 行銷專員代碼
  PROMOTER_CD: string;

  /// 自動分行指派代碼
  ASSIGNED_BU: string;

  /// UNICA_TREATMENTCODE
  UNICA_TREATMENTCODE: string;

  /// 分數
  SCORE: string;

  /// 風險等級
  PD_LEVEL: string;

  /// 違約機率
  PD: string;

  /// 最高可貸額度(元)
  MAX_LIMIT: string;

  /// 最高期數(月)
   MAX_LOAN_PERIOD: string;

  /// 高總價貸款註記
  HIGH_PRICE_FLAG: string;

  /// 線上估價金額(元)
  HOUSE_VALUE_AMOUNT: string;

  /// 拒貸描述
  REJECT_DESC: string;

  /// 貸款方式
  MTG_PURPOSE_CD: string;

  /// 顧客填的地址
  HOUSE_ADDR: string;

  /// 評估的房屋所在地址
  MTG_HS_HOUSE_ADDR: string;

  /// 房屋型態
  MTG_HS_PATTERN_CD: string;

  /// 房屋的總樓層
  MTG_HS_TOTAL_FLOOR_NO: string;

  /// 房屋所在樓層
  MTG_HS_FLOOR_NO: string;

  /// 屋齡
  MTG_HS_AGE_CD: string;

  /// 屋齡(數字)
  MTG_HS_AGE: string;

  /// 不含車位的房屋坪數
  MTG_HS_BUILDING_AREA_NO_PARK: string;

  /// 房屋座落土地坪數
  MTG_HS_LAND_AREA: string;

  /// 車位註記
  MTG_HS_PARKING_CD: string;

  /// 平面車位數量(元)
  MTG_HS_PARKING_NO: string;

  /// 機械車位數量(元)
  MTG_HS_PARKING_NO_MACHINE: string;

  /// 平面車位單價(元)
  MTG_HS_PARKING_PRICE: string;

  /// 機械車位單價(元)
  MTG_HS_PARKING_PRICE_MACHINE: string;

  /// 平面車位總價(元)
  MTG_TOTAL_HS_PARKING_PRICE: string;

  /// 機械車位總價(元)
  MTG_TOTAL_HS_PARKING_PRICE_MACHINE: string;

  /// 成交總價或是賣方開價(萬)
  MTG_HS_PRICE_CD: string;

  /// 買房配合的房仲
  MTG_AGENT_CD: string;

  /// 房屋是否還在貸款中註記
  MTG_LN_STATUS_CD: string;

  /// 當初的貸款金額(萬)
  MTG_LN_AMOUNT_CD: string;

  /// 當初的貸款餘額(萬)
  MTG_LN_REMAIN_CD: string;

  /// 申請者年齡
  AGE: string;

  /// 申請者職業
  STD_OCCUPATION_CD: string;

  /// 是否已送至Notes系統
  SEND_TO_NOTES: string;

  /// 修改者
  UPDATER: string;

  /// 修改時間
  UPDATE_TIME: string;

  /// 產品代碼
  PRODUCT_CD: string;

  /// 是否已送至目標系統
  SEND_TO_TARGET: string;

  /// 試算結果費用
  FEE_AMT: string;

  /// 客戶端IP
  CLIENT_IP_ADDR: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// OLPA線上信貸申請明細檔
export interface NetOnlineCreditLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
   GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 類別
  Category: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 相同IP申辦筆數
   CaseCount: string;

  /// 相同公司統編申辦筆數
   SameCompanyIdApplyCount: string;

  /// PersonalLoan系統流水編號
   SeqNo: string;

  /// 中文姓名
  ApplicantName: string;

  /// 身分證字號
  ApplicantID: string;

  /// 出生日期
   ApplicantBirthDate: string;

  /// 婚姻狀況
  MaritalStatus: string;

  /// 子女數
   Children: string;

  /// 最高學歷
  EducationLevel: string;

  /// 戶籍地聯絡電話(區域碼)
  PermanentAddressPhoneCode: string;

  /// 戶籍地聯絡電話(電話號碼)
  PermanentAddressPhone: string;

  /// 戶籍地址
  PermanentAddress: string;

  /// 戶籍地址郵遞區號
  PermanentAddressCode: string;

  /// 居住地址
  CurrentAddress: string;

  /// 居住地址郵遞區號
  CurrentPostalCode: string;

  /// 通訊地址(文件寄送地址)
  DocumentPostalAddress: string;

  /// 通訊地址郵遞區號
  DocumentPostalCode: string;

  /// 現住房屋
  CurrentResidenceStatus: string;

  /// 居住地聯絡電話(區域碼)
  HomePhoneCode: string;

  /// 居住地聯絡電話(電話號碼)
  HomePhone: string;

  /// 行動電話
  MobilePhone: string;

  /// 電子郵件信箱
  Email: string;

  /// 公司名稱
  Company: string;

  /// 公司統一編號
  CompanyID: string;

  /// 年所得(萬)
   AnnualIncome: string;

  /// 收入證明
  IncomeCertification: string;

  /// 收入證明(說明欄位)
  IncomeCertificationComment: string;

  /// 公司電話(區域碼)
  OfficePhoneCode: string;

  /// 公司電話(電話號碼)
  OfficePhone: string;

  /// 公司電話(分機)
  OfficePhoneExt: string;

  /// 職業別
  CareerType: string;

  /// 職業別(說明)
  CareerTypeComment: string;

  /// 現職年資(年)
   Seniority: string;

  /// 現職年資(月)
   SeniorityMonth: string;

  /// 貸款金額(萬)
   RequestAmount: string;

  /// 貸款期間(月)
   LoanMonth: string;

  /// 主要貸款用途
  LoanPurpose: string;

  /// 主要貸款用途(說明欄位)
  LoanPurposeComment: string;

  /// IP位址
  IP: string;

  /// 身分認證成功的時間(OAUTH導回申請書的時間)
   AuthSucccessTime: string;

  /// 申請書送出時間
   CreateTime: string;

  /// 認證方式
  AuthType: string;

  /// 案件編號
  CaseNumber: string;

  /// 案件通路
  Source: string;

  /// 上傳檔案個數
   FileCount: string;

  /// 行銷單位代碼
  MarketingDept: string;

  /// 行銷專員員編
  MarketingExecutive: string;

  /// 聯徵查詢狀態
  JCICStatus: string;

  /// OTP發送號碼
  OTPNumber: string;

  /// 專案代碼
  ApprovedCode: string;

  /// 核貸結果
  ApprovedResult: string;

  /// 線上申請補充說明
  Memo: string;

  /// 呈現網頁與否
  DHshowresult: string;

  /// 黑名單註記
  Blacklist: string;

  /// 產品行銷專案
  MKProject: string;

  /// 產品行銷專案策略合作夥伴
  MKPartner: string;

  /// 產品行銷專案策略合作夥伴推薦人員
  MKPartnerPerson: string;

  /// 申請人英文名
  ApplicantFirstName: string;

  /// 申請人英文姓
  ApplicantLastName: string;

  /// 申請人是否具有多重國籍
  MultipleNationality: string;

  /// 多重國籍1
  Nationality1: string;

  /// 多重國籍2
  Nationality2: string;

  /// 多重國籍3
  Nationality3: string;

  /// 多重國籍4
  Nationality4: string;

  /// 是否為政治人物或與政治人物有關係
  PoliticalConnection: string;

  /// 與政治人物的關係(政治人物1)
  ConnectionTypeGroup1: string;

  /// 政治人物性別(政治人物1)
  PoliticianGenderGroup1: string;

  /// 政治人物國籍(政治人物1)
  PoliticianNationalityGroup1: string;

  /// 政治人物中文姓名(政治人物1)
  PoliticianNameGroup1: string;

  /// 政治人物英文名(政治人物1)
  PoliticianFirstNameGroup1: string;

  /// 政治人物英文姓(政治人物1)
  PoliticianLastNameGroup1: string;

  /// 政治人物生日(政治人物1)
   PoliticianBirthDateGroup1: string;

  /// 任職狀態(政治人物1)
  ServiceStatusGroup1: string;

  /// 卸任日期(政治人物1)
  LeaveServiceDateGroup1: string;

  /// 任職國家(政治人物1)
  ServingCountryGroup1: string;

  /// 職稱(政治人物1)
  TitleGroup1: string;

  /// 與政治人物的關係(政治人物2)
  ConnectionTypeGroup2: string;

  /// 政治人物性別(政治人物2)
  PoliticianGenderGroup2: string;

  /// 政治人物國籍(政治人物2)
  PoliticianNationalityGroup2: string;

  /// 政治人物中文姓名(政治人物2)
  PoliticianNameGroup2: string;

  /// 政治人物英文名(政治人物2)
  PoliticianFirstNameGroup2: string;

  /// 政治人物英文姓(政治人物2)
  PoliticianLastNameGroup2: string;

  /// 政治人物生日(政治人物2)
   PoliticianBirthDateGroup2: string;

  /// 任職狀態(政治人物2)
  ServiceStatusGroup2: string;

  /// 卸任日期(政治人物2)
  LeaveServiceDateGroup2: string;

  /// 任職國家(政治人物2)
  ServingCountryGroup2: string;

  /// 職稱(政治人物2)
  TitleGroup2: string;

  /// 與政治人物的關係(政治人物3)
  ConnectionTypeGroup3: string;

  /// 政治人物性別(政治人物3)
  PoliticianGenderGroup3: string;

  /// 政治人物國籍(政治人物3)
  PoliticianNationalityGroup3: string;

  /// 政治人物中文姓名(政治人物3)
  PoliticianNameGroup3: string;

  /// 政治人物英文名(政治人物3)
  PoliticianFirstNameGroup3: string;

  /// 政治人物英文姓(政治人物3
  PoliticianLastNameGroup3: string;

  /// 政治人物生日(政治人物3)
   PoliticianBirthDateGroup3: string;

  /// 任職狀態(政治人物3)
  ServiceStatusGroup3: string;

  /// 卸任日期(政治人物3)
  LeaveServiceDateGroup3: string;

  /// 任職國家(政治人物3)
  ServingCountryGroup3: string;

  /// 職稱(政治人物3)
  TitleGroup3: string;

  /// 與政治人物的關係(政治人物4)
  ConnectionTypeGroup4: string;

  /// 政治人物性別(政治人物4)
  PoliticianGenderGroup4: string;

  /// 政治人物國籍(政治人物4)
  PoliticianNationalityGroup4: string;

  /// 政治人物中文姓名(政治人物4)
  PoliticianNameGroup4: string;

  /// 政治人物英文名(政治人物4)
  PoliticianFirstNameGroup4: string;

  /// 政治人物英文姓(政治人物4)
  PoliticianLastNameGroup4: string;

  /// 政治人物生日(政治人物4)
   PoliticianBirthDateGroup4: string;

  /// 任職狀態(政治人物4)
  ServiceStatusGroup4: string;

  /// 卸任日期(政治人物4)
  LeaveServiceDateGroup4: string;

  /// 任職國家(政治人物4)
  ServingCountryGroup4: string;

  /// 職稱(政治人物4)
  TitleGroup4: string;

  /// 與政治人物的關係(政治人物5)
  ConnectionTypeGroup5: string;

  /// 政治人物性別(政治人物5)
  PoliticianGenderGroup5: string;

  /// 政治人物國籍(政治人物5)
  PoliticianNationalityGroup5: string;

  /// 政治人物中文姓名(政治人物5)
  PoliticianNameGroup5: string;

  /// 政治人物英文名(政治人物5)
  PoliticianFirstNameGroup5: string;

  /// 政治人物英文姓(政治人物5)
  PoliticianLastNameGroup5: string;

  /// 政治人物生日(政治人物5)
   PoliticianBirthDateGroup5: string;

  /// 任職狀態(政治人物5)
  ServiceStatusGroup5: string;

  /// 卸任日期(政治人物5)
  LeaveServiceDateGroup5: string;

  /// 任職國家(政治人物5)
  ServingCountryGroup5: string;

  /// 職稱(政治人物5)
  TitleGroup5: string;

  /// 客群行銷資訊
  OfferName: string;

  /// 黑名單原因
  BlackReason: string;

  /// 薪轉顧客註記
  PayrollInd: string;

  /// 薪轉月收入
   PayrollSalary: string;

  /// 舊貸戶遲繳註記
  DelayYN: string;

  /// 預審風險等級
  OPDLevel: string;

  /// 最高可貸額度
  OMaxLimit: string;

  /// 預給利率
  OInterestFee: string;

  /// 預審費用
  OFeeAmount: string;

  /// 客戶沒有核貸資格的原因
  RejectReason: string;

  /// 客戶沒有核貸資格的原因代碼
  RejectReasonCode: string;

  /// 被刪除的身分證明數量
   DeleteIDFileCount: string;

  /// 被刪除的財力證明數量
   DeleteFinancialStatementCount: string;

  /// 使用者是否被轉往試算結果頁面
  CalculateShowResult: string;

  /// 上傳失敗總數
   FailFailCount: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// OLPA線上信貸申請DH檔
export interface NetOnlineCreditLoanDH {
  /// Guid
  UUID: string;

  /// 線上申請 - 信貸明細檔Guid
  NetOnlineCreditLoanDetailUUID: string;

  /// ApplyOnline.PersonalLoan的系統流水編號
  ApplySeqNo: string;

  /// 系統流水編號
  SeqNo: string;

  /// 風險模型分群
  M_SEG: string;

  /// PD值
  PD: string;

  /// 風險等級(1~15)
  PD_GRADE: string;

  /// 回應代碼
  RETURN_CODE: string;

  /// 回應訊息
  RETURN_MSG: string;

  /// 償債能力評分
  CCCS: string;

  /// 償債能力等級
  CCCS_Level2: string;

  /// 核拒貸組別
  Approve_SegmentID: string;

  /// 核拒貸決策
  Approve_Treatment: string;

  /// 額度組別
  Limit_SegmentID: string;

  /// 額度決策_DBR倍數上限
  Limit_DBRCap: string;

  /// 額度決策_金額上限
  Limit_Treatment: string;

  /// 定價組別
  Pricing_SegmentID: string;

  /// 定價決策_利率
  Pricing_Treatment_Rate: string;

  /// 定價決策_手續費
  Pricing_Treatment_Fee: string;

  /// 貸款期間
  Loan_Period: string;

  /// 綁約期間
  Contract_Period: string;

  /// 免綁約利率
  No_Contract_Rate: string;

  /// 貸款額度
  Loan_Limit: string;

  /// 總費用年百分率
  Total_Fee_Percent: string;

  /// 階段數
  Stage_Number: string;

  /// 第一階段綁約利率
  Rate_Stage1: string;

  /// 第二階段綁約利率
  Rate_Stage2: string;

  /// 第三階段綁約利率
  Rate_Stage3: string;

  /// 第一階免綁約段利率
  Rate_Stage1_NO: string;

  /// 第二階免綁約段利率
  Rate_Stage2_NO: string;

  /// 第三階免綁約段利率
  Rate_Stage3_NO: string;

  /// 第一階段起
  Period_Stage1_S: string;

  /// 第二階段起
  Period_Stage2_S: string;

  /// 第三階段起
  Period_Stage3_S: string;

  /// 第一階段迄
  Period_Stage1_E: string;

  /// 第二階段迄
  Period_Stage2_E: string;

  /// 第三階段迄
  Period_Stage3_E: string;

  /// 寫入時間
  CreateTime: string;

  /// 綁約總費用年百分率
  ContractTFP: string;

  /// 綁約每月還款金額
  ContractMonthlyPayment: string;

  /// 免綁約總費用年百分率
  NoContractTFP: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// OLHA線上房貸申請明細檔
export interface NetOnlineHouseLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 類別
  Category: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 相同IP申辦筆數
  CaseCount: string;

  /// 相同公司統編申辦筆數
  SameCompanyIdApplyCount: string;

  /// 申請案件編號
  APPLY_NO: string;

  /// 認證方式
  AUTH_TYPE_CD: string;

  /// 申請人中文姓名
  NAME: string;

  /// 身分證字號
  CUST_ID: string;

  /// 出生日期
  BIRTHDAY: string;

  /// 行動電話
  MOBILE: string;

  /// 住家電話
  HOME_PHONE: string;

  /// 通訊地址-郵遞區號
  ZIP_CD: string;

  /// 通訊地址-縣市別描述
  CITY_NAME: string;

  /// 通訊地址-鄉鎮市區描述
  TOWN_NAME: string;

  /// 通訊地址-地址(巷弄路街號樓)
  ADDRESS: string;

  /// 現住房屋
  HOUSE_TYPE_VAL: string;

  /// 電子郵件信箱
  EMAIL: string;

  /// 婚姻
  MARRIAGE_VAL: string;

  /// 子女數
  CHILDREN_VAL: string;

  /// 最高學歷描述
  EDUCATION_VAL: string;

  /// 公司名稱
  OFFICE_NAME: string;

  /// 公司電話
  OFFICE_PHONE: string;

  /// 年所得描述
  ANNUAL_INCOME_VAL: string;

  /// 收入來源描述
  INCOME_DOC_VAL: string;

  /// 職稱描述
  JOB_TITLE_VAL: string;

  /// 現職年資-**年
  SENIORITY_YEAR: string;

  /// 現職年資-**月
  SENIORITY_MONTH: string;

  /// 是否完成整份申請書
  APPLY_STATUS: string;

  /// 貸款用途
  APPLY_PURPOSE_VAL: string;

  /// 貸款期間(年)
  LOAN_PERIOD: string;

  /// 貸款金額(新台幣 萬元)
  LOAN_AMOUNT: string;

  /// 行銷單位代碼
  PROMOTE_BRCH_CD: string;

  /// 行銷專員代碼
  PROMOTER_EMP_ID: string;

  /// 自動分行指派名稱
  ASSIGNED_BU_NAME: string;

  /// 貸款房屋所在地址_1-郵遞區號
  MI1_ZIP_CD: string;

  /// 貸款房屋所在地址_1-縣市別
  MI1_CITY_NAME: string;

  /// 貸款房屋所在地址_1-鄉鎮市區
  MI1_TOWN_NAME: string;

  /// 貸款房屋所在地址_1-地址(巷弄路街號樓)
  MI1_ADDRESS: string;

  /// 貸款房屋所在地址-2-郵遞區號
  MI2_ZIP_CD: string;

  /// 貸款房屋所在地址-2-縣市別
  MI2_CITY_NAME: string;

  /// 貸款房屋所在地址-2-鄉鎮市區
  MI2_TOWN_NAME: string;

  /// 貸款房屋所在地址_2-地址(巷弄路街號樓)
  MI2_ADDRESS: string;

  /// 貸款房屋所在地址-3-郵遞區號
  MI3_ZIP_CD: string;

  /// 貸款房屋所在地址-3-縣市別
  MI3_CITY_NAME: string;

  /// 貸款房屋所在地址-3-鄉鎮市區
  MI3_TOWN_NAME: string;

  /// 貸款房屋所在地址_3-地址(巷弄路街號樓)
  MI3_ADDRESS: string;

  /// 貸款房屋所在地址-4-郵遞區號 (保留欄位)
  MI4_ZIP_CD: string;

  /// 貸款房屋所在地址-4-縣市別(保留欄位)
  MI4_CITY_NAME: string;

  /// 貸款房屋所在地址-4-鄉鎮市區(保留欄位)
  MI4_TOWN_NAME: string;

  /// 貸款房屋所在地址_4-地址(巷弄路街號樓) (保留欄位)
  MI4_ADDRESS: string;

  /// 貸款房屋所在地址-5-郵遞區號(保留欄位)
  MI5_ZIP_CD: string;

  /// 貸款房屋所在地址-5-縣市別(保留欄位)
  MI5_CITY_NAME: string;

  /// 貸款房屋所在地址-5-鄉鎮市區(保留欄位)
  MI5_TOWN_NAME: string;

  /// 貸款房屋所在地址_5-地址(巷弄路街號樓) (保留欄位)
  MI5_ADDRESS: string;

  /// 同一關係人-1-身分證號|居留證號|護照號碼
  REL1_CUST_ID: string;

  /// 同一關係人-1-關係
  REL1_RELATIVES_VAL: string;

  /// 同一關係人-1-中文姓名
  REL1_NAME: string;

  /// 同一關係人-1-職稱
  REL1_JOB_TITLE_VAL: string;

  /// 同一關係人-2-身分證號|居留證號|護照號碼
  REL2_CUST_ID: string;

  /// 同一關係人-2-關係
  REL2_RELATIVES__VAL: string;

  /// 同一關係人-2-中文姓名
  REL2_NAME: string;

  /// 同一關係人-2-職稱
  REL2_JOB_TITLE_VAL: string;

  /// 同一關係人-3-身分證號|居留證號|護照號碼
  REL3_CUST_ID: string;

  /// 同一關係人-3-關係
  REL3_RELATIVES__VAL: string;

  /// 同一關係人-3-中文姓名
  REL3_NAME: string;

  /// 同一關係人-3-職稱
  REL3_JOB_TITLE_VAL: string;

  /// 同一關係人-4-身分證號|居留證號|護照號碼
  REL4_CUST_ID: string;

  /// 同一關係人-4-關係
  REL4_RELATIVES__VAL: string;

  /// 同一關係人-4-中文姓名
  REL4_NAME: string;

  /// 同一關係人-4-職稱
  REL4_JOB_TITLE_VAL: string;

  /// 同一關係人-5-身分證號|居留證號|護照號碼
  REL5_CUST_ID: string;

  /// 同一關係人-5-關係
  REL5_RELATIVES__VAL: string;

  /// 同一關係人-5-中文姓名
  REL5_NAME: string;

  /// 同一關係人-5-職稱
  REL5_JOB_TITLE_VAL: string;

  /// 同一關係人-6-身分證號|居留證號|護照號碼
  REL6_CUST_ID: string;

  /// 同一關係人-6-關係
  REL6_RELATIVES__VAL: string;

  /// 同一關係人-6-中文姓名
  REL6_NAME: string;

  /// 同一關係人-6-職稱
  REL6_JOB_TITLE_VAL: string;

  /// 同一關係人-7-身分證號|居留證號|護照號碼
  REL7_CUST_ID: string;

  /// 同一關係人-7-關係
  REL7_RELATIVES__VAL: string;

  /// 同一關係人-7-中文姓名
  REL7_NAME: string;

  /// 同一關係人-7-職稱
  REL7_JOB_TITLE_VAL: string;

  /// 同一關係人-8-身分證號|居留證號|護照號碼
  REL8_CUST_ID: string;

  /// 同一關係人-8-關係
  REL8_RELATIVES__VAL: string;

  /// 同一關係人-8-中文姓名
  REL8_NAME: string;

  /// 同一關係人-8-職稱
  REL8_JOB_TITLE_VAL: string;

  /// 同一關係人-9-身分證號|居留證號|護照號碼
  REL9_CUST_ID: string;

  /// 同一關係人-9-關係
  REL9_RELATIVES__VAL: string;

  /// 同一關係人-9-中文姓名
  REL9_NAME: string;

  /// 同一關係人-9-職稱
  REL9_JOB_TITLE_VAL: string;

  /// 同一關係人-10-身分證號|居留證號|護照號碼
  REL10_CUST_ID: string;

  /// 同一關係人-10-關係
  REL10_RELATIVES__VAL: string;

  /// 同一關係人-10-中文姓名
  REL10_NAME: string;

  /// 同一關係人-10-職稱
  REL10_JOB_TITLE_VAL: string;

  /// 負責企業-1-負責人身分證
  ORG1_CUST_ID: string;

  /// 負責企業-1-同一關係人關係
  ORG1_RELATIVES_VAL: string;

  /// 負責企業-1-公司統一編號
  ORG1_ORG_NO: string;

  /// 負責企業-1-公司名稱
  ORG1_ORG_NAME: string;

  /// 負責企業-2-負責人身分證
  ORG2_CUST_ID: string;

  /// 負責企業-2-同一關係人關係
  ORG2_RELATIVES_VAL: string;

  /// 負責企業-2-公司統一編號
  ORG2_ORG_NO: string;

  /// 負責企業-2-公司名稱
  ORG2_ORG_NAME: string;

  /// 負責企業-3-負責人身分證
  ORG3_CUST_ID: string;

  /// 負責企業-3-同一關係人關係
  ORG3_RELATIVES_VAL: string;

  /// 負責企業-3-公司統一編號
  ORG3_ORG_NO: string;

  /// 負責企業-3-公司名稱
  ORG3_ORG_NAME: string;

  /// 負責企業-4-負責人身分證
  ORG4_CUST_ID: string;

  /// 負責企業-4-同一關係人關係
  ORG4_RELATIVES_VAL: string;

  /// 負責企業-4-公司統一編號
  ORG4_ORG_NO: string;

  /// 負責企業-4-公司名稱
  ORG4_ORG_NAME: string;

  /// 負責企業-5-負責人身分證
  ORG5_CUST_ID: string;

  /// 負責企業-5-同一關係人關係
  ORG5_RELATIVES_VAL: string;

  /// 負責企業-5-公司統一編號
  ORG5_ORG_NO: string;

  /// 負責企業-5-公司名稱
  ORG5_ORG_NAME: string;

  /// 英文名
  APPLICANT_FIRST_NAME: string;

  /// 英文姓
  APPLICANT_LAST_NAME: string;

  /// 是否具有多重國籍
  MULTIPLE_NATIONALITY: string;

  /// 是否具有政治人物關係
  POLITICAL_CONNECTION: string;

  /// 第 1 組國籍名稱
  NATIONALITY1: string;

  /// 第 2 組國籍名稱
  NATIONALITY2: string;

  /// 第 3 組國籍名稱
  NATIONALITY3: string;

  /// 第 4 組國籍名稱
  NATIONALITY4: string;

  /// 第 1 組政治人物
  GROUP_NO1: string;

  /// 與政治人物的關係
  GRP1_CONNECTION_TYPE: string;

  /// 政治人物性別
  GRP1_POLITICIAN_GENDER: string;

  /// 政治人物國籍
  GRP1_POLITICIAN_NATIONALITY: string;

  /// 政治人物中文姓名
  GRP1_POLITICIAN_NAME: string;

  /// 政治人物英文名
  GRP1_POLITICIAN_FIRST_NAME: string;

  /// 政治人物英文姓
  GRP1_POLITICIAN_LAST_NAME: string;

  /// 政治人物生日
  GRP1_POLITICIAN_BIRTHDATE: string;

  /// 任職狀態
  GRP1_SERVICE_STATUS: string;

  /// 卸任日期
  GRP1_LEAVE_SERVICE_DATE: string;

  /// 任職國家
  GRP1_SERVING_COUNTRY: string;

  /// 職稱
  GRP1_TITLE: string;

  /// 第 2 組政治人物
  GROUP_NO2: string;

  /// 與政治人物的關係
  GRP2_CONNECTION_TYPE: string;

  /// 政治人物性別
  GRP2_POLITICIAN_GENDER: string;

  /// 政治人物國籍
  GRP2_POLITICIAN_NATIONALITY: string;

  /// 政治人物中文姓名
  GRP2_POLITICIAN_NAME: string;

  /// 政治人物英文名
  GRP2_POLITICIAN_FIRST_NAME: string;

  /// 政治人物英文姓
  GRP2_POLITICIAN_LAST_NAME: string;

  /// 政治人物生日
  GRP2_POLITICIAN_BIRTHDATE: string;

  /// 任職狀態
  GRP2_SERVICE_STATUS: string;

  /// 卸任日期
  GRP2_LEAVE_SERVICE_DATE: string;

  /// 任職國家
  GRP2_SERVING_COUNTRY: string;

  /// 職稱
  GRP2_TITLE: string;

  /// 第 3 組政治人物
  GROUP_NO3: string;

  /// 與政治人物的關係
  GRP3_CONNECTION_TYPE: string;

  /// 政治人物性別
  GRP3_POLITICIAN_GENDER: string;

  /// 政治人物國籍
  GRP3_POLITICIAN_NATIONALITY: string;

  /// 政治人物中文姓名
  GRP3_POLITICIAN_NAME: string;

  /// 政治人物英文名
  GRP3_POLITICIAN_FIRST_NAME: string;

  /// 政治人物英文姓
  GRP3_POLITICIAN_LAST_NAME: string;

  /// 政治人物生日
  GRP3_POLITICIAN_BIRTHDATE: string;

  /// 任職狀態
  GRP3_SERVICE_STATUS: string;

  /// 卸任日期
  GRP3_LEAVE_SERVICE_DATE: string;

  /// 任職國家
  GRP3_SERVING_COUNTRY: string;

  /// 職稱
  GRP3_TITLE: string;

  /// 第 4 組政治人物
  GROUP_NO4: string;

  /// 與政治人物的關係
  GRP4_CONNECTION_TYPE: string;

  /// 政治人物性別
  GRP4_POLITICIAN_GENDER: string;

  /// 政治人物國籍
  GRP4_POLITICIAN_NATIONALITY: string;

  /// 政治人物中文姓名
  GRP4_POLITICIAN_NAME: string;

  /// 政治人物英文名
  GRP4_POLITICIAN_FIRST_NAME: string;

  /// 政治人物英文姓
  GRP4_POLITICIAN_LAST_NAME: string;

  /// 政治人物生日
  GRP4_POLITICIAN_BIRTHDATE: string;

  /// 任職狀態
  GRP4_SERVICE_STATUS: string;

  /// 卸任日期
  GRP4_LEAVE_SERVICE_DATE: string;

  /// 任職國家
  GRP4_SERVING_COUNTRY: string;

  /// 職稱
  GRP4_TITLE: string;

  /// 第 5 組政治人物
  GROUP_NO5: string;

  /// 與政治人物的關係
  GRP5_CONNECTION_TYPE: string;

  /// 政治人物性別
  GRP5_POLITICIAN_GENDER: string;

  /// 政治人物國籍
  GRP5_POLITICIAN_NATIONALITY: string;

  /// 政治人物中文姓名
  GRP5_POLITICIAN_NAME: string;

  /// 政治人物英文名
  GRP5_POLITICIAN_FIRST_NAME: string;

  /// 政治人物英文姓
  GRP5_POLITICIAN_LAST_NAME: string;

  /// 政治人物生日
  GRP5_POLITICIAN_BIRTHDATE: string;

  /// 任職狀態
  GRP5_SERVICE_STATUS: string;

  /// 卸任日期
  GRP5_LEAVE_SERVICE_DATE: string;

  /// 任職國家
  GRP5_SERVING_COUNTRY: string;

  /// 職稱
  GRP5_TITLE: string;

  /// 申請書PDF檔
  PDF_MEDIA: string;

  /// IP
  IP_ADDR: string;

  /// 產品行銷專案
  MK_PROJECT: string;

  /// 產品行銷專案策略合作夥伴
  MK_PARTNER: string;

  /// 產品行銷專案策略合作夥伴推薦人員
  MK_PARTNER_PERSON: string;

  /// 建檔者
  CREATOR: string;

  /// 建檔時間
  CREATE_TIME: string;

  /// 提供不動產抵押
  RealEstateMortgage: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// Olmbp網路留言板信貸明細檔
export interface NetMessageBoardCreditLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 序號
  Sn: string;

  /// 姓名
  Name: string;

  /// 身分證字號
  Id: string;

  /// 手機
  Mobile: string;

  /// 住宅電話
  LiveTel: string;

  /// 公司電話
  CompanyTel: string;

  /// Email
  Email: string;

  /// 留言
  Comment: string;

  /// 活動代碼
  ActivityNo: string;

  /// 最初之活動代碼
  OriginalActivityNo: string;

  /// 案件來源
  Source: string;

  /// 欲申貸額度
  Amount: string;

  /// 貸款用途
  Purpose: string;

  /// 方便聯絡時間
  ContactTime: string;

  /// 顧客申請日期
  ApplicantDate: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// Olmbh網路留言板房貸明細檔
export interface NetMessageBoardHouseLoanDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 序號
  Sn: string;

  /// 姓名
  Name: string;

  /// 性別
  Sex: string;

  /// 郵遞區號
  LiveZip: string;

  /// 通訊地址
  LiveAddr: string;

  /// 通訊電話
  LiveTel: string;

  /// 手機
  Mobile: string;

  /// Email
  Email: string;

  /// 欲申購房屋郵遞區號
  HouseZip: string;

  /// 欲申購房屋縣市
  HouseAddr: string;

  /// 消金中心
  BranchName: string;

  /// 問券答案1
  Q1: string;

  /// 問券答案2
  Q2: string;

  /// 問券答案3
  Q3: string;

  /// 問券答案4
  Q4: string;

  /// 問券答案5
  Q5: string;

  /// 問券答案6
  Q6: string;

  /// 問券答案7
  Q7: string;

  /// 問券答案8
  Q8: string;

  /// 問券適合房貸
  Result: string;

  /// 活動代碼
  ActivityNo: string;

  /// 是否已送到 Notes
  SentToNotes: string;

  /// 輸入日期
  InputDate: string;

  /// 身分證字號
  Id: string;

  /// 聯絡時間
  ContactTime: string;

  /// 最初之活動代碼
  OriginalActivityNo: string;

  /// 案件來源
  Source: string;

  /// 欲申貸額度
  Amount: string;

  /// 貸款用途
  Purpose: string;

  /// 留言
  Comment: string;

  /// 提供不動產抵押
  RealEstateFlg: string;

  /// 受理單位
  ReceivedUnit: string;

  /// 名單分派說明
  BOLDescription: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

/// 系統轉介名單明細
export interface SystemReferralDetail {

  Product: string;

  SourceReferralUnit: string;

  SourceReferralEmpId: string;

  Phone: string;

  ReferralsProductRemark: string;
}

/// 自建名單資訊
export interface SelfBuiltDetail {
  /// Guid
  UUID: string;

  /// 一般名單主檔Guid
  GeneralBOLUUID: string;

  /// 名單編號
  BOLNo: string;

  /// 顧客姓名
  CustomerName: string;

  /// 身份證字號/統一編號
  IdentityCardNumber: string;

  /// 產品別
  ProductType: string;

  /// 案源說明
  CaseSourceDesc: string;

  /// 介紹人姓名
  IntroducerName: string;

  /// 介紹人統一編號
  IntroducerId: string;

  /// 備註
  Remark: string;

  /// 建立者
  CreateEmpId: string;

  /// 建立日期
  CreateDate: string;

  /// 更新者
  UpdateEmpId: string;

  /// 更新日期
  UpdateDate: string;
}

export interface LoanDeliveryResponseDto {
  /// 名單GUID
  UUID: string;

  /// 名單編號
  BOLNo: string;

  /// 大消金案件編號
  NCSCode: string;

  /// 批覆書編號
  ApprovalSN: string;

  /// 名單狀態
  BOLStatus: string;

  /// 送件日期
  DeliveryDate: string;

  /// 撥款日期
  GrantDate: string;

  /// 統一編號
  CustomerID: string;

  /// 戶名
  CustomerName: string;

  /// 產品
  Product: string;

  /// 名單來源
  BOLSource: string;

  /// 名單類型
  BOLType: string;

  /// 行銷單位
  MarketingUnit: string;

  /// 行銷人員
  MarketingPerson: string;

  /// 審核經辦
  CheckCreditClerk: string;

  /// 核准金額
  ApprovalAmount: string;

  /// 狀態(對應大消金系統列表欄位：狀態+案件進度，例如：編輯中-徵信經辦)
  Status: string;

  /// 批覆書核准日期 (以過授信經辦後的資料為主)
  ApprovedDate: string;

  /// 銷案日期
  CancelDate: string;

  /// 婉拒日期
  RefusedDate: string;

  /// 撤件日期
  WithdrawalDate: string;
}

export interface LoanDeliveryTableRowDto {
  /// UUID
  UUID: string;

  /// 名單編號
  BOLNo: string;

  /// 大消金狀態
  NCSStatus: string;

  /// 行銷單位
  marketingUnit: string;

  /// 行銷人員
  marketingPerson: string;

  /// 審核經辦
  checkCreditClerk: string;

  /// 核准金額
  approvalAmount: string;

  /// 送件日期
  deliveryDate: string;

  /// 撥款日期
  grantDate: string;

  /// 統一編號
  customerID: string;

  /// 戶名
  customerName: string;

  /// 顧客360資訊總覽連結
  customerLink: Array<string>;

  /// 產品
  productTypeLabel: string;

  /// 名單狀態
  BOLStatus: string;

  /// 名單來源
  BOLSource: string;

  /// 名單來源 Label
  BOLSourceLabel: string;

  /// 名單類型
  BOLType: string;

  /// 名單連結
  BOLLink: Array<string>;
}
