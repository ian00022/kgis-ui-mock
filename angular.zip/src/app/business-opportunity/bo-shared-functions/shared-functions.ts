// angular module
import { ValidatorFn, FormGroup } from '@angular/forms';
// 3rd party module
import * as _ from 'lodash';
// model
import { BOLNormalCaseTableRowDto } from '../business-opportunity.model';
import { StatusProcess } from 'app/shared/components/ibm-table/ibm-table.model';
import { ControlBase } from './../../shared/components/dynamic-form/controls/control-base';
// helper
import { BolHelper } from 'app/business-opportunity/bol-helper';

export default class BOSharedFunctions {
    // 是否顯示退回總行
    public static showReturnHeadoff(selectedRowData: BOLNormalCaseTableRowDto): boolean {
        if (selectedRowData) {
            // 潛客不顯示退回總行
            if (_.toString(selectedRowData.customerType) === '1') {
                return false;
            }
            return selectedRowData.BOLStatus.process !== StatusProcess.WAIT;
        } else {
            return false;
        }
    }

    public static showSearchGroup(selectedRowData: BOLNormalCaseTableRowDto): boolean {
      if (selectedRowData) {
        return selectedRowData.BOLStatus.process === StatusProcess.DUPLICATE;
      } else {
        return true;
      }
    }

    public static showCreateBo(selectedRowData: BOLNormalCaseTableRowDto): boolean {
      if (selectedRowData) {
        // customerType === 1 為潛在顧客
        return _.toString(selectedRowData.customerType) !== '1';
      } else {
        return false;
      }
    }

    public static showSearchBankAcct(selectedRowData: BOLNormalCaseTableRowDto): boolean {
      if (selectedRowData) {
        // customerType === 1 為潛在顧客
        return _.toString(selectedRowData.customerType) !== '1';
      } else {
        return false;
      }
    }

    public static getGeneralUUID(boDetail: any): string {
        const bolNo = boDetail['Bol']['BOLNo'];
        const filteredData = boDetail['MarketingLogs'].filter(el => {
            let result = BolHelper.processMarketingLog(el);
            return result['BOLNo'] === bolNo;
        });
        if ( filteredData.length > 0 ) {
            return boDetail['Bol']['UUID'];
        }
        return '';
    }

    public static yesNoConverter(value: any): string {
        if (_.toString(value) === '0') {
            return '否';
        }else if (_.toString(value) === '1') {
            return '是';
        }
        return '';
    }

    public static headofficeFormValidators(controls: ControlBase<any>[]): ValidatorFn {
      return (form: FormGroup): { [key: string]: any } => {
        if (!_.isNull(form.controls['type'].value)) {
          _.find(controls, ['key', 'selectDate']).required = true;
          // 日期類型有選取時，日期為必填
          if (_.isNull(form.controls['selectDate'].value)) {
            // 顯示 required 紅點
            return {
              selectDateRequire: true
            };
          }
        } else {
          // 關閉 required 紅點
          _.find(controls, ['key', 'selectDate']).required = false;
        }
      };
    }
}
