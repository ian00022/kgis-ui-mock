import { StaticSelectOptionsService } from 'app/shared/services/select-options.service';
import { StatusLight } from './../shared/components/ibm-table/ibm-table.model';
import * as _ from 'lodash';
import { StatusProcess } from '../shared/components/ibm-table/ibm-table.model';
import { BOLStatus, BOLSource } from './business-opportunity.model';

export class BolHelper {
  constructor() {}

  public static transferBolStatus(value: any): any {
    return {
      light: value['IsDue'] ? StatusLight.RED : StatusLight.GRAY,
      text: this.toBOLStatus(value),
      process: _.result(value, 'WFStatus.Action', false) ? this.getStatusProcess(value['WFStatus'].Action) : (value['HasDuplicateBol'] ? StatusProcess.DUPLICATE : StatusProcess.NONE ),
      frontTooltip: value['IsDue'] ? value['DueReason'] : '',
      backTooltip: _.result(value, 'WFStatus.ActionLog', false) ? value['WFStatus'].ActionLog : (value['HasDuplicateBol'] ? '重複商機' : ''),
      wfStatus: value['WFStatus'],
      detailTooltip: this.toDetailTooltip(value),
      detailTooltipType: value['BOLStatusDetailCategory'] || '',
      otherData: value
    };
  }

  public static toDetailTooltip(value): string {
    if (value['BOLStatus'] === 'SUBMT' || value['BOLStatus'] === 'DUP') {
      return StaticSelectOptionsService.getOptionLabel('prod', value['product']);
    }
    if (value['BOLStatusDetail']) {
      return value['BOLStatusDetail'];
    }
    return '';
  }

  public static toBOLStatus(value): string {
    let processingPrompt = '';
    if (value) {
      if (value['BOLStatus'] === 'SUBMT' && _.toString(value['NCSProcessingFlag']) === '1') {
        processingPrompt = '(送件處理中...)';
      }
      return BOLStatus[value['BOLStatus']] + processingPrompt;
    }
    return '';
  }

  public static getBolSource(source) {
    return BOLSource[source];
  }

  public static getCustLink(row: any): any[] {
    // bol data need customerType
    const overview = _.result(row, 'circiKey.length') === 8 ? 'comp-overview' : 'cust-overview';
    return ['/clients', 'client', row.circiKey? row.circiKey : '', overview];
  }

  public static processNormalCaseTableData(value): any {
    return {
      UUID: value['UUID'],
      assignedDate: value['AssignedDate'],
      circiKey: value['CustomerID'],
      customerName: value['CustomerName'],
      customerType: value['CustomerType'], // 1.潛在顧客 2.既有顧客
      productType: value['Product'],
      marketingUnit: value['MarketingUnit'],
      marketingPerson: value['MarketingPerson'],
      BOLSource: value['BOLSource'],
      BOLType: value['BOLType'],
      BOLNo: value['BOLNo'],
      BOLName: value['BOLName'],
      status: this.transferBolStatus(value),
      isFavorite: value['IsFavorite'],
      WFStatus: _.result(value, 'WFStatus.Action', null),
      isDue: value['IsDue'],
      dueReason: value['DueReason'],
      hasDuplicateBol: value['HasDuplicateBol'],
      visitTime: value['VisitTime']
    };
  }

  public static processHeadOfficCaseTableData(value): any {
    return {
      UUID: value['UUID'],
      caseNo: value['CaseNo'],
      subject: value['Subject'],
      assignedUnit: value['AssignedUnit'],
      replyDate: value['ReplyDate'],
      closeDate: value['CloseDate'],
      caseCategory: value['CaseCategory'],
      caseContent: value['CaseContent'],
      activeCode: value['ActiveCode'],
      applyEmpId: value['ApplyEmpId'],
      verifyEmpId: value['VerifyEmpId'],
      backToHeadOfficeFlag: value['BackToHeadOfficeFlag'],
      backToHeadOfficeReason: value['BackToHeadOfficeReason'],
      createEmpId: value['CreateEmpId'],
      createDate: value['CreateDate'],
      updateEmpId: value['UpdateEmpId'],
      updateDate: value['UpdateDate'],
    };
  }

  public static processMarketingLog(value): any {
    return {
      BOLNo: value['BOLNo'],
      BOLStatus: value['BOLStatus'],
      customerAttribute: value['customerAttribute'],
      customerName: value['CustomerName'],
      overdue: value['Overdue'],
      auditFlag: value['AuditFlag'],
      assignedDate: value['AssignedDate'],
      product: value['Product'],
      marketingPerson: value['MarketingPerson'],
      marketingPersonName: value['MarketingPersonName'],
      marketingUnit: value['marketingUnit'],
      marketingUnitName: value['marketingUnitName'],
      BOLSource: value['BOLSource'],
      BOLSourceDesc: value['BOLSourceDesc'],
      NCSProcessingFlag: value['NCSProcessingFlag'],
      BOLType: value['BOLType'],
      remarks: value['Remarks'].map( el => this.processRemark(el)),
      remarkEditable: false
    };

  }

  public static processRemark(value): any {
    return {
      UUID: value['UUID'],
      generalBOLUUID: value['GeneralBOLUUID'],
      BOLNo: value['BOLNo'],
      remark: value['Remark'],
      createEmpId: value['CreateEmpId'],
      createDate: value['CreateDate'],
      updateEmpId: value['UpdateEmpId'],
      updateDate: value['UpdateDate'],
    };
  }

  public static processFlowLogs(value): any {
    return {
      UUID: value['UUID'],
      generalBOLUUID: value['GeneralBOLUUID'],
      BOLNo: value['BOLNo'],
      processDatetime: value['ProcessDatetime'],
      transferUnit: value['TransferUnit'],
      executedEmpId: value['ExecutedEmpId'],
      executedItem: value['ExecutedItem'],
      action: value['Action'],
      receivedUnitId: value['ReceivedUnitId'],
      receivedEmpId: value['ReceivedEmpId'],
      createEmpId: value['CreateEmpId'],
      createDate: value['CreateDate'],
      updateEmpId: value['UpdateEmpId'],
      updateDate: value['UpdateDate'],
    };
  }

  private static getStatusProcess(process: string) {
    switch (process) {
      case 'WaitForApproval':
        return StatusProcess.WAIT;
      case 'Rejected':
        return StatusProcess.REJECT;
      case 'Approved':
      return StatusProcess.NONE;
    }
  }
}
