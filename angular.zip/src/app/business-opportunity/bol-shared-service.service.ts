import { Injectable } from '@angular/core';
import { AuthService } from 'app/core/services/auth.service';
import { BolHelper } from 'app/business-opportunity/bol-helper';
import { HeadCaseDetailType } from './business-opportunity.model';

@Injectable()
export class BolSharedService {

  private headCaseType: HeadCaseDetailType = HeadCaseDetailType.SEARCH;

  constructor(private auth: AuthService ) { }

  public transformMarketRecord(marketingLogs: any[]) {
    return marketingLogs.map( (el) => {
      let result = BolHelper.processMarketingLog(el);
      if (result.hasOwnProperty('remarks') && result.remarks.length > 0) {
        result['subRow'] = result.remarks;
      }
      result['status'] = BolHelper.transferBolStatus(result);
      // 處理經辦為本人才能新增備註
      if (result['marketingPerson'] === this.auth.getLoginUser().loginEmpId) {
        result['remarkEditable'] = true;
      }
      return result;
    });
  }

  public setHeadCaseType(type: HeadCaseDetailType) {
    this.headCaseType = type;
  }

  public getHeadCaseType(): HeadCaseDetailType {
    return this.headCaseType;
  }
}

