// angular module
import { Injectable } from '@angular/core';
// 3rd party module
import * as _ from 'lodash';
// model
import { StatusColumn, StatusLight, StatusProcess, StatusTooltip } from '../shared/components/ibm-table/ibm-table.model';
import { ProductHelper, WFAction } from 'app/core/models/comm-data';
import {
  BOLNormalCaseTableRowDto,
  BOLNormalCaseResponseDto,
  BOLStatus,
  BOLHeadofficeCaseResponseDto,
  BOLHeadofficeCaseTableRowDto,
  BOLNormalCaseVisitResponsDto,
  BOLNormalCaseVisitTableRowDto,
  BOLNormalCaseDuplicateResponseDto,
  BOLNormalCaseDuplicateTableRowDto,
  LoanDeliveryResponseDto,
  LoanDeliveryTableRowDto
} from './business-opportunity.model';
// service
import { BolStatusService } from './bol-status.service';
// helper
import { DateHelper } from 'app/shared/helper/date-helper';

@Injectable({
  providedIn: 'root'
})
export class BolResponseService {

  /**
   * 逾期燈號說明
   *
   * @private
   * @memberof BolResponseService
   */
  private lightDescription = {
    1: '未分派',
    2: '已分派',
    3: '未執行',
    4: '追蹤逾期',
    5: '到期通知',
  };

  /**
   * 名單來源 Label
   *
   * @private
   * @memberof BolResponseService
   */
  private BOLSourceLabel = {
    1: 'EBM',
    2: '網路進件',
    3: '系統轉介',
    4: '自建名單',
  };

  constructor(
    private bolStatus: BolStatusService
  ) { }

  /**
   * 一般名單 Api 回傳值轉成 table row
   *
   * @param {BOLNormalCaseResponseDto} map
   * @returns {BOLNormalCaseTableRowDto}
   * @memberof BolResponseService
   */
  public mapToNormalCaseTableRow(map: BOLNormalCaseResponseDto): BOLNormalCaseTableRowDto {
    return {
      UUID: map.UUID,
      assignedDate: DateHelper.formatDate(map.AssignedDate),
      circiKey: map.CustomerID,
      customerType: map.CustomerType,
      customerName: map.CustomerName,
      customerLink: this.mapCustLink(map, 'overview'),
      customerAcctLink: this.mapCustLink(map, 'assets'),
      productType: map.Product,
      productTypeLabel:  ProductHelper.ProductLabelMap[map.Product],
      marketingUnit: `(${map.MarketingUnit})${map.MarketingUnitName}`,
      marketingPerson: `(${map.MarketingPerson})${map.MarketingPersonName}`,
      marketingUnitId: map.MarketingUnit,
      marketingUnitName: map.MarketingUnitName,
      marketingPersonId: map.MarketingPerson,
      marketingPersonName: map.MarketingPersonName,
      BOLSource: map.BOLSource,
      BOLSourceLabel:  this.BOLSourceLabel[map.BOLSource],
      BOLType: map.BOLType,
      BOLStatusLabel: this.mapBOLStatusText(map),
      BOLStatus: this.transferBolStatus(map),
      BOLNo: map.BOLNo,
      BOLLink: this.mapBOLLink(map),
      isFavorite: map.IsFavorite,
      actions: {
        showCreateBo: this.showCreateBo(map),
        showReturnHeadoff: this.showReturnHeadoff(map),
        showSearchBankAcct: this.showSearchBankAcct(map),
        showSearchGroup: this.showSearchGroup(map),
      }
    };
  }

  /**
   * 總行案件 Api 回傳值轉成 table row
   *
   * @param {BOLHeadofficeCaseResponseDto} map
   * @returns {BOLHeadofficeCaseTableRowDto}
   * @memberof BolResponseService
   */
  public mapToHeadofficeCaseTableRow(map: BOLHeadofficeCaseResponseDto): BOLHeadofficeCaseTableRowDto {
    return {
      caseNo: map.CaseNo,
      subject: map.Subject,
      createEmp: `(${map.CreateEmpId}) ${map.CreateEmpName}`,
      assignedUnit: `(${map.AssignedUnit}) ${map.AssignedUnitName}`,
      replyDate: DateHelper.formatDate(map.ReplyDate),
      closeDate: DateHelper.formatDate(map.CloseDate),
      createDate: DateHelper.formatDate(map.CreateDate),
      UUID: map.UUID,
    };
  }

  /**
   * 今日行程 Api 回傳值轉成 table row
   *
   * @param {BOLNormalCaseVisitResponsDto} map
   * @returns {BOLNormalCaseVisitTableRowDto}
   * @memberof BolResponseService
   */
  public mapToNormalCaseVisitTableRow(map: BOLNormalCaseVisitResponsDto): BOLNormalCaseVisitTableRowDto {
    return {
      UUID: map.UUID,
      assignedDate: DateHelper.formatDate(map.AssignedDate),
      circiKey: map.CustomerID,
      customerType: map.CustomerType,
      customerName: map.CustomerName,
      customerLink: this.mapCustLink(map, 'overview'),
      customerAcctLink: this.mapCustLink(map, 'assets'),
      productType: map.Product,
      productTypeLabel:  ProductHelper.ProductLabelMap[map.Product],
      marketingUnit: `(${map.MarketingUnit})${map.MarketingUnitName}`,
      marketingPerson: `(${map.MarketingPerson})${map.MarketingPersonName}`,
      marketingUnitId: map.MarketingUnit,
      marketingUnitName: map.MarketingUnitName,
      marketingPersonId: map.MarketingPerson,
      marketingPersonName: map.MarketingPersonName,
      BOLSource: map.BOLSource,
      BOLSourceLabel:  this.BOLSourceLabel[map.BOLSource],
      BOLType: map.BOLType,
      BOLStatusLabel: this.mapBOLStatusText(map),
      BOLStatus: this.transferBolStatus(map),
      BOLNo: map.BOLNo,
      BOLLink: this.mapBOLLink(map),
      isFavorite: map.IsFavorite,
      actions: {
        showCreateBo: this.showCreateBo(map),
        showReturnHeadoff: this.showReturnHeadoff(map),
        showSearchBankAcct: this.showSearchBankAcct(map),
        showSearchGroup: this.showSearchGroup(map),
      },
      visitTime: DateHelper.formatTime(map.VisitTime, 'HH:mm:ss')
    };
  }

  /**
   * 重複群組 Api 回傳值轉成 table row
   *
   * @param {BOLNormalCaseDuplicateResponseDto} map
   * @returns {BOLNormalCaseDuplicateTableRowDto}
   * @memberof BolResponseService
   */
  public mapToNormalCaseDuplicateTableRow(map: BOLNormalCaseDuplicateResponseDto): BOLNormalCaseDuplicateTableRowDto {
    return {
      UUID: map.UUID,
      assignedDate: DateHelper.formatDate(map.AssignedDate),
      circiKey: map.CustomerID,
      customerType: map.CustomerType,
      customerName: map.CustomerName,
      customerLink: this.mapCustLink(map, 'overview'),
      customerAcctLink: this.mapCustLink(map, 'assets'),
      productType: map.Product,
      productTypeLabel:  ProductHelper.ProductLabelMap[map.Product],
      marketingUnit: `(${map.MarketingUnit})${map.MarketingUnitName}`,
      marketingPerson: `(${map.MarketingPerson})${map.MarketingPersonName}`,
      marketingUnitId: map.MarketingUnit,
      marketingUnitName: map.MarketingUnitName,
      marketingPersonId: map.MarketingPerson,
      marketingPersonName: map.MarketingPersonName,
      mainBOLUUID: map.MainBOLUUID,
      BOLSource: map.BOLSource,
      BOLSourceLabel:  this.BOLSourceLabel[map.BOLSource],
      BOLType: map.BOLType,
      BOLStatusLabel: this.mapBOLStatusText(map),
      BOLStatus: this.transferBolStatus(map),
      BOLNo: map.BOLNo,
      BOLLink: this.mapBOLLink(map),
      isFavorite: map.IsFavorite,
      pointAbstract: map.PointAbstract,
      selectable: this.mapDupBOLSelectable(map)
    };

  }

  /**
   * 貸款查詢 api 回傳值轉成 table row
   *
   * @param {LoanDeliveryResponseDto} map
   * @returns {LoanDeliveryTableRowDto}
   * @memberof BolResponseService
   */
  public mapToLoanDeliveryTableRow(map: LoanDeliveryResponseDto): LoanDeliveryTableRowDto {
    return {
      UUID: map.UUID,
      NCSStatus: map.NCSCode,
      marketingUnit: map.MarketingUnit,
      marketingPerson: map.MarketingPerson,
      checkCreditClerk: map.CheckCreditClerk,
      approvalAmount: map.ApprovalAmount,
      deliveryDate: DateHelper.formatDate(map.DeliveryDate),
      grantDate: DateHelper.formatDate(map.GrantDate),
      customerID: map.CustomerID,
      customerName: map.CustomerName,
      customerLink: this.mapLoanDeliveryCustLink(map),
      productTypeLabel: ProductHelper.ProductLabelMap[map.Product],
      BOLLink: this.mapLoanDeliveryBOLLink(map),
      BOLStatus: map.BOLStatus,
      BOLSourceLabel:  this.BOLSourceLabel[map.BOLSource],
      BOLSource: map.BOLSource,
      BOLType: map.BOLType,
      BOLNo: map.BOLNo
    };
  }

  /**
   * 名單狀態燈號及 tooltip
   *
   * @param {BOLNormalCaseResponseDto} value
   * @returns {StatusColumn}
   * @memberof BolResponseService
   */
  public transferBolStatus (value: BOLNormalCaseResponseDto): StatusColumn {
    return {
      light: this.mapBOLStatusLight(value), // 逾期燈號
      frontTooltip: this.mapFrontToolTip(value), // 逾期燈號 tooltip
      text: this.mapBOLStatusText(value), // 名單狀態
      detailTooltip: this.mapDetailToolTip(value), // 狀態細項 tooltip
      detailTooltipType: this.mapDetailToolTipType(value) , // 細項類別 tooltip
      process: this.mapBOLProcess(value), // 流程燈號
      backTooltip: this.mapBackToolTip(value), // 流程燈號 tooltip
      otherData: value
    };
  }

  /**
   * 顧客360資訊總覽連結、顧客360資產類連結
   * linkType: overview, asset
   *
   * @private
   * @param {BOLNormalCaseResponseDto} map
   * @param {string} linkType
   * @returns {Array<string>}
   * @memberof BolResponseService
   */
  private mapCustLink(map: BOLNormalCaseResponseDto, linkType: string): Array<string> {
    let path = ['/clients', 'client'];
    if (_.toString(map.CustomerType) === '2') {
      // 判斷是否為既有顧客
      path.push(map.CustomerID);

      if (map.CustomerID.length === 8) {
        // 判斷為公司戶
        path.push(`comp-${linkType}`);

      } else if (map.CustomerID.length === 10 ) {
        // 判斷為個人戶
        path.push(`cust-${linkType}`);
      }
    } else {
      path = [];
    }
    return path;
  }

  /**
   * 名單詳細連結
   *
   * @private
   * @param {BOLNormalCaseResponseDto} map
   * @returns {Array<string>}
   * @memberof BolResponseService
   */
  private mapBOLLink(map: BOLNormalCaseResponseDto): Array<string> {
    return ['/business-op', 'detail', map.BOLNo];
  }

  /**
   * 名單狀態燈號
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusLight}
   * @memberof BolResponseService
   */
  private mapBOLStatusLight(data: BOLNormalCaseResponseDto): StatusLight {
    return _.isNil(data.NoticeLight) ?  StatusLight.GRAY: StatusLight.RED ;
  }

  /**
   * 名單狀態文字
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {string}
   * @memberof BolResponseService
   */
  private mapBOLStatusText(data: BOLNormalCaseResponseDto): string {
    let processingPrompt = '';
    if (data.BOLStatus === BOLStatus.SUBMT && _.toString(data.NCSProcessingFlag) === '1') {
      processingPrompt = '(送件處理中...)';
    }
    return this.bolStatus.mapTo(data.BOLStatus) + processingPrompt;
  }

  /**
   * 名單狀態流程情形
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusProcess}
   * @memberof BolResponseService
   */
  private mapBOLProcess(data: BOLNormalCaseResponseDto): StatusProcess {
    if (data.WFStatus) {
      if (data.WFStatus.Action) {
        switch (data.WFStatus.Action) {

          case WFAction.WAITAPPROVE:
            return StatusProcess.WAIT;

          case WFAction.REJECT:
            return StatusProcess.REJECT;

          case WFAction.APPROVE:
            return StatusProcess.NONE;
        }
      }
    } else if (data.HasDuplicateBol){
      return StatusProcess.DUPLICATE;
    } else if (_.toString(data.NCSProcessingFlag) === '1') {
      return StatusProcess.NCSPROCESSING;
    }
    return StatusProcess.NONE;
  }

  /**
   * 名單狀態燈號的 tooltip
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusTooltip}
   * @memberof BolResponseService
   */
  private mapFrontToolTip(data: BOLNormalCaseResponseDto): StatusTooltip {
    return {
      show: !_.isNil(data.NoticeLight),
      text: this.lightDescription[data.NoticeLight]
    };
  }

  /**
   * 名單狀態的狀態細項 tooltip
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusTooltip}
   * @memberof BolResponseService
   */
  private mapDetailToolTip(data: BOLNormalCaseResponseDto): StatusTooltip {
    let show = false,
        text = '';
    if (data.BOLStatus === BOLStatus.SUBMT || data.BOLStatus === BOLStatus.DUP) {
      show = true;
      text = ProductHelper.mapTo(ProductHelper.CodeEnum[data.Product]);
    } else if (data.BOLStatusDetail) {
      show = true;
      text = data.BOLStatusDetail;
    }
    return {
      show: show,
      text: text
    };
  }

  /**
   * 名單狀態的細項類別 tooltip
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusTooltip}
   * @memberof BolResponseService
   */
  private mapDetailToolTipType(data: BOLNormalCaseResponseDto): StatusTooltip {
    let show = false,
        text = '';
    if (data.BOLStatusDetailCategory) {
      show = true;
      text = '';
    }
    return {
      show: show,
      text: text
    };
  }

  /**
   * 名單狀態流程的 tooltip
   *
   * @private
   * @param {BOLNormalCaseResponseDto} data
   * @returns {StatusTooltip}
   * @memberof BolResponseService
   */
  private mapBackToolTip(data: BOLNormalCaseResponseDto): StatusTooltip {
    let show = false,
        text = '';
    if (data.WFStatus) {
      if (data.WFStatus.ActionLog) {
        show = true;
        text = data.WFStatus.ActionLog;
      }
    } else if (data.HasDuplicateBol) {
      show = true;
      text = '重複商機';
    } else if (_.toString(data.NCSProcessingFlag) === '1') {
      show = true;
      text = '進件處理中';
    }
    return {
      show: show,
      text: text
    };
  }

  /**
   * 潛在顧客不能新增自建名單
   */
  private showCreateBo(data: BOLNormalCaseResponseDto): boolean {
    // customerType = 1 為潛在顧客
    return _.toString(data.CustomerType) !== '1';
  }

  /**
   * 潛在顧客不能退回總行,
   * 名單狀態為待覆核不能退回總行
   */
  private showReturnHeadoff(data: BOLNormalCaseResponseDto): boolean {
    // customerType = 1 為潛在顧客
    if (_.toString(data.CustomerType) === '1') {
      return false;
    }
    // 名單狀態為待覆核不能退回總行
    if (data.WFStatus && data.WFStatus.Action !== WFAction.WAITAPPROVE) {
      return true;
    }
    return false;
  }

  /**
   * 潛在顧客不能調閱行內帳務資料
   */
  private showSearchBankAcct(data: BOLNormalCaseResponseDto): boolean {
    // customerType = 1 為潛在顧客
    return _.toString(data.CustomerType) !== '1';
  }

  /**
   * 有重複資料才能查找群組名單
   */
  private showSearchGroup(data: BOLNormalCaseResponseDto): boolean {
    return data.HasDuplicateBol;
  }

  /**
   * 追蹤中 or 未執行才能選取為重複商機主名單
   */
  private mapDupBOLSelectable(data: BOLNormalCaseDuplicateResponseDto): boolean {
    return data.BOLStatus === BOLStatus.INIT || data.BOLStatus === BOLStatus.INPRG;
  }

  /**
   * map loan delivery customer link
   *
   * @private
   * @param {LoanDeliveryResponseDto} map
   * @returns {Array<string>}
   * @memberof BolResponseService
   */
  private mapLoanDeliveryCustLink(map: LoanDeliveryResponseDto): Array<string> {
    if (map.CustomerID.length === 8) {
      // 判斷為公司戶
      return ['/clients', 'client', map.CustomerID, 'comp-overview'];

    } else if(map.CustomerID.length === 10 ) {
      // 判斷為個人戶
      return ['/clients', 'client', map.CustomerID, 'cust-overview'];
    }
    return [];
  }

  /**
   * map loan delivery BOLLink
   *
   * @private
   * @param {LoanDeliveryResponseDto} map
   * @returns {Array<string>}
   * @memberof BolResponseService
   */
  private mapLoanDeliveryBOLLink(map: LoanDeliveryResponseDto): Array<string> {
    return ['/business-op', 'detail', map.BOLNo];
  }
}
