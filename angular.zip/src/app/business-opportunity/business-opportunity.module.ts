import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

import { BoSearchComponent } from './bo-search/bo-search.component';
import { BoAssignmentComponent } from './bo-assignment/bo-assignment.component';
import { BoHeadCaseDetailComponent } from './bo-head-case-detail/bo-head-case-detail.component';
import { BoReviewComponent } from './bo-review/bo-review.component';
import { BoTodayScheduleComponent } from './bo-today-schedule/bo-today-schedule.component';
import { BoFavoriteComponent } from './bo-favorite/bo-favorite.component';
import { BoLoanProcessComponent } from './bo-loan-process/bo-loan-process.component';

import { BoOnlineLoanComponent } from './bo-detail/bo-online-loan/bo-online-loan.component';
import { BoMessageBoardComponent } from './bo-detail/bo-message-board/bo-message-board.component';
import { BoEbmComponent } from './bo-detail/bo-ebm/bo-ebm.component';
import { BoDetailComponent } from './bo-detail/bo-detail.component';
import { BoSelfCreateComponent } from './bo-detail/bo-self-create/bo-self-create.component';
import { BoRateComponent } from './bo-detail/bo-rate/bo-rate.component';
import { BoTransComponent } from './bo-detail/bo-trans/bo-trans.component';

import { MarketRecordComponent } from './shared-components/market-record/market-record.component';
import { ReturnCaseDialogComponent } from './shared-components/return-case-dialog/return-case-dialog.component';
import { SearchGroupDialogComponent } from './shared-components/search-group-dialog/search-group-dialog.component';
import { UploadFileDialogComponent } from './shared-components/upload-file-dialog/upload-file-dialog.component';
import { BoAssignmentDialogComponent } from './shared-components/bo-assignment-dialog/bo-assignment-dialog.component';

import { BolStatusService } from './bol-status.service';
import { BolResponseService } from './bol-response.service';
import { BolSharedService } from 'app/business-opportunity/bol-shared-service.service';
import { BolProductPipe } from './bol-product.pipe';
import { Permissions } from '../core/models/permissions';
import { NgxPermissionsGuard } from 'ngx-permissions';


const sharedDialogComponents = [
  UploadFileDialogComponent,
  SearchGroupDialogComponent,
  BoAssignmentDialogComponent,
  ReturnCaseDialogComponent,
  MarketRecordComponent
];
@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild([
      {
        path: 'search',
        component: BoSearchComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '名單查詢',
          permissions: {
            redirectTo: '/no-auth',
            only: [
              Permissions.GENERAL_BOL_SEARCH,
              Permissions.HEAD_OFFICE_BOL_SEARCH
            ],
          }
        }
      },
      {
        path: 'favorite',
        component: BoFavoriteComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '我的最愛',
          permissions: {
            redirectTo: '/no-auth',
            only: [ Permissions.MY_FAVORITE_BOL_SEARCH ],
          }
        }
      },
      {
        path: 'schedule',
        component: BoTodayScheduleComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '今日行程',
          permissions: {
            redirectTo: '/no-auth',
            only: [ Permissions.TODAY_VISIT_SEARCH ]
          }
        }
      },
      {
        path: 'loan-process',
        component: BoLoanProcessComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '貸款送件查詢',
          permissions: {
            redirectTo: '/no-auth',
            only: [ Permissions.LOAN_BOL_SEARCH ],
          }
        }
      },
      {
        path: 'review',
        component: BoReviewComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '名單覆核',
          permissions: {
            redirectTo: '/no-auth',
            only: [
              Permissions.GENERAL_BOL_APPROVE_SEARCH,
              Permissions.HEAD_OFFICE_BOL_APPROVE_SEARCH
            ],
          }
        }
      },
      {
        path: 'assignment',
        component: BoAssignmentComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '名單分派',
          permissions: {
            redirectTo: '/no-auth',
            only: [
              Permissions.ASSIGN_GENETAL_BOL_SEARCH,
              Permissions.ASSIGN_HEAD_OFFFICE_SEARCH
            ],
          }
        }
      },
      {
        path: 'detail/:BOLNo',
        component: BoDetailComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '一般名單詳細頁',
          permissions: {
            redirectTo: '/no-auth',
            only: [
              Permissions.GENERAL_BOL_EBM_FIND,
              Permissions.GENERAL_BOL_NET_FIND,
              Permissions.GENERAL_BOL_REFERRAL_FIND,
              Permissions.GENERAL_BOL_SELF_BUILD_FIND
            ],
          }
        }
      },
      {
        path: 'headCase/:UUID',
        component: BoHeadCaseDetailComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '總行指派名單詳細頁',
          permissions: {
            redirectTo: '/no-auth',
            only: [
              Permissions.HEAD_OFFICE_BOL_FIND,
            ],
          }
        }
      },
      { path: '', redirectTo: 'search', pathMatch: 'full' },
    ])
  ],
  declarations: [
    BoSearchComponent,
    BoDetailComponent,
    BoEbmComponent,
    BoSelfCreateComponent,
    BoMessageBoardComponent,
    BoOnlineLoanComponent,
    BoRateComponent,
    BoTransComponent,
    BoAssignmentComponent,
    BoHeadCaseDetailComponent,
    BoReviewComponent,
    BoTodayScheduleComponent,
    BoFavoriteComponent,
    BoLoanProcessComponent,
    ...sharedDialogComponents,
    BolProductPipe,
  ],
  providers: [
    BolSharedService,
    BolStatusService,
    BolResponseService
  ]

// entryComponents: [
  //   ...sharedDialogComponents
  // ]
})
export class BusinessOpportunityModule { }
