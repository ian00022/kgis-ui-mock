import { BolSharedService } from './../../bol-shared-service.service';
import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { BolHelper } from './../../bol-helper';
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-bo-self-create',
  templateUrl: './bo-self-create.component.html',
  styleUrls: ['./bo-self-create.component.scss']
})
export class BoSelfCreateComponent implements OnInit, OnDestroy {


  @Input('bol')
  set bol(value) {
    if (value) {
      if (this.boDetail !== value) {
        this.boDetail = value;
        this.updateDetail();
      }
    }
  }
  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;

  public recordData: any = {};
  public marketRecord: any = {};
  public selfInfo: any = {};
  public remarkInfo: any;
  public boDetail: any = {};
  public uploadInfo: any = {};
  public bolAttachments: any[] = [];
  public Permissions = Permissions;

  private ngUnSubscirbe: Subject<any> = new Subject();
  private generalBOLUUID = '';
  private bolNo = '';

  constructor(
    private bolSharedService: BolSharedService,
    private boService: BusinessOppotunityService
  ) { }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.ngUnSubscirbe.next();
    this.ngUnSubscirbe.complete();
  }

  public updateDetail() {
    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.selfInfo = this.boDetail['SelfBuiltDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.boService.getBOLAttachments(this.bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.bolAttachments = resp.value;
        }
      }
    );

    this.remarkInfo = {
      generalBOLUUID: this.generalBOLUUID,
      bolNo: this.bolNo
    };
  }
}
