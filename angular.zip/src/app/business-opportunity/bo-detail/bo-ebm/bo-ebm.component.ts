import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { BolHelper } from './../../bol-helper';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { BolSharedService } from 'app/business-opportunity/bol-shared-service.service';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-bo-ebm',
  templateUrl: './bo-ebm.component.html',
  styleUrls: ['./bo-ebm.component.scss']
})
export class BoEbmComponent implements OnInit {

  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;
  @Input('bol')
  set bol(value) {
    if (value) {
      if (this.boDetail !== value) {
        this.boDetail = value;
        this.updateDetail();
      }
    }
  }
  public contactData = [
    {
      status: '追蹤中',
      date: '2017/10/28',
      type: '房貸',
      sales: '傅哲仁',
      department: '消金營運部',
    }
  ];

  public recordData: any = [];
  public marketRecord: any = [];
  public ebmInfo: any;
  public remarkInfo: any;
  public boDetail: any = {};
  public uploadInfo: any = {};
  public bolAttachments: any[] = [];
  public Permissions = Permissions;

  private generalBOLUUID = '';
  private bolNo = '';

  constructor(
    private bolSharedService: BolSharedService,
    private boService: BusinessOppotunityService,
     ) { }

  ngOnInit() {
  }

  public updateDetail() {

    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.ebmInfo = this.boDetail['EbmDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.boService.getBOLAttachments(this.bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.bolAttachments = resp.value;
        }
      }
    );

    this.remarkInfo = {
      generalBOLUUID: this.generalBOLUUID,
      bolNo: this.bolNo
    };
  }
}


