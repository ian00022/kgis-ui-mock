import { BolSharedService } from './../../bol-shared-service.service';
import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { BolHelper } from './../../bol-helper';
import { Subject } from 'rxjs';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';
import * as _ from 'lodash';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';
import { Permissions } from 'app/core/models/permissions';

enum CustSelect {
  NOTSELECT = '0',
  WITHCONTRACT = '1',
  WITHOUTCONTRACT = '2'
}

@Component({
  selector: 'esun-bo-online-loan',
  templateUrl: './bo-online-loan.component.html',
  styleUrls: ['./bo-online-loan.component.scss']
})
export class BoOnlineLoanComponent implements OnInit, OnDestroy {

  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;
  // @Input('boDetail') boDetail: any = {};
  @Input('bol')
  set bol(value) {
    if (value) {
      if (this.boDetail !== value) {
        this.boDetail = value;
        this.updateDetail();
      }
    }
  }

  public recordData: any;
  public marketRecord: any = {};
  public creditInfo: any;
  public onlineLoanInfo: any = { };
  public remarkInfo: any;
  public selectedProject: any;
  public calculateResult: any;
  public boDetail: any = {};
  public uploadInfo: any = {};
  public bolAttachments: any[] = [];
  public Permissions = Permissions;

  // 顧客選擇方案 map
  public detailLabelMap = {

  };

  // 審核結果 map
  public DHLabelMap = {
    Loan_Limit: '最高可申貸額度(萬元)',
    Loan_Period: '貸款期間(年)',
    Pricing_Treatment_Rate :'貸款利率(%)',
    Pricing_Treatment_Fee :'貸款費用(元)',
    ContractMonthlyPayment :'每月還款金額(元)',
    Contract_Period :'綁約期間(年)',
  };

  private ngUnSubscribe: Subject<any> = new Subject();
  private generalBOLUUID = '';
  private bolNo = '';
  private custSelect: CustSelect;

  constructor(
    private boService: BusinessOppotunityService,
    private bolSharedService: BolSharedService
    ) { }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get getTaxNumberDialogHeader(): string  {
    // const count = this.onlineLoanInfo.applyInfo ? this.onlineLoanInfo.applyInfo.career.records.length : 0 ;
    // return `相同 統編 申辦筆數(${count})`;
    return `相同統編申辦筆數(2)`;
  }
  get getIpDialogHeader(): string  {
    // const count = this.onlineLoanInfo.applyInfo ? this.onlineLoanInfo.applyInfo.marketMark.records.length : 0 ;
    // return `相同 IP 申辦筆數(${count})`;
    return `相同統編申辦筆數(2)`;
  }

  get isCreditMode(): boolean {
    return this.boDetail['Bol']['CaseSource'] === '3';
  }

  public updateDetail() {
    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.onlineLoanInfo = this.isCreditMode ? this.boDetail['OlpaDetail'] : this.boDetail['OlhaDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.boService.getBOLAttachments(this.bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.bolAttachments = resp.value;
        }
      }
    );


    if (this.isCreditMode) {
      this.custSelect = this.onlineLoanInfo['ApprovedCode'];
      this.selectedProject = this.selectedProjectData(this.custSelect);
      this.calculateResult = this.calculateResultData(this.custSelect);
      // {
      //   title : `顧客選擇方案：${this.selectedDesc(this.custSelect)}`,
      //   data: this.selectedProjectData()
      // }
    }

    this.remarkInfo = {
      generalBOLUUID: this.generalBOLUUID,
      bolNo: this.bolNo
    };
  }

  public hideAML(): boolean {
    if (this.isCreditMode) {
      return _.toString(this.onlineLoanInfo.MultipleNationality) !== '0' && _.toString(this.onlineLoanInfo.PoliticalConnection) !== '0';
    }else {
      return _.toString(this.onlineLoanInfo.MULTIPLE_NATIONALITY) !== '0' && _.toString(this.onlineLoanInfo.POLITICAL_CONNECTION) !== '0';
    }
  }

  private calculateResultData(code): any {
    switch(code) {
      case CustSelect.WITHCONTRACT:
        let contentWithContract = [
          'Loan_Limit',
          'Loan_Period',
          'Pricing_Treatment_Rate',
          'Pricing_Treatment_Fee',
          'ContractMonthlyPayment',
          'Contract_Period',
        ];
        return {
          title: '顧客選擇方案：綁約轉案',
          data: contentWithContract.map( (el) => {
            return {
              title: this.DHLabelMap[el],
              content: this.boDetail['OlpaDetail'][el]
            };
          })
        };
      case CustSelect.WITHOUTCONTRACT:
        let contentWithoutContract = [
          'Loan_Limit',
          'Loan_Period',
          'Pricing_Treatment_Fee',
          'Pricing_Treatment_Rate',
          'ContractMonthlyPayment',
        ];
        return {
          title: '顧客選擇方案：免綁約專案',
          data: contentWithoutContract.map( (el) => {
            return {
              title: this.DHLabelMap[el],
              content: this.boDetail['OlpaDetail'][el]
            };
          })
        };
      case CustSelect.NOTSELECT:
      default:
        return {
          title: '顧客選擇方案：未選擇專案',
          data: []
        };
    }
  }

  private selectedProjectData(code): any {
    let result = [];
    if (this.custSelect === CustSelect.NOTSELECT) {
      result.push({
        title: '未選擇原因',
        content: this.onlineLoanInfo['CalculateShowResult'] === '0' ? '未轉導至試算結果頁面' : '轉導至試算結果頁面'
      });
    }
  }
}
