import { Subject } from 'rxjs';
import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { IbmDialogComponent } from 'app/shared/components/ibm-dialog/ibm-dialog.component';
import { BolHelper } from '../../bol-helper';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';
import { BolSharedService } from 'app/business-opportunity/bol-shared-service.service';
import { Permissions } from 'app/core/models/permissions';

@Component({
  selector: 'esun-bo-message-board',
  templateUrl: './bo-message-board.component.html',
  styleUrls: ['./bo-message-board.component.scss']
})
export class BoMessageBoardComponent implements OnInit, OnDestroy {

  // @Input('boDetail') boDetail: any = {};
  @Input('bol')
  set bol(value) {
    if (value) {
      if (this.boDetail !== value) {
        this.boDetail = value;
        this.updateDetail();
      }
    }
  }
  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;

  public recordData: any;
  public marketRecord: any;
  public messageBoardInfo: any;
  public remarkInfo: any;
  public boDetail: any = {};
  public uploadInfo: any = {};
  public bolAttachments: any[] = [];
  public Permissions = Permissions;

  private ngUnSubscribe: Subject<any> = new Subject();
  private generalBOLUUID = '';
  private bolNo = '';

  constructor(
    private bolSharedService: BolSharedService,
    private boService: BusinessOppotunityService
  ) { }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isCreditMode(): boolean {
    return this.boDetail['Bol']['Product'] === '1';
  }

  public updateDetail() {

    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.messageBoardInfo = this.isCreditMode ? this.boDetail['OlmbpDetail'] : this.boDetail['OlmbhDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.boService.getBOLAttachments(this.bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.bolAttachments = resp.value;
        }
      }
    );

    this.remarkInfo = {
      generalBOLUUID: this.generalBOLUUID,
      bolNo: this.bolNo
    };
  }
}
