// angular module
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { forkJoin ,Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { ClientDetail, ClientType, ReferralProd, ProductHelper, ISelectOptionModel } from './../../core/models/comm-data';
import { BOLStatus } from './../business-opportunity.model';
import { Permissions } from 'app/core/models/permissions';
import { StatusProcess } from 'app/shared/components/ibm-table/ibm-table.model';
import { BOLSelfCreateDto, BOLReturnCaseDto, BOLUploadInfo } from 'app/business-opportunity/business-opportunity.model';
// component
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { ControlBase, TextControl, SingleDropdownControl, TextareaControl, MultiSelectControl, RadioControl, DatepickerControl } from '../../shared/components/dynamic-form/controls';
// service
import { AuthService, BreadcrumbService ,BusinessOppotunityService ,ClientService } from 'app/core/services';
import { LoggerService } from '../../shared/logger.service';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
// helper
import { DateHelper } from './../../shared/helper/date-helper';
import FormatChecker from '../../shared/functions/formatChecker';
// moment
declare var moment: any;

/**
 *  bo detail component
 */
@Component({
  selector: 'esun-bo-detail',
  templateUrl: './bo-detail.component.html',
  styleUrls: ['./bo-detail.component.scss']

})
export class BoDetailComponent implements OnInit, OnDestroy, AfterViewInit {

  /**
   * 自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;

  /**
   * 新增行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;

  /**
   * 上傳文件 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('uploadFile') uploadFileDialog: IbmDialogComponent;

  /**
   * 查找群組名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('searchGroup') searchGroupDialog: IbmDialogComponent;

  /**
   * 退回總行 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;

  /**
   * 新增備註 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;

  /**
   * 資產負債圖 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('assets') assetsDialog: IbmDialogComponent;

  /**
   * 編輯續訪日期 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('editSchedule') editScheduleDialog: IbmDialogComponent;

  /**
   * 編輯洽談重點摘要 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('editPointNote') editPointNoteDialog: IbmDialogComponent;

  /**
   * 編輯洽談重點摘要 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('editPointNoteForm') editPointNoteForm: DynamicFormComponent;

  /**
   * 名單狀態 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('boStatus') boStatusDialog: IbmDialogComponent;

  /**
   * 名單狀態 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('boStatusForm') boStatusForm: DynamicFormComponent;

  /**
   * 警示「不接受電話行銷」 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('warningDialog') warningDialog: IbmDialogComponent;

  /**
   * 編輯潛在顧客 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('editPotential') editPotentialDialog: IbmDialogComponent;

  /**
   * 編輯潛在顧客 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('editPotentialForm') editPotentialForm: DynamicFormComponent;

  /**
   * 確認送由大消金 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoDetailComponent
   */
  @ViewChild('confirmNCS') confirmNCSDialog: IbmDialogComponent;

  /**
   * default data for selfCreateBOL
   *
   * @type {BOLSelfCreateDto}
   * @memberof BoDetailComponent
   */
  public selfCreateBOL: BOLSelfCreateDto;

  public customerDetail: ClientDetail = {} as any;
  public overView: any;
  public type = 'ebm';
  public scheduleBolData = {};
  public remarkInfo = {};
  public BOLRemark: any = {};

  /**
   * 編輯洽談重點摘要 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoDetailComponent
   */
  public editPointNoteControls: ControlBase<any>[] = [];

  /**
   * 名單狀態 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoDetailComponent
   */
  public boStatusControls: ControlBase<any>[] = [];

  public selectedItems: any[] = [];
  public boDetail: any = {};
  public boProcessStatus: any = {};
  public returnList: BOLReturnCaseDto[] = [];
  public isPotentialCustomer = false;
  public bankBranchesOptions: ISelectOptionModel[] = [];
  public employeeOptions: ISelectOptionModel[] = [];
  public boStatusOptions: ISelectOptionModel[] = [
    {value: 'INPRG', label: '追蹤中'},
    {value: 'SUBMT', label: '已受理'},
    {value: 'RJECT', label: '婉拒'},
    {value: 'REF', label: '轉介其他商品'},
  ];
  public productCodeOptions: ISelectOptionModel[] = [];
  public currencyTypeOptions: ISelectOptionModel[] = [];
  public reVisitSchedule: any = {};
  /**
   * info for upload file
   *
   * @type {BOLUploadInfo}
   * @memberof BoDetailComponent
   */
  public uploadInfo: BOLUploadInfo;

  /**
   * permissions enum property for template
   *
   * @memberof BoDetailComponent
   */
  public Permissions = Permissions;

  /**
   * 編輯潛在顧客 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoDetailComponent
   */
  public editPotentialControls: ControlBase<any>[] = [];
  /**
   * 統一編號
   *
   * @private
   * @type {string}
   * @memberof BoDetailComponent
   */
  private circiKey: string;
  /**
   * 名單編號
   *
   * @private
   * @type {string}
   * @memberof BoDetailComponent
   */
  private bolNo: string;

  //潛在顧客資訊
  private pCustInfo: any;

  private updateBOStatusRequestCopy;


  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private route: ActivatedRoute,
    private clientService: ClientService,
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private breadcrumb: BreadcrumbService,
    private router: Router,
    private auth: AuthService,
    private option: SelectOptionsService,
  ) {
    this.bankBranchesOptions = this.option.getOptions('bankBranches');
    this.employeeOptions = this.option.getOptions('employee');
    this.currencyTypeOptions = this.option.getOptions('currencyType');
  }

  public boStatusFormValidators: ValidatorFn = (form: FormGroup): { [key: string]: any } => {
    if (form.controls['BOLStatus'].value === 'REF' &&
      _.parseInt(form.controls['productCode'].value) <= 6) {
        if (_.isNull(form.controls['acceptedReferralUnit'].value)
        || _.isNull(form.controls['acceptedReferralEmpId'].value)) {
          return {
            productCodeSpecialRequire: true
          };
        }
    }
  }

  ngOnInit() {
    this.bolNo = this.route.snapshot.params['BOLNo'];
    this.boService.getBoDetail(this.bolNo).subscribe(
      (resp) => {
        this.boDetail = resp.value;
        this.circiKey = this.boDetail['Bol']['CustomerID'];

        // 顧客為潛在顧客
        if (this.boDetail['Bol']['CustomerType'] === '2') {
          this.isPotentialCustomer = false;
          this.getCust360Data(this.circiKey);

        } else {
          this.isPotentialCustomer = true;
          this.getCustPotential(this.bolNo);
        }

        if (this.boDetail['Bol']['BOLStatus'] === 'INIT' ||
              this.boDetail['Bol']['BOLStatus'] === 'INPRG') {
          this.boDetail['isBOLEditable'] = true;
        } else {
          this.boDetail['isBOLEditable'] = false;
        }

        if (this.boDetail) {
          this.type = this.checkBolType(this.boDetail['Bol']);
          this.initEditPointNoteForm();
          this.initAllDialogInputs();
          this.logger.debug(this.boDetail);
        }
      }
    );

    this.boService.updateTrigger.subscribe(
      (isNeedToUpdate) => {
        if (isNeedToUpdate) {
          this.updateBoDetail();
        }
      }
    );
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.boStatusForm.form.get('detailReject1').valueChanges
      .subscribe(
        (changes) => {
          if (typeof changes === 'object' && changes) {
            this.selectedItems = changes;
          }
        });
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get detailMode(): ClientType {
    return this.customerDetail.customerAttribute;
  }

  get isCompMode(): boolean {
    return this.detailMode === ClientType.COMP;
  }

  public showTag(show: string) {
    return show === 'Y';
  }

  get getLink(): any {
    const id = this.customerDetail.circiKey || '';
    const assetComponent = this.customerDetail.customerAttribute === ClientType.COMP ? 'comp-assets' : 'cust-assets';
    return ['/clients', 'client', id, assetComponent] ;
  }

  get headTitle(): string {
    return this.customerDetail.customerAttribute === ClientType.COMP ? this.customerDetail.name : this.customerDetail.name;
  }

  get isSelectedItemsHidden(): boolean {
    if (this.boStatusForm.form.controls['BOLStatus'].value === 'RJECT' &&
          this.boStatusForm.form.controls['detailReject'].value === '2') {
            return false;
    }
    return true;
  }

  get selectedItemsLabel(): string {
    return this.selectedItems.join(', ');
  }

  get getSource(): string {
    switch (this.type) {
      case 'ebm' :
        return 'EBM';
      case 'messageBoard' :
        return '網路進件-網路留言板';
      case 'onlineLoan' :
        return '網路進件-線上申請';
      case 'rate' :
        return '網路進件-額度利率評估';
      case 'selfCreate' :
        return '自建名單';
      case 'trans' :
        return '轉介名單';
      default:
        return null;
    }
  }

  get getClientAssetLink(): any[] {
    const id = this.customerDetail.circiKey || '';
    const type = this.customerDetail.customerAttribute === ClientType.CUST ? 'cust-assets' : 'comp-assets';
    return ['/clients', 'client', id, type] ;
  }

  get assetsDialogHeader(): string {
    const header = this.customerDetail.name || '';
    return header + ' | 資產分配圖';
  }

  get showBOLStatusUntrackDetail(): boolean {
    return this.boStatusForm.form.controls['BOLStatus'].value === 'INPRG';
  }

  get showBOLStatusRejectDetail(): boolean {
    return this.boStatusForm.form.controls['BOLStatus'].value === 'RJECT';
  }

  get showSearchBankAcct(): boolean {
    if (this.boDetail) {
      return this.boDetail.customerType !== '1';
    } else {
      return false;
    }
  }

  get showCreateBo(): boolean {
    if (this.boDetail) {
      return this.boDetail.customerType !== '1' && this.boDetail.isBOLEditable;
    } else {
      return false;
    }
  }

  get showReturnHeadoff(): boolean {
    if (this.boDetail) {
      if (this.boDetail.customerType !== '1') {
        return false;
      }
      return _.result(this.boDetail, 'WFStatus.Action', null) !== StatusProcess.WAIT;
    } else {
      return false;
    }
  }

  get showSearchGroup(): boolean {
    if (this.boDetail) {
      return _.result(this.boDetail, 'WFStatus.Action', null) === StatusProcess.DUPLICATE;
    } else {
      return true;
    }
  }

  get displayBOLStatus(): string {
    let processingPrompt = '';
    if (this.boDetail.Bol) {
      if (this.boDetail.Bol.BOLStatus === 'SUBMT' && _.toString(this.boDetail.Bol.NCSProcessingFlag) === '1') {
        processingPrompt = '(送件處理中...)';
      }
      return BOLStatus[this.boDetail.Bol.BOLStatus] + processingPrompt;
    }
    return '-';
  }

  get displayBOLStatusDetail(): string {
    let rs = '';
    if (this.boDetail.Bol) {
      if (_.includes(['SUBMT', 'DUP', 'REF'], this.boDetail.Bol.BOLStatus)) {
        rs = this.option.getOptionLabel('prod', this.boDetail.Bol.Product);
      } else {
        rs = this.boDetail.Bol.BOLStatusDetail;
      }
    }
    if (_.isEmpty(rs)) {
      return '-';
    }
    return rs;
  }

  public isFormValid(form): boolean {
    if (form) {
      return form.valid;
    }
    return false;
  }

  public openDialog(dialogType: string) {
    switch (dialogType) {
      case 'createBo':
        this.createBoDialog.open();
        break;
      case 'createSchedule':
        this.createScheduleDialog.open();
        break;
      case 'uploadFile':
        this.uploadFileDialog.open();
        break;
      case 'searchGroup':
        this.searchGroupDialog.open();
        break;
      case 'rejectToHeadOffice':
        this.rejectToHeadOfficeDialog.open();
        break;
      case 'createNote':
        this.createNoteDialog.open();
        break;
      case 'editSchedule':
        this.editScheduleDialog.open();
        break;
      case 'editPointNote':
        this.editPointNoteDialog.open();
        break;
      case 'boStatus':
        this.boStatusDialog.open();
        break;
    }
  }

  public afterCloseDialog(dialogType: string) {
    // switch (dialogType) {
    //   case 'editPointNote':
    //     this.editPointNoteForm.reset();
    //     break;
    //   case 'boStatus':
    //     this.boStatusForm.reset();
    //     break;
    // }

  }
  public handleBoStatusFormSubmit(value: any) {
    let result = _.assign({
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo'],
      WFObjectName: this.boService.getWFObjectName(),
      BaseUrl: this.router.url
    }, _.cloneDeep(value));
    switch(value.BOLStatus) {
      case 'INPRG':
        result['BOLStatusDetail'] = value.detailTrack;
        break;
      case 'SUBMT':

        break;
      case 'RJECT':
        result['BOLStatusDetail'] = value.detailReject;
        result['BOLStatusDetailCategory'] = value.detailReject1 || value.detailReject2;
        break;
      case 'REF':
        result['CustomerID'] = this.customerDetail.circiKey;
        result['CustomerName'] = this.customerDetail.name;
        result['Phone'] = this.customerDetail.phone;
        result['SourceReferralEmpId'] = this.auth.getLoginUser().loginEmpId;
        result['SourceReferralUnit'] = this.auth.getLoginUser().unitId;
        result['MarketingUnit'] = value['acceptedReferralUnit'];
        result['MarketingPerson'] = value['acceptedReferralEmpId'];
        result['Product'] = value['productCode'];
        break;
    }
    if (value.BOLStatus === 'SUBMT' &&
        ( value.product === ProductHelper.CodeEnum.CREDIT ||
          value.product === ProductHelper.CodeEnum.GUARANTEE ||
          value.product === ProductHelper.CodeEnum.HOUSE ||
          value.product === ProductHelper.CodeEnum.SB)) {
      this.updateBOStatusRequestCopy = result;
      this.confirmNCSDialog.open();
    }else {
      this.updateBOLStatus(result);
    }
  }

  public updateBOStatusWith(value: boolean) {
    this.updateBOStatusRequestCopy['IsSubmitNCS'] = value;
    this.updateBOLStatus(this.updateBOStatusRequestCopy);
    this.confirmNCSDialog.close();
  }




  public handleEditPointNoteFormSubmit(value: any) {
    let data = _.assign({
      bolNo: this.bolNo
    }, value);
    this.boService.updatePointAbstract(data).subscribe(
      (resp) => {
        if (resp.isOk) {
          // 更新前端畫面
          // this.boDetail['Bol']['PointAbstract'] = value.pointAbstract;
          this.editPointNoteForm.reset();
          this.updateBoDetail();
        }
        this.editPointNoteDialog.close();
      }
    );
  }

  public confirmClick(form: DynamicFormComponent) {
    if (form.form.valid) {
      form.submit();
    }
  }

  public getChipsClass(bool: boolean): string {
    return bool ? 'text-success' : 'text-danger';
  }

  public getChipsIconClass(bool: boolean): string {
    return bool ? 'fa-check' : 'fa-ban';
  }

  public openChartModal() {
    this.assetsDialog.open();
  }

  public goClientAssets() {
    const assetComponent = this.customerDetail.customerAttribute === ClientType.COMP ? 'comp-assets' : 'cust-assets';
    this.router.navigate(['/clients', 'client', this.customerDetail.circiKey, assetComponent]);
  }

  public updateBoDetail() {
    this.boService.getBoDetail(this.bolNo).subscribe(
      (resp) => {
        this.boDetail = resp.value;
        this.initEditPointNoteForm();
        this.initAllDialogInputs();
        this.initBoStatusForm();
        if (this.boDetail['Bol']['BOLStatus'] === 'INIT' ||
              this.boDetail['Bol']['BOLStatus'] === 'INPRG') {
          this.boDetail['isBOLEditable'] = true;
        } else {
          this.boDetail['isBOLEditable'] = false;
        }
      }
    );
  }

  // 編輯潛在顧客
  public onEditPCustClick() {
    console.log(this.pCustInfo);
    if (this.isCompMode) {
      this.editPotentialForm.form.patchValue({
        customerType: this.pCustInfo['CustomerType'],
        compCustomerName: this.pCustInfo['CustomerName'],
        compPersonCertNo: this.pCustInfo['PersonCertNo'],
        compContactPhone: this.pCustInfo['ContactPhone'],
        compBDate: DateHelper.formatDate(this.pCustInfo['BDate']),
        compContactAddress: this.pCustInfo['ContactAddress'],
        compEmail: this.pCustInfo['Email'],
        companyCertNo: this.pCustInfo['CompanyCertNo'],
        companyName: this.pCustInfo['CompanyName'],
        companyAddress: this.pCustInfo['CompanyAddress'],
      });
    } else {
      this.editPotentialForm.form.patchValue({
        bDate: DateHelper.formatDate(this.pCustInfo['BDate']),
        customerType: this.pCustInfo['CustomerType'],
        customerName: this.pCustInfo['CustomerName'],
        personCertNo: this.pCustInfo['PersonCertNo'],
        contactPhone: this.pCustInfo['ContactPhone'],
        email: this.pCustInfo['Email'],
        contactAddress: this.pCustInfo['ContactAddress'],
      });
    }

    this.editPotentialDialog.open();
  }

  // 編輯潛在顧客
  public handleEditPotentialForm(value) {
    let data = _.assign({
      BOLNo: this.bolNo,
      customerType: this.pCustInfo['CustomerType'],
      source: this.pCustInfo['Source'],
      productCategory: this.pCustInfo['ProductCategory'],
    }, value);

    if (this.isCompMode) {
      data.customerName = value['compCustomerName'];
      data.personCertNo = value['compPersonCertNo'];
      data.contactPhone = value['compContactPhone'];
      data.bDate = value['compBDate'];
      data.contactAddress = value['compContactAddress'];
      data.email = value['compEmail'];
    }

    this.boService.updatePotentialCustomer(data).subscribe(
      (resp) => {
        this.editPotentialDialog.close();
        this.getCustPotential(this.bolNo);
        console.log(resp);
      }
    );
  }

  private prepareControls() {
    this.editPointNoteControls = [
      new TextareaControl({
        key: 'pointAbstract',
        label: '洽談重點摘要',
        isWordCount: true,
        required: true,
        maxlength: 1200,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
    this.boStatusControls = [
      new SingleDropdownControl({
        key: 'BOLStatus',
        label: '狀態類別',
        required: true,
        columnClasses: ['12'],
        options: this.boStatusOptions,
        placeholder: '請選擇...'
      }),

      // 追蹤中
      new SingleDropdownControl({
        key: 'detailTrack',
        label: '狀態細項',
        required: true,
        columnClasses: ['12'],
        options: [
          {value: '有意願、待補文件', label: '有意願、待補文件'}
        ],
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'INPRG';
        },
        placeholder: '請選擇...'
      }),

      // 已受理
      new SingleDropdownControl({
        key: 'product',
        label: '受理產品',
        required: true,
        columnClasses: ['12'],
        options: ProductHelper.getOptionsOf([
          ProductHelper.CodeEnum.CREDIT,
          ProductHelper.CodeEnum.GUARANTEE,
          ProductHelper.CodeEnum.HOUSE,
          ProductHelper.CodeEnum.SB,
          ProductHelper.CodeEnum.CARD,
          ProductHelper.CodeEnum.INSURENCE,
          ProductHelper.CodeEnum.OTHERINSURENCE,
        ]),
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'SUBMT';
        },
        placeholder: '請選擇...'
      }),
      // new TextControl({
      //   key: 'insuranceNo',
      //   label: '保單流水編號',
      //   required: true,
      //   columnClasses: ['12'],
      //   placeholder: '請輸入保單流水編號',
      //   condition: (form: FormGroup) => {
      //     return  (form.controls['BOLStatus'].value === 'SUBMT' && form.controls['product'].value === ReferralProd.INSURENCE)
      //         || form.controls['BOLStatus'].value === 'REF' && form.controls['productCode'].value === '7';
      //   }
      // }),
      new TextareaControl({
        key: 'pointAbstract',
        label: '洽談重點摘要',
        required: true,
        maxlength: 1200,
        columnClasses: ['12'],
        isWordCount: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'SUBMT';
        },
        placeholder: '請輸入...'
      }),
      // 婉拒
      new SingleDropdownControl({
        key: 'detailReject',
        label: '狀態細項',
        required: true,
        columnClasses: ['6'],
        options: [
          { value: '1', label: '無意願'},
          { value: '2', label: '不符合申辦資格(可複選)'}
        ],
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'RJECT';
        },
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'detailReject0',
        label: '細項類別',
        required: true,
        columnClasses: ['6'],
        options: [
          { value: '貸款條件不符資格', label: '貸款條件不符資格'}
        ],
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'RJECT' &&
                  form.controls['detailReject'].value === '1';
        },
        placeholder: '請選擇...'
      }),
      new MultiSelectControl({
        key: 'detailReject1',
        label: '細項類別',
        required: true,
        columnClasses: ['6'],
        options: [
          { value: '聯徵信用異常(含配偶)', label: '聯徵信用異常(含配偶)'},
          { value: '本行風險警訊註記', label: '本行風險警訊註記'},
          { value: '無法徵提個人財證', label: '無法徵提個人財證'},
          { value: '無法徵提保證人/不動產', label: '無法徵提保證人/不動產'},
          { value: '無法徵提個人財證', label: '無法徵提個人財證'},
          { value: '擔保品無承做空間', label: '擔保品無承做空間'},
          { value: '無明確工作', label: '無明確工作'},
        ],
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'RJECT' &&
                  form.controls['detailReject'].value === '2';
        },
        placeholder: '請選擇...'
      }),

      // 轉介其他商品
      new TextControl({
        key: 'circiKey',
        label: '身分證字號/統一編號',
        columnClasses: ['12'],
        required: true,
        disabled: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        placeholder: 'e.g. A123456789'
      }),
      new TextControl({
        key: 'customerName',
        label: '戶名',
        columnClasses: ['6'],
        required: true,
        disabled: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        placeholder: 'e.g. 李大名'
      }),
      new TextControl({
        key: 'phone',
        label: '電話',
        columnClasses: ['6'],
        required: true,
        disabled: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        placeholder: 'e.g. 0912345678'
      }),
      new TextControl({
        key: 'referralEmpId',
        label: '轉介人員',
        columnClasses: ['6'],
        value: `(${this.auth.getLoginUser().loginEmpId}) ${this.auth.getLoginUser().name}`,
        disabled: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        }
      }),
      new SingleDropdownControl({
        key: 'productCode',
        label: '轉介產品',
        columnClasses: ['6'],
        required: true,
        options: this.productCodeOptions,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        placeholder: '請選擇...'
      }),
      new MultiSelectControl({
        key: 'cuerrency',
        label: '轉介產品備註',
        columnClasses: ['12'],
        options: this.currencyTypeOptions,
        placeholder: '請選擇幣別...',
        condition: (form: FormGroup) => {
          return form.controls['BOLStatus'].value === 'REF' && form.controls['productCode'].value === ReferralProd.FORDEP;
        }
      }),
      new SingleDropdownControl({
        key: 'acceptedReferralUnit',
        label: '受理轉介單位',
        columnClasses: ['6'],
        enableAutocomplete: true,
        options: this.bankBranchesOptions,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        requireCondition: function(form: FormGroup) {
          return _.parseInt(form.controls['productCode'].value) <= 6;
        },
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'acceptedReferralEmpId',
        label: '受理轉介人員',
        columnClasses: ['6'],
        enableAutocomplete: true,
        options: this.employeeOptions,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        requireCondition: function(form: FormGroup) {
          return _.parseInt(form.controls['productCode'].value) <= 6;
        },
        placeholder: '請選擇...'
      }),

      new TextControl({
        key: 'referralsProductRemark',
        label: '轉介產品備註',
        columnClasses: ['12'],
        placeholder: '請輸入保單流水編號',
        condition: (form: FormGroup) => {
          return form.controls['BOLStatus'].value === 'REF' && form.controls['productCode'].value === ReferralProd.OTHERINSURENCE;
        }
      }),
      new TextControl({
        key: 'creditNumber',
        label: '轉介產品備註',
        columnClasses: ['12'],
        placeholder: '請輸入信託憑證編號',
        condition: (form: FormGroup) => {
          return form.controls['BOLStatus'].value === 'REF' && form.controls['productCode'].value === ReferralProd.FUND;
        }
      }),

      new TextareaControl({
        key: 'otherDesc',
        label: '其他說明',
        columnClasses: ['12'],
        isWordCount: true,
        condition: function(form: FormGroup) {
          return form.controls['BOLStatus'].value === 'REF';
        },
        placeholder: '請輸入...'
      })
    ];
    this.editPotentialControls = [

      new RadioControl({
        key: 'customerType',
        label: '潛在顧客類別',
        columnClasses: ['12'],
        disabled: true,
        options: [
          {value: '1', label: '個人戶'},
          {value: '2', label: '公司戶'}
        ],
        condition: (form: FormGroup) => {
          return false;
        }
      }),
      // 1
      // 姓名
      new TextControl({
        key: 'customerName',
        label: '顧客姓名',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 陳大明',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 身分證字號
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 聯繫用手機
      new TextControl({
        key: 'contactPhone',
        label: '聯繫用手機',
        disabled: true,
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 09123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 生日
      new DatepickerControl({
        key: 'bDate',
        label: '生日',
        columnClasses: ['6'],
        singleDatePicker: true,
        placeholder: '請選擇日期...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // 通訊地址
      new TextControl({
        key: 'contactAddress',
        label: '通訊地址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),
      // E-mail
      new TextControl({
        key: 'email',
        label: 'E-mail',
        columnClasses: ['12'],
        placeholder: 'e.g. abc@abc.com',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '1';
        }
      }),

      // 2
      // 公司名稱
      new TextControl({
        key: 'companyName',
        label: '公司名稱',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. XX有限公司',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司統編
      new TextControl({
        key: 'companyCertNo',
        label: '公司統編',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司住址
      new TextControl({
        key: 'companyAddress',
        label: '公司住址',
        columnClasses: ['12'],
        placeholder: '請輸入...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 負責人姓名
      new TextControl({
        key: 'compCustomerName',
        label: '負責人姓名',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 陳大明',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 負責人統一編號
      new TextControl({
        key: 'compPersonCertNo',
        label: '負責人統一編號',
        columnClasses: ['6'],
        placeholder: 'e.g. A123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 聯繫用手機
      new TextControl({
        key: 'compContactPhone',
        label: '聯繫用手機',
        required: true,
        columnClasses: ['6'],
        placeholder: 'e.g. 09123456789',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),
      // 公司成立日期
      new DatepickerControl({
        key: 'compBDate',
        label: '公司成立日期',
        columnClasses: ['6'],
        singleDatePicker: true,
        placeholder: '請選擇日期...',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),

      new TextControl({
        key: 'compContactAddress',
        label: '通訊地址',
        columnClasses: ['12'],
        placeholder: '請輸入',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      }),

      // E-mail
      new TextControl({
        key: 'compEmail',
        label: 'E-mail',
        columnClasses: ['12'],
        placeholder: 'e.g. abc@abc.com',
        condition: (form: FormGroup) => {
          return form.controls['customerType'].value === '2';
        }
      })
    ];

  }

  private changeProductCodeOptionsBasedOnCustomerType(): void {
    const personalId = _.result(this.boStatusForm.form, 'controls.circiKey.value') as string;
    this.productCodeOptions.splice(0, this.productCodeOptions.length);
    if (FormatChecker.isTaiwanId(personalId)) {
      ProductHelper.getOptionsOf([
        ProductHelper.CodeEnum.CREDIT,
        ProductHelper.CodeEnum.GUARANTEE,
        ProductHelper.CodeEnum.HOUSE,
        ProductHelper.CodeEnum.CARD,
        ProductHelper.CodeEnum.INSURENCE,
        ProductHelper.CodeEnum.OTHERINSURENCE,
        ProductHelper.CodeEnum.FUND,
        ProductHelper.CodeEnum.TWDEP,
        ProductHelper.CodeEnum.FORDEP,
        ProductHelper.CodeEnum.GOLDDEP,
        ProductHelper.CodeEnum.SECURITIES,
        ProductHelper.CodeEnum.OTHER,
      ]).forEach( o => this.productCodeOptions.push(o) );
    }else {
      ProductHelper.getOptionsOf([
        ProductHelper.CodeEnum.SB,
        ProductHelper.CodeEnum.OTHERINSURENCE,
        ProductHelper.CodeEnum.FUND,
        ProductHelper.CodeEnum.TWDEP,
        ProductHelper.CodeEnum.FORDEP,
        ProductHelper.CodeEnum.GOLDDEP,
        ProductHelper.CodeEnum.SECURITIES,
        ProductHelper.CodeEnum.OTHER,
      ]).forEach( o => this.productCodeOptions.push(o) );
    }
  }

  private initBoStatusForm() {
    this.boStatusForm.patchValue({
      pointAbstract: this.boDetail['Bol']['PointAbstract'] || '',
      BOLStatus: this.boDetail['Bol']['BOLStatus'],
      circiKey: this.customerDetail.circiKey || '',
      customerName: this.customerDetail.name || '',
      phone: this.customerDetail.phone || '',
    });
    this.changeProductCodeOptionsBasedOnCustomerType();
  }

  private initEditPointNoteForm() {
    this.editPointNoteForm.form.controls['pointAbstract'].setValue(this.boDetail['Bol']['PointAbstract'] || '');
  }
  private updateBOLStatus(requestBody) {
    this.boService.updateBOLStatus(requestBody).subscribe( (resp) => {
      if (resp.isOk) {
        this.boStatusForm.reset();
        this.updateBoDetail();
      }
      this.boStatusDialog.close();
    });
  }
  private getCust360Data(circiKey) {
    forkJoin(
      this.clientService.getCustomerDetail(circiKey),
      this.clientService.getOverView(circiKey),
    )
    .subscribe(
      ([detail, overview]) => {
        this.customerDetail = detail;

        if (this.customerDetail.customerAttribute === ClientType.COMP) {
          this.overView = this.clientService.transferCompOverview(overview.value);
        } else {
          this.overView = this.clientService.transferCusOverview(overview.value);
        }

        this.breadcrumb.setCurrentPageName(this.customerDetail.name);
        this.selfCreateBOL = {
          customerName: this.customerDetail.name,
          circiKey: this.customerDetail.circiKey
        };

        this.initBoStatusForm();
        // need UUID
        this.returnList = [{UUID: this.customerDetail.email}];
        if (!this.isAbleToUsePhoneMarketing()) {
          this.warningDialog.open();
        }
      });
  }

  private getCustPotential(bolNo) {
    this.clientService.getPotentialCustomer(bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.pCustInfo = resp.value;
          this.customerDetail.customerAttribute = resp.value['CustomerType'];
          if (this.isCompMode) {
            this.customerDetail.circiKey = resp.value['CompanyCertNo'] || '-';
            this.customerDetail.name = resp.value['CompanyName'] || '-';
            this.customerDetail.principleName = resp.value['CustomerName'] || '-';
            this.customerDetail.phone = resp.value['ContactPhone'] || '-';
            this.customerDetail.companyAddr = resp.value['CompanyAddress'] || '-';
            this.customerDetail.email = resp.value['Email'] || '-';
            this.customerDetail.address = resp.value['ContactAddr'] || '-';
          } else {
            this.customerDetail.name = resp.value['CustomerName'] || '-';
            this.customerDetail.circiKey = resp.value['PersonCertNo'] || '-';
            this.customerDetail.phone = resp.value['ContactPhone'] || '-';
            this.customerDetail.email = resp.value['Email'] || '-';
            this.customerDetail.address = resp.value['ContactAddress'] || '-';
            this.customerDetail.age = moment.duration(moment(new Date(), 'YYYY/MM/DD')
                                            .diff(moment(resp.value['BDate'], 'YYYY/MM/DD'))
                                            ).years() || '-';
          }
        }
        this.initBoStatusForm();
      }
    );
  }

  private checkBolType(bol): string {
    switch(bol['BOLSource']) {
      case '1':
        return 'ebm';
      case '2':
        switch(bol['CaseSource']) {
          case '1':
          case '3':
            //1. OLHA 線上房貸申請
            //3. OLPA 線上信貸申請
            return 'onlineLoan';
          case '2':
          case '4':
            //2.OLHL 線上房貸額度利率評估
            //4.OLPL 線上信貸額度利率評估
            return 'rate';
          case '5':
            //官網留言板
            return 'messageBoard';
        }
        break;
      case '3':
        return 'trans';
      case '4':
        return 'selfCreate';
    }
  }

  private isAbleToUsePhoneMarketing(): boolean{
    return this.customerDetail.marketingAlertBlock.phoneSaleFlag === 'Y';
  }

  private initAllDialogInputs() {
    // todo bolNo
    this.scheduleBolData = {
      bolNo: this.boDetail['Bol']['BOLNo'],
      bolName: ''
    };

    this.remarkInfo = {
      generalBOLUUID: this.boDetail['Bol']['UUID'],
      bolNo: this.boDetail['Bol']['BOLNo']
    };

    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };

    let marketingLog = this.boDetail['MarketingLogs'].filter( (el) => {
      return el['BOLNo'] === this.boDetail['Bol']['BOLNo'];
    });
    if (marketingLog.length > 0 && marketingLog[0]['Remarks'].length > 0) {
      this.BOLRemark = {
        updateDate: marketingLog[0]['Remarks'][0]['UpdateDate'],
        content: marketingLog[0]['Remarks'][0]['Remark'],
      };
    }

    if (this.boDetail['Visit']) {
      this.reVisitSchedule = {
        UUID: this.boDetail['Visit']['UUID'],
        BOLNo: this.boDetail['Visit']['BOLNo'],
        visitDate: this.boDetail['Visit']['VisitDate'],
        visitTime: this.boDetail['Visit']['VisitTime'],
        subject: this.boDetail['Visit']['Subject'],
        visitAddress: this.boDetail['Visit']['VisitAddress'],
        contactPhone: this.boDetail['Visit']['ContactPhone'],
        remark: this.boDetail['Visit']['Remark'],
        createEmpId: this.boDetail['Visit']['CreateEmpId'],
        createDate: this.boDetail['Visit']['CreateDate'],
        updateEmpId: this.boDetail['Visit']['UpdateEmpId'],
        updateDate: this.boDetail['Visit']['UpdateDate']
      };
    }
  }
}
