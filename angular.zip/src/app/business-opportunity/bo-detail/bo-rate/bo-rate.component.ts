import { BolSharedService } from './../../bol-shared-service.service';
import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { BolHelper } from './../../bol-helper';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { BusinessOppotunityService } from './../../../core/services/business-oppotunity.service';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';

@Component({
  selector: 'esun-bo-rate',
  templateUrl: './bo-rate.component.html',
  styleUrls: ['./bo-rate.component.scss']
})
export class BoRateComponent implements OnInit, OnDestroy {

  @ViewChild('createNote') createNoteDialog: IbmDialogComponent;
  @Input('bol')
  set bol(value) {
    if (value) {
      if (this.boDetail !== value) {
        this.boDetail = value;
        this.updateDetail();
      }
    }
  }
  public recordData: any;
  public marketRecord: any;
  public remarkInfo: any;
  public rateInfo: any;
  public boDetail: any = {};
  public uploadInfo: any = {};
  public bolAttachments: any = [];

  // public rateMap = {
  //   SOURCE: '案件來源',
  //   APPLY_TIME: '顧客申請日期',
  //   TIME_AVAILABLE: '方便聯絡時間',
  //   PROMOTE_BRCH_CD: '行銷單位',
  //   PROMOTER_EMP_ID: '行銷人員',
  //   ReceivedUnit: '受理單位',
  //   MOLDescription: '名單分派說明',
  //   MK_PARTNER_CD: '策略夥伴',
  //   MK_PARTNER_PERSON: '推薦人員',
  //   MK_PROJECT_CD: '合作專案',
  //   CUSTOMER_SEGMENT: '客群行銷資訊',
  //   PAYROLL_IND: '薪轉戶註記',
  //   PAYROLL_SALARY: '本行薪轉月收入(估算)',
  //   BLACK_REASON: '黑名單註記',
  // };

  // public olplDetail = {
  //   applyInfoDesc:[
  //     'SOURCE',
  //     'APPLY_TIME',
  //     'TIME_AVAILABLE',
  //   ],
  //   applyInfoMaintain: [
  //     'PROMOTE_BRCH_CD',
  //     'PROMOTER_EMP_ID',
  //     'ReceivedUnit',
  //     'MOLDescription',
  //     'MK_PARTNER_CD',
  //     'MK_PARTNER_PERSON',
  //     'MK_PROJECT_CD',
  //     'CUSTOMER_SEGMENT',
  //     'PAYROLL_IND',
  //     'PAYROLL_SALARY',
  //     'BLACK_REASON',
  //   ]
  // };

  // public defaultOLPL = {
  //   applyInfoDesc: [],
  //   applyInfoMaintain: []
  // };

  private ngUnSubscribe: Subject<any> = new Subject();
  private generalBOLUUID = '';
  private bolNo = '';

  constructor(
    private bolSharedService: BolSharedService,
    private boService: BusinessOppotunityService
    ) { }

  ngOnInit() {
    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.uploadInfo = {
      UUID: this.boDetail['Bol']['UUID'],
      BOLNo: this.boDetail['Bol']['BOLNo']
    };
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.rateInfo = this.isCreditMode ? this.boDetail['OlplDetail'] : this.boDetail['OlhlDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.boService.getBOLAttachments(this.bolNo).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.bolAttachments = resp.value;
        }
      }
    );
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isCreditMode(): boolean {
    return this.boDetail['Bol']['CaseSource'] === '4';
  }

  public updateDetail() {

    this.bolNo = this.boDetail['Bol']['BOLNo'];
    this.recordData = this.boDetail['FlowLogs'].map( (el) => {
      return BolHelper.processFlowLogs(el);
    });
    this.rateInfo = this.isCreditMode ? this.boDetail['OlplDetail'] : this.boDetail['OlhlDetail'];
    // 行銷接觸記錄
    this.marketRecord =
      this.bolSharedService.transformMarketRecord(this.boDetail['MarketingLogs']);
    this.generalBOLUUID = BOSharedFunctions.getGeneralUUID(this.boDetail);

    this.remarkInfo = {
      generalBOLUUID: this.generalBOLUUID,
      bolNo: this.bolNo
    };
  }

  // public processData(boDetail) {
  //   let result = {};
  //   if (this.rateMode === 'credit') {
  //     let source = boDetail['olplDetail'];
  //     Object.keys(this.defaultOLPL).forEach( (displayBlockKey) => {
  //       result[displayBlockKey] = this.olplDetail[displayBlockKey].map( (el) => {
  //         return {
  //           title: this.rateMap[el],
  //           content: source[el]
  //         };
  //       });
  //     });
  //     result['applyInfoRealEstate'] = source['IS_REAL_ESTATE_FLG'] ? true : false;
  //     result['applyInfoRealEstateAddr'] = source['REAL_ESTATE_ADDRESS'];
  //     result['applyInfoComment'] = source['COMMENT'] || '';
  //     console.log(result);
  //     return result;
  //   }
  // }

}
