// angular module
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
import { NgxPermissionsService } from 'ngx-permissions';
// model
import { Permissions } from 'app/core/models/permissions';
import { BOLNormalCaseSearchParams } from '../business-opportunity.model';
import { ISelectOptionModel } from './../../core/models/comm-data';
import {
  HeadCaseDetailType, BOLStatus,
  BOLSelfCreateDto, BOLUploadInfo,
  BOLAssignCaseDto, BOLNormalCaseTableRowDto,
  BOLHeadofficeCaseTableRowDto, BOLReturnCaseDto
} from './../business-opportunity.model';
// component
import { ControlBase, MultiSelectControl, DatepickerControl, TextControl, SingleDropdownControl } from '../../shared/components/dynamic-form/controls';
import { DynamicFormComponent } from './../../shared/components/dynamic-form/dynamic-form.component';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { IbmTabsComponent } from '../../shared/components/ibm-tabs/ibm-tabs.component';
// service
import { BolSharedService } from './../bol-shared-service.service';
import { LoggerService } from '../../shared/logger.service';
import { SelectOptionsService } from './../../shared/services/select-options.service';
import { ApiService, BusinessOppotunityService } from 'app/core/services';
// helper
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { DateHelper } from './../../shared/helper/date-helper';
import { CirciKeyValidator } from './../../shared/functions/validators';
import BOSharedFunctions from 'app/business-opportunity/bo-shared-functions/shared-functions';

@Component({
  selector: 'esun-bo-search',
  templateUrl: './bo-search.component.html',
  styleUrls: ['./bo-search.component.css']
})
export class BoSearchComponent implements OnInit, OnDestroy, AfterViewInit {
  /**
   * 一般名單查詢 input form
   *
   * @type {DynamicFormComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('normalCaseForm') normalCaseForm: DynamicFormComponent;

  /**
   * 總行案件查詢 input form
   *
   * @type {DynamicFormComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('headofficeCaseForm') headofficeCaseForm: DynamicFormComponent;

  /**
   * 自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;

  /**
   * 新增行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;

  /**
   * 上傳文件 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('uploadFile') uploadFileDialog: IbmDialogComponent;

  /**
   * 查找群組名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('searchGroup') searchGroupDialog: IbmDialogComponent;

  /**
   * 退回總行 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;

  /**
   * 一般名單列表
   *
   * @type {IbmTableComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;

  /**
   * 總行案件列表
   *
   * @type {IbmTableComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('headofficeCaseTable') headofficeCaseTable: IbmTableComponent;

  /**
   * 改派名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('boAssignment') boAssignmentDialog: IbmDialogComponent;

  /**
   * tab container
   *
   * @type {IbmTabsComponent}
   * @memberof BoSearchComponent
   */
  @ViewChild('tabs') tabs: IbmTabsComponent;

  /**
   * permissions enum property for template
   *
   * @memberof BoSearchComponent
   */
  public Permissions = Permissions;

  /**
   * normalCaseForm 擇一必填 property
   *
   * @type {string[]}
   * @memberof BoSearchComponent
   */
  public requiredAnyKeys: string[] = ['assignedDate', 'personCertNo'];

  /**
   * normalCaseForm controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoSearchComponent
   */
  public normalCaseControls: ControlBase<any>[] = [];

  /**
   * headofficeForm controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoSearchComponent
   */
  public headofficeCaseControls: ControlBase<any>[] = [];

  /**
   * normalCase search result
   *
   * @type {BOLNormalCaseTableRowDto[]}
   * @memberof BoSearchComponent
   */
  public normalTableData: BOLNormalCaseTableRowDto[] = [];

  /**
   * headofficeCase search result
   *
   * @type {BOLHeadofficeCaseTableRowDto[]}
   * @memberof BoSearchComponent
   */
  public headOfficeTableData: BOLHeadofficeCaseTableRowDto[] = [];

  /**
   * default data for selfCreateBOL
   *
   * @type {BOLSelfCreateDto}
   * @memberof BoSearchComponent
   */
  public selfCreateBOL: BOLSelfCreateDto;

  /**
   * info for upload file
   *
   * @type {BOLUploadInfo}
   * @memberof BoSearchComponent
   */
  public uploadInfo: BOLUploadInfo;

  /**
   * header for boAssignmentDialog
   *
   * @type {string}
   * @memberof BoSearchComponent
   */
  public boAssignmentDialogHeader: string;


  /**
   * case for return to headoffice or operator
   *
   * @type {BOLReturnCaseDto[]}
   * @memberof BoSearchComponent
   */
  public returnList: BOLReturnCaseDto[] = [];

  /**
   * case for assign or reassign
   *
   * @type {BOLAssignCaseDto[]}
   * @memberof BoSearchComponent
   */
  public assigneeList: BOLAssignCaseDto[] = [];

  /**
   * normalCase search sort options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public normalCaseOrderTypes: ISelectOptionModel[] = [
    { value: 'BOLStatus', label: '名單狀態' },
    { value: 'assignDate', label: '分派/建立日期' },
    { value: 'customerId', label: '統一編號' },
    { value: 'customerName', label: '戶名' },
    { value: 'productType', label: '產品別' },
    { value: 'marketingUnit', label: '行銷單位' },
    { value: 'marketingPerson', label: '行銷人員' },
    { value: 'BOLSource', label: '名單來源' },
    { value: 'BOLType', label: '名單類型' }
  ];

  /**
   * headofficeCase search sort options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public headofficeCaseOrderTypes: ISelectOptionModel[] = [
    { value: 'number', label: '單號' },
    { value: 'subject', label: '主旨' },
    { value: 'operator', label: '建立者' },
    { value: 'department', label: '指派單位' },
    { value: 'relpyDate', label: '指定回覆日期' },
    { value: 'dueDate', label: '結案日期' },
  ];

  /**
   * BOLStatus select options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   *
   * @todo 使用 bolStatus select service
   */
  public bolStatusOptions: ISelectOptionModel[] = [
    { value: 'INIT', label: '未執行'},
    { value: 'INPRG', label: '追蹤中'},
    { value: 'SUBMT', label: '已受理'},
    { value: 'RJECT', label: '婉拒'},
    { value: 'REF', label: '轉介其他商品'},
    { value: 'SYCLOS', label: '系統自動銷案'},
    { value: 'DUP', label: '重複商機結案'}
  ];
  public headBolStatusOptions = [
    { value: 'INIT', label: '未執行'},
    { value: 'END', label: '已結案'},
  ];

  /**
   * marketing unit options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public marketingUnitOptions: ISelectOptionModel[] = [
    { value: '01234', label: '01234 板橋分行' },
    { value: '01235', label: '01235 林口分行' },
    { value: '01236', label: '01236 台北分行' },
  ];

  /**
   * marketing person options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public marketingPersonOptions: ISelectOptionModel[] = [
    { value: '11234', label: '(11234) 王小明'},
    { value: '21235', label: '(21235) 王中明'},
    { value: '31236', label: '(31236) 華小明'},
    { value: '41237', label: '(41237) 黃小明'},
    { value: '0001', label: '(0001) 王小圖'},
  ];

  /**
   *
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public bolSourceOptions: ISelectOptionModel[] = [
    { value: '1', label: 'EBM'},
    { value: '2', label: '網路進件'},
    { value: '3', label: '系統轉介'},
    { value: '4', label: '自建名單'},
  ];

  /**
   * headofficeCase search params option
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoSearchComponent
   */
  public dateTypeOptions: ISelectOptionModel[]  = [];

  public normalCase: {
    tabTitle: string,
    currentOrderType: ISelectOptionModel,
    selectedRowList: BOLNormalCaseTableRowDto[],
    listConfig: any
  } = {
    tabTitle: '一般名單',
    currentOrderType: this.normalCaseOrderTypes[0],
    selectedRowList: [],
    listConfig: {} as any
  };

  public headofficeCase = {
    tabTitle: '總行指派案件',
    currentOrderType: this.headofficeCaseOrderTypes[0],
    selectedRowList: [],
    listConfig: {} as any
  };

  /**
   * selected row
   *
   * @type {BOLNormalCaseTableRowDto}
   * @memberof BoSearchComponent
   */
  public selectedRowData: BOLNormalCaseTableRowDto;

  /**
   * 總行案件 form validator
   *
   * @memberof BoSearchComponent
   */
  public headofficeFormValidator: ValidatorFn;

  /**
   * unSubscribe all subscription when ngOnDestroy call
   *
   * @private
   * @type {Subject<any>}
   * @memberof BoSearchComponent
   */
  private ngUnSubscribe: Subject<any> = new Subject();

  /**
   * 主管權限才能使用查詢條件,
   * 行銷人員及行銷單位
   *
   * @private
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  private showMarketingPersonAndUnit: boolean = false;

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private router: Router,
    private route: ActivatedRoute,
    private option: SelectOptionsService,
    private permissionService: NgxPermissionsService,
    private bolShared: BolSharedService,
    private ref: ChangeDetectorRef,
    private api: ApiService
  ) {
    this.dateTypeOptions = this.option.getOptions('dateSearchType');
    this.permissionService.hasPermission([
      Permissions.ASSIGN_CHANGE_GENERAL_BOL_UPDATE
    ]).then(
      (show) => {
        this.showMarketingPersonAndUnit = show;
      }
    );
   }


  ngOnInit() {
    this.prepareControls();
    this.route.paramMap.subscribe(
      (param: ParamMap) => {
        this.logger.debug(param.getAll('ids'));
      }
    );

    this.headofficeFormValidator = BOSharedFunctions.headofficeFormValidators(this.headofficeCaseControls);
  }

  ngAfterViewInit() {
    // let params = this.route.snapshot.queryParams;
    // if (params.activeTab) {
    //   this.tabs.selectTab(_.parseInt(params.activeTab));
    // }
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * check input form is valid
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  public isFormValid(form: DynamicFormComponent): boolean {
    if (form.form) {
      return form.form.valid;
    }
  }

  /**
   * check normalCaseForm has any selected row
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get isNormalCaseAnySelected(): boolean {
    if (this.normalCaseTable) {
      return this.normalCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  /**
   * check headOfficeCaseForm has any selected row
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get isHeadOfficeCaseAnySelected(): boolean {
    if (this.headofficeCaseTable) {
      return this.headofficeCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  /**
   * disable action button when choose no selected rows
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get disableActionButton(): boolean {
    if (this.tabs.selectedTab) {
      if (this.isNormalCaseMode) {
        return this.normalCase.selectedRowList.length === 0 ;
      } else {
        return this.headofficeCase.selectedRowList.length === 0 ;
      }
    }
    return true;
  }

  /**
   * check current page is normalCase active
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get isNormalCaseMode(): boolean {
    if (this.tabs.selectedTab) {
      return this.tabs.selectedTab.tabTitle === this.normalCase.tabTitle;
    }
    return true;
  }

  /**
   * table data orderType label
   *
   * @readonly
   * @type {string}
   * @memberof BoSearchComponent
   */
  get orderTypeLabel(): string {
    return this.isNormalCaseMode ? this.normalCase.currentOrderType.label : this.headofficeCase.currentOrderType.label;
  }

  /**
   * 潛在顧客無「調閱行內帳務資料」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get showSearchBankAcct(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchBankAcct;
    }
    return false;
  }

  /**
   * 潛在顧客無「新增自建名單」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get showCreateBo(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showCreateBo;
    }
    return false;
  }

  /**
   * 潛在顧客無「退回總行」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get showReturnHeadoff(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showReturnHeadoff;
    }
    return false;
  }

  /**
   * 重複商機案件才有「查找群組名單」
   *
   * @readonly
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  get showSearchGroup(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchGroup;
    }
    return false;
  }


  public updateActiveTab(event) {
    const index = event.index;
    this.router.navigate([],{
        relativeTo: this.route,
        queryParams: {
          activeTab: index
        },
        queryParamsHandling: 'merge'
      });
  }
  /**
   * 跳轉到總行指派案件詳細頁
   *
   * @param {string} UUID
   * @memberof BoSearchComponent
   */
  public goHeadOffice(UUID: string) {
    // 主管模式下進入總行指派案件，不能對 detail 進行編輯
    this.permissionService.hasPermission(Permissions.ASSIGN_CHANGE_HEAD_OFFFICE_BOL_UPDATE)
    .then( (isReviewMode) => {
      if(isReviewMode) {
        this.bolShared.setHeadCaseType(HeadCaseDetailType.NONE);
      } else {
        this.bolShared.setHeadCaseType(HeadCaseDetailType.SEARCH);
      }
      this.router.navigate(['/business-op', 'headCase', UUID]);
    });
  }

  /**
   * handle normal case form submit
   *
   * @param {*} listConfig
   * @memberof BoSearchComponent
   */
  public handleNormalCaseSubmit(listConfig: any) {
    let params: BOLNormalCaseSearchParams = {
      bolStatus: listConfig.bolStatus,
      assignedDate: DateHelper.divideDate(listConfig.assignedDate),
      personCertNo: listConfig.personCertNo,
      marketingUnit: listConfig.marketingUnitCode,
      marketingPerson: listConfig.marketingPersonEmpId,
      bolSource: listConfig.bolSource,
      orderCol: this.normalCase.currentOrderType.value,
      pf: {
        skip: 0,
        take: this.api.getLimitTake()
      }
    };

    this.boService.query(params).subscribe(
      (data) => {
        this.normalTableData = data;
    });
  }

  /**
   * handle headoffice case form submit
   *
   * @param {*} listConfig
   * @memberof BoSearchComponent
   */
  public handleHeadofficeCase(listConfig: any) {
    let config;
    this.headofficeCase.listConfig = listConfig;
    config = _.assign(_.cloneDeep(listConfig), {
      pf: this.headofficeCaseTable.pageFilter,
      orderCol: this.headofficeCase.currentOrderType.value
    });
    if (config.selectDate) {
      config.selectDate = DateHelper.divideDate(config.selectDate);
    }
    this.boService.queryHeadOffice(config).subscribe(
      (data) => {
        this.headOfficeTableData = data;
    });
  }

  /**
   * add or remove favorite bol
   *
   * @param {BOLNormalCaseTableRowDto} scope
   * @memberof BoSearchComponent
   */
  public onFavoriteToggle(scope: BOLNormalCaseTableRowDto) {
    if (scope.isFavorite) {
      this.boService.deletFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    } else {
      this.boService.addFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    }
  }

  /**
   * table header checkbox helper
   *
   * @param {string} type
   * @memberof BoSearchComponent
   */
  public handleSelectAllCheckboxClick(type: string) {
    switch (type) {
      case 'normalCase':
      this.normalCase.selectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isNormalCaseAnySelected,
          this.normalCaseTable.getcurrentPageRows(),
          this.normalCase.selectedRowList
        );
        this.logger.debug('normalCaseSelectAll length: ', this.normalCase.selectedRowList.length);
        break;
      case 'headofficeCase':
      this.headofficeCase.selectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isHeadOfficeCaseAnySelected,
          this.headofficeCaseTable.getcurrentPageRows(),
          this.headofficeCase.selectedRowList
        );
        this.logger.debug('headofficeCaseSelectAll length: ', this.headofficeCase.selectedRowList.length);
        break;
      default:
        break;
    }
  }

  /**
   * table row checkbox helper
   *
   * @param {*} row
   * @param {string} type
   * @memberof BoSearchComponent
   */
  public handleCheckboxClick(row: any, type: string) {
    switch (type) {
      case 'normalCase':
      this.normalCase.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.normalCase.selectedRowList);
        break;
      case 'headofficeCase':
      this.headofficeCase.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.headofficeCase.selectedRowList);
        break;
      default:
        break;
    }
  }

  /**
   * trigger matmenu
   *
   * @param {BOLNormalCaseTableRowDto} row
   * @memberof BoSearchComponent
   */
  public openMenu(row: BOLNormalCaseTableRowDto) {
    this.selectedRowData = row;
  }

  /**
   * matmenu click action
   *
   * @param {string} dialogType
   * @memberof BoSearchComponent
   */
  public menuClick(dialogType: string) {
    switch (dialogType) {
      case 'searchBankAcct':
        this.router.navigate(this.selectedRowData.customerAcctLink);
        break;
      case 'createBo':
        this.selfCreateBOL = {
          customerName: this.selectedRowData.customerName,
          circiKey: this.selectedRowData.circiKey
        };
        this.createBoDialog.open();
        break;
      case 'createSchedule':
        this.createScheduleDialog.open();
        break;
      case 'uploadFile':
        this.uploadInfo = {
          UUID: this.selectedRowData.UUID,
          BOLNo: this.selectedRowData.BOLNo
        };
        this.uploadFileDialog.open();
        break;
      case 'searchGroup':
        this.searchGroupDialog.open();
        break;
      case 'rejectToHeadOffice':
        this.onManagerActionOpen('rejectToHeadOffice', true);
        break;
    }
  }

  /**
   * open manager action dialog
   *
   * @param {string} type
   * @param {boolean} [isSingleSelect=false]
   * @memberof BoSearchComponent
   */
  public onManagerActionOpen(type: string, isSingleSelect: boolean = false) {
    switch (type) {
      case 'rejectToHeadOffice':
        if (this.isNormalCaseMode) {
          const list = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.normalCase.selectedRowList);
          this.returnList = list.map( el => { return {UUID: el.UUID}; } );
        } else {
          this.returnList = _.cloneDeep(this.headofficeCase.selectedRowList).map( el => { return {UUID: el.UUID}; } );
        }
        this.rejectToHeadOfficeDialog.open();
        break;
      case 'boAssignment':
          if (this.isNormalCaseMode) {
            const list = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.normalCase.selectedRowList);
            this.boAssignmentDialogHeader = `改派名單 (${list.length})`;
            this.assigneeList = list.map( el => {
              return {
                UUID: el.UUID,
                BOLNo: el.BOLNo,
                marketingPerson: el.marketingPersonName,
                marketingPersonID: el.marketingPersonId,
                marketingUnit: el.marketingUnitName,
                marketingUnitID: el.marketingUnitId,
              };
            });
          } else {
            this.boAssignmentDialogHeader = `改派名單 (${this.headofficeCase.selectedRowList.length})`;
            this.assigneeList = _.cloneDeep(this.headofficeCase.selectedRowList).map( el => {
              return {
                UUID: el.UUID,
                BOLNo: el.BOLNo,
                marketingPerson: el.MarketingPerson,
                marketingPersonID: el.MarketingPersonID,
                marketingUnit: el.MarketingUnit,
                marketingUnitID: el.MarketingUnitID,
              };
            });
          }
        this.boAssignmentDialog.open();
        break;
      default:
       break;
    }
  }

  /**
   * change table sort
   * when form valid is true
   * then submit form
   *
   * @param {ISelectOptionModel} orderType
   * @memberof BoSearchComponent
   */
  public chooseOrderType(orderType: ISelectOptionModel) {
    if (this.isNormalCaseMode) {
      this.normalCase.currentOrderType = orderType;
      if (this.normalCaseForm.form.valid) {
        this.normalCaseForm.submit();
      }
    } else {
      this.headofficeCase.currentOrderType = orderType;
      if (this.headofficeCaseForm.form.valid) {
        this.headofficeCaseForm.submit();
      }
    }
  }

  /**
   * check form component view is init
   *
   * @param {string} type
   * @memberof BoSearchComponent
   */
  public afterFormViewInit(type: string) {
    this.ref.detectChanges();
    let params = this.route.snapshot.queryParams;
    if (type === 'normalCase') {
      // 名單提醒通知條件
      if (params.status) {
        this.normalCaseForm.patchValue({
          bolStatus: [params.status],
          bolSource: [params.source]
        });
      } else {
        this.normalCaseForm.form.patchValue({
          bolStatus: [BOLStatus.INIT, BOLStatus.INPRG],
          assignedDate: DateHelper.getLastThreeMonths()
        });
      }
      this.normalCaseForm.submit();
    }
    if (type === 'headofficeCase') {
      // 名單提醒通知條件
      if (params.status) {
        this.headofficeCaseForm.patchValue({
          bolStatus: [params.status]
        });
      } else {
        this.headofficeCaseForm.form.patchValue({
          bolStatus: [BOLStatus.INIT],
          selectDate: DateHelper.getLastThreeMonths()
        });
      }

      this.headofficeCaseForm.submit();
    }
  }

  /**
   * dialog 完成後執行搜尋，更新畫面
   *
   * @memberof BoSearchComponent
   */
  public afterActionsComplete() {
    if (this.isNormalCaseMode) {
      this.normalCaseForm.submit();
    } else {
      this.headofficeCaseForm.submit();
    }
  }

  /**
   * init form controls
   *
   * @private
   * @memberof BoSearchComponent
   */
  private prepareControls() {
    this.normalCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolStatusOptions,
        placeholder: '請選擇...'
      }),

      new DatepickerControl({
        key: 'assignedDate',
        label: '分派/建立日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789',
        validators: [CirciKeyValidator]
      }),
      new SingleDropdownControl({
        key: 'marketingUnitCode',
        label: '行銷單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.marketingUnitOptions,
        condition: (form: FormGroup) => {
          return this.showMarketingPersonAndUnit;
        }
      }),
      new MultiSelectControl({
        key: 'marketingPersonEmpId',
        label: '行銷人員',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.marketingPersonOptions,
        condition: (form: FormGroup) => {
          return this.showMarketingPersonAndUnit;
        }
      }),
      new MultiSelectControl({
        key: 'bolSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolSourceOptions,
        placeholder: '請選擇...'
      }),
    ];

    this.headofficeCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.headBolStatusOptions,
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'caseNo',
        label: '單號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'subject',
        label: '主旨',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'createEmpId',
        label: '建立者',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'type',
        label: '日期類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.dateTypeOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'selectDate',
        label: '　',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      })
    ];
  }
}
