import { Injectable } from '@angular/core';
import { BaseCodeHelper } from 'app/core/models/base-enum-code';

@Injectable({
  providedIn: 'root'
})
export class BolStatusService extends BaseCodeHelper<number>{
  constructor() {
      const codeLabelMap = {
        'INIT': '未執行',
        'INPRG': '追蹤中',
        'SUBMT': '已受理',
        'RJECT': '婉拒',
        'REF': '轉介其他商品',
        'SYCLOS': '系統自動銷案',
        'DUP': '重複商機結案',
      };
      super(codeLabelMap);
  }
}
