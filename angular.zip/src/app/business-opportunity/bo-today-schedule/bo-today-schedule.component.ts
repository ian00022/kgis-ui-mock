// angular module
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { Permissions } from './../../core/models/permissions';
import { ISelectOptionModel } from './../../core/models/comm-data';
import { BOLUploadInfo, BOLReturnCaseDto } from '../business-opportunity.model';
import { BOLSelfCreateDto, BOLNormalCaseTableRowDto, BOLNormalCaseVisitTableRowDto } from 'app/business-opportunity/business-opportunity.model';
// component
import { IbmTableComponent } from './../../shared/components/ibm-table/ibm-table.component';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
// service
import { BusinessOppotunityService } from './../../core/services/business-oppotunity.service';
import { SelectOptionsService } from '../../shared/services/select-options.service';

/**
 *  toady schedule component
 */
@Component({
  selector: 'esun-bo-today-schedule',
  templateUrl: './bo-today-schedule.component.html',
  styleUrls: ['./bo-today-schedule.component.scss'],
  providers: [ DatePipe ]
})
export class BoTodayScheduleComponent implements OnInit, OnDestroy {

  /**
   * 自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;

  /**
   * 新增行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;

  /**
   * 上傳文件 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('uploadFile') uploadFileDialog: IbmDialogComponent;

  /**
   * 查找群組名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('searchGroup') searchGroupDialog: IbmDialogComponent;

  /**
   * 退回總行 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;

  /**
   * 一般名單列表
   *
   * @type {IbmTableComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;

  /**
   * 改派名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoTodayScheduleComponent
   */
  @ViewChild('boAssignment') boAssignmentDialog: IbmDialogComponent;

  /**
   * normalCase search result
   *
   * @type {BOLNormalCaseTableRowDto[]}
   * @memberof BoTodayScheduleComponent
   */
  public normalTableData: BOLNormalCaseVisitTableRowDto[] = [];

  /**
   * selected row
   *
   * @type {BOLNormalCaseTableRowDto}
   * @memberof BoTodayScheduleComponent
   */
  public selectedRowData: BOLNormalCaseTableRowDto;

  /**
   * default data for selfCreateBOL
   *
   * @type {BOLSelfCreateDto}
   * @memberof BoTodayScheduleComponent
   */
  public selfCreateBOL: BOLSelfCreateDto;

  /**
   * info for upload file
   *
   * @type {BOLUploadInfo}
   * @memberof BoTodayScheduleComponent
   */
  public uploadInfo: BOLUploadInfo;

  /**
   * case for return to headoffice or operator
   *
   * @type {BOLReturnCaseDto[]}
   * @memberof BoTodayScheduleComponent
   */
  public returnList: BOLReturnCaseDto[] = [];

  /**
   * normalCase search sort options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoTodayScheduleComponent
   */
  public normalCaseOrderTypes: ISelectOptionModel[] = [
    { value: 'BOLStatus', label: '名單狀態' },
    { value: 'assignDate', label: '分派/建立日期' },
    { value: 'customerId', label: '統一編號' },
    { value: 'customerName', label: '戶名' },
    { value: 'productType', label: '產品別' },
    { value: 'marketingUnit', label: '行銷單位' },
    { value: 'marketingPerson', label: '行銷人員' },
    { value: 'BOLSource', label: '名單來源' },
    { value: 'BOLType', label: '名單類型' }
  ];

  /**
   * current orderType
   *
   * @type {ISelectOptionModel}
   * @memberof BoTodayScheduleComponent
   */
  public currentOrderType: ISelectOptionModel = this.normalCaseOrderTypes[0];

  /**
   * permissions enum property for template
   *
   * @memberof BoTodayScheduleComponent
   */
  public Permissions = Permissions;


  /**
   * today date
   *
   * @type {string}
   * @memberof BoTodayScheduleComponent
   */
  public today: string = '';


  private ngUnSubscribe: Subject<any> = new Subject();
  constructor(
    private boService: BusinessOppotunityService,
    private router: Router,
    private datePipe: DatePipe,
    private option: SelectOptionsService
  ) {
    this.today = this.datePipe.transform(Date.now(), 'yyyy/MM/dd');
  }

  ngOnInit() {
    this.getTodayVisit(this.currentOrderType.value);
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * table data orderType handler
   */
  get orderTypeLabel(): string {
    return this.currentOrderType.label;
  }

  /**
   * 潛在顧客無「調閱行內帳務資料」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoTodayScheduleComponent
   */
  get showSearchBankAcct(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchBankAcct;
    }
    return false;
  }

  /**
   * 潛在顧客無「新增自建名單」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoTodayScheduleComponent
   */
  get showCreateBo(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showCreateBo;
    }
    return false;
  }

  /**
   * 潛在顧客無「退回總行」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoTodayScheduleComponent
   */
  get showReturnHeadoff(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showReturnHeadoff;
    }
    return false;
  }

  /**
   * 重複商機案件才有「查找群組名單」
   *
   * @readonly
   * @type {boolean}
   * @memberof BoTodayScheduleComponent
   */
  get showSearchGroup(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchGroup;
    }
    return false;
  }

  /**
   * change table sort
   * when form valid is true
   * then submit form
   *
   * @param {ISelectOptionModel} orderType
   * @memberof BoTodayScheduleComponent
   */
  public chooseOrderType(orderType) {
    this.currentOrderType = orderType;
    this.getTodayVisit(this.currentOrderType.value);
  }

  /**
   * add or remove favorite bol
   *
   * @param {BOLNormalCaseTableRowDto} scope
   * @memberof BoTodayScheduleComponent
   */
  public onFavoriteToggle(scope: BOLNormalCaseTableRowDto) {
    if (scope.isFavorite) {
      this.boService.deletFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    } else {
      this.boService.addFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    }
  }

  /**
   * trigger matmenu
   *
   * @param {BOLNormalCaseTableRowDto} value
   * @memberof BoTodayScheduleComponent
   */
  public openMenu(value: BOLNormalCaseTableRowDto) {
    this.selectedRowData = value;
  }

  /**
   * matmenu click action
   *
   * @param {string} dialogType
   * @memberof BoTodayScheduleComponent
   */
  public menuClick(dialogType: string) {
    switch (dialogType) {
      case 'searchBankAcct':
        this.router.navigate(this.selectedRowData.customerAcctLink);
        break;
      case 'createBo':
        this.selfCreateBOL = {
          customerName: this.selectedRowData.customerName,
          circiKey: this.selectedRowData.circiKey
        };
        this.createBoDialog.open();
        break;
      case 'createSchedule':
        this.createScheduleDialog.open();
        break;
      case 'uploadFile':
        this.uploadInfo = {
          UUID: this.selectedRowData.UUID,
          BOLNo: this.selectedRowData.BOLNo
        };
        this.uploadFileDialog.open();
        break;
      case 'searchGroup':
        this.searchGroupDialog.open();
        break;
      case 'rejectToHeadOffice':
        this.returnList = [{ UUID: this.selectedRowData.UUID}];
        this.rejectToHeadOfficeDialog.open();
        break;
    }
  }

  private getTodayVisit(orderCol?: string) {
    this.boService.queryTodaySchedule({orderCol: orderCol}).subscribe(
      (response) => {
        this.normalTableData = response;
    });
  }
}
