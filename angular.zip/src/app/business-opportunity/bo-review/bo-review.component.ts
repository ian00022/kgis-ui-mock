import { BolSharedService } from './../bol-shared-service.service';
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BOLSource, BOLSearchAction } from './../business-opportunity.model';
import { DateHelper } from './../../shared/helper/date-helper';
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { BusinessOppotunityService } from './../../core/services/business-oppotunity.service';
import { LoggerService } from './../../shared/logger.service';
import { ControlBase, TextControl, MultiSelectControl, DatepickerControl, SingleDropdownControl} from './../../shared/components/dynamic-form/controls';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { IbmTabsComponent } from '../../shared/components/ibm-tabs/ibm-tabs.component';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { BolHelper } from '../bol-helper';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { CirciKeyValidator } from '../../shared/functions/validators';
import { HeadCaseDetailType } from '../business-opportunity.model';
import { Permissions } from '../../core/models/permissions';
import BOSharedFunctions from '../bo-shared-functions/shared-functions';
import { ValidatorFn } from '@angular/forms';

@Component({
  selector: 'esun-bo-review',
  templateUrl: './bo-review.component.html',
  styleUrls: ['./bo-review.component.scss']
})
export class BoReviewComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;
  @ViewChild('normalCaseForm') normalCaseForm: DynamicFormComponent;
  @ViewChild('headofficeCaseTable') headofficeCaseTable: IbmTableComponent;
  @ViewChild('headofficeCaseForm') headofficeCaseForm: DynamicFormComponent;
  @ViewChild('rejectToHeadCaseForm') rejectToHeadCaseForm: DynamicFormComponent;
  @ViewChild('rejectToHeadCaseTable') rejectToHeadCaseTable: IbmTableComponent;
  @ViewChild('reject') rejectDialog: IbmDialogComponent;
  @ViewChild('agree') agreeDialog: IbmDialogComponent;
  @ViewChild('tabs') tabs: IbmTabsComponent;
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;

  public requiredAnyKeys = ['assignedDate', 'personCertNo'];
  public normalCaseControls: ControlBase<any>[] = [];
  public headofficeCaseControls: ControlBase<any>[] = [];
  public normalTableData: any[] = [];
  public headOfficeTableData: any[] = [];
  public rejectToHeadTableData: any[] = [];

  public agreeDialogHeader = '放行';
  public rejectList: any[] = [];
  public agreeList: any[] = [];
  public tempSelectedRow: any = {};
  public Permissions = Permissions;
  /**
   * 總行案件 form validator
   *
   * @memberof BoSearchComponent
   */
  public headofficeFormValidator: ValidatorFn;

  public bolStatusOptions = [
    {value: 'INIT', label: '未執行'},
    {value: 'INPRG', label: '追蹤中'},
    {value: 'SUBMT', label: '已受理'},
    {value: 'RJECT', label: '婉拒'},
    {value: 'REF', label: '轉介其他商品'},
    {value: 'SYCLOS', label: '系統自動銷案'},
    {value: 'DUP', label: '重複商機結案'}
  ];

  public headBolStatusOptions = [
    {value: 'INIT', label: '未執行'},
    {value: 'END', label: '已結案'},
  ];

  public branchOptions = [
    { value: '01234', label: '01234 板橋分行' },
    { value: '01235', label: '01235 林口分行' },
    { value: '01236', label: '01236 台北分行' },
  ];

  public employeeOptions = [
    { label: '(11234) 王小明', value: '11234'},
    { label: '(21235) 王中明', value: '21235'},
    { label: '(31236) 華小明', value: '31236'},
    { label: '(41237) 黃小明', value: '41237'},
    { label: '(0001) 王小圖', value: '0001'},
  ];

  public bolSourceOptions = [
    {value: '1', label: 'EBM'},
    {value: '2', label: '網路進件'},
    {value: '3', label: '系統轉介'},
    {value: '4', label: '自建名單'},
  ];

  public dateTypeOptions = [
    {value: '1', label: '建立日期'},
    {value: '2', label: '指定回覆日期'},
    {value: '3', label: '結案日期'},
  ];


  private normalCaseSelectedRowList: any[] = [];
  private normalCaseSelectedRow: any = {};
  private headOfficeCaseSelectedRowList: any[] = [];
  private headOfficeCaseSelectedRow: any = {};
  private rejectToHeadCaseSelectedRowList: any[] = [];
  private rejectToHeadCaseSelectedRow: any = {};
  // private normalCaseListConfig: BoListConfig = {
  //   type: 'normalCase',
  //   filters: {}
  // };
  // private headOfficeCaseListConfig: BoListConfig = {
  //   type: 'headOfficeCase',
  //   filters: {}
  // };
  // private rejectToHeadCaseListConfig: BoListConfig = {
  //   type: 'normalCase',
  //   filters: {}
  // };
  private isSingleSelect = false;

  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private router: Router,
    private route: ActivatedRoute,
    private option: SelectOptionsService,
    private bolShared: BolSharedService
  ) { }

  ngOnInit() {
    this.prepareControls();
    this.headofficeFormValidator = BOSharedFunctions.headofficeFormValidators(this.headofficeCaseControls);
  }

  ngAfterViewInit() {
    let params = this.route.snapshot.queryParams;
    if (params.activeTab) {
      this.tabs.selectTab(_.parseInt(params.activeTab));
    }
    // this.normalCaseForm.form.patchValue({
    //   bolStatus: this.bolStatusOptions.map(el => el.value)
    // });
    this.headofficeCaseForm.form.patchValue({
      bolStatus: ['END'],
      selectDate: DateHelper.getLastThreeMonths()
    });
    this.normalCaseForm.form.patchValue({
      bolStatus: ['RJECT'],
      assignedDate: DateHelper.getLastThreeMonths()
    });
    this.rejectToHeadCaseForm.patchValue({
      bolStatus: this.bolStatusOptions.map(e => e.value),
      assignedDate: DateHelper.getLastThreeMonths()
    });

    this.normalCaseForm.submit();
    this.headofficeCaseForm.submit();
    this.rejectToHeadCaseForm.submit();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isNormalCaseFormValid(): boolean {
    return this.normalCaseForm.form.valid;
  }

  get isRejectToHeadCaseFormValid(): boolean {
    return this.rejectToHeadCaseForm.form.valid;
  }

  get isNormalCaseAnySelected(): boolean {
    if (this.normalCaseTable) {
      return this.normalCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  get isRejectToHeadCaseAnySelected(): boolean {
    if (this.rejectToHeadCaseTable) {
      return this.rejectToHeadCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  get isHeadOfficeCaseAnySelected(): boolean {
    if (this.headofficeCaseTable) {
      return this.headofficeCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  get disableButton(): boolean {
    switch (this.currentType) {
      case 'normalCase':
        return this.normalCaseSelectedRowList.length === 0;
      case 'headofficeCase':
        return this.headOfficeCaseSelectedRowList.length === 0;
      case 'rejectToHeadCase':
        return this.rejectToHeadCaseSelectedRowList.length === 0;
      default:
        return true;
    }
  }

  get currentType(): string {
    switch (this.tabs.getSelectedTab().tabTitle) {
      case '一般名單':
        return 'normalCase';
      case '總行指派案件':
        return 'headofficeCase';
      case '退回總行':
        return 'rejectToHeadCase';
      default:
        return '';
    }
  }

  get displaySelectedStatus(): string {
    if (!this.normalCaseForm.form.controls['bolStatus'].value) {
      return '';
    }
    return this.normalCaseForm.form.controls['bolStatus'].value.map((el) => {
      return this.option.getOptionLabel('bolReviewStatus', el);
    }).join('、');
  }

  get displaySelectedSources(): string {
    if (!this.normalCaseForm.form.controls['bolSource'].value) {
      return '';
    }
    return this.normalCaseForm.form.controls['bolSource'].value.map((el) => {
      return this.option.getOptionLabel('boSource', el);
    }).join('、');
  }

  get displaySelectedMarketingEmp(): string {
    if (!this.normalCaseForm.form.controls['marketingPersonEmpId'].value) {
      return '';
    }
    return this.normalCaseForm.form.controls['marketingPersonEmpId'].value.map((el) => {
      return _.find(this.employeeOptions, {value: el}).label;
    }).join('、');
  }

  public submitNormalCaseForm() {
    this.normalCaseForm.submit();
  }

  public goHeadOffice(UUID: any) {
    this.bolShared.setHeadCaseType(HeadCaseDetailType.REVIEW);
    this.router.navigate(['/business-op', 'headCase', UUID]);
  }

  public handleSubmit(listConfig: any, type: string) {
    this.logger.debug('submit: ', type);
    let config;
    switch (type) {
      case 'normalCase':
        config = _.assign(_.cloneDeep(listConfig), {
          pf: this.normalCaseTable.pageFilter,
          orderCol: ''
        });
        if (config.assignedDate) {
          config.assignedDate = DateHelper.divideDate(config.assignedDate);
        }
        this.boService.query(config, BOLSearchAction.REVIEW_SEARCH).subscribe(
          (data) => {
            this.normalTableData = data;
        });
        break;
      case 'headofficeCase':
        config = _.assign(_.cloneDeep(listConfig), {
          pf: this.headofficeCaseTable.pageFilter,
          orderCol: ''
        });
        if (config.selectDate) {
          config.selectDate = DateHelper.divideDate(config.selectDate);
        }
        this.boService.queryHeadOffice(config, BOLSearchAction.REVIEW_SEARCH).subscribe(
          (data) => {
            this.headOfficeTableData = data;
        });
        break;
      case 'rejectToHeadCase':
        config = _.assign(_.cloneDeep(listConfig), {
          pf: this.normalCaseTable.pageFilter,
          orderCol: ''
        });
        if (config.assignedDate) {
          config.assignedDate = DateHelper.divideDate(config.assignedDate);
        }
        this.boService.query(config, BOLSearchAction.RETURN_TO_HEAD_SEARCH).subscribe(
          (data) => {
            this.rejectToHeadTableData = data;
        });
        break;
      default:
        break;
    }
  }

  public handleSelectAllCheckboxClick() {
    switch (this.currentType) {
      case 'normalCase':
      this.normalCaseSelectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isNormalCaseAnySelected,
          this.normalCaseTable.getcurrentPageRows(),
          this.normalCaseSelectedRowList
        );
        this.logger.debug('normalCaseSelectAll length: ', this.normalCaseSelectedRowList.length);
        break;
      case 'headofficeCase':
      this.headOfficeCaseSelectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isHeadOfficeCaseAnySelected,
          this.headofficeCaseTable.getcurrentPageRows(),
          this.headOfficeCaseSelectedRowList
        );
        this.logger.debug('headofficeCaseSelectAll length: ', this.headOfficeCaseSelectedRowList.length);
        break;
      case 'rejectToHeadCase':
      this.rejectToHeadCaseSelectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isRejectToHeadCaseAnySelected,
          this.rejectToHeadCaseTable.getcurrentPageRows(),
          this.rejectToHeadCaseSelectedRowList
        );
        this.logger.debug('rejectToHeadCaseSelectAll length: ', this.rejectToHeadCaseSelectedRowList.length);
        break;
      default:
        break;
    }
  }

  public handleCheckboxClick(row: any) {
    switch (this.currentType) {
      case 'normalCase':
        this.normalCaseSelectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.normalCaseSelectedRowList);
        break;
      case 'headofficeCase':
        this.headOfficeCaseSelectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.headOfficeCaseSelectedRowList);
        break;
      case 'rejectToHeadCase':
        this.rejectToHeadCaseSelectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.rejectToHeadCaseSelectedRowList);
        break;
      default:
        break;
    }
  }

  public openModal(type: string) {
    const list = this.handleAgreeOrRejectList();
    this.boService.checkoutBOLWF({
      WFObjectName: this.boService.getWFObjectName(),
      UUIds: list.map(bo => bo.UUID)
    }).subscribe( (resp) => {
      if (resp.isOk) {
        switch (type) {
          case 'reject':
            this.rejectList = list;
            this.rejectDialog.open();
            break;
          case 'agree':
            this.agreeDialogHeader = `放行 (${list.length})`;
            this.agreeList = list;
            this.agreeDialog.open();
            break;
          default:
           break;
        }
      }
    });
  }

  public setSelectedRow(row: any) {
    this.isSingleSelect = true;
    switch (this.currentType) {
      case 'normalCase':
        this.normalCaseSelectedRow = row;
        break;
      case 'headofficeCase':
        this.headOfficeCaseSelectedRow = row;
        break;
      case 'rejectToHeadCase':
        this.rejectToHeadCaseSelectedRow = row;
        break;
      default:
        break;
    }
  }

  public handleAgreeDialogConfirm() {
    this.logger.debug('agree: ', this.agreeList.length);
    let data = {
      UUIDs: this.agreeList.map(agree => agree.UUID),
      WFObjectName: this.boService.getWFObjectName(),
      BaseUrl: this.router.url,
      Action: 'Approved',
      Comment: ''
    };
    this.boService.reviewBOL(data).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.submitNormalCaseForm();
          this.agreeDialog.close();
        }
      }
    );
  }

  public handleAgreeDialogCancel() {
    this.boService.cancelCheckoutBOLWF({
      WFObjectName: this.boService.getWFObjectName(),
      UUIDs: this.agreeList.map(agree => agree.UUID)
    }).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.agreeDialog.close();
        }
      }
    );
  }

  public onAgreeClick(row?: any) {
    if (row) {
      this.setSelectedRow(row);
    } else {
      this.isSingleSelect = false;
    }
    this.openModal('agree');
  }

  public onRejectClick(row?: any) {
    if (row) {
      this.setSelectedRow(row);
    } else {
      this.isSingleSelect = false;
    }
    this.openModal('reject');
  }

  public displayProdText(prodType) {
    return this.option.getOptionLabel('referralProd', prodType) || '-';
  }

  public updateActiveTab(event) {
    const index = event.index;
    this.router.navigate([],{
        relativeTo: this.route,
        queryParams: {
          activeTab: index
        },
        queryParamsHandling: 'merge',
      });
  }

  private handleAgreeOrRejectList(): any[] {
    switch (this.currentType) {
      case 'normalCase':
        return this.isSingleSelect ? [this.normalCaseSelectedRow] : _.cloneDeep(this.normalCaseSelectedRowList);
      case 'headofficeCase':
        return this.isSingleSelect ? [this.headOfficeCaseSelectedRow] : _.cloneDeep(this.headOfficeCaseSelectedRowList);
      case 'rejectToHeadCase':
        return this.isSingleSelect ? [this.rejectToHeadCaseSelectedRow] : _.cloneDeep(this.rejectToHeadCaseSelectedRowList);
      default:
        return [];
    }
  }

  // private prepareControls() {
  //   this.normalCaseControls = [
  //     new MultiSelectControl({
  //       key: 'status',
  //       label: '名單狀態',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       options: [
  //         {value: '追蹤中', label: '追蹤中'},
  //         {value: '已受理', label: '已受理'},
  //         {value: '未執行', label: '未執行0.0'},
  //         {value: '婉拒', label: '婉拒'},
  //       ],
  //       placeholder: '請選擇...'
  //     }),
  //     new MultiSelectControl({
  //       key: 'source',
  //       label: '名單來源',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       options: [
  //         {value: 'EBM', label: 'EBM'},
  //         {value: '網路進件', label: '網路進件'},
  //         {value: '自建名單', label: '自建名單'},
  //         {value: '名單', label: '名單'},
  //       ],
  //       placeholder: '請選擇...'
  //     }),
  //     new DatepickerControl({
  //       key: 'activeDate',
  //       label: '分派/建立日期',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: '請選擇日期...'
  //     }),
  //     new TextControl({
  //       key: 'uniqueId',
  //       label: '身分證字號/統一編號',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: 'e.g. A123456789'
  //     }),
  //     new SingleDropdownControl({
  //       key: 'marketingDepartment',
  //       label: '行銷單位',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       enableAutocomplete: true,
  //       placeholder: '請選擇...',
  //       options: [
  //         { value: '01234 板橋分行', label: '01234 板橋分行' },
  //         { value: '01235 林口分行', label: '01235 林口分行' },
  //         { value: '01236 台北分行', label: '01236 台北分行' },
  //       ]
  //     }),
  //     new MultiSelectControl({
  //       key: 'marketingOperaotor',
  //       label: '行銷人員',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       enableAutocomplete: true,
  //       placeholder: '請選擇...',
  //       options: [
  //         { value: '王大明', label: '王大明' },
  //         { value: '王小明', label: '王小明' },
  //         { value: '王中明', label: '王中明' }
  //       ]
  //     })
  //   ];

  //   this.headofficeCaseControls = [
  //     new MultiSelectControl({
  //       key: 'status',
  //       label: '名單狀態',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       options: [
  //         {value: '追蹤中1.1', label: '追蹤中'},
  //         {value: '已受理', label: '已受理'},
  //         {value: '未執行', label: '未執行1.1'},
  //         {value: '婉拒', label: '婉拒'},
  //       ],
  //       placeholder: '請選擇...'
  //     }),
  //     new TextControl({
  //       key: 'number',
  //       label: '單號',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: '請輸入...'
  //     }),
  //     new TextControl({
  //       key: 'subject',
  //       label: '主旨',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: '請輸入...'
  //     }),
  //     new TextControl({
  //       key: 'bulider',
  //       label: '建立者',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: '請輸入...'
  //     }),
  //     new SingleDropdownControl({
  //       key: 'dateType',
  //       label: '日期類型',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       options: [
  //         {value: '建立日期', label: '建立日期'}
  //       ],
  //       placeholder: '請選擇...'
  //     }),
  //     new DatepickerControl({
  //       key: 'activeDate',
  //       label: '　',
  //       columnClasses: ['12', 'md-4', 'lg-3'],
  //       placeholder: '請選擇日期...'
  //     })
  //   ];
  // }

  private prepareControls() {
    this.normalCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolStatusOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'assignedDate',
        label: '分派/建立日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789',
        validators: [CirciKeyValidator]
      }),
      new SingleDropdownControl({
        key: 'marketingUnitCode',
        label: '行銷單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.branchOptions
      }),
      new MultiSelectControl({
        key: 'marketingPersonEmpId',
        label: '行銷人員',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.employeeOptions
      }),
      new MultiSelectControl({
        key: 'bolSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolSourceOptions,
        placeholder: '請選擇...'
      }),
    ];

    this.headofficeCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.headBolStatusOptions,
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'caseNo',
        label: '單號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'subject',
        label: '主旨',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'createEmpId',
        label: '建立者',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'type',
        label: '日期類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.dateTypeOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'selectDate',
        label: '　',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      })
    ];
  }
}
