import { BolSharedService } from './../bol-shared-service.service';
import { BolHelper } from './../bol-helper';
import { TextareaControl } from './../../shared/components/dynamic-form/controls/textarea-control';
import { ControlBase } from './../../shared/components/dynamic-form/controls/control-base';
import { BusinessOppotunityService } from './../../core/services/business-oppotunity.service';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { IbmTableComponent } from './../../shared/components/ibm-table/ibm-table.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { LoggerService } from '../../shared/logger.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DynamicFormComponent } from '../../shared/components/dynamic-form/dynamic-form.component';
import { CheckBoxTableHelper } from '../../shared/helper/table-checkbox-helper';
import { HeadCaseDetailType, HeadCaseAction } from '../business-opportunity.model';
import { Permissions } from '../../core/models/permissions';

@Component({
  selector: 'esun-bo-head-case-detail',
  templateUrl: './bo-head-case-detail.component.html',
  styleUrls: ['./bo-head-case-detail.component.scss']
})
export class BoHeadCaseDetailComponent implements OnInit {

  @ViewChild('reviewModeTable') reviewModeTable: IbmTableComponent;
  @ViewChild('reject') rejectDialog: IbmDialogComponent;
  @ViewChild('agree') agreeDialog: IbmDialogComponent;
  @ViewChild('editRemark') editRemarkDialog: IbmDialogComponent;
  @ViewChild('editRemarkForm') editRemarkForm: DynamicFormComponent;
  @ViewChild('boAssignment') boAssignmentDialog: IbmDialogComponent;
  @ViewChild('editResult') editResultDialog: IbmDialogComponent;
  @ViewChild('editResultForm') editResultForm: DynamicFormComponent;

  public collapsed: boolean = true;
  public boHeadCaseList: any[] = [];
  public selectedRowList: any[] = [];
  public selectedRow: any = {};
  public boHeadCaseDetail: any = {};
  public boDefault: any = {};
  public source: HeadCaseDetailType;
  public boList: any[] = [];
  public reAssign: boolean = false;
  public tempSelectedRow;
  public HeadCaseDetailType = HeadCaseDetailType;
  public Permissions = Permissions;

  public controls: ControlBase<any>[] = [];
  public editResultControls: ControlBase<any>[] = [];


  private selectedMode = 'multiple';
  private headCaseAction: HeadCaseAction;
  private id: string;

  constructor(
    private logger: LoggerService,
    private route: ActivatedRoute,
    private router: Router,
    private boService: BusinessOppotunityService,
    private bolShared: BolSharedService
  ) {
    this.source = this.bolShared.getHeadCaseType();
  }

  ngOnInit() {
    this.id = this.route.snapshot.params['UUID'];
    this.getDetail(this.id);
    this.prepareControls();
  }

  get isAnySelected(): boolean {
    if (this.reviewModeTable) {
      return this.reviewModeTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  /**
   * use permission service
   */
  get isReviewMode(): boolean {
    return true;
  }

  get getAssignmentHeader(): string {
    const preTitle = this.reAssign ? '改派' : '分派';
    return `${preTitle}(${this.boList.length})`;
  }

  public showTopButton(source: HeadCaseDetailType): boolean {
    return this.source === source && this.isReviewMode;
  }

  public getCustLink(id: any): any[] {
    return ['/clients', 'client', id || ''];
  }

  public handleSelectAllCheckboxClick() {
    this.selectedRowList = CheckBoxTableHelper.handleSelectAll(
      this.isAnySelected,
      this.reviewModeTable.getcurrentPageRows(),
      this.selectedRowList
    );
  }

  public handleCheckboxClick(row: any) {
    this.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.selectedRowList);
  }

  public handleAgreeDialogConfirm() {
    const data = this.selectedMode === 'multiple' ? this.selectedRowList : [this.selectedRow];
    this.logger.debug('agree: ', data.length);
    this.agreeDialog.close();
  }

  public openMenu(row: any) {
    switch (this.source) {
      case HeadCaseDetailType.REVIEW:
        this.selectedMode = this.beforeModalOpen(row);
        break;
      case HeadCaseDetailType.ASSIGNMENT:
        break;
      case HeadCaseDetailType.SEARCH:
        this.boDefault = {
          customerName: row.CaseDetail.CustomerName,
          circiKey: row.CaseDetail.IdentityCardNumber
        };
        break;
      default:
        break;
    }
  }

  public onAgreeClick(row?: any) {
    this.selectedMode = this.beforeModalOpen(row);
    this.agreeDialog.open();
  }

  public onRejectClick(row?: any) {
    this.selectedMode = this.beforeModalOpen(row);
    this.boList = this.selectedMode === 'single' ? [_.cloneDeep(this.selectedRow)] : _.cloneDeep(this.selectedRowList);
    this.rejectDialog.open();
  }

  public onAssignmentClick(reAssign: boolean, row?: any) {
    this.reAssign = reAssign;
    this.selectedMode = this.beforeModalOpen(row);
    this.boList = this.selectedMode === 'single' ? [_.cloneDeep(this.selectedRow)] : _.cloneDeep(this.selectedRowList);
    this.boAssignmentDialog.open();
  }

  public isBoOwner(row: any): boolean {
    return row.CaseDetail.CreateEmpId === this.boHeadCaseDetail.CreateEmpId;
  }

/**
 * editRemarkForm helper
 */

  get isEditRemarkFormValid(): boolean {
    return this.editRemarkForm.form.valid;
  }

  public onEditRemarkClick() {
    this.editRemarkForm.reset();
    this.editRemarkDialog.open();
  }

  public editRemarkFormTemp() {
    this.headCaseAction = HeadCaseAction.SAVE;
    this.editRemarkForm.submit();
  }
  public editRemarkFormCancel() {
    this.editRemarkForm.reset();
    this.editRemarkDialog.close();
  }
  public editRemarkFormConfirm() {
    this.headCaseAction = HeadCaseAction.CLOSE;
    this.editRemarkForm.submit();
  }
  public onSubmit(value) {
    let body = _.assign({
      UserAction: this.headCaseAction,
      BaseUrl: this.router.url,
      WFObjectName: this.boService.getWFObjectName()
    }, this.selectedRow.CaseDetail, value);

    this.boService.updateHeadOfficeCase(body).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.editRemarkDialog.close();
          this.editRemarkForm.reset();
          this.getDetail(this.id);
        }
      }
    );
  }

  /**
   * editResultForm helper
   */

  get isEditResultFormValid(): boolean {
     return this.editResultForm.form.valid;
  }

  public onEditResultClick(row: any) {
    this.selectedRow = row;
    this.editResultForm.reset();
    this.editResultDialog.open();
  }
  public editResultFormCancel() {
    this.editResultDialog.close();
    this.getDetail(this.id);
  }
  public editResultFormConfirm() {
    let body = _.assign({
      UserAction: HeadCaseAction.SAVE,
      BaseUrl: this.router.url,
      WFObjectName: this.boService.getWFObjectName()
    }, this.selectedRow.CaseDetail, this.editResultForm.form.value);
    this.boService.updateHeadOfficeCase(body).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.editResultDialog.close();
          this.editResultForm.reset();
          this.getDetail(this.id);
        }
      }
    );
  }

  private prepareControls() {
    this.controls = [
      new TextareaControl({
        key: 'remark',
        label: '備註',
        isWordCount: true,
        required: true,
        columnClasses: ['12']
      })
    ];

    this.editResultControls = [
      new TextareaControl({
        key: 'processResult',
        label: '處理記錄',
        isWordCount: true,
        required: true,
        columnClasses: ['12']
      })
    ];
  }

  private beforeModalOpen(row?: any) {
    if (row) {
      this.selectedRow = row;
      return 'single';
    }
    return 'multiple';
  }

  private getDetail(id) {
    this.boService.getHeadCaseDetail(id)
    .subscribe( (resp) => {
      this.boHeadCaseDetail = resp.value.CaseInfo;
      this.boHeadCaseList = resp.value.CaseDetails.map( (el) => {
        if (el['ProcessLogs'].length > 0) {
          el['subRow'] = el['ProcessLogs'];
        }
        el['status'] = BolHelper.transferBolStatus(el.CaseDetail);
        return el;
      });
    });
  }

}
