import { ProductHelper } from './../core/models/comm-data';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'bolProduct'
})
export class BolProductPipe implements PipeTransform {

  transform(value: any): string {
    return ProductHelper.ProductLabelMap[value];
  }

}
