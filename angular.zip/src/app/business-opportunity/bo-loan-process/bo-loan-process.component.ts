// angular module
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { ClientType } from 'app/core/models/comm-data';
import { Permissions } from './../../core/models/permissions';
// component
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
import { DynamicFormComponent } from 'app/shared/components/dynamic-form/dynamic-form.component';
import {
  ControlBase,
  TextControl,
  DatepickerControl,
  MultiSelectControl,
  SingleDropdownControl
} from 'app/shared/components/dynamic-form/controls/index';
// service
import { LoggerService } from 'app/shared/logger.service';
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';
import { SelectOptionsService } from '../../shared/services/select-options.service';
// helper
import { CirciKeyValidator } from './../../shared/functions/validators';
import { DateHelper } from '../../shared/helper/date-helper';
import { NgxPermissionsService } from 'ngx-permissions';

declare var moment: any;


@Component({
  selector: 'esun-bo-loan-process',
  templateUrl: './bo-loan-process.component.html',
  styleUrls: ['./bo-loan-process.component.scss']
})
export class BoLoanProcessComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('normalCaseForm') normalCaseForm: DynamicFormComponent;
  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;

  public normalCaseControls: ControlBase<any>[] = [];
  public normalTableData: any[] = [];
  public bolSourceOptions = [
    {value: '1', label: 'EBM'},
    {value: '2', label: '網路進件'},
    {value: '3', label: '系統轉介'},
    {value: '4', label: '自建名單'},
  ];

  public employeeOptions = [
    { label: '(11234) 王小明', value: '11234'},
    { label: '(21235) 王中明', value: '21235'},
    { label: '(31236) 華小明', value: '31236'},
    { label: '(41237) 黃小明', value: '41237'},
    { label: '(0001) 王小圖', value: '0001'},
  ];

  public branchOptions = [
    { value: '01234', label: '01234 板橋分行' },
    { value: '01235', label: '01235 林口分行' },
    { value: '01236', label: '01236 台北分行' },
  ];

  public productTypeOptions = [
    {value: '1', label: '信貸'},
    {value: '3', label: '房貸'},
    {value: '4', label: '小型企業(SB)'},
  ];

  /**
   * permissions enum property for template
   *
   * @memberof BoSearchComponent
   */
  public Permissions = Permissions;

  /**
   * 主管權限才能使用查詢條件,
   * 行銷人員及行銷單位
   *
   * @private
   * @type {boolean}
   * @memberof BoSearchComponent
   */
  private showMarketingPersonAndUnit: boolean = false;

  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private option: SelectOptionsService,
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private route: ActivatedRoute,
    private permissionService: NgxPermissionsService
  ) {}

  ngOnInit() {
    this.prepareControls();
    this.route.paramMap.subscribe(
      (param: ParamMap) => {
        this.logger.debug(param.getAll('ids'));
      }
    );

    this.permissionService.hasPermission([
      Permissions.ASSIGN_CHANGE_GENERAL_BOL_UPDATE
    ]).then(
      (show) => {
        this.showMarketingPersonAndUnit = show;
      }
    );
  }
  ngAfterViewInit() {
    this.normalCaseForm.form.patchValue({
      deliveryDate: DateHelper.getLastOneMonths()
    });
    this.normalCaseForm.submit();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  // validate form
  get isNormalCaseFormValid(): boolean {
    return this.normalCaseForm.form.valid;
  }

  // form submit
  public handleSubmit(value: any) {

    let config = _.cloneDeep(value);
    config.deliveryDate = DateHelper.divideDate(config.deliveryDate);
    this.boService.queryLoanDelivery(config).subscribe(
      (data) => {
        this.normalTableData = data;
      }
    );
  }

  // dynamic form inputs
  private prepareControls() {
    this.normalCaseControls = [
      new TextControl({
        key: 'customerID',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789',
        validators: [CirciKeyValidator]
      }),
      new DatepickerControl({
        key: 'deliveryDate',
        label: '送件日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new MultiSelectControl({
        key: 'productType', // 房貸、信貸、小型企業(SB)
        label: '產品別',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.productTypeOptions,
        placeholder: '請選擇...'
      }),
      new SingleDropdownControl({
        key: 'marketingUnitCode',
        label: '行銷單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.branchOptions,
        condition: (form: FormGroup) => {
          return this.showMarketingPersonAndUnit;
        }
      }),
      new MultiSelectControl({
        key: 'marketingPerson',
        label: '行銷人員',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.employeeOptions,
        condition: (form: FormGroup) => {
          return this.showMarketingPersonAndUnit;
        }
      }),
      new MultiSelectControl({
        key: 'bolSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolSourceOptions,
        placeholder: '請選擇...'
      }),
    ];
  }
}
