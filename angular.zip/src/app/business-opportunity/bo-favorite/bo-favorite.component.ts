// angular module
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { Permissions } from 'app/core/models/permissions';
import { ISelectOptionModel } from 'app/core/models/comm-data';
import { BOLReturnCaseDto, BOLStatus, BOLNormalCaseSearchParams } from '../business-opportunity.model';
import { BOLNormalCaseTableRowDto, BOLUploadInfo, BOLSelfCreateDto } from 'app/business-opportunity/business-opportunity.model';
// component
import { ControlBase, DatepickerControl, TextControl, MultiSelectControl } from './../../shared/components/dynamic-form/controls';
import { IbmDialogComponent } from './../../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from './../../shared/components/dynamic-form/dynamic-form.component';
import { IbmTableComponent } from 'app/shared/components/ibm-table/ibm-table.component';
// service
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { BusinessOppotunityService } from './../../core/services/business-oppotunity.service';
import { ApiService } from 'app/core/services/api.service';
// helper
import { DateHelper } from './../../shared/helper/date-helper';
import { CirciKeyValidator } from '../../shared/functions/validators';

/**
 * BOL myFavorite component
 */
@Component({
  selector: 'esun-bo-favorite',
  templateUrl: './bo-favorite.component.html',
  styleUrls: ['./bo-favorite.component.scss']
})
export class BoFavoriteComponent implements OnInit, OnDestroy, AfterViewInit {

  /**
   * 一般名單查詢 input form
   *
   * @type {DynamicFormComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('normalCaseForm') normalCaseForm: DynamicFormComponent;

  /**
   * 自建名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('createBo') createBoDialog: IbmDialogComponent;

  /**
   * 新增行程 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('createSchedule') createScheduleDialog: IbmDialogComponent;

  /**
   * 上傳文件 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('uploadFile') uploadFileDialog: IbmDialogComponent;

  /**
   * 查找群組名單 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('searchGroup') searchGroupDialog: IbmDialogComponent;

  /**
   * 退回總行 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;

  /**
   * 一般名單列表
   *
   * @type {IbmTableComponent}
   * @memberof BoFavoriteComponent
   */
  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;

  /**
   * normalCaseForm 擇一必填 property
   *
   * @memberof BoFavoriteComponent
   */
  public requiredAnyKeys = ['assignedDate', 'personCertNo'];

  /**
   * normalCaseForm controls
   *
   * @type {ControlBase<any>[]}
   * @memberof BoFavoriteComponent
   */
  public normalCaseControls: ControlBase<any>[] = [];

  /**
   * normalCase search result
   *
   * @type {BOLNormalCaseTableRowDto[]}
   * @memberof BoFavoriteComponent
   */
  public normalTableData: BOLNormalCaseTableRowDto[] = [];

  /**
   * selected row
   *
   * @type {BOLNormalCaseTableRowDto}
   * @memberof BoFavoriteComponent
   */
  public selectedRowData: BOLNormalCaseTableRowDto;

  /**
   * normalCase search sort options
   *
   * @type {ISelectOptionModel[]}
   * @memberof BoFavoriteComponent
   */
  public normalCaseOrderTypes: ISelectOptionModel[] = [
    { value: 'BOLStatus', label: '名單狀態' },
    { value: 'assignDate', label: '分派/建立日期' },
    { value: 'customerId', label: '統一編號' },
    { value: 'customerName', label: '戶名' },
    { value: 'productType', label: '產品別' },
    { value: 'marketingUnit', label: '行銷單位' },
    { value: 'marketingPerson', label: '行銷人員' },
    { value: 'BOLSource', label: '名單來源' },
    { value: 'BOLType', label: '名單類型' }
  ];

  /**
   * current orderType
   *
   * @type {ISelectOptionModel}
   * @memberof BoFavoriteComponent
   */
  public currentOrderType: ISelectOptionModel = this.normalCaseOrderTypes[0];

  /**
   * default data for selfCreateBOL
   *
   * @type {BOLSelfCreateDto}
   * @memberof BoFavoriteComponent
   */
  public selfCreateBOL: BOLSelfCreateDto;

  /**
   * case for return to headoffice or operator
   *
   * @type {BOLReturnCaseDto[]}
   * @memberof BoFavoriteComponent
   */
  public returnList: BOLReturnCaseDto[] = [];

  /**
   * info for upload file
   *
   * @type {BOLUploadInfo}
   * @memberof BoFavoriteComponent
   */
  public uploadInfo: BOLUploadInfo;

  /**
   *  permissions enum property for template
   *
   * @memberof BoFavoriteComponent
   */
  public Permissions = Permissions;

  public bolSourceOptions = [
    {value: '1', label: 'EBM'},
    {value: '2', label: '網路進件'},
    {value: '3', label: '系統轉介'},
    {value: '4', label: '自建名單'},
  ];

  /**
   * unSubscribe all subscription when ngOnDestroy call
   *
   * @private
   * @type {Subject<any>}
   * @memberof BoFavoriteComponent
   */
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private boService: BusinessOppotunityService,
    private router: Router,
    private option: SelectOptionsService,
    private api: ApiService
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.normalCaseForm.form.patchValue({
      bolStatus: [BOLStatus.INIT, BOLStatus.INPRG],
      assignedDate: DateHelper.getLastThreeMonths(),
    });
    this.normalCaseForm.submit();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * table data orderType handler
   */
  get orderTypeLabel(): string {
    return this.currentOrderType.label;
  }

  /**
   * check NormalCaseForm valid
   *
   * @readonly
   * @type {boolean}
   * @memberof BoFavoriteComponent
   */
  get isNormalCaseFormValid(): boolean {
    return this.normalCaseForm.form.valid;
  }

  /**
   * 潛在顧客無「調閱行內帳務資料」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoFavoriteComponent
   */
  get showSearchBankAcct(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchBankAcct;
    }
    return false;
  }

  /**
   * 潛在顧客無「新增自建名單」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoFavoriteComponent
   */
  get showCreateBo(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showCreateBo;
    }
    return false;
  }

  /**
   * 潛在顧客無「退回總行」選項
   *
   * @readonly
   * @type {boolean}
   * @memberof BoFavoriteComponent
   */
  get showReturnHeadoff(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showReturnHeadoff;
    }
    return false;
  }

  /**
   * 重複商機案件才有「查找群組名單」
   *
   * @readonly
   * @type {boolean}
   * @memberof BoFavoriteComponent
   */
  get showSearchGroup(): boolean {
    if (this.selectedRowData && this.selectedRowData.actions) {
      return this.selectedRowData.actions.showSearchGroup;
    }
    return false;
  }

  /**
   * handle normal case form submit
   *
   * @param {*} listConfig
   * @memberof BoFavoriteComponent
   */
  public handleSubmit(listConfig) {
    let params: BOLNormalCaseSearchParams = {
      bolStatus: listConfig.bolStatus,
      assignedDate: DateHelper.divideDate(listConfig.assignedDate),
      personCertNo: listConfig.personCertNo,
      marketingUnit: listConfig.marketingUnitCode,
      marketingPerson: listConfig.marketingPersonEmpId,
      bolSource: listConfig.bolSource,
      orderCol: this.currentOrderType.value,
      pf: {
        skip: 0,
        take: this.api.getLimitTake()
      }
    };
    this.boService.queryFavorite(params).subscribe(
      (data) => {
        this.normalTableData = data;
    });
  }

  /**
   * add or remove favorite bol
   *
   * @param {BOLNormalCaseTableRowDto} scope
   * @memberof BoFavoriteComponent
   */
  public onFavoriteToggle(scope: BOLNormalCaseTableRowDto) {
    if (scope.isFavorite) {
      this.boService.deletFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    } else {
      this.boService.addFavorite(scope.BOLNo).subscribe(
        (resp) => {
          if (resp.isOk) {
            // 直接更新前端畫面，search 之後 tableData 會更新
            scope.isFavorite = !scope.isFavorite;
          }
        }
      );
    }
  }

  /**
   * trigger matmenu
   *
   * @param {BOLNormalCaseTableRowDto} value
   * @memberof BoFavoriteComponent
   */
  public openMenu(value: BOLNormalCaseTableRowDto) {
    this.selectedRowData = value;
  }

  /**
   * matmenu click action
   *
   * @param {string} dialogType
   * @memberof BoFavoriteComponent
   */
  public menuClick(dialogType: string) {
    switch (dialogType) {
      case 'searchBankAcct':
        this.router.navigate(this.selectedRowData.customerAcctLink);
        break;
      case 'createBo':
        this.selfCreateBOL = {
          customerName: this.selectedRowData.customerName,
          circiKey: this.selectedRowData.circiKey
        };
        this.createBoDialog.open();
        break;
      case 'createSchedule':
        this.createScheduleDialog.open();
        break;
      case 'uploadFile':
        this.uploadInfo = {
          UUID: this.selectedRowData.UUID,
          BOLNo: this.selectedRowData.BOLNo
        };
        this.uploadFileDialog.open();
        break;
      case 'searchGroup':
        this.searchGroupDialog.open();
        break;
      case 'rejectToHeadOffice':
        this.returnList = [{ UUID: this.selectedRowData.UUID}];
        this.rejectToHeadOfficeDialog.open();
        break;
    }
  }

  /**
   * change table sort
   * when form valid is true
   * then submit form
   *
   * @param {ISelectOptionModel} orderType
   * @memberof BoFavoriteComponent
   */
  public chooseOrderType(orderType: ISelectOptionModel) {
    this.currentOrderType = orderType;
      if (this.normalCaseForm.form.valid) {
        this.normalCaseForm.submit();
      }
  }

  /**
   * init form controls
   *
   * @private
   * @memberof BoFavoriteComponent
   */
  private prepareControls() {
    this.normalCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: [
          {value: 'INIT', label: '未執行'},
          {value: 'INPRG', label: '追蹤中'},
          {value: 'SUBMT', label: '已受理'},
          {value: 'RJECT', label: '婉拒'},
        ],
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'assignedDate',
        label: '分派/建立日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789',
        validators: [CirciKeyValidator]
      }),
      new MultiSelectControl({
        key: 'bolSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolSourceOptions,
        placeholder: '請選擇...'
      }),
    ];
  }
}
