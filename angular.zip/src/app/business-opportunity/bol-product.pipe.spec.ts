/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BolProductPipe } from './bol-product.pipe';

describe('Pipe: BolProducte', () => {
  it('create an instance', () => {
    let pipe = new BolProductPipe();
    expect(pipe).toBeTruthy();
  });
});
