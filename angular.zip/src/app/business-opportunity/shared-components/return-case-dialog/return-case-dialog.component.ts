// angular module
import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
// model
import { BOLReturnCaseDto } from './../../business-opportunity.model';
import { ControlBase, TextareaControl } from '../../../shared/components/dynamic-form/controls';
// component
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from '../../../shared/components/dynamic-form/dynamic-form.component';
// service
import { LoggerService } from '../../../shared/logger.service';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';

/**
 * 退回對象
 * HEADOFIICE: 總行
 * OPERATOR: 經辦
 * @enum {number}
 */
enum ReturnTo {
  HEADOFIICE = 'headoffice',
  OPERATOR = 'operator'
}

/**
 * 退回總行 or 退回經辦
 */
@Component({
  selector: 'esun-return-case-dialog',
  templateUrl: './return-case-dialog.component.html',
  styleUrls: ['./return-case-dialog.component.scss']
})

export class ReturnCaseDialogComponent implements OnInit {
  /**
   * 名單退回 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ReturnCaseDialogComponent
   */
  @ViewChild('dialog') dialog: IbmDialogComponent;

  /**
   * 名單退回 input form
   *
   * @type {DynamicFormComponent}
   * @memberof ReturnCaseDialogComponent
   */
  @ViewChild('form') form: DynamicFormComponent;

  /**
   * 二次確認 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof ReturnCaseDialogComponent
   */
  @ViewChild('doubleCheck') doubleCheckDialog: IbmDialogComponent;


  /**
   * after return confirmed
   *
   * @type {EventEmitter<any>}
   * @memberof ReturnCaseDialogComponent
   */
  @Output('afterReturnConfirm') afterReturnConfirm: EventEmitter<any> = new EventEmitter();


  /**
   * 退回對象
   *
   * @type {string}
   * @memberof ReturnCaseDialogComponent
   */
  @Input('returnTo') returnTo: string = ReturnTo.HEADOFIICE;

  /**
   * 名單退回列表
   *
   * @memberof ReturnCaseDialogComponent
   */
  @Input('returnList')
  set returnList(value: BOLReturnCaseDto[]) {
    if (value.length !== 0 && value) {
      this.returnListUUIDs = value.map(el => el.UUID);
    }
  }

  /**
   * 名單退回 form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof ReturnCaseDialogComponent
   */
  public controls: ControlBase<any>[] = [];

  /**
   * 名單退回列表
   *
   * @private
   * @type {string[]}
   * @memberof ReturnCaseDialogComponent
   */
  private returnListUUIDs: string[] = [];

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private router: Router
  ) { }

  ngOnInit() {
    this.prepareControls();
  }

  /**
   * 名單退回 form valid
   *
   * @readonly
   * @memberof ReturnCaseDialogComponent
   */
  get isValid() {
    return this.form.form.valid || false;
  }

  /**
   * 名單退回 dialog header
   *
   * @readonly
   * @type {string}
   * @memberof ReturnCaseDialogComponent
   */
  get header(): string {
    return this.returnTo === ReturnTo.HEADOFIICE ? '退回總行' : '退回經辦';
  }

  /**
   * 名單退回描述
   *
   * @readonly
   * @type {string}
   * @memberof ReturnCaseDialogComponent
   */
  get returnListCountDescroption(): string {
    return this.returnListUUIDs.length === 1 ? '' : ` ${this.returnListUUIDs.length} `;
  }

  /**
   * handle 名單退回 form submit
   *
   * @param {*} value
   * @memberof ReturnCaseDialogComponent
   */
  public handleSubmit(value) {
    if (this.returnTo === ReturnTo.HEADOFIICE) {
      let data = {
        SubmitWFParams: {
          UUIDs: this.returnListUUIDs,
          WFObjectName: this.boService.getWFObjectName(),
          BaseUrl: this.router.url,
          UpdateData: {}
        },
        Reason: value.returnReason
      };
      this.logger.debug('returnToHead: ', data);
      this.boService.returnBOLToHeadOffice(data).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.afterReturnConfirm.emit();
            this.doubleCheckCancelClick();
          }
        }
      );
    } else {
      let data = {
        UUIDs: this.returnListUUIDs,
        WFObjectName: this.boService.getWFObjectName(),
        BaseUrl: this.router.url,
        Action: 'Rejected',
        Comment: value.returnReason
      };
      this.boService.reviewBOL(data).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.afterReturnConfirm.emit();
            this.doubleCheckCancelClick();
          }
        }
      );
    }
  }

  /**
   * 名單退回 dialog open
   *
   * @memberof ReturnCaseDialogComponent
   */
  public open() {
    this.form.reset();
    this.dialog.open();
  }

  /**
   * 名單退回 dialog confirm click
   *
   * @memberof ReturnCaseDialogComponent
   */
  public onConfirmClick() {
    this.doubleCheckDialog.open();
    this.dialog.close();
  }

  /**
   * 名單退回 dialog cancel click
   *
   * @memberof ReturnCaseDialogComponent
   */
  public onCancelClick() {
    if (this.returnTo === ReturnTo.OPERATOR ) {
      this.boService.cancelCheckoutBOLWF({
        WFObjectName: this.boService.getWFObjectName(),
        UUIds: this.returnListUUIDs
      }).subscribe(
        (resp) => {
          if (resp.isOk) {
            this.form.reset();
            this.dialog.close();
          }
        }
      );
    } else {
      this.form.reset();
      this.dialog.close();
    }
  }

  /**
   * 二次確認 dialog confirm click
   *
   * @memberof ReturnCaseDialogComponent
   */
  public doubleCheckConfirmClick() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }

  /**
   * 二次確認 dialog cancel click
   *
   * @memberof ReturnCaseDialogComponent
   */
  public doubleCheckCancelClick() {
    this.doubleCheckDialog.close();
  }

  /**
   * init form controls
   *
   * @private
   * @memberof ReturnCaseDialogComponent
   */
  private prepareControls() {
    this.controls = [
      // 退回原因
      new TextareaControl({
        key: 'returnReason',
        label: '請輸入退回原因',
        isWordCount: true,
        required: true,
        columnClasses: ['12'],
        placeholder: '請輸入...'
      })
    ];
  }
}

