import { Component, OnInit, ViewChild, Input, OnDestroy, ElementRef } from '@angular/core';
import { FileUploader, FileItem, ParsedResponseHeaders } from 'ng2-file-upload';
import { Subject } from 'rxjs';
import { LoggerService } from './../../../shared/logger.service';
import { IbmDialogComponent } from './../../../shared/components/ibm-dialog/ibm-dialog.component';
import { environment } from './../../../../environments/environment';
import { BOLFileType, BOLUploadInfo } from './../../business-opportunity.model';
import { ReferralProd } from '../../../core/models/comm-data';
import { ApiService, AuthService } from 'app/core/services';

@Component({
  selector: 'esun-upload-file-dialog',
  templateUrl: './upload-file-dialog.component.html',
  styleUrls: ['./upload-file-dialog.component.scss']
})
export class UploadFileDialogComponent implements OnInit, OnDestroy {

  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('uploadEl') uploadEl: ElementRef;

  @Input('productType') productType: ReferralProd;
  @Input('header') header: string = '上傳文件';
  @Input('uploadInfo') uploadInfo: BOLUploadInfo;

  public options = [];
  public selectedValue: any = '';
  public continueUpload: boolean = false;
  public uploader: FileUploader;

  private fileName: string = '';
  private uploadComplete: Subject<any> = new Subject();
  private ngUnSubscribe: Subject<any> = new Subject();
  private custFileTypeOptions = [
    {value: BOLFileType.APPLY_DOC, label: '申請書'},
    {value: BOLFileType.IDCARD, label: '身分證'},
    {value: BOLFileType.INCOME_PROOF, label: '所得證明'},
    {value: BOLFileType.WORK_PROOF, label: '工作證明'},
    {value: BOLFileType.COLLATERAL, label: '擔保品資料'},
    {value: BOLFileType.OTHER, label: '其他'}
  ];

  private compFileTypeOptions = [
    {value: BOLFileType.APPLY_DOC, label: '申請書'},
    {value: BOLFileType.COMP_PROOF, label: '公司證明文件'},
    {value: BOLFileType.TREASURY_PROOF, label: '財資歷證明'},
    {value: BOLFileType.REVENUE_REPORT, label: '營收報表'},
    {value: BOLFileType.LOCATION_PHOTO, label: '營業地點照片'},
    {value: BOLFileType.OTHER, label: '其他'}
  ];

  constructor(
    private logger: LoggerService,
    private auth: AuthService,
    private api: ApiService
  ) {
    this.uploader = this.api.createFileUploader({
      url: `${environment.api_url}BOLFile`,
      method: 'POST',
      itemAlias: 'file',
      autoUpload: false
    });
  }


  ngOnInit() {

    this.uploader.onSuccessItem = this.onSuccessItem.bind(this);
    this.uploader.onCompleteItem = this.onCompleteItem.bind(this);
    this.uploader.onBuildItemForm = (fileItem: any, form: any) => {

      form.append('fileInfo', JSON.stringify({
        UUID: this.uploadInfo.UUID,
        BOLNo: this.uploadInfo.BOLNo,
        LoginUser: this.auth.getLoginUser(),
        BOLFileType: this.selectedValue,
        FileDPName: fileItem.file.name,
      }));
    };
    this.uploader.onAfterAddingFile = (file: any) => { file.withCredentials = false; };
    this.uploadComplete

      .subscribe(
        () => {

          if (this.continueUpload) {
            this.reset();
          } else {
            this.cancel();
          }
        }
      );
  }

  ngOnDestroy() {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isTypeSelected(): boolean {
    return this.selectedValue !== '';
  }

  get isValid(): boolean {
    return this.isTypeSelected && this.uploader.queue.length > 0 && !this.uploader.isUploading;
  }

  get getUploadedFileName(): string {
    return this.fileName;
  }

  public open() {
    if (this.productType === ReferralProd.SB) {
      this.options = this.compFileTypeOptions;
    } else if (this.productType === ReferralProd.CREDIT ||
                this.productType === ReferralProd.GUARANTEE ||
                this.productType === ReferralProd.HOUSE) {
      this.options = this.custFileTypeOptions;
    } else {
      // 除了小型企業(SB)，其他產品通通都是申請書、身分證、所得證明、工作證明、擔保品資料、其他
      this.options = this.custFileTypeOptions;
    }
    this.dialog.open();
  }

  public cancel() {
    this.dialog.close();
  }

  public confirm() {
    // this.uploader.queue[0].upload();
    // console.log(this.uploader.queue[0].upload());
    this.uploader.queue[0].upload();
    this.logger.debug('upload: ', this.uploader.queue[0].file.name);
  }

  public afterClose() {
    this.reset();
  }

  public selectedFile(fileList: any) {
    if (fileList && fileList.length !== 0) {
      this.fileName = fileList[0].name;
      this.uploader.clearQueue();
      this.uploader.addToQueue(fileList, this.uploader.options);
    }
  }

  private reset() {
    this.fileName = '';
    this.selectedValue = '';
    this.continueUpload = false;
    this.uploader.cancelAll();
    this.uploader.clearQueue();
    this.uploadEl.nativeElement.value = '';
  }

  private onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    this.uploadComplete.next();
  }

  private onCompleteItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    // this.uploadComplete.next();
  }


}
