// angular module
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
// component
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
// service
import { SelectOptionsService } from '../../../shared/services/select-options.service';
import { BusinessOppotunityService } from 'app/core/services';
// helper
import { BOLNormalCaseDuplicateTableRowDto } from 'app/business-opportunity/business-opportunity.model';

/**
 *  search group dialog
 */
@Component({
  selector: 'esun-search-group-dialog',
  templateUrl: './search-group-dialog.component.html',
  styleUrls: ['./search-group-dialog.component.scss']
})
export class SearchGroupDialogComponent implements OnInit {

  /**
   * 查詢重複群組 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof SearchGroupDialogComponent
   */
  @ViewChild('group') groupDialog: IbmDialogComponent;

  /**
   * 移轉重點摘要 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof SearchGroupDialogComponent
   */
  @ViewChild('trans') transDialog: IbmDialogComponent;

  /**
   * 設定成功 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof SearchGroupDialogComponent
   */
  @ViewChild('result') resultDialog: IbmDialogComponent;

  /**
   * 查詢重複群組的名單編號
   *
   * @type {string}
   * @memberof SearchGroupDialogComponent
   */
  @Input('bolNo') bolNo: string;

  /**
   * 已選擇名單
   *
   * @type {BOLNormalCaseDuplicateTableRowDto}
   * @memberof SearchGroupDialogComponent
   */
  public selectedRow: BOLNormalCaseDuplicateTableRowDto;

  /**
   * add style class to others row
   *
   * @memberof SearchGroupDialogComponent
   */
  public resultClassNameFunction = (row) => {
    if (this.selectedRow.UUID !== row.UUID) {
      return 'table-light';
    }
  };

  /**
   * add style class to unSelectable row
   *
   * @memberof SearchGroupDialogComponent
   */
  public selectableRowClassFunction = (row) => {
    if (!row.selectable) {
      return 'table-light';
    }
    return '';
  };

  /**
   * dulpicate BOL list
   *
   * @type {BOLNormalCaseDuplicateTableRowDto[]}
   * @memberof SearchGroupDialogComponent
   */
  public dataSource: BOLNormalCaseDuplicateTableRowDto[] = [];

  /**
   * control after dialog close,
   * whether call reset or not
   *
   * @private
   * @memberof SearchGroupDialogComponent
   */
  private isProcessing = false;

  constructor(
    private router: Router,
    private boService: BusinessOppotunityService,
    private option: SelectOptionsService
  ) { }

  ngOnInit() {
  }

  /**
   * get dialog header
   *
   * @readonly
   * @type {string}
   * @memberof SearchGroupDialogComponent
   */
  get dialogHeader(): string {
    return `群組名單(${this.dataSource.length || 0})`;
  }

  /**
   * open dialog
   *
   * @memberof SearchGroupDialogComponent
   */
  public open() {
    this.isProcessing = true;
    this.getBolDuplicate();
    this.groupDialog.open();
  }

  /**
   * set main BOL
   *
   * @memberof SearchGroupDialogComponent
   */
  public onGroupConfirmClick() {
    this.groupDialog.close();
    if (this.dataSource
            .filter( data => data !== this.selectedRow )
            .filter( data => data.pointAbstract !== null ).length > 0 ) {
      this.closeDialog();
      // open transfer warning dialog
      this.transDialog.open();
    } else {
      this.setMainBol(false);
    }
  }

  /**
   * cancel group dialog
   *
   * @memberof SearchGroupDialogComponent
   */
  public onGroupCancelClick() {
    this.isProcessing = false;
    this.groupDialog.close();
  }

  /**
   * cancel transfer warning dialog
   *
   * @memberof SearchGroupDialogComponent
   */
  public onTransCancelClick() {
    this.isProcessing = false;
    this.transDialog.close();
  }

  /**
   * transfer pointAbstract to new main BOL or not
   *
   * @memberof SearchGroupDialogComponent
   */
  public onTransClick(needTrans: boolean) {
    this.setMainBol(needTrans);
  }

  /**
   * result dialog
   *
   * @memberof SearchGroupDialogComponent
   */
  public onResultConfirmClick() {
    this.isProcessing = false;
    this.resultDialog.close();
  }

  /**
   * dialog afterClose event emit
   *
   * @memberof SearchGroupDialogComponent
   */
  public afterClosed() {
    if (!this.isProcessing) {
      this.reset();
    }
  }

  /**
   * navigate to BOLDetail or CustomerDetail
   *
   * @param {string[]} link
   * @memberof SearchGroupDialogComponent
   */
  public goDetail(link: string[]) {
    this.closeDialog();
    this.router.navigate(link);
  }

  /**
   * close dialog
   *
   * @private
   * @memberof SearchGroupDialogComponent
   */
  private closeDialog() {
    this.isProcessing = false;
    if (this.groupDialog.isOpen) {
      this.groupDialog.close();
    }
    if (this.resultDialog.isOpen) {
      this.resultDialog.close();
    }
  }

  /**
   * reset propety
   *
   * @private
   * @memberof SearchGroupDialogComponent
   */
  private reset() {
    this.dataSource = [];
    this.selectedRow = null;
  }

  /**
   * set main BOL
   *
   * @private
   * @memberof SearchGroupDialogComponent
   */
  private setMainBol(isTransferOldPointAbstract: boolean) {
    let body = {
      BOLNo: this.selectedRow.BOLNo,
      isTransferOldPointAbstract: isTransferOldPointAbstract,
      mainBOLUUID: this.selectedRow.mainBOLUUID
    }
    this.boService.setMainBOL(body).subscribe(
      (resp) => {
        if (resp.isOk) {
          this.closeDialog();
          this.getBolDuplicate();
          this.resultDialog.open();
        }
      }
    )
  }

  /**
   * get duplicate BOL
   *
   * @private
   * @memberof SearchGroupDialogComponent
   */
  private getBolDuplicate() {
    this.boService.getBolDuplicate(this.bolNo).subscribe(
      (duplicate) => {
        this.dataSource = duplicate;
        this.selectedRow = this.dataSource.filter(data => data.selectable)[0] || null;
      }
    );
  }
}
