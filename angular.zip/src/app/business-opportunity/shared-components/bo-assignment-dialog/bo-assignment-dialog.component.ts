import { FormGroup } from '@angular/forms';
import { LoggerService } from './../../../shared/logger.service';
import { DynamicFormComponent } from './../../../shared/components/dynamic-form/dynamic-form.component';
import { Component, OnInit, ViewChild, Input, AfterViewInit } from '@angular/core';
import { IbmDialogComponent } from '../../../shared/components/ibm-dialog/ibm-dialog.component';
import { RadioControl } from '../../../shared/components/dynamic-form/controls/radio-control';
import { SingleDropdownControl } from '../../../shared/components/dynamic-form/controls/single-dropdown-control';
import { MultiSelectControl } from '../../../shared/components/dynamic-form/controls/multi-select-control';
import * as _ from 'lodash';
import { BusinessOppotunityService } from '../../../core/services/business-oppotunity.service';
import { SelectOptionsService } from 'app/shared/services/select-options.service';
import { BOLAssignCaseDto } from '../../business-opportunity.model';

@Component({
  selector: 'esun-bo-assignment-dialog',
  templateUrl: './bo-assignment-dialog.component.html',
  styleUrls: ['./bo-assignment-dialog.component.scss']
})
export class BoAssignmentDialogComponent implements OnInit, AfterViewInit {
  @ViewChild('dialog') dialog: IbmDialogComponent;
  @ViewChild('form') form: DynamicFormComponent;

  @Input('header') header: string = '';
  @Input('reAssign') reAssign: boolean = false;
  @Input('boList')
  set boList(value: BOLAssignCaseDto[]) {
    if (value.length !== 0 && value) {
      this.privateBoList = value;
      this.assigneeFilter = _.uniqBy(this.privateBoList, 'marketingPersonID').map(element => {
        return element.marketingPersonID;
      });
      this.branchFilter = _.uniqBy(this.privateBoList, 'marketingUnitID').map(element => {
        return element.marketingUnitID;
      });
      this.initControlOptions();
    }
  }

  public controls: any[] = [];
  public assigneeList: any[] = [];
  public branchList: any[] = [];

  private privateBoList: BOLAssignCaseDto[] = [];
  private branchOptions: any[];
  private branchFilter: any[] = [];
  private assigneeOptions: any[] = [];
  private assigneeFilter: any[] = [];

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private option: SelectOptionsService
  ) { }

  ngOnInit() {
    this.branchOptions = this.option.getOptions('bankBranches');
    this.assigneeOptions = this.option.getOptions('employee');
    this.prepareControls();
  }

  ngAfterViewInit() {
    this.form.form.valueChanges
      .subscribe(
        (value) => {
          if (value.assignee && value.assignee !== '') {
            this.assigneeList = value.assignee.map(
              (assignee) => {
                return {
                  assignee: assignee,
                  count: 0
                };
              }
            );
          }

          if (value.branches && value.branches !== '') {
            this.branchList = value.branches.map(
              (branch) => {
                return {
                  branch: branch,
                  count: 0
                };
              }
            );
          }
        }
      );
  }

  get isValid() {
    if (this.showAssignCount) {
      let temp = 0;
      this.assigneeList.forEach(
        (assignee) => {
          temp = temp + assignee.count;
        }
      );

      return temp === this.privateBoList.length;
    }

    if (this.showAssignBranchCount) {
      let temp = 0;
      this.branchList.forEach(
        (branch) => {
          temp = temp + branch.count;
        }
      );

      return temp === this.privateBoList.length;
    }
    return this.form.form.valid || false;
  }

  get boListCount() {
    return this.privateBoList.length;
  }

  get showAssignCount(): boolean {
    return this.form.form.controls['assignType'].value === '3' && this.form.form.controls['assignOption'].value === '1';
  }

  get showAssignBranchCount(): boolean {
    return this.form.form.controls['branchAssignType'].value === '3' && this.form.form.controls['assignOption'].value === '2';
  }

  public onSubmit(value) {
    // todo
    // Http request then close dialog
    // this.logger.debug('assignment value: ', value);
    // this.logger.debug('assignment boList: ', this.privateBoList);
    // setTimeout(() => {
    //   this.cancel();
    // }, 10000);
    let result = {
      assignOption: value.assignOption,
      bolNos: this.privateBoList.map( (el) => {
        return el.BOLNo;
      })
    };
    if (value.assignOption === '2') {
      result['assignWay'] = value.branchAssignType;
      if (result['assignWay'] === '1') {
        result['assignWayDetails'] = [{
          assignTarget: value.assignBranch,
          count: this.privateBoList.length
        }];
      }
      if (result['assignWay'] === '2') {
        result['assignWayDetails'] = value.assignBranchRandom.map((branch) => {
          return {
            assignTarget: branch,
          };
        });
      }
      if (result['assignWay'] === '3') {
        result['assignWayDetails'] = this.branchList.map((branch) => {
          return {
            assignTarget: branch.branch,
            count: branch.count
          };
        });
      }
    } else {
      result['assignWay'] = value.assignType;
      if (result['assignWay'] === '1') {
        result['assignWayDetails'] = [{
          assignTarget: value.assignAo,
          count: this.privateBoList.length,
          usedCount: 0
        }];
      }
      if (result['assignWay'] === '2') {
        result['assignWayDetails'] = value.assignRandom.map((branch) => {
          return {
            assignTarget: branch,
          };
        });
      }
      if (result['assignWay'] === '3') {
        result['assignWayDetails'] = this.assigneeList.map((assignee) => {
          return {
            assignTarget: assignee.assignee,
            count: assignee.count,
            usedCount: 0
          };
        });
      }
    }

    this.boService.assignBOL(result).subscribe(
      (resp) => {
        console.log(resp);
        if (resp.isOk) {
          this.dialog.close();
        }
      }
    );

    console.log(result);
  }

  public open() {
    this.dialog.open();
  }

  public confirm() {
    if (this.form.form.valid) {
      this.form.submit();
    }
  }
  public cancel() {
    this.dialog.close();
  }

  public dialogAfterClosed() {
    this.form.reset();
    this.assigneeList = [];
    this.branchList = [];
  }

  private prepareControls() {
    this.controls = [
      new RadioControl({
        key: 'assignOption',
        label: '分配選項',
        value: '2',
        columnClasses: ['12'],
        required: true,
        options: [
          {value: '2', label: '分行'},
          {value: '1', label: '人員'}
        ]
      }),
      new SingleDropdownControl({
        key: 'branchAssignType',
        label: '分派方式',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        options: [
          {value: '1', label: '指定分行'},
          {value: '2', label: '隨機分派'},
          {value: '3', label: '筆數分配'},
        ],
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '2';
        }
      }),
      new SingleDropdownControl({
        key: 'assignBranch',
        label: '分派分行',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.branchOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '2' && form.controls['branchAssignType'].value === '1';
        }
      }),
      new MultiSelectControl({
        key: 'assignBranchRandom',
        label: '分派分行',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.branchOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '2' && form.controls['branchAssignType'].value === '2';
        }
      }),
      new MultiSelectControl({
        key: 'branches',
        label: '分派分行',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.branchOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '2' && form.controls['branchAssignType'].value === '3';
        }
      }),
      new SingleDropdownControl({
        key: 'assignType',
        label: '分派方式',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        options: [
          {value: '1', label: '指定人員'},
          {value: '2', label: '隨機分派'},
          {value: '3', label: '筆數分配'},
        ],
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '1';
        }
      }),
      new SingleDropdownControl({
        key: 'assignAo',
        label: '分派人員',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.assigneeOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '1' && form.controls['assignType'].value === '1';
        }
      }),
      new MultiSelectControl({
        key: 'assignRandom',
        label: '分派人員',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.assigneeOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '1' && form.controls['assignType'].value === '2';
        }
      }),
      new MultiSelectControl({
        key: 'assignee',
        label: '分派人員',
        placeholder: '請選擇...',
        required: true,
        columnClasses: ['12'],
        enableAutocomplete: true,
        options: this.assigneeOptions,
        condition: (form: FormGroup) => {
          return form.controls['assignOption'].value === '1' && form.controls['assignType'].value === '3';
        }
      })
    ];
  }

  private getIndex(array: any[], pattern: any): number {
    return _.findIndex(array, pattern);
  }

  private changeControlOptions(source: any[], filter: any[]): any[] {
    if (this.reAssign) {
      return source.filter( (options) => {
        return filter.indexOf(options.value) === -1;
      });
    }
    return source;
  }

  private initControlOptions() {
    const branchPattern = [
      ['key', 'assignBranch'],
      ['key', 'assignBranchRandom'],
      ['key', 'branches']
    ];
    const assaignPattern = [
      ['key', 'assignAo'],
      ['key', 'assignRandom'],
      ['key', 'assignee']
    ];
    const branchIndexes = branchPattern.map( (pattern) => {
      return this.getIndex(this.controls, pattern);
    });

    const assignIndexes = assaignPattern.map( (pattern) => {
      return this.getIndex(this.controls, pattern);
    });

    assignIndexes.forEach( (index) => {
      this.controls[index].options = this.changeControlOptions(this.assigneeOptions, this.assigneeFilter);
      this.logger.debug('assigneeOptions length: ', this.controls[index].options.length);
    });

    branchIndexes.forEach( (index) => {
      this.controls[index].options = this.changeControlOptions(this.branchOptions, this.branchFilter);
      this.logger.debug('branchOptions length: ', this.controls[index].options.length);
    });
  }
}
