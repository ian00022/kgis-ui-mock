import { BOLSource } from './../../business-opportunity.model';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BusinessOppotunityService } from 'app/core/services/business-oppotunity.service';

@Component({
  selector: 'esun-market-record',
  templateUrl: './market-record.component.html',
  styleUrls: ['./market-record.component.scss']
})
export class MarketRecordComponent implements OnInit {

  @Input('marketRecord')
  set marketRecord(value) {
    if (value) {
      this.tableData = value;
    }
  }

  @Input('remarkInfo')
  set remarkInfo(value) {
    if (value) {
      this.createRemarkInfo = value;
    }
  }

  @Output('afterCreateNote') afterCreateNote: EventEmitter<any> = new EventEmitter();

  public tableData: any[] = [];
  public createRemarkInfo;
  constructor(
    private boService: BusinessOppotunityService
  ) { }

  ngOnInit() {
  }

  public handleAfterCreateNote(value) {
    this.boService.triggerBOLUpdate(value);
    this.afterCreateNote.emit(value);
  }

  public getBOLLink(row) {
    return ['/business-op', 'detail', row.BOLNo];
  }

  public getBOLSourceLabel(row) {
    return BOLSource[row.BOLSource];
  }
}
