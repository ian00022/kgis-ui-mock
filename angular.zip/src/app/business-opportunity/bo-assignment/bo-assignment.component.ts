import { ValidatorFn } from '@angular/forms';
import { Permissions } from './../../core/models/permissions';
import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { IbmTableComponent } from '../../shared/components/ibm-table/ibm-table.component';
import { IbmTabsComponent } from '../../shared/components/ibm-tabs/ibm-tabs.component';
import { IbmDialogComponent } from '../../shared/components/ibm-dialog/ibm-dialog.component';
import { CheckBoxTableHelper } from './../../shared/helper/table-checkbox-helper';
import { BolHelper } from '../bol-helper';
import { BOLSearchAction } from './../business-opportunity.model';
import { DateHelper } from './../../shared/helper/date-helper';
import { DynamicFormComponent } from './../../shared/components/dynamic-form/dynamic-form.component';
import { ControlBase, MultiSelectControl, TextControl, SingleDropdownControl, DatepickerControl } from './../../shared/components/dynamic-form/controls';
import { BusinessOppotunityService } from './../../core/services/business-oppotunity.service';
import { LoggerService } from './../../shared/logger.service';
import { CirciKeyValidator } from '../../shared/functions/validators';
import { HeadCaseDetailType } from '../business-opportunity.model';
import { BolSharedService } from 'app/business-opportunity/bol-shared-service.service';
import BOSharedFunctions from '../bo-shared-functions/shared-functions';
import { ISelectOptionModel } from 'app/core/models/comm-data';

@Component({
  selector: 'esun-bo-assignment',
  templateUrl: './bo-assignment.component.html',
  styleUrls: ['./bo-assignment.component.scss']
})
export class BoAssignmentComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('normalCaseTable') normalCaseTable: IbmTableComponent;
  @ViewChild('headofficeCaseTable') headofficeCaseTable: IbmTableComponent;
  @ViewChild('normalCaseForm') normalCaseForm: DynamicFormComponent;
  @ViewChild('headofficeCaseForm') headofficeCaseForm: DynamicFormComponent;
  @ViewChild('rejectToHeadOffice') rejectToHeadOfficeDialog: IbmDialogComponent;
  @ViewChild('boAssignment') boAssignmentDialog: IbmDialogComponent;
  @ViewChild('tabs') tabs: IbmTabsComponent;

  /**
   * 總行案件 form validator
   *
   * @memberof BoSearchComponent
   */
  public headofficeFormValidator: ValidatorFn;
  public requiredAnyKeys = ['assignedDate', 'personCertNo'];
  public normalCaseControls: ControlBase<any>[] = [];
  public headofficeCaseControls: ControlBase<any>[] = [];
  public normalTableData: any[] = [];
  public headOfficeTableData: any[] = [];
  public boAssignmentDialogHeader;
  public rejectList: any[] = [];
  public assigneeList: any[] = [];
  public selectedRowData: any = {};

  public normalCaseOrderTypes: ISelectOptionModel[] = [
    { value: 'BOLStatus', label: '名單狀態' },
    { value: 'assignDate', label: '分派/建立日期' },
    { value: 'customerId', label: '統一編號' },
    { value: 'customerName', label: '戶名' },
    { value: 'productType', label: '產品別' },
    { value: 'marketingUnit', label: '行銷單位' },
    { value: 'marketingPerson', label: '行銷人員' },
    { value: 'BOLSource', label: '名單來源' },
    { value: 'BOLType', label: '名單類型' }
  ];

  public headofficeCaseOrderTypes = [
    { label: '單號', value: 'number' },
    { label: '主旨', value: 'subject' },
    { label: '建立者', value: 'operator' },
    { label: '指派單位', value: 'department' },
    { label: '指定回覆日期', value: 'relpyDate' },
    { label: '結案日期', value: 'dueDate' },
  ];

  public bolStatusOptions = [
    {value: 'INIT', label: '未執行'},
    {value: 'INPRG', label: '追蹤中'},
    {value: 'SUBMT', label: '已受理'},
    {value: 'RJECT', label: '婉拒'},
    {value: 'REF', label: '轉介其他商品'},
    {value: 'SYCLOS', label: '系統自動銷案'},
    {value: 'DUP', label: '重複商機結案'}
  ];

  public headBolStatusOptions = [
    {value: 'INIT', label: '未執行'},
    {value: 'END', label: '已結案'},
  ];

  public branchOptions = [
    { value: '01234', label: '01234 板橋分行' },
    { value: '01235', label: '01235 林口分行' },
    { value: '01236', label: '01236 台北分行' },
  ];

  public employeeOptions = [
    { label: '(11234) 王小明', value: '11234'},
    { label: '(21235) 王中明', value: '21235'},
    { label: '(31236) 華小明', value: '31236'},
    { label: '(41237) 黃小明', value: '41237'},
    { label: '(0001) 王小圖', value: '0001'},
  ];

  public bolSourceOptions = [
    {value: '1', label: 'EBM'},
    {value: '2', label: '網路進件'},
    {value: '3', label: '系統轉介'},
    {value: '4', label: '自建名單'},
  ];

  public dateTypeOptions = [
    {value: '1', label: '建立日期'},
    {value: '2', label: '指定回覆日期'},
    {value: '3', label: '結案日期'},
  ];

  public normalCase = {
    tabTitle: '一般名單',
    currentOrderType: this.normalCaseOrderTypes[0],
    selectedRowList: [],
    listConfig: {} as any
  };

  public headofficeCase = {
    tabTitle: '總行指派案件',
    currentOrderType: this.headofficeCaseOrderTypes[0],
    selectedRowList: [],
    listConfig: {} as any
  };

  public normalCaseSelectedRow: any;
  public headOfficeCaseSelectedRow: any;
  public Permissions = Permissions;
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private logger: LoggerService,
    private boService: BusinessOppotunityService,
    private router: Router,
    private route: ActivatedRoute,
    private bolShared: BolSharedService
  ) { }

  ngOnInit() {
    this.prepareControls();
    this.headofficeFormValidator = BOSharedFunctions.headofficeFormValidators(this.headofficeCaseControls);
  }

  ngAfterViewInit() {
    let params = this.route.snapshot.queryParams;
    if (params.activeTab) {
      this.tabs.selectTab(_.parseInt(params.activeTab));
    }
    this.normalCaseForm.form.patchValue({
      bolStatus: this.bolStatusOptions.map(el => el.value),
      assignedDate: DateHelper.getLastThreeMonths()
    });
    this.headofficeCaseForm.form.patchValue({
      bolStatus: this.headBolStatusOptions.map(el => el.value),
      selectDate: DateHelper.getLastThreeMonths()
    });

    this.normalCaseForm.submit();
    this.headofficeCaseForm.submit();
  }

  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  get isNormalCaseFormValid(): boolean {
    return this.normalCaseForm.form.valid;
  }

  get isNormalCaseAnySelected(): boolean {
    if (this.normalCaseTable) {
      return this.normalCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  get isHeadOfficeCaseAnySelected(): boolean {
    if (this.headofficeCaseTable) {
      return this.headofficeCaseTable.getcurrentPageRows().filter( el => el.checked ).length !== 0;
    }
    return false;
  }

  get disableButton(): boolean {
    if (this.tabs.selectedTab) {
      if (this.isNormalCaseMode) {
        return this.normalCase.selectedRowList.length === 0 ;
      } else {
        return this.headofficeCase.selectedRowList.length === 0 ;
      }
    }
    return true;
  }

  get isNormalCaseMode(): boolean {
    if (this.tabs.selectedTab) {
      return this.tabs.selectedTab.tabTitle === this.normalCase.tabTitle;
    }
    return true;
  }

  public updateActiveTab(event) {
    const index = event.index;
    this.router.navigate([],{
        relativeTo: this.route,
        queryParams: {
          activeTab: index
        },
        queryParamsHandling: 'merge'
      });
  }


  public goHeadOffice(UUID: any) {
    this.bolShared.setHeadCaseType(HeadCaseDetailType.ASSIGNMENT);
    this.router.navigate(['/business-op', 'headCase', UUID]);
  }

  public handleSubmit(listConfig: any) {
    let config;
    if (this.isNormalCaseMode) {
      this.normalCase.listConfig = listConfig;
      config = _.assign(_.cloneDeep(listConfig), {
        pf: this.normalCaseTable.pageFilter,
        orderCol: this.normalCase.currentOrderType.value
      });
      if (config.assignedDate) {
        config.assignedDate = DateHelper.divideDate(config.assignedDate);
      }
      this.boService.query(config, BOLSearchAction.ASSIGN_SEARCH ).subscribe(
        (data) => {
          this.normalTableData = data;
          // this.normalTableData = resp.value.map( (el) => {
          //   return BolHelper.processNormalCaseTableData(el);
          // });
      });

    } else {
      this.headofficeCase.listConfig = listConfig;
      config = _.assign(_.cloneDeep(listConfig), {
        pf: this.headofficeCaseTable.pageFilter,
        orderCol: this.headofficeCase.currentOrderType.value
      });
      if (config.selectDate) {
        config.selectDate = DateHelper.divideDate(config.selectDate);
      }
      this.boService.queryHeadOffice(config, BOLSearchAction.ASSIGN_SEARCH ).subscribe(
        (data) => {
          this.headOfficeTableData = data;
      });
    }
  }

  public handleSelectAllCheckboxClick(type: string) {
    switch (type) {
      case 'normalCase':
      this.normalCase.selectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isNormalCaseAnySelected,
          this.normalCaseTable.getcurrentPageRows(),
          this.normalCase.selectedRowList
        );
        this.logger.debug('normalCaseSelectAll length: ', this.normalCase.selectedRowList.length);
        break;
      case 'headofficeCase':
      this.headofficeCase.selectedRowList = CheckBoxTableHelper.handleSelectAll(
          this.isHeadOfficeCaseAnySelected,
          this.headofficeCaseTable.getcurrentPageRows(),
          this.headofficeCase.selectedRowList
        );
        this.logger.debug('headofficeCaseSelectAll length: ', this.headofficeCase.selectedRowList.length);
        break;
      default:
        break;
    }
  }

  public handleCheckboxClick(row: any, type: string) {
    switch (type) {
      case 'normalCase':
      this.normalCase.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.normalCase.selectedRowList);
        break;
      case 'headofficeCase':
      this.headofficeCase.selectedRowList = CheckBoxTableHelper.handleSelected(!row.checked, row, this.headofficeCase.selectedRowList);
        break;
      default:
        break;
    }
  }

  public handleAssignmentClick(row: any) {
    this.normalCaseSelectedRow = row;
    this.openModal('boAssignment', true);
  }

  public openModal(type: string, isSingleSelect: boolean = false) {
    switch (type) {
      case 'rejectToHeadOffice':
        if (this.isNormalCaseMode) {
          this.rejectList = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.normalCase.selectedRowList);
        } else {
          this.rejectList = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.headofficeCase.selectedRowList);
        }
        this.rejectToHeadOfficeDialog.open();
        break;
      case 'boAssignment':
          if (this.isNormalCaseMode) {
            const list = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.normalCase.selectedRowList);
            this.boAssignmentDialogHeader = `改派名單 (${list.length})`;
            this.assigneeList = list;
          } else {
            const list = isSingleSelect ? [this.selectedRowData] : _.cloneDeep(this.headofficeCase.selectedRowList);
            this.boAssignmentDialogHeader = `改派名單 (${list.length})`;
            this.assigneeList = list;
          }
        this.boAssignmentDialog.open();
        break;
      default:
       break;
    }
  }

  public openMenu(row: any) {
    if (this.tabs.selectedTab.tabTitle === '一般名單') {
      this.normalCaseSelectedRow = row;
    } else {
      this.headOfficeCaseSelectedRow = row;
    }
  }

  private prepareControls() {
    this.normalCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolStatusOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'assignedDate',
        label: '分派/建立日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      }),
      new TextControl({
        key: 'personCertNo',
        label: '身分證字號/統一編號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: 'e.g. A123456789',
        validators: [CirciKeyValidator]
      }),
      new SingleDropdownControl({
        key: 'marketingUnitCode',
        label: '行銷單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        enableAutocomplete: true,
        placeholder: '請選擇...',
        options: this.branchOptions
      }),
      new MultiSelectControl({
        key: 'bolSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bolSourceOptions,
        placeholder: '請選擇...'
      }),
    ];

    this.headofficeCaseControls = [
      new MultiSelectControl({
        key: 'bolStatus',
        label: '名單狀態',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.headBolStatusOptions,
        placeholder: '請選擇...'
      }),
      new TextControl({
        key: 'caseNo',
        label: '單號',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'subject',
        label: '主旨',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new TextControl({
        key: 'createEmpId',
        label: '建立者',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請輸入...'
      }),
      new SingleDropdownControl({
        key: 'type',
        label: '日期類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.dateTypeOptions,
        placeholder: '請選擇...'
      }),
      new DatepickerControl({
        key: 'selectDate',
        label: '　',
        columnClasses: ['12', 'md-4', 'lg-3'],
        placeholder: '請選擇日期...'
      })
    ];
  }
}
