import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'esun-unauth',
  templateUrl: './unauth.component.html',
  styleUrls: ['./unauth.component.scss']
})
export class UnauthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
