import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { NgxPermissionsModule, NgxPermissionsService } from 'ngx-permissions';
import { NgProgressHttpModule } from '@ngx-progressbar/http';
import { NgProgressModule } from '@ngx-progressbar/core';
import { SignalRModule, SignalRConfiguration } from 'ng2-signalr';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LayoutModule } from './layout/layout.module';
import { CoreModule } from './core/core.module';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UnauthComponent } from './unauth/unauth.component';

import { SharedModule } from './shared/shared.module';
import { SamplePagesComponent } from './sample-pages/sample-pages.component';
import { AuthService } from 'app/core/services/auth.service';
import { SimplePermissionDto } from './core/models/permissions';
import { PermissionResponseDto } from 'app/core/models/permissions';
import { JwtService } from './core/services/jwt.service';
import { GlobalHttpInterceptor } from './core/interceptors/global-http-interceptor';

/**
 * create signalR config function for SignalRModule
 *
 * @export
 * @returns {SignalRConfiguration}
 */
export function createConfig(): SignalRConfiguration {
  const config = new SignalRConfiguration();
  config.hubName = 'notificationHub';
  config.url = 'https://esunbank-mars-signalr.azurewebsites.net/signalr/hubs';
  // config.logging = true;

  // >= v5.0.0
  // c.executeEventsInZone = true; // optional, default is true
  // c.executeErrorsInZone = false; // optional, default is false
  // c.executeStatusChangeInZone = true; // optional, default is true
  return config;
}



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SamplePagesComponent,
    UnauthComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    LayoutModule,
    CoreModule,
    SharedModule,
    NgxPermissionsModule.forRoot(),
    NgProgressModule.forRoot(),
    NgProgressHttpModule.forRoot(),
    SignalRModule.forRoot(createConfig)
  ],
  providers: [
    AuthService,
    {
      provide: APP_INITIALIZER,
      useFactory: (as: AuthService, ps: NgxPermissionsService, js: JwtService ) => function () {
        // sessionID or token
        let tokenID = js.getToken();
        if (tokenID) {
          return as.loadPermissionsByToken().toPromise()
          .then(
            (data: PermissionResponseDto) => {
              const permissions = data.Permissions.map((p: SimplePermissionDto) => p.Code);
              // if load permission failed
              if (permissions.length === 0) {
                permissions.push('NEED_LOGIN');
              } else {
                permissions.push('LOGIN_SUCCESS');
              }
              ps.loadPermissions(permissions);
            }
          );
        } else {
          return ps.loadPermissions(['NEED_LOGIN']);
        }
      },
      deps: [AuthService, NgxPermissionsService, JwtService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: GlobalHttpInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
