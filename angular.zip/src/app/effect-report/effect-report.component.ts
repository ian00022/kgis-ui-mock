// angular module
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { PercentPipe, DecimalPipe, DatePipe, CurrencyPipe } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
// 3rd party module
import * as _ from 'lodash';
// model
import { ControlBase, DatepickerControl, SingleDropdownControl, MultiSelectControl } from './../shared/components/dynamic-form/controls';
import { Permissions } from 'app/core/models/permissions';
import { EffectReportSearchParams, EffectReportType } from './effect-report.model';
import { ISelectOptionModel } from '../core/models/comm-data';
import { CalculateType } from '../shared/components/ibm-table/ibm-table.model';
// component
import { IbmDialogComponent } from './../shared/components/ibm-dialog/ibm-dialog.component';
import { DynamicFormComponent } from './../shared/components/dynamic-form/dynamic-form.component';
import { IbmTableComponent } from '../shared/components/ibm-table/ibm-table.component';
import { IbmTabsComponent } from '../shared/components/ibm-tabs/ibm-tabs.component';
// service
import { ApiService, EffectReportService } from 'app/core/services/';
import { SharedService } from '../shared/services/shared.service';
import { SelectOptionsService } from '../shared/services/select-options.service';
// helper
import { DateHelper } from 'app/shared/helper/date-helper';

/**
 * effect report component
 */
@Component({
  selector: 'esun-effect-report',
  templateUrl: './effect-report.component.html',
  styleUrls: ['./effect-report.component.scss'],
  providers:[ PercentPipe, DecimalPipe, DatePipe, CurrencyPipe ]
})
export class EffectReportComponent implements OnInit, OnDestroy {

  /**
   * 名單執行成效 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('executeDialog') executeDialog: IbmDialogComponent;

  /**
   * 名單執行明細 dialog
   *
   * @type {IbmDialogComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('detailDialog') detailDialog: IbmDialogComponent;

  /**
   * 名單執行成效 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('execute') executeForm: DynamicFormComponent;

  /**
   * 名單執行成效 table
   *
   * @type {IbmTableComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('executeTable') executeTable: IbmTableComponent;

   /**
   * 名單執行明細 dynamic form
   *
   * @type {DynamicFormComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('detail') detailForm: DynamicFormComponent;

  /**
   * 名單執行明細 table
   *
   * @type {IbmTableComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('detailTable') detailTable: IbmTableComponent;

  /**
   * tabs
   *
   * @type {IbmTabsComponent}
   * @memberof EffectReportComponent
   */
  @ViewChild('tabs') tabs: IbmTabsComponent;

  /**
   * permissions enum property for template
   *
   * @memberof EffectReportComponent
   */
  public Permissions = Permissions;

  /**
   * search dynamic form controls
   *
   * @type {ControlBase<any>[]}
   * @memberof EffectReportComponent
   */
  public searchFormControls: ControlBase<any>[] = [];

  /**
   * 名單執行成效 tableData
   *
   * @type {any[]}
   * @memberof EffectReportComponent
   */
  public executeTableData: any[] = [];

  /**
   * 名單執行明細 tableData
   *
   * @type {any[]}
   * @memberof EffectReportComponent
   */
  public detailData: any[] = [];

  /**
   * 名單執行成效匯出 list
   *
   * @type {*}
   * @memberof EffectReportComponent
   */
  public executeListConfig: any = {};

  /**
   * 名單執行明細匯出 list
   *
   * @type {*}
   * @memberof EffectReportComponent
   */
  public detailListConfig: any = {};

  /**
   * ibm-table summary row type
   *
   * @type {*}
   * @memberof EffectReportComponent
   */
  public calculateType: any = CalculateType;

  /**
   * 分行選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof EffectReportComponent
   */
  public bankBranchesOptions: ISelectOptionModel[];

  /**
   * 單位選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof EffectReportComponent
   */
  public bankSearchRangeOptions: ISelectOptionModel[];

  /**
   * 經辦選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof EffectReportComponent
   */
  public employeeOptions: ISelectOptionModel[];

  /**
   * 名單來源選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof EffectReportComponent
   */
  public boSourceOptions: ISelectOptionModel[];

  /**
   * 產品選單
   *
   * @type {ISelectOptionModel[]}
   * @memberof EffectReportComponent
   */
  public prodTypeOptions: ISelectOptionModel[];

  public boTypeOptions: ISelectOptionModel[];

  /**
   * unsbscribe when lifecycle run ngOnDestroy
   *
   * @private
   * @type {Subject<any>}
   * @memberof EffectReportComponent
   */
  private ngUnSubscribe: Subject<any> = new Subject();

  constructor(
    private reportService: EffectReportService,
    private sharedService: SharedService,
    private options: SelectOptionsService,
    private api: ApiService,
    private number: DecimalPipe,
    private percent: PercentPipe,
    private date: DatePipe,
    private currency: CurrencyPipe
  ) {
    const option = this.options.getOptions([
      'bankBranches',
      'bankSearchRange',
      'employee',
      'boSource',
      'prodType',
      'boType'
    ]);

    this.bankBranchesOptions = option['bankBranches'];
    this.bankSearchRangeOptions = option['bankSearchRange'];
    this.employeeOptions = option['employee'];
    this.boSourceOptions = option['boSource'];
    this.prodTypeOptions = option['prodType'];
    this.boTypeOptions = option['boType'];
  }

  /**
   * angular hook ngOnInit
   */
  ngOnInit() {
    this.prepareControls();
  }

  /**
   * angular hook ngOnDestroy
   */
  ngOnDestroy(): void {
    this.ngUnSubscribe.next();
    this.ngUnSubscribe.complete();
  }

  /**
   * check current tab
   *
   * @readonly
   * @type {EffectReportType}
   * @memberof EffectReportComponent
   */
  get effectReportType(): EffectReportType {
    return this.tabs.getSelectedTab().index === 0 ? EffectReportType.EXECUTE : EffectReportType.DETAIL;
  }

  /**
   * handle search form submit
   * distinguish which form submit by this.effectReportType
   *
   * @param {*} config
   * @memberof EffectReportComponent
   */
  public handleFormSubmit(config: any) {
    let searchParams = this.mapSearchParams(config);
    switch (this.effectReportType) {
      case EffectReportType.EXECUTE:
        this.reportService.queryExecute(searchParams)
          .subscribe(
            response => {
              this.executeTableData = response;
            });
        break;
      case EffectReportType.DETAIL:
        this.reportService.queryDetail(searchParams)
          .subscribe(
            response => {
              this.detailData = response;
            });
        break;
      default:
        break;
    }
  }

  /**
   * open export dialog
   * fn: processData => for export dialog search control descriptons
   *
   * @memberof EffectReportComponent
   */
  public onExportDialogOpen() {
    // export dialog display value & label
    if (this.effectReportType === EffectReportType.EXECUTE ) {
      this.executeListConfig = this.processData(_.cloneDeep(this.executeForm.form.value));
      this.executeDialog.open();
    } else {
      this.detailListConfig = this.processData(_.cloneDeep(this.detailForm.form.value));
      this.detailDialog.open();
    }
  }

  /**
   * export execel file
   *
   * @param {*} exportType
   * @param {IbmDialogComponent} dialog
   * @memberof EffectReportComponent
   */
  public onExportConfirmed(exportType: any, dialog: IbmDialogComponent) {

    const fileName = '成效管理';
    let searchParams: EffectReportSearchParams;
    if (this.effectReportType === EffectReportType.EXECUTE) {
      searchParams = this.mapSearchParams(this.executeForm.form.value);
      if (exportType !== 'all') {
        searchParams.pf.skip = this.executeTable.pageFilter.skip;
        searchParams.pf.take = this.executeTable.pageFilter.take;
      }

      this.reportService.queryExecute(searchParams).subscribe(
        (resp) => {
          const tableData = _.cloneDeep(resp).map( (data) => {
            const result = _.pick(data, _.keys(this.reportService.getExecuteTableHeader()));
            // todo combine id & name

            result['BOLTotalCount']= this.number.transform(result['BOLTotalCount'], '1.0-0');
            result['BOLAcceptCount']= this.number.transform(result['BOLAcceptCount'], '1.0-0');
            result['BOLProcessCount']= this.number.transform(result['BOLProcessCount'], '1.0-0');
            result['applicationApprovedCount']= this.number.transform(result['applicationApprovedCount'], '1.0-0');
            result['applicationApprovedAmount']= this.number.transform(result['applicationApprovedAmount'], '1.0-0');
            result['BOLAcceptPercentage'] = this.percent.transform(result['BOLAcceptPercentage']);
            result['BOLProcessPercentage'] = this.percent.transform(result['BOLProcessPercentage']);
            result['approvedPercentage'] = this.percent.transform(result['approvedPercentage']);
            return result;
          });
          const sheetData = this.sharedService.convertToSheetData(tableData, this.reportService.getExecuteTableHeader());
          const sheetName = '名單執行成效';
          this.sharedService.writeToSheet(sheetData, fileName, sheetName);
          dialog.close();
        }
      );
    } else {

      searchParams = this.mapSearchParams(this.detailForm.form.value);
      if (exportType !== 'all') {
        searchParams.pf.skip = this.detailTable.pageFilter.skip;
        searchParams.pf.take = this.detailTable.pageFilter.take;
      }

      this.reportService.queryDetail(searchParams).subscribe(
        (resp) => {
          const tableData = _.cloneDeep(resp).map( (data) => {
            const result = _.pick(data, _.keys(this.reportService.getDetailTableHeader()));
            // todo combine id & name
            result['createDate'] = this.date.transform(result['createDate'], 'yyyy/MM/dd');
            result['assignedDate'] = this.date.transform(result['assignedDate'], 'yyyy/MM/dd');
            result['applicationApprovedAmount'] = this.currency.transform(result['applicationApprovedAmount'],'', 'symbol' ,'1.0-0');
            result['dulpicateGroup'] = result['BOLStatus'] === 'DUP' ? '是' : '否';
            return result;
          });
          const sheetData = this.sharedService.convertToSheetData(tableData, this.reportService.getDetailTableHeader());
          const sheetName = '名單執行明細';
          this.sharedService.writeToSheet(sheetData, fileName, sheetName);
          dialog.close();
        }
      );
    }
  }

  /**
   * cancel export excel file
   *
   * @param {IbmDialogComponent} dialog
   * @memberof EffectReportComponent
   */
  public onExportCanceled(dialog: IbmDialogComponent) {
    dialog.close();
  }

  /**
   * prepare dynamic form controls
   *
   * @private
   * @memberof EffectReportComponent
   */
  private prepareControls() {
    this.searchFormControls = [

      new SingleDropdownControl({
        key: 'unitType',
        label: '單位',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bankSearchRangeOptions,
        placeholder: '請選擇...'
      }),

      new SingleDropdownControl({
        key: 'unitCode',
        label: '分行',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bankBranchesOptions,
        enableAutocomplete: true,
        condition: (form: FormGroup) => {
          return form.controls['unitType'].value === '2';
        },
        placeholder: '請選擇...'
      }),

      new MultiSelectControl({
        key: 'branchEmpIds',
        label: '分行經辦',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.employeeOptions,
        enableAutocomplete: true,
        condition: (form: FormGroup) => {
          return form.controls['unitType'].value === '2';
        },
        placeholder: '請選擇...'
      }),

      new SingleDropdownControl({
        key: 'customerCenter',
        label: '消金中心',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.bankBranchesOptions,
        enableAutocomplete: true,
        condition: (form: FormGroup) => {
          return form.controls['unitType'].value === '4';
        },
        placeholder: '請選擇...'
      }),

      new DatepickerControl({
        key: 'assignedDateInterval',
        label: '名單日期',
        columnClasses: ['12', 'md-4', 'lg-3'],
        type: 'datepicker',
        required: true,
        placeholder: '請選擇日期...'
      }),

      new SingleDropdownControl({
        key: 'caseSource',
        label: '名單來源',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.boSourceOptions,
        enableAutocomplete: true,
        placeholder: '請選擇...'
      }),

      new MultiSelectControl({
        key: 'BOLTypes',
        label: '名單類型',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.boTypeOptions,
        enableAutocomplete: true,
        placeholder: '請選擇...'
      }),

      new MultiSelectControl({
        key: 'products',
        label: '產品',
        columnClasses: ['12', 'md-4', 'lg-3'],
        options: this.prodTypeOptions,
        enableAutocomplete: true,
        placeholder: '請選擇...'
      })
    ];
  }

  /**
   * transfer data to export dialog description
   *
   * @private
   * @param {*} value
   * @returns {*}
   * @memberof EffectReportComponent
   */
  private processData(value): any {
    if (value['unitType']) {
      value['unitType'] = _.find(this.bankSearchRangeOptions, {value: value['unitType']})['label'];
    }
    if (value['unitCode']) {
      value['unitCode'] = _.find(this.bankBranchesOptions, {value: value['unitCode']})['label'];
    }
    if (value['branchEmpIds']) {
      value['branchEmpIds'] = value['branchEmpIds'].map( (el) => {
        return _.find(this.employeeOptions, {value: el})['label'];
      });
    }
    if (value['customerCenter']) {
      value['customerCenter'] = _.find(this.bankBranchesOptions, {value: value['customerCenter']})['label'];
    }
    if (value['caseSource']) {
      value['caseSource'] = _.find(this.boSourceOptions, {value: value['caseSource']})['label'];
    }
    if (value['BOLTypes']) {
      value['BOLTypes'] = value['BOLTypes'].map( (el) => {
        return _.find(this.boTypeOptions, {value: el})['label'];
      });
    }
    if (value['products']) {
      value['products'] = value['products'].map( (el) => {
        return _.find(this.prodTypeOptions, {value: el})['label'];
      });
    }
    return value;
  }

  /**
   * map searchParams form search form
   * defualt skip = 0
   *         take = limitTake
   *
   * @private
   * @param {*} map
   * @returns {EffectReportSearchParams}
   * @memberof EffectReportComponent
   */
  private mapSearchParams(map: any): EffectReportSearchParams {
    // unittype = 4 為消金中心
    let unicode = _.toString(map.unitType) === '4' ? map.customerCenter : map.unitCode;
    let searchParams: EffectReportSearchParams = {
      unitType: map.unitType,
      unitCode: unicode,
      branchEmpIds: map.branchEmpIds,
      assignedDateInterval: DateHelper.divideDate(map.assignedDateInterval),
      caseSource: map.caseSource,
      BOLTypes: map.BOLTypes,
      products: map.products,
      pf: {
        skip: 0,
        take: this.api.getLimitTake(),
      }
    };
    return searchParams;
  }

  // private exportToExcel(rowDatas) {
  //   const tableData = _.cloneDeep(rowDatas).map( (data) => {
  //     const result = _.pick(data, _.keys(this.referralService.getReferralTableHeader()));
  //     // todo combine id & name
  //     result['ReferralUnit'] =  `${result['ReferralUnit']} ${result['ReferralUnitName']}`;
  //     result['ReferralEmpId'] = `${result['ReferralEmpId']} ${result['ReferralEmpName']}`;
  //     result['AcceptedReferralUnit'] = `${result['AcceptedReferralUnit']} ${result['AcceptedReferralUnitName']}`;
  //     result['AcceptedReferralEmpId'] = `${result['AcceptedReferralEmpId']} ${result['AcceptedReferralEmpName']}`;
  //     result['ProcessStatusCode'] = result['ProcessStatusCode'].text;
  //     result['ReferralDate'] = this.datePipe.transform(result['ReferralDate'], 'yyyy/MM/dd HH:mm');
  //     return result;
  //   });
  //   const sheetData = this.sharedService.convertToSheetData(tableData, this.referralService.getReferralTableHeader());
  //   const sheetName = '分頁1';
  //   const fileName = '轉介案件';

  //   this.sharedService.writeToSheet(sheetData, fileName, sheetName);

  // }
}

