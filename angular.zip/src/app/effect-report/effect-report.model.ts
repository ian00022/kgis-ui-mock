import { DateRange } from 'app/core/models/comm-data';

export interface EffectReportSearchParams {
  /**
   * 單位類別
   */
  unitType: string;
  /**
   * 單位代碼
   */
  unitCode: string;
  /**
   * 分行經辦
   */
  branchEmpIds: string[];
  /**
   * 名單日期
   */
  assignedDateInterval: DateRange;
  /**
   * 名單來源
   */
  caseSource: string;
  /**
   * 名單類型
   */
  BOLTypes: string[];
  /**
   * 產品
   */
  products: string[];
  /**
   * page filter
   */
  pf: {
    skip: number;
    take: number;
  };
}

export interface EffectReportExecuteResponseDto {
  /**
   * 行銷經辦
   */
  MarketingPersonName: string;
  /**
   * 單位代碼
   */
  MarketingUnitName: string;
  /**
   * 單位
   */
  MarketingUnit: string;
  /**
   * 名單來源
   */
  CaseSourceName: string;
  /**
   * 名單類型
   */
  BOLTypeName: string;
  /**
   * 產品別
   */
  ProductName: string;
  /**
   * 名單數
   */
  BOLTotalCount: number;
  /**
   * 執行數
   */
  BOLProcessCount: number;
  /*
   * 執行率
   */
  BOLProcessPercentage: number;
  /*
   * 送件數
   */
  BOLAcceptCount: number;
  /*
   * 送件率
   */
  BOLAcceptPercentage: number;
  /*
   * 核貸數
   */
  ApplicationApprovedCount: number;
  /*
   * 核貸率
   */
  ApprovedPercentage: number;
  /*
   * 核貸金額
   */
  ApplicationApprovedAmount: number;
}

export interface EffectReportExecuteTableDataDto {
  /**
   * 行銷經辦
   */
  marketingPersonName: string;
  /**
   * 單位代碼
   */
  marketingUnitName: string;
  /**
   * 單位
   */
  marketingUnit: string;
  /**
   * 名單來源
   */
  caseSourceName: string;
  /**
   * 名單類型
   */
  BOLTypeName: string;
  /**
   * 產品別
   */
  productName: string;
  /**
   * 名單數
   */
  BOLTotalCount: number;
  /**
   * 執行數
   */
  BOLProcessCount: number;
  /*
   * 執行率
   */
  BOLProcessPercentage: number;
  /*
   * 送件數
   */
  BOLAcceptCount: number;
  /*
   * 送件率
   */
  BOLAcceptPercentage: number;
  /*
   * 核貸數
   */
  applicationApprovedCount: number;
  /*
   * 核貸率
   */
  approvedPercentage: number;
  /*
   * 核貸金額
   */
  applicationApprovedAmount: number;
}

export interface EffectReportDetailResponseDto {
  /**
   * 新增日期
   */
  CreateDate: string;
  /**
   * 指派日期
   */
  AssignedDate: string;
  /**
   * 名單來源
   */
  CaseSourceName: string;
  /**
   * 名單類型
   */
  BOLTypeName: string;
  /**
   * 產品別
   */
  ProductName: string;
  /**
   * 統一編號
   */
  IdentityCardNo: string;
  /**
   * 顧客姓名
   */
  CustomerName: string;
  /**
   * 行銷經辦
   */
  ReferralEmpId: string;
  /**
   * 轉介經辦
   */
  SourceReferralEmpId: string;
  /**
   * 處理日期
   */
  HandleDate: string;
  /**
   * 名單狀態
   */
  BOLStatus: string;
  /**
   * 主要名單 UUID
   */
  MainBOLUUID: string;
  /**
   * 審核結果
   */
  AuditResult: string;
  /**
   * 核貸金額
   */
  ApplicationApprovedAmount: string;
}
export interface EffectReportDetailTableDataDto {
  /**
   * 新增日期
   */
  createDate: string;
  /**
   * 指派日期
   */
  assignedDate: string;
  /**
   * 名單來源
   */
  caseSourceName: string;
  /**
   * 名單類型
   */
  BOLTypeName: string;
  /**
   * 產品別
   */
  productName: string;
  /**
   * 統一編號
   */
  identityCardNo: string;
  /**
   * 顧客姓名
   */
  customerName: string;
  /**
   * 行銷經辦
   */
  referralEmpId: string;
  /**
   * 轉介經辦
   */
  sourceReferralEmpId: string;
  /**
   * 處理日期
   */
  handleDate: string;
  /**
   * 名單狀態
   */
  BOLStatus: string;
  /**
   * 主要名單 UUID
   */
  mainBOLUUID: string;
  /**
   * 審核結果
   */
  auditResult: string;
  /**
   * 核貸金額
   */
  applicationApprovedAmount: string;
  /**
   * 顧客360 url
   */
  customerLink: string[];
}

/**
 * effect report type
 */
export enum EffectReportType {
  EXECUTE = 'execute',
  DETAIL = 'detail'
}
