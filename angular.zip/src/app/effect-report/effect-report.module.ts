import { RouterModule } from '@angular/router';
import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { EffectReportComponent } from './effect-report.component';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { Permissions } from 'app/core/models/permissions';

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild([
      {
        path: 'list',
        component: EffectReportComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          breadcrumb: '成效管理',
          permissions: {
            only: [
              Permissions.BOL_RESULT_SEARCH,
              Permissions.BOL_DETAIL_SEARCH
            ],
            redirectTo: '/no-auth'
          }
        }
      },
      {path: '', redirectTo: 'list', pathMatch: 'full'}
    ])
  ],
  declarations: [EffectReportComponent]
})
export class EffectReportModule { }
