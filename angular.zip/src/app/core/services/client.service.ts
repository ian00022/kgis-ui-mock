// angular module
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
// 3rd party module
import * as _ from 'lodash';
// model
import { ClientListConfig } from '../models/client-list-config';
import { ClientType } from './../models/comm-data';
import { SpecificMemberResponseDto, SpecificMemberSearchParams, SpecificMemberTableRowDto } from 'app/client/client.model';
// service
import { AuthService } from './auth.service';
import { ApiService } from './api.service';
// helper
import { BolHelper } from '../../business-opportunity/bol-helper';
import { DateHelper } from 'app/shared/helper/date-helper';
// momet js
declare var moment: any;

/**
 * client service
 */
@Injectable()
export class ClientService {
  public marketMarkLabelMap = {
    RefuseLoanReasonCode: '消金拒貸理由',
    PersonalCreditRatingCode: '個金信評等級',
    CardCreditRatingCode: '信用卡信評等級',
    RejectedCheckDate: '支票拒往日期',
    BankingActStakeholderFlag: '利害關係人註記',
    FinancialHoldingCompanyActArtical44StakeholderFlag: '利害關係人註記',
    FinancialHoldingCompanyActArtical45StakeholderFlag: '利害關係人註記',
    Oa615Crn: '債務協商',
    Oa615Dcr: '債清註記',
    Oa601Yon: '債務展延',
    Oa616Mor: '存單設質',
    HasEx: '事故',
    AmlSanctionsbolFlag: 'AML 制裁名單',
    AmlPoliticalSensitiveCharactersFlag: 'AML 政治敏感人物',
    AmlPepRelationshipFlag: 'AML PEP關係人'
  };
  public overviewLabelMap: any = {
    TwdAum: '台幣存款',
    CustomerInsuranceAum: '保險',
    ForeignCurrencyAum: '外幣存款',
    OthersAum: '其他理財',
    CustomerMonthEndAum: '顧客月底綜合AUM',
    GrownUpGuardianshipCode: '成年監護(輔助)代碼',
    ServeCompanyName: '服務公司',
    ServeCompanyCertNo: '服務公司統編',
    JobTitle: '職稱',
    FatcaFlag: 'FATCA 註記',
    ResidencePermitCertNo: '居留證統一證號',
    ResidencePermitCertStartDate: '居留證核發日期',
    RegCountryCode: '註冊國別代碼',
    CustomerKycTypeCode: '顧客身分代碼',
    FundExpertInvestorCode: '專業投資人代碼-財富',
    FundExpertInvestorEndDate: '專業投資人有效期限-財富',
    PayrollFlag: '薪轉戶',
    PerformanceDptCode: '主經營行',
    FcSupervisorEmpNo: '所屬理專',
    ContactPhone: '聯繫用手機',
    TxnPhone: 'OTP 約定手機',
    Email: 'E-mail',
    CompanyTel: '公司電話',
    CompanyAddr: '公司地址',
    ContactTel: '通訊電話',
    ContactAddr: '通訊地址',
    ResidenceTel: '戶籍電話',
    ResidenceAddr: '戶籍/註冊地址',

    DtaDt: '資料日期',
    Mchsd: '簽約日期',
    Mched: '解約日期',
    Rsncd: '解約原因',
    BusTp: '商店型態',
    TcFlg: '國旅卡特店',
    NearYearReceiveAmount: '近一年收單總額(元)',
    NearYearRefund: '近一年退款總額(元)',
    NearYearMonth: '近一年有使用本行收單服務月數',
    NearYearAvgAmount: '近一年平均月收單金額(元)',

    CompanyStatusDesc: '公司狀況',
    CompanyName: '公司名稱',
    CapitalStockAmount: '資本總額(元)',
    PaidInCapitalAmount: '實收資本額(元)',
    RepName: '代表人姓名',
    CompanyLocation: '公司所在地',
    RegisterOrganizationDesc: '登記機關',
    CompanySetupDate: '核准設立日',
    ChangeOfApprovalData: '最後核准變更日',
    CmpBusiness: '所營事業資料',
    RevokeAppDate: '公司撤銷日',
    SusAppDate: '停業核准日',
    CaseStatus: '停復業狀況',
    CaseStatusDesc: '停復業狀況描述',
    SusBegDate: '停業/延展日(起)',
    SusEndDate: '停業/延展日(迄)',
    CirciKey: '統一編號',
    PrincipalName: '負責人姓名',
    PrincipalPartyCertNo: '負責人統編',
    PrincipalBirthday: '負責人出生日期',
    BeneficialOwnerName: '實質受益人',
    Capital: '公司資本額',
    ForeignBranchFlag: '外商分公司註記',
    WiseExpertInvestorCode: '專業投資人代碼-財富',
    WiseExpertInvestorEndDate: '專業投資人有效期限-財富',
    BelongFcEmpNo: '所屬理專',
    RmNo: '維護RM',
    SbProfitAllocationBank: 'SB 利潤撥補分行',
    CorporateCenterGroupCode: '所屬企金中心組別',
    NearYearRevenue: '近一年法人營收',
    CorpBankContactAttributeCode: '法金顧客往來屬性',
    CorpBankRoleAttributeCode: '法金顧客身份屬性',
    ActualOperatingAddr: '實際營運地址'
  };
  public cusOverviewMap = {
    custInfo: {
      base: [
        'GrownUpGuardianshipCode',
        'ServeCompanyName',
        'ServeCompanyCertNo',
        'JobTitle',
        'FatcaFlag',
        'ResidencePermitCertNo',
        'ResidencePermitCertStartDate',
        'RegCountryCode',
      ],
      career: [
        'FundExpertInvestorCode',
        'FundExpertInvestorEndDate',
      ],
      careerTag: [
        'PayrollFlag'
      ],
      maintain: [
        'PerformanceDptCode',
        'FcSupervisorEmpNo',
      ],
      contact: [
        'ContactPhone',
        'TxnPhone',
        'Email',
        'CompanyTel',
        'CompanyAddr',
        'ContactTel',
        'ContactAddr',
        'ResidenceTel',
        'ResidenceAddr',
      ]
    },
    liabilitiesChart: {
      WaFrom: 'loanHeader',
      WaLan: 'loanId',
      RepayRate: 'loanPayed',
      WaPia: 'totalLoanAmount',
      WaCpa: 'needPayback',
      LACNO: 'loanId',
      GVAMT: 'totalLoanAmount',
      LSBAL: 'needPayback'
    }
  };
  public compOverviewMap = {
    custInfo: {
      base: [
        'PrincipalName',
        'CirciKey',
        'PrincipalPartyCertNo',
        'PrincipalBirthday',
        'BeneficialOwnerName',
        'Capital',
        'RegCountryCode',
        'ForeignBranchFlag',
      ],
      career: [
        'WiseExpertInvestorCode',
        'WiseExpertInvestorEndDate'
      ],
      maintain: [
        'PerformanceDptCode',
        'BelongFcEmpNo',
        'RmNo',
        'SbProfitAllocationBank',
        'CorporateCenterGroupCode',
        'NearYearRevenue',
        'CorpBankContactAttributeCode',
        'CorpBankRoleAttributeCode',
      ],
      contact: [
        'Email',
        'CompanyTel',
        'CompanyAddr',
        'ContactPhone',
        'TxnPhone',
        'ResidenceAddr',
        'ResidenceTel',
        'ActualOperatingAddr',
        'ContactTel',
        'ContactAddr',
      ],
    },
    bussinessReg: [
      'CompanyStatusDesc',
      'CompanyName',
      'CapitalStockAmount',
      'PaidInCapitalAmount',
      'RepName',
      'CompanyLocation',
      'RegisterOrganizationDesc',
      'CompanySetupDate',
      'ChangeOfApprovalData',
      'CmpBusiness',
      'RevokeAppDate',
      'SusAppDate',
      'CaseStatus',
      'CaseStatusDesc',
      'SusBegDate',
      'SusEndDate'
    ],
    liabilitiesChart: {
      WaFrom: 'loanHeader',
      WaLan: 'loanId',
      RepayRate: 'loanPayed',
      WaPia: 'totalLoanAmount',
      WaCpa: 'needPayback',
    },
    spectialData: [
      'DtaDt',
      'Mchsd',
      'Mched',
      'Rsncd',
      'BusTp',
      'TcFlg',
      'NearYearReceiveAmount',
      'NearYearRefund',
      'NearYearMonth',
      'NearYearAvgAmount',
    ]
  };
  public assetsMap = {
    OA616_XAN: 'acct',
    OA616_OPD: 'activeDate',
    OA615_CSA: 'balance',
    OA616_ADP_A: 'lastThreeMonth',
    OA616_ADP_B: 'lastsixMonth',
    OPDATE: 'transitionDate',
    CHC: 'summary',
    CDC: 'debit',
    AMT: 'debitAmount',
    NBA: 'balance',
    DPP: 'note',
    WA_ACN: 'acct',
    WA_CPA: 'amount',
    WA_INR: 'rate',
    WA_FRF: 'rateCategory',
    WA_SID: 'startDate',
    WA_MTD: 'endDate',
    WA_ATF: 'isContinued',
    WA_MOT: 'deposit',
    Curr: 'currency',
    AccBalance: 'acctBalance',
    AccBalanceTwd: 'acctBalanceTW',
    WaApp: 'avgBalance',
    WaAppTwd: 'avgBalanceTW',
    ProductName: 'product',
    WA_CUR: 'currency',
    WaTwdValue: 'presentTW',
    APLYINVNO: 'prodId',
    PRDNAM: 'prod',
    INVCURR: 'currency',
    ORGNLCOST: 'investmentAmount',
    INVPRSVLU: 'investmentValue',
    RTNAMT: 'investmentState', //	投資損益(含累計配息)
    //'TOTXD': 3245, 投資損益(含累計配息)
    RTNRATE: 'roi',
    PolicyNo: 'num',
    PoStatusCode: 'status',
    PlanName: 'name',
    PoIssueDate: 'activeDate',
    PayExpiredDate: 'endDate',
    CuyCpo: 'currency',
    PremAmt: 'firstFee',
    PremAmtTotal: 'cumulativeFee',
    OwnerId: 'applicantId',
    OwnerName: 'applicantName',
  };
  public liabilitiesMap = {
    // 帳戶資訊
    OA616_PBN: 'approvalNumber', // 批覆書編號
    OA616_XAN: 'account',
    OA615_CSA: 'balance',
    OA615_CLA: 'amount',
    OA615_FROM: 'prod',
    OA615_ANS: 'status',
    OA616_CLD: 'activeDate',
    OA616_RED: 'endDate',
    OA616_LPPP: 'breachDuration',
    OA616_FIR: 'rate',
    OA616_ODC: 'latePayment',
    WA_TXD: 'transitionDate',
    WA_MRK: 'summary',
    WA_IBD: 'valueDate',
    WA_IED: 'expiryDate',
    WA_XIR: 'rate',
    WA_PRA: 'principal',
    WA_RIA: 'interest',
    WA_RXA: 'breachInterset',
    LateDays: 'latePaymentDays',

    // 卡友貸
    PBN: 'approvalNumber',
    LACNO: 'account',
    LSBAL: 'balance',
    GVAMT: 'amount',
    TYPNM: 'prod',
    LASTS: 'status',
    LNSDT: 'activeDate',
    LNEDT: 'endDate',
    TOTRM: 'breachDuration',
    FIRRT: 'rate',
    ODNCT: 'latePayment',
    TXDAT: 'transitionDate',
    TEXT: 'summary',
    INTDT: 'valueDate',
    INEDT: 'expiryDate',
    ALRIR: 'rate',
    PYAMT: 'principal',
    INSAM: 'interest',
    PFAMT: 'breachInterset',
    LDAYS: 'latePaymentDays',

    // 退票記錄
    //OA616_XAN: 'account',
    OA616_YIC: 'depositRefundCount',
    OA616_YCC: 'signRefundCount',
    OA616_BCT: 'refundMark',
    OA616_RRC: 'refundCount',
    OA616_RXD: 'denyDate',

    // 未解除之存摺事故
    OA615_XAN: 'account',
    OA611_EXCODE: 'id',
    OA611_EXNAME: 'content',
    OA611_REGBHI: 'department',
    OA611_REGOP: 'person',
    OA611_REGDATE: 'date',
    OA611_PUBN: 'note',

    // 信用卡
    AGNM: 'name',
    OPCDT: 'activeDate',
    CYCAM: 'amount',
    AFCD: 'positiveCard',
    SLDT: 'stopDate',
    SLRN: 'stopReason',
    TAMT: 'totalPayment',
    MIMPY: 'leastPayment',

    // 同業綜合授信
    BankName: 'bankName',
    CreditSubject: 'credits',
    Function: 'use',
    CreditType: 'creditType',
    GageLocation: 'location',
    TotalQuota: 'totalAmount',
    CreditUnOverdue: 'notOverdueAmount',
    OverdueAmount: 'overdueAmount',
    DataDate: 'dataDate',

    OA606_PBN: 'approvalNumber',
    OA606_TYP: 'category',
    OA606_ANS: 'status',
    OA606_FLG: 'overDate',
    OA606_RLR: 'totalAmount',
    OA606_CPA: 'arrears',
    OA606_CBH: 'operation',
    OA609_ADR: 'address',
    OA609_TAL: 'evaluateAmount',
    OA609_SAL: 'guaranteeValue',
    OA606_LID: 'borrower',
  };
  public clientParamsMap = {
    clientSearch: {
      CustomerAttribute: 'customerAttribute',
      PerformanceDptCode: 'performanceDptCode',
      PerformanceDptName: 'performanceDptName',
      Circikey: 'circiKey',
      CustomerName: 'customerName',
      ContactPhone: 'contactPhone',
      CustomerBirthday: 'customerBirthday',
      SpecificMemberFlag: 'specificMemberFlag',
      CreateEmpId: 'createEmpId',
      CreateEmpName: 'createEmpName',
      BolNo: 'BOLNo'
    },
    companyInfo360Block: {
      CustomerName: 'name',
      BusinessRegCertNo: 'circiKey',
      PrincipalName: 'principleName',
      CompanyTel: 'phone',
      CompanyAddr: 'companyAddr',
      Email: 'email',
      ContactAddr: 'address',
    },
    personalInfo360Block: {
      CustomerName: 'name',
      Circikey: 'circiKey',
      ContactPhone: 'phone',
      Email: 'email',
      ContactAddr: 'address',
      Age: 'age',
      GenderDesc: 'gender',
      MerriedStatusDesc: 'marriage',
    },
    marketingAlertBlock: {
      CustomerStatusCode: 'customerStatusCode',
      CustomerStatusDesc: 'customerStatusDesc',
      DmSaleFlag: 'dmSaleFlag',
      SmsSaleFlag: 'smsSaleFlag',
      EmailSaleFlag: 'emailSaleFlag',
      PhoneSaleFlag: 'phoneSaleFlag',
      StopUseCustomerDataFlag: 'stopUseCustomerDataFlag',
      AgreeCrossSellingFlag: 'agreeCrossSellingFlag',
    }
  };

  public prePath = 'Customer';

  // tslint:disable-next-line
  private custDetail;

  constructor(
    private api: ApiService,
    private auth: AuthService,
  ) { }

  public transferCusOverview(value: any): any {
    let overview = {
      custInfo: {},
      marketingLogs: {},
      recommend: {},
      povertyChart: {},
      liabilitiesChart: {}
    };
    // 顧客資訊
    for (let key of Object.keys(this.cusOverviewMap.custInfo)) {
      overview.custInfo[key] = this.cusOverviewMap.custInfo[key].map( (el) => {
        if (el === 'PayrollFlag') {
          return '薪轉戶';
        }
        if (el === 'PerformanceDptCode') {
          return {
            title: this.overviewLabelMap.PerformanceDptCode,
            text: `${value['CustomerInfoBlock']['PerformanceDptCode']} ${value['CustomerInfoBlock']['PerformanceDptName']}`
          };
        }
        if (el === 'FcSupervisorEmpNo') {
          return {
            title: this.overviewLabelMap.FcSupervisorEmpNo,
            text: `${value['CustomerInfoBlock']['FcSupervisorEmpNo']} ${value['CustomerInfoBlock']['FcSupervisorEmpName']}`
          };
        }
        return {
          title: this.overviewLabelMap[el],
          text: value['CustomerInfoBlock'][el]
        };
      });
    }

    // 顧客 AUM
    overview.povertyChart['chartData'] = [];
    overview.povertyChart['aum'] = {
      title: '顧客月底綜合AUM',
      content: value['AumBlock']['CustomerMonthEndAum']
    };
    for (let key of Object.keys(value['AumBlock'])) {
      if (key !== 'CustomerMonthEndAum') {
        overview.povertyChart['chartData'].push({
          label: this.overviewLabelMap[key],
          value: value['AumBlock'][key],
        });
      }
    }

    // 顧客負債分配
    let allocation = value['DebtAllocationBlock'].map( (el) => {
      return this.transferMap(el, this.cusOverviewMap.liabilitiesChart);
    });
    let cardAllocation =  value['DebtCardAllocationBlock'].map( (el) => {
      return this.transferMap(el, this.cusOverviewMap.liabilitiesChart);
    });
    overview.liabilitiesChart = _.concat(allocation, cardAllocation);

    // 顧客身份別
    for (let identity of value['IdentitysBlock']) {
      overview.custInfo['careerTag'].push(`${identity['CustomerKycTypeCode']}-${identity['CustomerKycTypeName']}`);
    }

    // 推薦產品 (貸款 & 整合行銷)
    // overview.recommend['marketing']
    overview.recommend['loan'] = value['OfferBlock'].map( (el) => {
      // need caseSourceDesc(來源說明)
      return _.assign({
        header: el['OfferDesc'],
        tags: el['Tags'],
        histories: [],
        // need if click helpInfo
        isGivenFeedback: false
      }, el);
    });

    // 行銷接觸記錄
    overview.marketingLogs = value['MarketingLogsBlock'].map( (el) => {
      let result = BolHelper.processMarketingLog(el);
      if (result.hasOwnProperty('remarks') && result.remarks.length > 0) {
        result['subRow'] = result.remarks;
      }
      result['status'] = BolHelper.transferBolStatus(result);
      if (result['marketingPerson'] === this.auth.getLoginUser().loginEmpId) {
        result['remarkEditable'] = true;
      }
      return result;
    });
    return overview;
  }

  public transferCompOverview(value: any): any {
    let overview = {
      custInfo: {},
      marketingLogs: {},
      bussinessReg: {},
      povertyChart: {},
      liabilitiesChart: {},
      productService: [],
      spectialData: [],
    };

    // 顧客資訊
    for (let key of Object.keys(this.compOverviewMap.custInfo)) {
      overview.custInfo[key] = this.compOverviewMap.custInfo[key].map( (el) => {
        switch(el) {
          case 'BeneficialOwnerName':
            return {
              title: this.overviewLabelMap.BeneficialOwnerName,
              text: `${value['CustomerInfoBlock']['BeneficialOwnerName']}(${moment(value['CustomerInfoBlock']['BeneficialOwnerIdentityDate']).format('YYYY/MM/DD')})`
            };
          case 'PrincipalBirthday':
            return {
              title: this.overviewLabelMap.PrincipalBirthday,
              text: `${moment(value['CustomerInfoBlock']['PrincipalBirthday']).format('YYYY/MM/DD')}`
            };
          case 'PerformanceDptCode':
            return {
              title: this.overviewLabelMap.PerformanceDptCode,
              text: `${value['CustomerInfoBlock']['PerformanceDptCode']} ${value['CustomerInfoBlock']['PerformanceDptName']}`
            };
          case 'BelongFcEmpNo':
            return {
              title: this.overviewLabelMap.BelongFcEmpNo,
              text: `${value['CustomerInfoBlock']['BelongFcEmpNo']} ${value['CustomerInfoBlock']['BelongFcEmpName']}`
            };
          case 'RmNo':
            return {
              title: this.overviewLabelMap.RmNo,
              text: `${value['CustomerInfoBlock']['RmNo']} ${value['CustomerInfoBlock']['RmName']}`
            };
          case 'CorporateCenterGroupCode':
            return {
              title: this.overviewLabelMap.CorporateCenterGroupCode,
              text: `${value['CustomerInfoBlock']['CorporateCenterGroupCode']} / ${value['CustomerInfoBlock']['CorporateCenterGroup']}`
            };
          default:
            return {
              title: this.overviewLabelMap[el],
              text: value['CustomerInfoBlock'][el]
            };
        }
      });
    }

    // 行銷接觸記錄
    overview.marketingLogs = value['MarketingLogsBlock'].map( (el) => {
      let result = BolHelper.processMarketingLog(el);
      if (result.hasOwnProperty('remarks') && result.remarks.length > 0) {
        result['subRow'] = result.remarks;
      }
      result['status'] = BolHelper.transferBolStatus(result);
      if (result['marketingPerson'] === this.auth.getLoginUser().loginEmpId) {
        result['remarkEditable'] = true;
      }
      return result;
    });

    // 商工登記
    overview.bussinessReg = this.compOverviewMap.bussinessReg.filter(
      (el) => {
        if(this.overviewLabelMap[el]) {
          return el;
        }
    }).map( (el) => {
      return {
        title: this.overviewLabelMap[el],
        content: value['BusinessRegistrationBlock']['CompanyBR'][el] || '-'
      };
    });

    // 顧客 AUM
    overview.povertyChart['chartData'] = [];
    overview.povertyChart['aum'] = {
      title: '顧客月底綜合AUM',
      content: value['AumBlock']['CustomerMonthEndAum']
    };
    for (let key of Object.keys(value['AumBlock'])) {
      if (key !== 'CustomerMonthEndAum') {
        overview.povertyChart['chartData'].push({
          label: this.overviewLabelMap[key],
          value: value['AumBlock'][key],
        });
      }
    }

    // 負債分配
    overview.liabilitiesChart =  value['DebtAllocationBlock'].map( (el) => {
      return this.transferMap(el, this.compOverviewMap.liabilitiesChart);
    });

    // 產品服務
    overview.productService = [
      {
        title: '外匯進口承作量',
        content: [
          `近一月 ${value['ProductServiceBlock']['ImportRemittanceCommitmentNearMonth']}`,
          `近一年 ${value['ProductServiceBlock']['ImportRemittanceCommitmentNearYear']}`,
          `近二年 ${value['ProductServiceBlock']['ImportRemittanceCommitmentNear2Year']}`,
        ],
        contentType: 'array'
      },
      {
        title: '外匯出口承作量',
        content: [
          `近一月 ${value['ProductServiceBlock']['ExportRemittanceCommitmentNearMonth']}`,
          `近一年 ${value['ProductServiceBlock']['ExportRemittanceCommitmentNearYear']}`,
          `近二年 ${value['ProductServiceBlock']['ExportRemittanceCommitmentNear2Year']}`,
        ],
        contentType: 'array'
      },
    ];

    // 特店資訊
    overview.spectialData = this.compOverviewMap.spectialData.map( (key) => {
      return {
        title: this.overviewLabelMap[key],
        content: value['SpecialShopBlock'][key] || '-'
      };
    });
    return overview;
  }

  public changeTo(obj) {
    let contentArr = [];
    Object.keys(obj).forEach( (key) => {
      if (this.marketMarkLabelMap[key]) {
        let data = {
          key: key,
          title: this.marketMarkLabelMap[key],
          content: obj[key]
        };
        // 債務協商 債清註記 債務展延 事故
        if (key === 'Oa615Crn' || key === 'Oa615Dcr'
            || key === 'Oa601Yon' || key === 'HasEx') {
          if (data.content.indexOf('Y') !== -1) {
            data['markRed'] = true;
          }
        }
        // 存單設質
        if (key === 'Oa616Mor') {
          if (data.content.indexOf('有設質') !== -1) {
            data['markRed'] = true;
          }
        }
        // if (key === 'BankingActStakeholderFlag') {
        //   data['contentType'] = 'array';
        // }
        contentArr.push(data);
      }
    });
    return contentArr;
  }

  public transferDetail(resp: any): any {
    let result: any = {};
    //
    result.customerAttribute = resp.hasOwnProperty('CompanyInfo360Block') ? ClientType.COMP : ClientType.CUST;
    result.identitysBlock = resp['IdentitysBlock'].map( (el) => {
      return {
        customerKycTypeCode: el['CustomerKycTypeCode'],
        customerKycTypeName: el['CustomerKycTypeName']
      };
    });
    result.marketingAlertBlock = this.transferMap(resp['MarketingAlertBlock'], this.clientParamsMap.marketingAlertBlock);

    if (result.customerAttribute === ClientType.COMP) {
      result = _.assign(result, this.transferMap(resp['CompanyInfo360Block'], this.clientParamsMap.companyInfo360Block));
    } else {
      result = _.assign(result, this.transferMap(resp['PersonalInfo360Block'], this.clientParamsMap.personalInfo360Block));
    }
    return result;
  }

  public transferAsset(value: any): any {
    let result:any = {
      twDeposit: {
        current: [],
        fixed: []
      },
      overseaDeposit: {
        current: [],
        fixed: []
      },
      insurances: [],
      fund: []
    };
    result.twDeposit.current = value['TwdpBlock'].map( (el) => {
      let twCurrent: any = {};
      for (let key of Object.keys(el)) {
        if (key === 'Detail') {
          twCurrent['subRow'] = {};
          twCurrent.subRow['title'] = '存摺近三個月交易記錄';
          twCurrent.subRow['tableData'] = el['Detail'].map( (detail) => {
            let subRowData: any = {};
            for (let detailKey of Object.keys(detail)) {
              subRowData[this.assetsMap[detailKey]] = detail[detailKey];
            }
            return {
              date: subRowData.transitionDate,
              data: [subRowData]
            };
          });
        } else {
          twCurrent[this.assetsMap[key]] = el[key];
        }
      }
      return twCurrent;
    });
    result.twDeposit.fixed = value['TwcdBlock'].map( (el) => {
      return this.transferMap(el, this.assetsMap);
    });
    result.overseaDeposit.current = value['FcdpBlock'].map( (el) => {
      return this.transferMap(el, this.assetsMap);
    });
    result.overseaDeposit.fixed = value['FccdBlock'].map( (el) => {
      return this.transferMap(el, this.assetsMap);
    });
    result.fund = value['FundBlock'].map( (el) => {
      return this.transferMap(el, this.assetsMap);
    });
    result.insurances = value['InsBlock'].map( (el) => {
      return {
        title: '',
        tableData: [this.transferMap(el, this.assetsMap)]
      };
    });

    return result;
  }

  public transferLiability(value: any): any {
    let result = {
      account: { title: '帳戶資料' } as any,
      credit: { title: '授信資訊（不動產）' } as any,
      promise: { title: '保證資訊' } as any,
      record: { title: '退票記錄' } as any,
      accident: { title: '未解除之存摺事故' } as any,
      creditcard:  { title: '信用卡' } as any,
      comprehensiveCredit: { title: '同業綜合授信' } as any,
      movableProperty: { title: '全國動產擔保交易公示資訊' } as any
    };

    // 待確認 LoanCardAccountInfo 是否合併到 account 裡面
    result.account['rowData'] = value['LoanAccountInfo'].map((el) => {
      // WaPbnContetDetail 需確認是否多筆
      let accountData = {};
      for(let key of Object.keys(el)) {
        accountData[this.liabilitiesMap[key]] = el[key];
      }
      return {
        approvalNumber: el['OA616_PBN'],
        tableData: [accountData]
      };
    });

    result.credit['tableData'] = value['LoanCreditInfo'].map((el) => {
      return this.transferMap(el, this.liabilitiesMap);
    });
    result.promise['tableData'] = value['LoanGuaranteeInfo'].map((el) => {
      let rowData: any = {};
      for(let key of Object.keys(el)) {
        if (key === 'LoanGuaranteeInfoDetail') {
          rowData['subRow'] = {};
          rowData.subRow['tableData'] = el['LoanGuaranteeInfoDetail'].map( (detail) => {
            let subRowData: any = {};
            for (let detailKey of Object.keys(detail)) {
              subRowData[this.liabilitiesMap[detailKey]] = detail[detailKey];
            }
            return {
              data: [subRowData]
            };
          });
        } else {
          rowData[this.liabilitiesMap[key]] = el[key];
        }
      }
      return rowData;
    });
    result.record['tableData'] = value['RefundRecord'].map((el) => {
      return this.transferMap(el, this.liabilitiesMap);
    });
    result.accident['tableData'] = value['UnreleasedPassbook'].map((el) => {
      return this.transferMap(el, this.liabilitiesMap);
    });
    result.creditcard['tableData'] = value['CreditCardInfo'].map((el) => {
      return this.transferMap(el, this.liabilitiesMap);
    });
    result.comprehensiveCredit['tableData'] = value['PeersCrditInfo'].map((el) => {
      return this.transferMap(el, this.liabilitiesMap);
    });
    result.comprehensiveCredit['date'] = value['PeersCrditInfo'][0].dataDate;

    return result;

  }

  public transferMarketMark(value: any): any {
    let result = {
      creditRiskBlock: [] as any,
      amlBlock: [] as any,
      creditNotice: {} as any,
      alertBlock: {} as any,
      noticeBlock: [] as any,
    };

    result.creditRiskBlock = this.preProcessMarketMarkData(value['CreditRiskBlock']);
    result.creditRiskBlock = this.changeTo(result.creditRiskBlock);
    result.amlBlock = this.changeTo(value['AmlBlock']);
    result.noticeBlock = this.processNoticeBlock(value['NoticeBlock']);
    result.creditNotice = value['CreditNotice'];
    result.alertBlock = this.transferMap(value['AlertBlock'], this.clientParamsMap.marketingAlertBlock);
    return result;
  }
  public updateProductRecommand(data, track) {
    let body = {
      'UUID': data.UUID,
      'BOLID': data.BOLID,
      'TreatmentCode': data.treatmentCode,
      'ResponseCode': track ? '我要追蹤' : '顧客無意願',
      'EmpId': this.auth.getLoginUser().loginEmpId,
      'ActionTime': new Date(),
      'Product': data.header
    };
    return this.api.patch(`${this.prePath}/ProductRecommend`, body);
  }

  getCustomerDetail(circiKey?: any): Observable<any> {
    // todo cache this.custDetail
    return this.api.get(`${this.prePath}/${circiKey}`).pipe( map( (el) => { this.custDetail = this.transferDetail(el.value); return this.transferDetail(el.value); }));
  }

  getPotentialCustomer(bolNo): Observable<any> {
    return this.api.get('PotentialCustomer', {bolNo: bolNo});
  }

  getOverView(circiKey) {
    return this.api.get(`${this.prePath}/${circiKey}/BasicInfo`);
  }

  getMarketMark(circiKey) {
    return this.api.get(`${this.prePath}/${circiKey}/Notice`);
  }

  getMarketingNotice(circiKey) {
    return this.api.get(`MarketingNotice/${circiKey}`).pipe( map ((el) => { return this.processNoticeBlock(el.value); } ));
  }

  getAssets(circiKey) {
    return this.api.get(`${this.prePath}/${circiKey}/Assets`);
  }

  getLiabilities(circiKey) {
    return this.api.get(`${this.prePath}/${circiKey}/Debt`);
  }

  getDBMarket(circiKey) {
    return this.api.get(`${this.prePath}/${circiKey}/MarketingProjects`);
  }

  public query(config: ClientListConfig): Observable<any> {
    let searchModel = _.assign({ loginUser: this.auth.getLoginUser() }, config);
    return this.api.post('Customer', searchModel).pipe(
            map( (resp) => {
              return resp.value.map( (el) => {
                return this.transferMap(el, this.clientParamsMap.clientSearch);
            });
        }));
  }

  /**
   * 特記對象查詢記錄
   *
   * @param {SpecificMemberSearchParams} searchParams
   * @returns {Observable<any>}
   * @memberof ClientService
   */
  public querySpecificMemberLog(searchParams: SpecificMemberSearchParams): Observable<any> {
    return this.api.post('Customer/SpecificMemberLog/Search', searchParams).pipe( map( data => {
      return data.value.map( (el: SpecificMemberResponseDto): SpecificMemberTableRowDto => {
        return {
          beInquirerCircikey: el.BeInquirerCircikey,
          beInquirerName: el.BeInquirerName,
          inquirerEmp: `${el.InquirerEmpId} ${el.InquirerEmpName}`,
          inquirerUnit: `${el.InquirerUnitCode} ${el.InquirerUnitName}`,
          inquiryDate: DateHelper.formatDate(el.InquiryDate),
          inquiryTime: DateHelper.formatTime(el.InquiryTime, 'HH:mm:ss'),
        };
      });
    }));
  }

  public addSpecificMemberLog(data: any): Observable<any> {
    return this.api.post('Customer/SpecificMemberLog', data);
  }

  private transferMap(obj, mapper) {
    let result: any = {};
    for (let key of Object.keys(obj)) {
      result[mapper[key]] = obj[key];
    }
    return result;
  }

  private preProcessMarketMarkData(data) {
    let result = _.cloneDeep(data);
    result['RefuseLoanReasonCode'] = `${data['RefuseLoanReasonCode']}: ${data['RefuseLoanReason']}`;
    result['PersonalCreditRatingCode'] = `${data['PersonalCreditRatingCode']} (${moment(data['PersonalCreditRatingCodeDate']).format('YYYY/MM/DD')})`;
    result['CardCreditRatingCode'] = `${data['CardCreditRatingCode']} (${moment(data['CardCreditRatingDate']).format('YYYY/MM/DD')})`;
    result['RejectedCheckDate'] = `${moment(data['RejectedCheckDate']).format('YYYY/MM/DD')}`;
    result['BankingActStakeholderFlag'] = `銀行法第32、33條 ${data['BankingActStakeholderFlag']}`;
    result['FinancialHoldingCompanyActArtical44StakeholderFlag'] = `金控法第44條 ${data['FinancialHoldingCompanyActArtical44StakeholderFlag']}`;
    result['FinancialHoldingCompanyActArtical45StakeholderFlag'] = `金控法第45條 ${data['FinancialHoldingCompanyActArtical45StakeholderFlag']}`;
    return result;
  }

  private processNoticeBlock(data) {
    return data.map( (notic) => {
      let deleted = _.find(notic['Details'], (o) => { return o['DeletedReason'];});
      return _.assign({
        editable: !deleted,
        status: deleted ? 'delete' : 'common'
      }, notic);
    });
  }

}
