import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { ApiService } from './api.service';
import { AuthService } from 'app/core/services/auth.service';
import { ManagementWFType } from './../../management/management.model';

const status = [
  '待覆核',
  '生效',
  '主管退回',
  '停用',
  '暫存',
];

const members = [
  {
    empId: '11234',
    empName: '王小明',
    jobTitle: '總行主管',
    organizationCode: 'C8765',
    systemRole: '後台管理主管',
    joinDate: '2018/09/11',
  },
  {
    empId: '21235',
    empName: '王中明',
    jobTitle: '總行經辦',
    organizationCode: 'C8764',
    systemRole: '後台管理主管',
    joinDate: '2018/01/01',
  },
  {
    empId: '31236',
    empName: '華小明',
    jobTitle: '總經理',
    organizationCode: 'C8763',
    systemRole: '後台管理主管',
    joinDate: '2018/02/01',
  }
];

const marketingTeamList: any[] = [
  {
    teamNo: '01234',
    teamCategory: '空中AO',
    teamName: '團隊名稱 1',
    organizationCode: 'A1304',
    description: '行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示，行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示',
    status: '停用',
    product: '空中AO',
    BOLMaxLimit: '300',
    acceptBOLSource: [
      'EBM',
      '網路進件'
    ],
    acceptBOLType: [
      '線上申請',
      '額度利率評估'
    ],
    teamMember: _.cloneDeep(members),
    teamLeader: '成員 1'
  },
  {
    teamNo: '01235',
    teamCategory: 'SBC',
    teamName: '團隊名稱 2',
    organizationCode: 'V1304',
    description: '行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示，行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示',
    status: '生效',
    product: '空中AO',
    BOLMaxLimit: '300',
    acceptBOLSource: [
      'EBM',
      '網路進件'
    ],
    acceptBOLType: [
      '線上申請',
      '額度利率評估'
    ],
    teamMember: _.cloneDeep(members),
    teamLeader: '成員 1'
  },
  {
    teamNo: '01236',
    teamCategory: '消金中心',
    teamName: '團隊名稱 3',
    organizationCode: 'B1304',
    description: '行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示，行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示',
    status: '待覆核',
    applicant: '王大明',
    applicantId: '23143',
    applyDate: '2018/09/10',
    product: '空中AO',
    BOLMaxLimit: '300',
    acceptBOLSource: [
      'EBM',
      '網路進件'
    ],
    acceptBOLType: [
      '線上申請',
      '額度利率評估'
    ],
    teamMember: _.cloneDeep(members),
    teamLeader: '成員 1'
  },
  {
    teamNo: '01235',
    teamCategory: 'SBC',
    teamName: '團隊名稱 2',
    organizationCode: 'V1304',
    description: '行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示，行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示',
    status: '主管退回',
    product: '空中AO',
    BOLMaxLimit: '300',
    acceptBOLSource: [
      'EBM',
      '網路進件'
    ],
    acceptBOLType: [
      '線上申請',
      '額度利率評估'
    ],
    teamMember: _.cloneDeep(members),
    teamLeader: '成員 1'
  },
  {
    teamNo: '01235',
    teamCategory: 'SBC',
    teamName: '團隊名稱 2',
    organizationCode: 'V1304',
    description: '行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示，行銷團隊描述，至多兩行。過長以刪節號表示，如此範例行銷團隊描述，至多兩行。過長以刪節號表示',
    status: '暫存',
    product: '空中AO',
    BOLMaxLimit: '300',
    acceptBOLSource: [
      'EBM',
      '網路進件'
    ],
    acceptBOLType: [
      '線上申請',
      '額度利率評估'
    ],
    teamMember: _.cloneDeep(members),
    teamLeader: '成員 1'
  },
];

const expiryNotificationInfo1 = {
  notifyReason: '已分派',
  notifyEvent: '已達分派上限',
  sourceType: [
    'EBM',
    '網路進件'
  ],
  prod: [
    '信貸',
    '房貸',
    '副擔保',
    'SB'
  ]
};
const expiryNotificationInfo2 = {
  buildDate: '2018/10/10',
  applicant: '王小姐',
  applicantId: '12394',
  applyDate: '2018/03/18'
};
const expiryNotificationRule = {
  notifyMethods: [
    '逾期燈號',
    '訊息通知',
    'Mail',
    '單筆通知',
  ],
  notifyTo: {
    primary: '總行主管',
    secondary: '總行經辦'
  },
  subject: '轉介商機已分派通知',
  content: '您轉介的網路商機(顧客姓名+ID )，已分派至”XXX”名下進行後續處理，如需知案件處理進度，可點選系統連結。<系統連結>',
  notifyTiming: {
    dateCount: 2,
    dateType: '日'
  },
  notifyFrequency: 'everyDay',
  collapsed: true
};

const emailTemplateInfo = {
  emailTemplateType: '電子 DM',
  prodType: '信貸',
  emailTemplateName: '玉山青年創業信貸專案',
  activeDate: '2018/02/28',
  expireDate: '2018/12/31'
};

const prodSetting = {
  productCode: 'offr001',
  productName: '房貸',
  activePeriod: 0,
  extensionPeriod: 0,
  isExcutable: true,
  isReferable: true,
  buildDate: '2018/02/01',
};

const headOfficeAssignmentDetail = [
  {
    attachedFiles: [
      {
        link: '',
        title: '日本東京機票'
      },
      {
        link: '',
        title: '日本大阪機票'
      }
    ],
    boHeadCaseList: [
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'reject'
        },
        acct: '陳先生',
        id: '1',
        uniqueId: 'A111111',
        handler: '理大吉',
        creator: '陳先生',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      },
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'none'
        },
        acct: '陳小姐',
        id: '2',
        uniqueId: 'A11133333',
        handler: '理小吉',
        creator: '陳小姐',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      }
    ]
  },
  {
    attachedFiles: [
      {
        link: '',
        title: '美國紐約機票'
      }
    ],
    boHeadCaseList: [
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'reject'
        },
        acct: '陳先生',
        id: '1',
        uniqueId: 'A111111',
        handler: '理大吉',
        creator: '陳先生',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      }
    ]
  }
];

const headOfficeAssignment: any[] = [
  {
    number: 'AA0012356789',
    subject: '日本東京來回機票資格審核名單',
    operator: '林美玲	',
    creator: {
      empName: '王中明',
      empId: '21235'
    },
    department: '01234 板橋分行',
    replyDate: '2018/01/07',
    dueDate: '2018/09/09',
    applicant: '王大明',
    applicantId: '23143',
    applyDate: '2018/09/10',
    assignmentType: '貸後追蹤',
    content: `急里為精實動較一小夜心所主分遠出條快展在處住要們種一城海馬再正品利動候子天
              人看一回這士反內之建：有兒！會不響品前有現水得面常。喜了說校，人得東自……
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。`,
  },
  {
    number: 'AA0011111111',
    subject: '美國來回機票資格審核名單',
    operator: '林美玲	',
    creator: {
      empName: '王中明',
      empId: '21235'
    },
    department: '01234 板橋分行',
    replyDate: '2018/01/07',
    dueDate: '2018/09/10',
    applicant: '王大明',
    applicantId: '23143',
    applyDate: '2018/09/10',
    assignmentType: '新聞事件',
    content: `急里為精實動較一小夜心所主分遠出條快展在處住要們種一城海馬再正品利動候子天
              人看一回這士反內之建：有兒！會不響品前有現水得面常。喜了說校，人得東自……
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。`,
  }
];


@Injectable({
  providedIn: 'root'
})
export class ManagementService {

  private WFObjectName = 'Management';
  private oriWFObjectName = this.WFObjectName;

  constructor(
    private api: ApiService,
    private auth: AuthService
  ) { }

  // common methods
  public getWFObjectName(): string {
    return this.WFObjectName;
  }

  public setWFObjectName(WFObjectName) {
    this.WFObjectName = WFObjectName;
  }

  public resetWFObjectName() {
    this.WFObjectName = this.oriWFObjectName;
  }

  public checkoutWF(props: any, type: ManagementWFType): Observable<any> {
    let body = _.assign({ActionEmp: this.auth.getLoginUser()}, props);
    return this.api.post(`${type}/wf/checkout`, body, {});
  }

  public cancelCheckoutWF(props: any, type: ManagementWFType): Observable<any> {
    let body = _.assign({ActionEmp: this.auth.getLoginUser()}, props);
    return this.api.post(`${type}/wf/cancel`, body, {});
  }

  public checkinWF(props: any, type: ManagementWFType): Observable<any> {
    let body = _.assign({ActionEmp: this.auth.getLoginUser()}, props);
    return this.api.post(`${type}/wf/checkin`, body, {});
  }

  public submitWF(props: any, type: ManagementWFType): Observable<any> {
    let body = _.assign({ApplyEmp: this.auth.getLoginUser()}, props);
    return this.api.post(`${type}/wf/submit`, body, {});
  }

  public discard(UUID: any, type: ManagementWFType): Observable<any> {
    return this.api.get(`${type}/${UUID}/discard`, {});
  }

  public removeFileByUUID(UUID: string): Observable<any> {
    return this.api.delete(`File/${UUID}`);
  }

  // marketingTeam methods
  public createMarketingTeam(props): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, props);
    return this.api.post('Team/create', body);
  }

  public getMarketingTeamInfo(teamNo): Observable<any> {
    return this.api.get(`Team/${teamNo}`);
  }

  public updateMarketingTeamInfo(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch(`Team/${info.TeamNo}`, body);
  }

  public getMarketingTeamMember(teamNo): Observable<any> {
    return this.api.get(`Team/${teamNo}/members`);
  }

  public updateMarketingTeamMember(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch(`Team/${info.TeamNo}/members`, body);
  }

  public getMarketingTeamList(searchModel): Observable<any> {
    return this.api.post('Team/search', searchModel);
  }

  // productTag methods
  public getProductTagList(searchModel): Observable<any> {
    return this.api.post('Tag/search', searchModel);
  }

  public getProductTagByTagId(tagId): Observable<any> {
    return this.api.get(`Tag/${tagId}`);
  }

  public updateProductTag(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch('Tag', body);
  }

  // productSetting methods
  public getProductSettingList(searchModel): Observable<any> {
    return this.api.post('Product/search', searchModel);
  }

  public getProductSettingByProdcutCode(productCode): Observable<any> {
    return this.api.get(`Product/${productCode}`);
  }

  public updateProductSetting(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch('Product', body);
  }

  public createProductSetting(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.post('Product', body);
  }

  // notification methods
  public getNotificationList(searchModel): Observable<any> {
    return this.api.post('Notification/search', searchModel);
  }

  public getNotificationByUUID(UUID): Observable<any> {
    return this.api.get(`Notification/${UUID}`);
  }

  public createNotification(props): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, props);
    return this.api.post('Notification', body);
  }

  public updateNotification(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch('Notification', body);
  }

  // headofficeAssignment methods
  public getHeadOfficeAssignmentList(searchModel): Observable<any> {
    return this.api.post('CaseMgm/search', searchModel);
  }

  public getHeadOfficeAssignmentByCaseNo(caseNo): Observable<any> {
    return this.api.get(`CaseMgm/${caseNo}`);
  }

  public getHeadOfficeAssignmentFilesByCaseNo(caseNo): Observable<any> {
    return this.api.get(`CaseMgm/${caseNo}/files`);
  }

  public getHeadOfficeAssignmentBOLListByCaseNo(caseNo): Observable<any> {
    return this.api.get(`CaseMgm/${caseNo}/details`);
  }

  public createHeadOfficeAssignment(props): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, props);
    return this.api.post('CaseMgm', body);
  }

  public updateHeadOfficeAssignment(info): Observable<any> {
    let body = _.assign({loginUser: this.auth.getLoginUser()}, info);
    return this.api.patch('CaseMgm', body);
  }

  // 逾期通知
  public getOverdueList(config): Observable<any> {
    return this.api.post('Overdue/search', config);
  }

  public getOverdueInfo(UUID): Observable<any> {
    return this.api.get(`Overdue/${UUID}`);
  }

  public getOverdueInfoDetail(UUID): Observable<any> {
    return this.api.get(`Overdue/${UUID}/rules`);
  }

  public createOverdue(props): Observable<any> {
    let body = _.assign({ LoginUser: this.auth.getLoginUser() }, props);
    return this.api.post('Overdue', body);
  }

  public updateOverdue(props): Observable<any> {
    let body = _.assign({ LoginUser: this.auth.getLoginUser() }, props);
    return this.api.patch('Overdue', body);
  }

  public discardOverdue(UUID): Observable<any> {
    return this.api.get(`Overdue/${UUID}/discard`);
  }

  // Email Template

  public getEmailTemplateInfoList(config: any): Observable<any> {
    // const list = [];

    // for (const statusValue of status) {
    //   const email = _.cloneDeep(emailTemplateInfo);
    //   email['status'] = statusValue;
    //   email['id'] = status.indexOf(statusValue);
    //   list.push(email);
    // }
    // return asyncReturn(list);
    return this.api.post('MailTemplate/search', config);
  }
}
function asyncReturn(value) {
  return new Observable((observer) => {
    observer.next(value);
  });
}
