// angular module
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
// model
import {
  CalendarEventResponseDto,
  CalendarEventDto,
  RelativeLinkResponseDto,
  RelativeLinkTableRowDto,
  AnnounceResponseDto,
  AnnounceTableRowDto,
  CalendarEventInfoDto,
  CalendarEventEditInfo
} from 'app/dashboard/dashboard.model';
// service
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
// helper
import { DateHelper } from 'app/shared/helper/date-helper';
// moment js
declare var moment: any;

/**
 * dashboard servie
 */
@Injectable()
export class DashboardService {

  private BOLRemindMapper = {
    Ebm: '1',
    Network: '2',
    SelfBuilt: '3',
    SystemReferral: '4'
  };

  private BOLSourceLabel = {
    1: 'EBM',
    2: '網路進件',
    3: '系統轉介',
    4: '自建名單',
  };

  constructor(
    private api: ApiService,
    private auth: AuthService
  ) {}

  /**
   *  get relative links
   */
  public getRelativeLinks(): Observable<any> {
    return this.api.get('RealLink').pipe( map( data => {
      return data.value.map( (el: RelativeLinkResponseDto): RelativeLinkTableRowDto => {
        return {
          UUID: el.UUID,
          name: el.Name,
          url: el.Url
        }
      })
    }));
  }

  /**
   *  get announces
   */
  public getAnnounce(): Observable<any> {
    return this.api.post('Announce', { pf: {skip: 0, take: 5 }}).pipe( map(
      data => {
        return data.value.map( (el: AnnounceResponseDto): AnnounceTableRowDto => {
          return {
            publishDate: DateHelper.formatDate(el.PublishDate),
            title: el.Title,
            content: el.Content
          }
        })
      }
    ));
  }

  /**
   * get BOL summary
   * fn: getBOLReminds
   *
   * @memberof DashboardService
   */
  public getBOLReminds() {
    return this.api.get('BOL/Summary', {empId: this.auth.getLoginUser().loginEmpId})
            .pipe( map( data => {
              if (data.isOk) {
                // return table data array
                return Object.keys(data.value).map( (key) => {
                  return {
                    source: this.BOLRemindMapper[key],
                    // need refactor
                    sourceLabel: this.BOLSourceLabel[this.BOLRemindMapper[key]],
                    unExecute: {
                      label: data.value[key]['Todo'],
                      link: ['/business-op', 'search'],
                      queryParams: {
                        source: this.BOLRemindMapper[key],
                        status: 'INIT'
                      }
                    },
                    track: {
                      label: data.value[key]['Tracking'],
                      link: ['/business-op', 'search'],
                      queryParams: {
                        source: this.BOLRemindMapper[key],
                        status: 'INPRG'
                      }
                    },
                    trackExpired: {
                      label: data.value[key]['TrackingOverdue'],
                      link: ['/business-op', 'search'],
                      queryParams: {
                        source: this.BOLRemindMapper[key],
                        status: 'INIT'
                      }
                    },
                    todayVisit: {
                      label: data.value[key]['TodayVisit'],
                      link: ['/business-op', 'schedule'],
                      queryParams: {
                        source: this.BOLRemindMapper[key],
                      }
                    },
                  };
                });
              }
            }));
  }

  /**
   * get events
   */
  public getEvents(params: {empId?: string, selectType?: number, selectDate?: string | Date} = {}): Observable<any> {
    return this.api.get('Calendar', params ).pipe( map( data => {
      return data.value.map( (event: CalendarEventResponseDto): CalendarEventDto  => {
        let formatedDate = moment(event['VisitDate']).format('YYYY-MM-DD') + `T${event['VisitTime']}`;
        const start = moment(formatedDate, moment.HTML5_FMT.DATETIME_LOCAL).format();
        const end = moment(formatedDate, moment.HTML5_FMT.DATETIME_LOCAL).format();
        return {
          start: start,
          end: end,
          title: event.Subject,
          id: event.UUID,
          data: event,
          color: moment(formatedDate).isAfter() ? '#00AD95' : '#7F7F7F'
        };
      });
    }));
  }

  /**
   * add event
   */
  public addEvent(formData: CalendarEventInfoDto): Observable<any> {
    return this.api.post('Calendar', formData);
  }

  /**
   * edit event
   */
  public editEvent(formData: CalendarEventEditInfo): Observable<any> {
    return this.api.put('Calendar', formData);
  }

  /**
   * delete event
   */
  public deleteEvent(params: {UUID: string}): Observable<any> {
    return this.api.delete('Calendar', params);
  }

}
