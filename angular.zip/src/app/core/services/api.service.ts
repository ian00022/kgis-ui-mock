import { HttpParams, HttpClient, HttpErrorResponse, HttpResponse, HttpHeaders, HttpRequest, HttpEvent, HttpEventType } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { MarsHttpResponseResult } from '../models/response.model';
import * as _ from 'lodash';
import { FileUploader, FileUploaderOptions } from 'ng2-file-upload';
import { NgxPermissionsService } from 'ngx-permissions';
import { JwtService } from './jwt.service';

@Injectable()
export class ApiService {

  public url: string;
  public errorMessage: Observable<{msg: string, show: boolean}>;
  private errorMessageEvent = new BehaviorSubject<{msg: string, show: boolean}>(
    {
      msg: '',
      show: false
    }
  );

  private limitTake = 10000;

  constructor(
    private http: HttpClient,
    private permissionService: NgxPermissionsService,
    private jwt: JwtService
  ) {
    this.errorMessage = this.errorMessageEvent.asObservable();
  }

  getExternal(path: string, params = {}): Observable<any> {
    // let httpParam = new HttpParams({fromObject: params});
    return this.http.get(`${path}`, { params })
      .pipe(catchError(this.formatErrors.bind(this)));
  }

  get(path: string, params = {}, noAPIAtLast?): Observable<MarsHttpResponseResult> {
      let httpParam = new HttpParams({fromObject: params});
      let apiUrl = environment.api_url;
      if (noAPIAtLast) {
        apiUrl = apiUrl.replace('/api/', '/');
      }
      return this.http.get(
        `${apiUrl}${path}`,
      {
        // headers: this.headers,
        params: httpParam,
        observe: 'response'
      }
    ).pipe(
        map(this.handleResponseBody),
        catchError(this.formatErrors.bind(this))
    );
  }

  put(path: string, body: Object = {}): Observable<MarsHttpResponseResult> {
    return this.http.put(
      `${environment.api_url}${path}`,
      JSON.stringify(body),
      {
        observe: 'response'
      }
    ).pipe(
      map(this.handleResponseBody),
      catchError(this.formatErrors.bind(this))
    );
  }

  post(path: string, body: Object = {}, options?: any ): Observable<MarsHttpResponseResult> {
    return this.http.post(
      `${environment.api_url}${path}`,
      JSON.stringify(body),
      _.assign({
          observe: 'response'
        }, options)
    ).pipe(
      map(this.handleResponseBody) as any,
      catchError(this.formatErrors.bind(this))
    );
  }

  patch(path: string, body = {}): Observable<MarsHttpResponseResult>  {
    return this.http.patch(
      `${environment.api_url}${path}`,
      JSON.stringify(body),
      {
        observe: 'response'
      }
    ).pipe(
      map(this.handleResponseBody),
      catchError(this.formatErrors.bind(this))
    );
  }

  // delete(path: string, params = {}): Observable<any> {
  //   let httpParam = new HttpParams({fromObject: params});
  //   return this.http.delete(
  //     `${environment.api_url}${path}`,
  //     {
  //       headers: this.headers,
  //       observe: 'response',
  //       params: httpParam
  //     }
  //   ).pipe(
  //     map(this.handleResponseBody),
  //     catchError(this.formatErrors));
  // }

  delete(path: string, body = {}): Observable<MarsHttpResponseResult> {
    return this.http.request(
      'delete',
      `${environment.api_url}${path}`,
      {
        // headers: this.headers,
        observe: 'response',
        body: JSON.stringify(body)
      }
    ).pipe(
      map(this.handleResponseBody),
      catchError(this.formatErrors.bind(this)));
  }

  upload(path: string, formData: FormData, upLoadItem: any) {
    const req = new HttpRequest(
      'POST',
      `${environment.api_url}${path}`,
      formData,
      {
        headers: new HttpHeaders({
          'Accept': 'application/json',
        }),
        reportProgress: true,
        // withCredentials: true,
      }
    );

    return this.http.request(req).pipe(catchError(this.formatErrors.bind(this)))
      .subscribe((event: HttpEvent<{}>) => {
        if (event.type === HttpEventType.UploadProgress) {
          if (event.total > 0) {
            // tslint:disable-next-line:no-any
            (event as any).percent = event.loaded / event.total * 100;
          }
          // 上傳進度，必須指定 `percent` 表示進度
          upLoadItem.onProgress(event, upLoadItem.file);
        } else if (event instanceof HttpResponse) {
          // 成功
          upLoadItem.onSuccess(event.body, upLoadItem.file, event);
        }
      }, (err) => {
        // 失敗
        upLoadItem.onError(err, upLoadItem.file);
    });
  }

  // loadPermissionsByTokenId(tokenId: string): Observable<any> {
  //   this.setAuthHeader(tokenId);
  //   return this.http.post(
  //     `${environment.api_url}Auth/Token`, {},
  //     {
  //       headers: this.headers,
  //       observe: 'response'
  //     }
  //   ).pipe(
  //     map(this.handleResponseBody)
  //   );
  // }

  public showErrorMessage(msg: string) {
    this.errorMessageEvent.next({
      msg: msg,
      show: true
    });
  }

  public getLimitTake(): number {
    return this.limitTake;
  }

  public createFileUploader(options: FileUploaderOptions): FileUploader {
    let header = {
      name: 'authorization',
      value: this.jwt.getAuthToken()
    };

    if (options.headers) {
      options.headers.push(header);
    } else {
      options.headers = [header];
    }
    return new FileUploader(options);
  }

  private handleResponseBody = (resp: HttpResponse<Object>) => {
    // const respBody = this.toCamel(resp.body) as MarsHttpResponseResult;
    let respBody: MarsHttpResponseResult = {
      isOk: resp.body['IsOk'],
      messages: resp.body['Messages'],
      value: resp.body['Value'],
      properties: resp.body['Properties'],
    };

    if (!respBody.isOk) {
      throw new HttpErrorResponse({
        error: respBody.messages,
        headers: resp.headers,
        status: resp.status,
        statusText: resp.statusText,
        url: resp.url
      });
    } else {
      return respBody;
    }
  }

  private formatErrors (error: HttpErrorResponse): Observable<MarsHttpResponseResult> {
    switch(error.status) {
      case 401:
        this.permissionService.flushPermissions();
        this.jwt.destroyToken();
        location.href = '/#/login';
        break;
      default:
        this.showErrorMessage(error.error);
    }
    return of({
      isOk: false,
      messages: error.error,
      value: []
    });
  }

  // private toCamel(o) {
  //   let newO, origKey, newKey, value;
  //   if (o instanceof Array) {
  //     return o.map( (obj) => {
  //         if (typeof obj === 'object') {
  //           obj = this.toCamel(obj);
  //         }
  //         return obj;
  //     });
  //   } else {
  //     newO = {};
  //     for (origKey in o) {
  //       if (o.hasOwnProperty(origKey)) {
  //         newKey = (origKey.charAt(0).toLowerCase() + origKey.slice(1) || origKey).toString();
  //         value = o[origKey];
  //         if (value instanceof Array || (value !== null && value.constructor === Object)) {
  //           value = this.toCamel(value);
  //         }
  //         newO[newKey] = value;
  //       }
  //     }
  //   }
  //   return newO;
  // }
}
