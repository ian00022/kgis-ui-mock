import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { NgxPermissionsService } from 'ngx-permissions';
import { PermissionResponseDto, LoginUserDto } from 'app/core/models/permissions';
import { ApiService } from './api.service';
import { JwtService } from './jwt.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loginUser: LoginUserDto;

  constructor(
    private api: ApiService,
    private permissionService: NgxPermissionsService,
    private jwt: JwtService
  ) { }

  public getLoginUser(): LoginUserDto {
    return this.loginUser;
  }

  public switchUser() {
    // if (this.loginUser.loginEmpId === this.ao.loginEmpId) {
    //   this.loginUser = this.manager;
    //   this.permissionService.addPermission('BOL_REVIEW');
    // } else {
    //   this.loginUser = this.ao;
    //   this.permissionService.removePermission('BOL_REVIEW');
    // }
  }

  public loadPermissionsByUserId(userId): Observable<PermissionResponseDto> {
    return this.api.get(`Auth/${userId}`).pipe(map(data => {
      this.setLoginUser(data.value);
      this.jwt.saveToken(data.value.TokenId);
      return data.value;
    }));
  }

  public loadPermissionsByToken(): Observable<PermissionResponseDto> {
    return this.api.post('Auth/Token').pipe(
      map( data => {
        if (data.isOk) {
          this.setLoginUser(data.value);
          return data.value;
        }
        return {Permissions: []};
      })
    );
  }

  public removeAllPermissions() {
    this.permissionService.flushPermissions();
  }

  private setLoginUser(data: PermissionResponseDto) {
    this.loginUser = {
      token: data.TokenId,
      loginEmpId: data.EmpId,
      name: data.Name,
      unitId: data.UnitId,
      unitName: data.UnitName
    };
  }
}
