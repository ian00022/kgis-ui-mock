import { Injectable } from '@angular/core';
import { MenuItem } from '../models/comm-data';
import { Permissions } from './../models/permissions';
import { of } from 'rxjs';

@Injectable()
export class MenuService {
  public Permissions = Permissions;

  menu: MenuItem[] = [
    { id: 1, text: '入口首頁', url: '/dashboard',
      permissions: [
        Permissions.VISIT_SEARCH,
        Permissions.ANNOUNCE_SEARCH,
        Permissions.REAL_LINK_SEARCH,
        Permissions.TODAY_VISIT_SEARCH
      ]
    },
    { id: 2, text: '顧客查詢', url: '/clients/search',
      permissions: [
        Permissions.PERSONAL_SEARCH,
        Permissions.PERSONAL_SPECIAL_MEMBER_SEARCH
      ]
    },
    { id: 0, text: '名單管理', url: '', collapsed: false,
      permissions: [
        Permissions.GENERAL_BOL_SEARCH,
        Permissions.HEAD_OFFICE_BOL_SEARCH,
        Permissions.MY_FAVORITE_BOL_SEARCH,
        Permissions.TODAY_VISIT_SEARCH,
        Permissions.LOAN_BOL_SEARCH,
        Permissions.GENERAL_BOL_APPROVE_SEARCH,
        Permissions.HEAD_OFFICE_BOL_APPROVE_SEARCH,
        Permissions.ASSIGN_GENETAL_BOL_SEARCH,
        Permissions.ASSIGN_HEAD_OFFFICE_SEARCH
      ],
      children:
        [
          { id: 6, text: '名單查詢', url: '/business-op/search',
            permissions: [
              Permissions.GENERAL_BOL_SEARCH,
              Permissions.HEAD_OFFICE_BOL_SEARCH
            ]
          },
          { id: 7, text: '我的最愛', url: '/business-op/favorite',
            permissions: [
              Permissions.MY_FAVORITE_BOL_SEARCH
            ]
          },
          { id: 8, text: '今日行程', url: '/business-op/schedule',
            permissions: [
              Permissions.TODAY_VISIT_SEARCH
            ]
          },
          { id: 15, text: '貸款送件查詢', url: '/business-op/loan-process',
            permissions: [
              Permissions.LOAN_BOL_SEARCH
            ]
          },
          { id: 9, text: '名單覆核', url: '/business-op/review',
            permissions: [
              Permissions.GENERAL_BOL_APPROVE_SEARCH,
              Permissions.HEAD_OFFICE_BOL_APPROVE_SEARCH
            ]
          },
          { id: 10, text: '名單分派', url: '/business-op/assignment',
            permissions: [
              Permissions.ASSIGN_GENETAL_BOL_SEARCH,
              Permissions.ASSIGN_HEAD_OFFFICE_SEARCH
            ]
          },
        ]
    },
    { id: 3, text: '商機轉介查詢', url: '/referral',
      permissions: [
        Permissions.REFERRAL_SEARCH
      ]
    },
    { id: 4, text: '行銷專區', url: '/marketing', collapsed: false,
      permissions: [
        Permissions.LOAN_CALCULATE_SEARCH,
        Permissions.EDM_SEARCH,
        Permissions.MAP_SEARCH,
        Permissions.REAL_ESTATE_TRANSACTION_SEARCH
      ],
      children: [
          { id: 13, text: '貸款試算', url: '/marketing/loan-trial',
            permissions: [
              Permissions.LOAN_CALCULATE_SEARCH
            ]
          },
          { id: 14, text: '電子 DM', url: '/marketing/edm',
            permissions: [
              Permissions.EDM_SEARCH
          ]
        },
          { id: 11, text: '行銷地圖', url: '/marketing/map',
            permissions: [
              Permissions.MAP_SEARCH
          ]
        },
          { id: 12, text: '估價查詢', url: '/marketing/valuation',
            permissions: [
              Permissions.REAL_ESTATE_TRANSACTION_SEARCH
          ]
        },
      ]
    },
    { id: 15, text: '管理功能', url: '/management', collapsed: false,
      permissions: [
        Permissions.USER_ROLE_SEARCH,
        Permissions.ROLE_SEARCH,
        Permissions.MARKETING_TEAM_SEARCH,
        Permissions.EMAIL_TEMPLATE_LIST_SEARCH,
        Permissions.NOTIFICATION_SEARCH,
        Permissions.CASE_MANAGEMENT_BOL_SEARCH,
        Permissions.OVERDUE_NOTIFICATION_LIST_SEARCH,
        Permissions.RECOMMEND_PRODUCTS_SEARCH,
        Permissions.PRODUCT_PARAMETER_SEARCH,
        Permissions.SYSTEM_PROPERTY_SEARCH
      ],
      children: [
        { id: 16, text: '角色權限', url: '/management/role',
          permissions: [
            Permissions.USER_ROLE_SEARCH,
            Permissions.ROLE_SEARCH
          ]
        },
        { id: 17, text: '行銷團隊', url: '/management/marketing-team',
          permissions: [
            Permissions.MARKETING_TEAM_SEARCH
          ]
        },
        { id: 18, text: 'E-mail 樣板', url: '/management/email-template',
          permissions: [
            Permissions.EMAIL_TEMPLATE_LIST_SEARCH
          ]
        },
        { id: 19, text: '推播通知', url: '/management/notification',
          permissions: [
            Permissions.NOTIFICATION_SEARCH
          ]
        },
        { id: 20, text: '總行指派案件', url: '/management/head-office-assignment',
          permissions: [
            Permissions.CASE_MANAGEMENT_BOL_SEARCH
          ]
        },
        { id: 21, text: '名單/案件逾期通知', url: '/management/expiry-notificaiton',
          permissions: [
            Permissions.OVERDUE_NOTIFICATION_LIST_SEARCH
          ]
        },
        { id: 22, text: '推薦產品標籤', url: '/management/product-tag',
          permissions: [
            Permissions.RECOMMEND_PRODUCTS_SEARCH
          ]
        },
        { id: 23, text: '產品參數', url: '/management/product-setting',
          permissions: [
            Permissions.PRODUCT_PARAMETER_SEARCH
          ]
        },
        { id: 24, text: '系統參數', url: '/management/system-setting',
          permissions: [
            Permissions.SYSTEM_PROPERTY_SEARCH
          ]
        },
      ]
    },
    { id: 5, text: '成效管理', url: '/effect-report',
      permissions: [
        Permissions.BOL_RESULT_SEARCH,
        Permissions.BOL_DETAIL_SEARCH
      ]
    },
  ];
  constructor() { }

  getMenu() {
    return of(this.menu);
  }
}
