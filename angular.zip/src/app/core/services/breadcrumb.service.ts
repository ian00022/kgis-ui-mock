import { Observable ,  Subject } from 'rxjs';
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';

@Injectable()
export class BreadcrumbService {
  public history$: Observable<any>;
  public historySubject: Subject<any>;

  private capacity = 6;
  private history = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
  ) {
    this.historySubject = new Subject<boolean>();
    this.history$ = this.historySubject.asObservable();
    // this.router.events.subscribe(() => {
    //   this.handleHistoryUpdate();
    // })
    this.location.subscribe((event) => {
      if (event.type === 'hashchange') {
        this.removeAfter(this.history.length - 2);
      }
    });
  }

  public loadRouting(): void {
    this.getNavigationEndEvent()
      .subscribe( (event: NavigationEnd) => {
        this.history = [...this.history, {
          url: event.urlAfterRedirects,
          name: this.getPageName(),
          data: {}
        }];
        if (this.history.length > this.capacity) {
          this.history.splice(0, 1);
        }
        this.handleHistoryUpdate();
      });
  }

  public getHistory(): string[] {
    return this.history;
  }

  public getPreviousUrl(): string {
    return this.history[this.history.length - 2] || '/index';
  }

  public removeAfter(index) {
    this.history = this.history.slice(0, index);
  }

  public setCurrentPageName(pageName: string) {
    this.history[this.history.length - 1].name = pageName;
    this.handleHistoryUpdate();
  }

  public setCurrentPageData(data: any) {
    this.history[this.history.length - 1].data = data;
  }

  public getCurrentPageData() {
    return this.history[this.history.length - 1].data;
  }

  
  private handleHistoryUpdate(){
    // this.history$ = of(this.history);
    this.historySubject.next(this.history);
  }

  private getNavigationEndEvent(): Observable<any> {
    return this.router.events.pipe(filter(event => event instanceof NavigationEnd));
  }

  private getPageName() {
    let route = this.route.firstChild;
    let child = route;
    while (child) {
      if (child.firstChild) {
        child = child.firstChild;
        route = child;
      } else {
        child = null;
      }
    }
    let data = route.data['value'];
    return data['breadcrumb']? data['breadcrumb'] : '未定義名稱';
  }
}
