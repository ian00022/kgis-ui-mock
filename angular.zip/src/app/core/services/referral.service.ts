import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { StatusProcess, StatusLight } from './../../shared/components/ibm-table/ibm-table.model';
import { ApiService } from './api.service';
import { ReferralListConfig } from '../models/referral-list-config.model';
import { Referral } from '../models/referral.model';
import { map } from 'rxjs/operators';
import { BolHelper } from '../../business-opportunity/bol-helper';


@Injectable()
export class ReferralService {

// public referralList: Referral[] = [
//   {
//     id: '1',
//     uniqueId: 'A128940184',
//     prod: '其他保險(非儲蓄險、非房貸壽險)',
//     acct: '陳先生',
//     tel: '02-11223311',
//     branch: {
//       branchCode: '01234',
//       branchName: '板橋分行'
//     },
//     operator: {
//       empId: '11234',
//       empName: '王小明'
//     },
//     referralBranch: {
//       branchCode: '01235',
//       branchName: '中和分行'
//     },
//     referralOperator: {
//       empId: '31236',
//       empName: '華小明'
//     },
//     referralTime: Date.now(),
//     status: {
//       light: StatusLight.RED,
//       text: '已受理',
//       process: StatusProcess.WAIT,
//       frontTooltip: '追蹤逾期'
//     },
//     prodNote: '轉介產品備註',
//     note: '其他說明',
//   }
// ];
public referralableHeader = {
  IdentityCardNo: '統一編號',
  ProductCode: '產品別',
  CustomerName: '戶名',
  ReferralUnit: '轉介單位',
  ReferralEmpId: '轉介人員',
  ProdNote: '轉介產品備註',
  AcceptedReferralUnit: '受理轉介單位',
  AcceptedReferralEmpId: '受理轉介人員',
  ReferralDate: '轉介時間',
  Note: '其他說明',
  ProcessStatusCode: '處理狀態',
};

public referralMap = {
  UUID: 'UUID',
  IdentityCardNo: 'IdentityCardNo',
  ProductCode: 'ProductCode',
  CustomerName: 'CustomerName',
  ReferralUnit: 'ReferralUnit',
  ReferralUnitName: 'ReferralUnitName',
  ReferralEmpId: 'ReferralEmpId',
  ReferralEmpName: 'ReferralEmpName',
  AcceptedReferralUnit: 'AcceptedReferralUnit',
  AcceptedReferralUnitName: 'AcceptedReferralUnitName',
  AcceptedReferralEmpId: 'AcceptedReferralEmpId',
  AcceptedReferralEmpName: 'AcceptedReferralEmpName',
  ReferralDate: 'ReferralDate',
  BOLStatus: 'BOLStatus',
  BOLStatusDetailCategory: 'BOLStatusDetailCategory',
  BOLStatusDetail: 'BOLStatusDetail',
  IsDue: 'IsDue',
  OverdueStatus: 'OverdueStatus',
  DueReason: 'DueReason',
  WFStatus: 'WFStatus',
  HasDuplicateBol: 'HasDuplicateBol',
  ProcessStatusCode: 'ProcessStatusCode',
};

constructor(
  private api: ApiService,
) { }

  public query(config: any): Observable<any> {
    return this.api.post('Referral/SearchReferrals', config).pipe(
        map( (resp) => {
          return resp.value.map( (el) => {
            return {
              UUID: el['UUID'],
              identityCardNo: el['IdentityCardNo'],
              productCode: el['ProductCode'],
              customerName: el['CustomerName'],
              referralUnit: el['ReferralUnit'],
              referralUnitName: el['ReferralUnitName'],
              referralEmpId: el['ReferralEmpId'],
              referralEmpName: el['ReferralEmpName'],
              acceptedReferralUnit: el['AcceptedReferralUnit'],
              acceptedReferralUnitName: el['AcceptedReferralUnitName'],
              acceptedReferralEmpId: el['AcceptedReferralEmpId'],
              acceptedReferralEmpName: el['AcceptedReferralEmpName'],
              referralDate: el['ReferralDate'],
              BOLStatus: el['BOLStatus'],
              BOLStatusDetailCategory: el['BOLStatusDetailCategory'],
              BOLStatusDetail: el['BOLStatusDetail'],
              isDue: el['IsDue'],
              overdueStatus: el['OverdueStatus'],
              dueReason: el['DueReason'],
              WFStatus: el['WFStatus'],
              hasDuplicateBol: el['HasDuplicateBol'],
              processStatusCode: el['ProcessStatusCode'],
              status: BolHelper.transferBolStatus(el)
            };
          });
        })
    );
  }

  public save(referral) {
    // If we're updating an existing referral
    if (referral.UUID) {
      return this.api.put('Referral', referral);
    // Otherwise, create a new referral
    } else {
      return this.api.post('Referral',referral);
    }
  }

  public export(config: ReferralListConfig, exportAll: boolean = false) {
    if (exportAll) {
      // return this.api.post('Referral/Export', config, {
      //   headers: new HttpHeaders({
      //     'Content-Type': 'application/force-download'
      //   })
      // });
      return this.api.post('Referral/Export', config);
    } else {
      return this.api.post('Referral/Export', config);
    }
  }

  public getReferralTableHeader() {
    return _.cloneDeep(this.referralableHeader);
  }

}
