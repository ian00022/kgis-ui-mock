import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JwtService {

  private id: string = 'tokenID';
  private token: string;

  getToken(): string {
    if (this.token) {
      return this.token;
    }
    return window.sessionStorage.getItem(this.id);
  }

  getAuthToken(): string {
    return `token ${this.getToken()}`;
  }

  saveToken(token: string) {
    window.sessionStorage.setItem(this.id, token);
    this.token = token;
  }

  destroyToken() {
    window.sessionStorage.removeItem(this.id);
    this.token = null;
  }
}
