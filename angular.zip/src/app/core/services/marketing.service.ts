import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

@Injectable()
export class MarketingService {

  public valuationList: any[] = [
    {
      infoSource: '本行鑑估',
      valuationDate: '0106/12/27',
      address: '台北市松山區民生東路三段 117 號',
      totalPrice: '80,000',
      landSquareMeters: '9',
      buildingSquareMeters: '26.04',
      squareMeterPrice: '44.2',
      floors: '3/005',
      completionDate: '0106/12/27',
    },
    {
      infoSource: '實價登錄',
      valuationDate: '0106/12/27',
      address: '台北市松山區民生東路三段 117 號',
      totalPrice: '236,700',
      landSquareMeters: '3.54',
      buildingSquareMeters: '26.04',
      squareMeterPrice: '44.2',
      floors: '3/005',
      completionDate: '0106/12/27',
    }
  ];
  public loadTrial: any = {
    loanTrialList: [
      {
        period: 1,
        principal: '2,533',
        interest: '323',
        principalAndInterest: '4,200',
        loanAmount: '13,244',
      }
    ],
    loanTrialSummary: {
      annaulRate: 0.0499,
      periodAmounts: [
        {
          label: '第 1 ~ 12 期 每期應還本利和',
          amount: '21,464',
          period: '第一期',
        },
        {
          label: '第 13 ~ 24 期 每期應還本利和',
          amount: '21,464',
          period: '第一期',
        },
        {
          label: '第 25 ~ 39 期 每期應還本利和',
          amount: '21,464',
          period: '第一期',
        }
      ]
    }
  };
  public dmList: any[] = [
    {
      UUID: '96d8a982-e9c7-4541-8db6-904a8a89f13b',
      ProductName: '玉山醫師信貸專案1',
      Expired: '2018/02/10',
      src: 'https://sfa-api.azurewebsites.net/api/MarketingDM/96d8a982-e9c7-4541-8db6-904a8a89f13b/preview'
    },
    {
      UUID: 'e8f6894a-097a-48e8-8217-abfcb8552d68',
      ProductName: '玉山加盟主信貸專案2',
      Expired: '2018/09/21',
      src: 'https://sfa-api.azurewebsites.net/api/MarketingDM/e8f6894a-097a-48e8-8217-abfcb8552d68/preview'
    }
  ];
  public dmHistoryList: any[] = [
    {
      sender: '林克',
      sendTime: '2018/04/12 04:47:25',
      status: 'fail',
    },
    {
      sender: '林克',
      sendTime: '2018/04/12 04:47:25',
      status: 'processing',
    },
    {
      sender: '林克',
      sendTime: '2018/04/12 04:47:25',
      status: 'sent',
    }
  ];


  constructor(
    private api: ApiService
  ) { }

  public getEstatePrices(cfg: any): Observable<any> {
    return this.api.post('MarektingEstate/Transaction', cfg);
  }

  public getValuationList(config: any): Observable<any> {

    return this.api.post('MarketingEstate', config);
  }

  public getLoanTrial(config: any): Observable<any> {
    // const arr = [];
    // for (let i = 1; i < 85; i++) {
    //   const obj = _.cloneDeep(this.loadTrial.loanTrialList[0]);
    //   obj.period = i;
    //   arr.push(obj);
    // }
    // this.loadTrial.loanTrialList = arr;
    // return new Observable( (observer) => {
    //   setTimeout(() => {
    //     observer.next({data: this.loadTrial});
    //     observer.complete();
    //   });
    // });
    return this.api.post('MarketingLoanTrial', config);
  }

  public sendMailMktLoanTrial(config: any): Observable<any> {
    return this.api.post('MarketingLoanTrial/SendMail', config);
  }

  public printMktLoanTrial(config: any): Observable<any> {
    return this.api.post('MarketingLoanTrial/PrintHtml', config);
  }

  public getDmList(config: any): Observable<{value: any[]}> {
    // return new Observable( (observer) => {
    //   setTimeout(() => {
    //     observer.next({data: this.dmList});
    //     observer.complete();
    //   });
    // });
    return this.api.post('MarketingDM', config);
  }

  public getDmHistoryList(UUID: any): Observable<{value: any[]}> {
    // return new Observable( (observer) => {
      // setTimeout(() => {
        // observer.next({value: this.dmHistoryList});
        // observer.complete();
      // });
    // });
    return this.api.get(`MarketingDM/${UUID}/SendHistory`);
  }

  public getEDMInputs(UUID: string, config: any): Observable<any> {
    // let dataQuery = _.cloneDeep(config);
    // delete dataQuery.UUID
    return this.api.get(`MailTemplate/${UUID}/fields`, config);
  }

  public sendMail(config: any): Observable<any> {
    return this.api.post(`MailTemplate/send`, config);
  }

  public uploadQRcode(config: FormData, item: any) {
    return this.api.upload(`File`, config, item);
  }
}
