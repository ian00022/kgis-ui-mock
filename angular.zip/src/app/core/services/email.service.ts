import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  public recipients$: Observable<any>;
  public recipientsSubject: Subject<any>;

  private recipients: string[] = [];

  constructor() {
    this.recipientsSubject = new Subject<boolean>();
    this.recipients$ = this.recipientsSubject.asObservable();
  }

  public isEmail(email: string): boolean {
    const req = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z]+$/;
    return req.test(email);
  }

  public illegalOrDuplicate(email: string | string[]): string[] {
    const compareEmails = _.isString(email) ? [email] : email;
    const notAllowStrings = compareEmails.filter(e =>
      (!this.isEmail(e) && e !== '') ||
      (this.isEmail(e) && compareEmails.filter(com => com === e).length > 1)
    );
    return _.uniq(notAllowStrings);
  }

  public setRecipients(recipient: string | string[]) {
    if ( typeof recipient === 'string') {
      this.recipients = _.uniq([...this.recipients, recipient]);
    } else {
      this.recipients = _.uniq(this.recipients.concat(recipient));
    }
    this.updateRecipients();
  }

  public removeRecipient(recipient: string | string[]) {
    if ( typeof recipient === 'string') {
      _.pull(this.recipients, recipient);
    } else {
      _.pullAll(this.recipients, recipient);
    }
    this.updateRecipients();
  }

  public getRecipient(): string[] {
    return this.recipients;
  }

  public sendToRecipients() {
    this.reset();
  }

  private reset() {
    this.recipients = [];
  }

  private updateRecipients() {
    this.recipientsSubject.next(this.recipients);
  }

}
