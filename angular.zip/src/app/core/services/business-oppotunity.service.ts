// angular module
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
// 3rd party module
import * as _ from 'lodash';
// model
import { ISelectOptionModel } from 'app/core/models/comm-data';
import {
  BOLSearchAction,
  BOLNormalCaseTableRowDto,
  BOLHeadofficeCaseTableRowDto,
  BOLNormalCaseResponseDto,
  BOLHeadofficeCaseResponseDto,
  BOLNormalCaseSearchParams,
  BOLNormalCaseVisitResponsDto,
  MkPersonWorkStatusResponseDto,
  MkPersonWorkStatusDto,
  LoanDeliveryResponseDto,
  LoanDeliveryTableRowDto
} from '../../business-opportunity/business-opportunity.model';
// service
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { BolResponseService } from 'app/business-opportunity/bol-response.service';

/**
 * BusinessOppotunityService
 */
@Injectable()
export class BusinessOppotunityService {

  public normalTableData: any[] = [
    {
      favorite: true,
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '1',
      prod: '副擔保',
      department: '消金營運部',
      operator: '李媛媛',
      source: 'EBM',
      type: '精彩稅月',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '2',
      prod: '個人信貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '線上申請',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '3',
      prod: '個人信貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '額度利率評估',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '4',
      prod: '個人信貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '網路留言板',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '5',
      prod: '副擔保',
      department: '消金營運部',
      operator: '李媛媛',
      source: '自建名單',
      type: '-',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'comp'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '6',
      prod: '副擔保',
      department: '消金營運部',
      operator: '李媛媛',
      source: '轉介名單',
      type: '-',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'comp'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '7',
      prod: '房貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '線上申請',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '8',
      prod: '房貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '額度利率評估',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    },
    {
      favorite: false,
      status: {
        light: 'gray',
        text: '追蹤中',
        process: 'wait',
        frontTooltip: '追蹤逾期',
        backTooltip: '待主管審核',
      },
      activeDate: '107/02/10',
      uniqueId: 'A128940184',
      acct: '陳先生',
      id: '9',
      prod: '房貸',
      department: '消金營運部',
      operator: '李媛媛',
      source: '網路進件',
      type: '網路留言板',
      action: {
        menus: [
          'searchBankAcct',
          'createBo',
          'createSchedule',
          'uploadFile',
          'rejectToHeadOffice',
          'searchGroup',
        ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust'
    }
  ];

  public headOfficeTableData: any[] = [
    {
      id: '1',
      number: 'AA0012356789',
      subject: '日本東京來回機票資格審核名單',
      operator: '林美玲	',
      creator: '陳先生',
      department: '01234 板橋分行',
      relpyDate: '2018/01/07',
      dueDate: '2018/09/09',
      action: {
        link: '1',
        dropdown: ''
      }
    },
    {
      id: '2',
      number: 'AA0011111111',
      subject: '美國來回機票資格審核名單',
      operator: '林美玲	',
      creator: '陳先生',
      department: '01234 板橋分行',
      relpyDate: '2018/01/07',
      dueDate: '2018/09/10',
      action: {
        link: '2',
        dropdown: ''
      }
    }
  ];

  public recordData = [
    {
      date: '2017/08/07 02:11',
      department: '網路',
      operator: '單位主管',
      excute: '網路派案收件',
      action: '覆核',
      excuteTo: '消金營運部',
      person: '單位主管',
    },
    {
      date: '2017/08/07 02:11',
      department: '消金營運部',
      operator: '系統',
      excute: '處理權移轉',
      action: '改派',
      excuteTo: '王珊珊',
      person: '張小雅',
    },
    {
      date: '2017/08/07 02:11',
      department: '消金營運部',
      operator: '張曉光',
      excute: '結案',
      action: '新建立',
      excuteTo: '王珊珊',
      person: '張小雅',
    }
  ];

  public marketRecord = {
    value: [
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'reject',
          frontTooltip: '追蹤逾期',
          backTooltip: '遭主管退回',
        },
        applyDate: '2017/10/28',
        department: '消金營運部',
        operator: '傅哲仁',
        source: '網路進',
        prod: '房貸',
      },
      {
        status: {
          text: '追蹤中',
          light: 'gray',
          process: '',
          frontTooltip: '尚未逾期',
        },
        applyDate: '2017/10/28',
        department: '消金營運部',
        operator: '傅哲仁',
        source: '網路進件',
        prod: '房貸',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      },
      {
        status: {
          text: '追蹤中',
          light: 'gray',
          process: 'wait',
          frontTooltip: '尚未逾期',
          backTooltip: '待主管放行',
        },
        applyDate: '2017/10/28',
        department: '消金營運部',
        operator: '傅哲仁',
        source: 'EBM',
        prod: '房貸',
      }
    ],
    type: '',
    cardTitle: '行銷接觸記錄'
  };

  public creditInfo = {
    value: {
      acct: [{
        title: '使用者帳號',
        content: 'ESB10000'
      }],
      department: [{
        title: '所屬單位',
        content: '808CL1 玉山商業銀行個人金融事業處'
      }],
      info: [
        {
          title: 'AAS003',
          content: '自然人姓名, 身分證補發, 通報, 補充註記'
        },
        {
          title: '身分證號',
          content: 'L123456789 陳大發'
        },
        {
          title: '清債/其他註記',
          content: 'N'
        },
        {
          title: '通報案件記錄',
          content: 'N'
        },
        {
          title: 'VAM030',
          content: '身分證號更改記錄'
        },
      ],
      item: [{
        title: '查詢項目',
        content: '098'
      }],
    },
    cardTitle: '資料查詢日期：2018/02/27'
  };

  public creditOnlineLoanInfo = {
    amlInfo: {
      cardTitle: 'AML 資訊',
      value: [
        {
          header: '多重國籍',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '第一國籍',
              content: '台灣'
            },
            {
              title: '第二國籍',
              content: '巴伐利亞'
            },
            {
              title: '第三國籍',
              content: '--'
            },
            {
              title: '第四國籍',
              content: '--'
            }
          ]
        },
        {
          header: '政治人物關係',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '與政治人物關係',
              content: '本人與政治人物是家庭成員'
            },
            {
              title: '稱謂',
              content: '女士'
            },
            {
              title: '姓名',
              content: '任盈盈'
            },
            {
              title: '英文姓名',
              content: 'Lian Yin-Yin'
            },
            {
              title: '出生日期',
              content: '69/09/28'
            },
            {
              title: '國籍',
              content: '台灣'
            },
            {
              title: '卸任/在職',
              content: '在職'
            },
            {
              title: '卸任時間',
              content: '--'
            },
            {
              title: '任職職務',
              content: '院長'
            },
            {
              title: '任職國家',
              content: '台灣'
            }
          ]
        }
      ]
    },
    applyInfo: {
      baseInfo: {
        data: [
          {
            title: '姓名',
            content: '令狐沖'
          },
          {
            title: '英文姓名',
            content: 'Lin Hu-Chong'
          },
          {
            title: '身分證字號',
            content: 'A123456789'
          },
          {
            title: '出生日期',
            content: '69/01/03'
          },
          {
            title: '婚姻',
            content: '已婚'
          },
          {
            title: '最高學歷',
            content: '大學'
          },
          {
            title: '子女數',
            content: '3'
          },
          {
            title: '是否有多重國籍',
            content: '是'
          },
          {
            title: '是否為政治人物或與政治人物有關係',
            content: '是'
          }
        ]
      },
      loanInfo: {
        data: [
          {
            title: '案件來源',
            content: '信貸線上申請'
          },
          {
            title: '顧客送出申請日',
            content: '2017/09/13'
          },
          {
            title: '申貸金額',
            content: '50 萬元'
          },
          {
            title: '貸款期間',
            content: '5 年'
          },
          {
            title: '貸款用途',
            content: '個人週轉金'
          },
          {
            title: '認證方式',
            content: '網銀'
          },
          {
            title: '線上申請補充說明',
            content: '有聯徵/無貸款條件'
          }
        ]
      },
      estate: {
        data: [
          {
            title: '不動產地址 (一)',
            content: '台北市松山區民生東路三段 117 號'
          },
          {
            title: '不動產地址 (二)',
            content: '台北市松山區民生東路三段 117 號/09/13'
          },
          {
            title: '不動產地址 (三)',
            content: '台北市松山區民生東路三段 117 號 萬元'
          },
          {
            title: '不動產地址 (四)',
            content: '台北市松山區民生東路三段 117 號 年'
          },
          {
            title: '不動產地址 (五)',
            content: '台北市松山區民生東路三段 117 號'
          }
        ]
      },
      contact: {
        data: [
          {
            title: '行動電話',
            content: '0987654321'
          },
          {
            title: '聯絡E-Mail',
            content: 'yaya3132@gmail.com'
          },
          {
            title: '現住地聯絡電話',
            content: '(02)2715-3132'
          },
          {
            title: '戶籍電話',
            content: '(02)2715-3132'
          },
          {
            title: '現住房屋',
            content: '自有'
          },
          {
            title: '現住地址',
            content: '105 台北市松山區民生東路三段 113 號'
          },
          {
            title: '通訊地址(文件寄送)',
            content: '105 台北市松山區民生東路三段 113 號'
          },
          {
            title: '戶籍地址',
            content: '105 台北市松山區民生東路三段 113 號'
          }
        ]
      },
      career: {
        data: [
          {
            title: '公司名稱',
            content: '大同電鍋'
          },
          {
            title: '公司統編',
            content: '55688131'
          },
          {
            title: '公司電話',
            content: '(02)2715-3132'
          },
          {
            title: '職業別',
            content: '一般職員'
          },
          {
            title: '現職年資',
            content: '7年10月'
          },
          {
            title: '年所得',
            content: '100'
          },
          {
            title: '所得證明文件',
            content: '執行業務收入'
          }
        ],
        records: [
          {
            applyDate: '2017/08/07',
            name: '汪小名',
            id: 'Q131313131',
            loanAmount: '30 萬',
            companyName: '笑傲江湖',
            companyAddress: '台北市中山區永綏街',
            companyIp: '123.94.113.90',
            status: '追蹤中',
          }
        ],
        texNumber: '11222333'
      },
      marketMark: {
        data: [
          {
            title: '行銷單位',
            content: '新樹分行'
          },
          {
            title: '行銷人員',
            content: '--'
          },
          {
            title: '受理單位',
            content: '新樹分行02)2715-3132'
          },
          {
            title: '名單分派說明',
            content: '依大消金起案經辦：蘇秀惠'
          },
          {
            title: '策略夥伴',
            content: '大潤發'
          },
          {
            title: '推薦人員',
            content: '王大名'
          },
          {
            title: '合作專案',
            content: '策略夥伴專案'
          },
          {
            title: '薪轉戶註記',
            content: 'Y'
          },
          {
            title: '本行薪轉月收入(估算)',
            content: '5,000元'
          },
          {
            title: '客群行銷資訊',
            content: '薪轉戶'
          },
          {
            title: '黑名單註記',
            content: '疑似代辦'
          },
          {
            title: 'IP 位址',
            content: '27.247.64.134'
          }
        ],
        records: [
          {
            applyDate: '2017/08/07',
            name: '汪小名',
            id: 'Q131313131',
            loanAmount: '30 萬',
            companyName: '笑傲江湖',
            companyAddress: '台北市中山區永綏街',
            currentAddress: '台北市中山區永綏街',
            status: '追蹤中',
          }
        ],
        companyIp: '123.94.113.90'
      }
    },
    choosen: {
      cardTitle: '顧客選擇方案：綁約專案',
      value: [
        {
          header: '',
          iconClass: '',
          data: [
            {
              title: '未選擇原因',
              content: '顧客未看到報價即跳離 / 顧客看到報價後跳離'
            },
            {
              title: '申貸額度(萬元)',
              content: '40'
            },
            {
              title: '貸款期間(年)',
              content: ' 3'
            },
            {
              title: ' 貸款利率(%)',
              content: ' 9'
            },
            {
              title: '貸款費用(元)',
              content: '6,000'
            },
            {
              title: '每月還款金額(元)',
              content: '5,000'
            },
            {
              title: '綁約期間(年)',
              content: ' 2'
            }
          ]
        },
      ]
    },
    reviewResult: {
      cardTitle: '平台試算結果',
      withContract: {
        header: '綁約專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '9.28%'
          },
          {
            title: '每月還款金額(元)',
            content: '3,000'
          },
          {
            title: '綁約期間(年)',
            content: '20'
          }
        ]
      },
      withoutContract: {
        header: '免綁約專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '10.19%'
          },
          {
            title: '每月還款金額(元)',
            content: '5,000'
          }
        ]
      },
      tag: {
        risk: 3,
        payLevel: '高'
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ],
    customerUpload: {
      description: '共上傳6個檔案，失敗3個',
      files: [
        {
          fileName: '身分證影本.jpg',
          url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
          type: 'image',
          editable: false
        },
        {
          fileName: '申請書.pdf',
          url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
          type: 'pdf',
          editable: false
        }
      ]
    }
  };

  public houseOnlineLoanInfo = {
    amlInfo: {
      cardTitle: 'AML 資訊',
      value: [
        {
          header: '多重國籍',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '第一國籍',
              content: '台灣'
            },
            {
              title: '第二國籍',
              content: '巴伐利亞'
            },
            {
              title: '第三國籍',
              content: '--'
            },
            {
              title: '第四國籍',
              content: '--'
            }
          ]
        },
        {
          header: '政治人物關係',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '與政治人物關係',
              content: '本人與政治人物是家庭成員'
            },
            {
              title: '稱謂',
              content: '女士'
            },
            {
              title: '姓名',
              content: '任盈盈'
            },
            {
              title: '英文姓名',
              content: 'Lian Yin-Yin'
            },
            {
              title: '出生日期',
              content: '69/09/28'
            },
            {
              title: '國籍',
              content: '台灣'
            },
            {
              title: '卸任/在職',
              content: '在職'
            },
            {
              title: '卸任時間',
              content: '--'
            },
            {
              title: '任職職務',
              content: '院長'
            },
            {
              title: '任職國家',
              content: '台灣'
            }
          ]
        }
      ]
    },
    relationship: {
      cardTitle: '同一關係人資料表/有關關係人資料',
      value: [
        {
          header: '本人及二親等親屬',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '稱謂',
              content: '本人'
            },
            {
              title: '姓名',
              content: '令狐沖'
            },
            {
              title: '身分證字號',
              content: 'Y131313131'
            },
            {
              title: '職稱',
              content: '中小企業主'
            }
          ]
        },
        {
          header: '本人或配偶負責之公司',
          iconClass: 'fa-thumb-tack',
          data: [
            {
              title: '負責人',
              content: '令狐沖'
            },
            {
              title: '公司名稱',
              content: '武當派股份有限公司'
            },
            {
              title: '統一編號',
              content: '12348888'
            }
          ]
        }
      ]
    },
    applyInfo: {
      baseInfo: {
        data: [
          {
            title: '姓名',
            content: '令狐沖'
          },
          {
            title: '英文姓名',
            content: 'Lin Hu-Chong'
          },
          {
            title: '身分證字號',
            content: 'A123456789'
          },
          {
            title: '出生日期',
            content: '69/01/03'
          },
          {
            title: '婚姻',
            content: '已婚'
          },
          {
            title: '最高學歷',
            content: '大學'
          },
          {
            title: '子女數',
            content: '3'
          },
          {
            title: '是否有多重國籍',
            content: '是'
          },
          {
            title: '是否為政治人物或與政治人物有關係',
            content: '是'
          }
        ]
      },
      loanInfo: {
        data: [
          {
            title: '案件來源',
            content: '房貸線上申請'
          },
          {
            title: '顧客送出申請日',
            content: '2017/09/13'
          },
          {
            title: '申貸金額',
            content: '50 萬元'
          },
          {
            title: '貸款期間',
            content: '5 年'
          },
          {
            title: '貸款用途',
            content: '個人週轉金'
          },
          {
            title: '認證方式',
            content: '網銀'
          }
        ]
      },
      estate: {
        data: [
          {
            title: '不動產地址 (一)',
            content: '台北市松山區民生東路三段 117 號'
          },
          {
            title: '不動產地址 (二)',
            content: '台北市松山區民生東路三段 117 號'
          },
          {
            title: '不動產地址 (三)',
            content: '台北市松山區民生東路三段 117 號'
          },
          {
            title: '線上申請補充說明',
            content: '有聯徵/無貸款條件'
          }
        ]
      },
      contact: {
        data: [
          {
            title: '行動電話',
            content: '0987654321'
          },
          {
            title: '聯絡E-Mail',
            content: 'yaya3132@gmail.com'
          },
          {
            title: '現住地聯絡電話',
            content: '(02)2715-3132'
          },
          {
            title: '現住房屋',
            content: '自有'
          },
          {
            title: '通訊地址(文件寄送)',
            content: '105 台北市松山區民生東路三段 113 號'
          }
        ]
      },
      career: {
        data: [
          {
            title: '公司名稱',
            content: '大同電鍋'
          },
          {
            title: '公司電話',
            content: '(02)2715-3132'
          },
          {
            title: '職業別',
            content: '一般職員'
          },
          {
            title: '現職年資',
            content: '7年10月'
          },
          {
            title: '年所得',
            content: '100'
          },
          {
            title: '收入來源',
            content: '薪轉存摺'
          }
        ],
        records: [
          {
            applyDate: '2017/08/07',
            name: '汪小名',
            id: 'Q131313131',
            loanAmount: '30 萬',
            companyName: '笑傲江湖',
            companyAddress: '台北市中山區永綏街',
            companyIp: '123.94.113.90',
            status: '追蹤中',
          }
        ],
        texNumber: '11222333'
      },
      marketMark: {
        data: [
          {
            title: '行銷單位',
            content: '新樹分行'
          },
          {
            title: '行銷人員',
            content: '--'
          },
          {
            title: '受理單位',
            content: '新樹分行02)2715-3132'
          },
          {
            title: '名單分派說明',
            content: '依大消金起案經辦：蘇秀惠'
          },
          {
            title: '策略夥伴',
            content: '大潤發'
          },
          {
            title: '推薦人員',
            content: '王大名'
          },
          {
            title: '合作專案',
            content: '策略夥伴專案'
          },
          {
            title: 'IP 位址',
            content: '27.247.64.134'
          }
        ],
        records: [
          {
            applyDate: '2017/08/07',
            name: '汪小名',
            id: 'Q131313131',
            loanAmount: '30 萬',
            companyName: '笑傲江湖',
            companyAddress: '台北市中山區永綏街',
            currentAddress: '台北市中山區永綏街',
            status: '追蹤中',
          }
        ],
        companyIp: '123.94.113.90'
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ],
    customerUpload: {
      description: '共上傳6個檔案，失敗3個',
      files: [
        {
          fileName: '身分證影本.jpg',
          url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
          type: 'image',
          editable: false
        },
        {
          fileName: '申請書.pdf',
          url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
          type: 'pdf',
          editable: false
        }
      ]
    }
  };

  public creditMessageBoardInfo = {
    applyInfo: {
      cardTitle: '基本資料',
      value: [
        {
          header: '',
          iconClass: '',
          data: [
            {
              title: '案件來源',
              content: '信貸網路留言板'
            },
            {
              title: '顧客申請日期',
              content: '2017/10/10'
            },
            {
              title: '申貸金額',
              content: '300'
            },
            {
              title: '貸款用途',
              content: '子女教育'
            },
            {
              title: '姓名',
              content: '陳萌萌'
            },
            {
              title: '身分證字號',
              content: 'A123456789'
            },
            {
              title: '行動電話',
              content: '0944442222'
            },
            {
              title: '公司電話',
              content: '(02)2715-3132'
            },
            {
              title: '現住地聯絡電話',
              content: '(02)2715-3132'
            },
            {
              title: '方便聯絡時間',
              content: '10:00-12:00 AM'
            },
            {
              title: '聯絡 E-mail',
              content: 'yaya3132@gmail.com'
            },
            {
              title: '受理單位',
              content: '-'
            },
            {
              title: '名單分派說明',
              content: '-'
            }
          ]
        }
      ],
      message: '您好，需要增貸 500 萬，請跟我聯絡',
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ]
  };

  public houseMessageBoardInfo = {
    applyInfo: {
      cardTitle: '基本資料',
      value: [
        {
          header: '',
          iconClass: '',
          data: [
            {
              title: '案件來源',
              content: '房貸網路留言板'
            },
            {
              title: '顧客申請日期',
              content: '2017/10/10'
            },
            {
              title: '申貸金額',
              content: '300'
            },
            {
              title: '貸款用途',
              content: '子女教育'
            },
            {
              title: '姓名',
              content: '陳萌萌'
            },
            {
              title: '身分證字號',
              content: 'A123456789'
            },
            {
              title: '行動電話',
              content: '0944442222'
            },
            {
              title: '現住地聯絡電話',
              content: '(02)2715-3132'
            },
            {
              title: '方便聯絡時間',
              content: '10:00-12:00 AM'
            },
            {
              title: '聯絡 E-mail',
              content: 'yaya3132@gmail.com'
            },
            {
              title: '受理單位',
              content: '-'
            },
            {
              title: '名單分派說明',
              content: '-'
            }
          ]
        }
      ],
      message: '您好，需要增貸 500 萬，請跟我聯絡',
      mortgage: '台北市松山區民生東路三段 117 號'
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ]
  };

  public creditRateInfo = {
    applyInfo: {
      cardTitle: '基本資料',
      desc: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '案件來源',
            content: '信貸額度利率評估'
          },
          {
            title: '顧客申請日期',
            content: '2017/09/13'
          },
          {
            title: '方便聯絡時間',
            content: '一、三、五'
          }
        ]
      },
      content: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '申貸金額',
            content: '50 萬元'
          },
          {
            title: '貸款期間',
            content: '5 年/09/13'
          },
          {
            title: '貸款用途',
            content: '個人週轉金'
          },
          {
            title: '認證方式',
            content: '網銀'
          }
        ]
      },
      maintain: {
        header: '行銷注意事項',
        iconClass: 'fa-thumb-tack',
        data: [
          {
            title: '行銷單位',
            content: '新樹分行'
          },
          {
            title: '行銷人員',
            content: '00819 邱淑亞'
          },
          {
            title: '受理單位',
            content: '--'
          },
          {
            title: '名單分派說明',
            content: '--'
          },
          {
            title: '策略夥伴',
            content: '邱淑亞'
          },
          {
            title: '推薦人員',
            content: '王小明'
          },
          {
            title: '合作專案',
            content: '策略夥伴專案'
          },
          {
            title: '客群行銷資訊',
            content: '--'
          },
          {
            title: '薪轉戶註記',
            content: '--'
          },
          {
            title: '本行薪轉月收入(估算)',
            content: '--'
          },
          {
            title: '黑名單註記',
            content: '--'
          }
        ]
      },
      mortgage: '台北市松山區民生東路三段 117 號',
      message: '您好，需要增貸 500 萬，請跟我聯絡',
    },
    survey: {
      cardTitle: '基本資料',
      base: {
        header: '基本資料',
        iconClass: 'fa-info-circle',
        data: [
          {
            title: '姓名',
            content: '王小明'
          },
          {
            title: '身分證字號',
            content: 'A123331178'
          },
          {
            title: '年齡',
            content: '40'
          },
          {
            title: '教育程度',
            content: '大學'
          }
        ]
      },
      contact: {
        header: '通訊資料',
        iconClass: 'fa-address-book-o',
        data: [
          {
            title: '行動電話',
            content: '0987654321'
          },
          {
            title: '聯絡E-Mail',
            content: 'yaya3132@gmail.com'
          },
          {
            title: '通訊電話',
            content: '(02)2715-3132'
          },
          {
            title: '通訊地址',
            content: '105 台北市松山區民生東路三段 113 號'
          },
          {
            title: '戶籍電話',
            content: '(02)2715-3132'
          },
          {
            title: '戶籍地址',
            content: '105 台北市松山區民生東路三段 113 號'
          }
        ]
      },
      career: {
        header: '職業資料',
        iconClass: 'fa-briefcase',
        data: [
          {
            title: '年收入',
            content: '91 萬～ 100 萬元'
          },
          {
            title: '職業別',
            content: '一般職員'
          },
          {
            title: '工作年資',
            content: '3'
          },
          {
            title: '公司/行號名稱',
            content: '大論發'
          },
          {
            title: '公司/行號統編',
            content: '234242'
          },
          {
            title: '成立年資',
            content: '10 年以上 - 未滿 15 年'
          },
          {
            title: '貸款用途',
            content: '週轉金'
          }
        ]
      },
      loanStatus: {
        header: '貸款情形',
        iconClass: 'fa-file-text-o',
        data: [
          {
            title: '名下貸款已繳款期數',
            content: '沒有貸款'
          },
          {
            title: '名下房貸已繳款期數',
            content: '沒有房貸'
          },
          {
            title: '貸款總金額(不含房貸)',
            content: '16 萬～20 萬元'
          },
          {
            title: '貸款餘額(不含房貸)',
            content: '5 萬～10 萬元'
          },
          {
            title: '近一年是否有新增任何貸款',
            content: '否'
          },
          {
            title: '近三個月是否向銀行申辦貸款',
            content: '否'
          },
          {
            title: '近三個月是否有遲繳',
            content: '否'
          }
        ]
      },
      creditStatus: {
        header: '信用卡資訊',
        iconClass: 'fa-file-text-o',
        data: [
          {
            title: '目前持有信用卡家數',
            content: '9'
          },
          {
            title: '使用現況',
            content: '使用一年以上'
          },
          {
            title: '最常使用額度',
            content: '11 萬～15 萬元'
          },
          {
            title: '近一個月信用卡帳單總金額',
            content: '11 萬～15 萬元'
          },
          {
            title: '循環金額',
            content: '無循環金額'
          },
          {
            title: '分期使用狀況',
            content: '無分期'
          }
        ]
      }
    },
    choosen: {
      cardTitle: '顧客選擇方案：綁約專案',
      value: [
        {
          header: '',
          iconClass: '',
          data: [
            {
              title: '貸款方案',
              content: '副擔保方案'
            },
            {
              title: '申請期間(年)',
              content: '20'
            },
            {
              title: '申請額度(萬元)',
              content: '4000'
            },
            {
              title: '貸款利率(%)',
              content: '9'
            },
            {
              title: '優惠專案',
              content: '就4要你好好貸'
            },
            {
              title: '優惠截止日期',
              content: '2018/12/31'
            },
            {
              title: '優惠內容說明',
              content: '優惠內容說明'
            }
          ]
        },
      ]
    },
    calculateResult: {
      cardTitle: '平台試算結果',
      guarantee: {
        header: '副擔保專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '最低利率 9.28% 起'
          },
          {
            title: '無貸款條件說明',
            content: '-'
          }
        ]
      },
      credit: {
        header: '信貸專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '最低利率 9.28% 起'
          },
          {
            title: '無貸款條件說明',
            content: '-'
          }
        ]
      },
      tag: {
        risk: 3
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ],
    customerUpload: {
      description: '共上傳6個檔案，失敗3個',
      files: [
        {
          fileName: '身分證影本.jpg',
          url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
          type: 'image',
          editable: false
        },
        {
          fileName: '申請書.pdf',
          url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
          type: 'pdf',
          editable: false
        }
      ]
    }
  };

  public houseRateInfo = {
    applyInfo: {
      cardTitle: '基本資料',
      desc: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '案件來源',
            content: '房貸額度利率評估'
          },
          {
            title: '顧客申請日期',
            content: '2017/09/13'
          }
        ]
      },
      content: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '申貸金額',
            content: '50 萬元'
          },
          {
            title: '貸款期間',
            content: '5 年/09/13'
          },
          {
            title: '貸款用途',
            content: '個人週轉金'
          },
          {
            title: '認證方式',
            content: '網銀'
          }
        ]
      },
      maintain: {
        header: '行銷注意事項',
        iconClass: 'fa-thumb-tack',
        data: [
          {
            title: '行銷單位',
            content: '新樹分行'
          },
          {
            title: '行銷人員',
            content: '00819 邱淑亞'
          },
          {
            title: '受理單位',
            content: '--'
          },
          {
            title: '名單分派說明',
            content: '--'
          },
          {
            title: '策略夥伴',
            content: '邱淑亞'
          },
          {
            title: '推薦人員',
            content: '邱小亞'
          },
          {
            title: '合作專案',
            content: '策略夥伴專案'
          }
        ]
      },
      mortgage: '台北市松山區民生東路三段 117 號',
      message: '您好，需要增貸 500 萬，請跟我聯絡'
    },
    survey: {
      cardTitle: '基本資料',
      base: {
        header: '基本資料',
        iconClass: 'fa-info-circle',
        data: [
          {
            title: '姓名',
            content: '王小明'
          },
          {
            title: '身分證字號',
            content: 'A123331178'
          },
          {
            title: '年齡',
            content: '40'
          },
          {
            title: '職業別',
            content: '一般職員'
          }
        ]
      },
      contact: {
        header: '通訊資料',
        iconClass: 'fa-address-book-o',
        data: [
          {
            title: '行動電話',
            content: '0987654321'
          },
          {
            title: '聯絡E-Mail',
            content: 'yaya3132@gmail.com'
          }
        ]
      },
      houseInfo: {
        header: '房屋資訊',
        iconClass: 'fa-file-text-o',
        data: [
          {
            title: '貸款需求',
            content: '我想拿既有的房子，來評估轉貸或增貸'
          },
          {
            title: '評估地址',
            content: '--'
          },
          {
            title: '房屋型態',
            content: '大樓'
          },
          {
            title: '總樓層',
            content: '20'
          },
          {
            title: '所在樓層',
            content: '1'
          },
          {
            title: '房屋坪數(不含車位)',
            content: '30'
          },
          {
            title: '屋齡',
            content: '30'
          },
          {
            title: '是否有車位',
            content: '是'
          }
        ]
      },
      houseInfoMore: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '平面車位數',
            content: '10'
          },
          {
            title: '機械車位數',
            content: '30'
          },
          {
            title: '成交總價(萬元)',
            content: '4000'
          },
          {
            title: '房屋是否貸款中',
            content: '是'
          },
          {
            title: '房貸貸款總額度(萬元)',
            content: '4000'
          },
          {
            title: '房屋貸款總現欠金額(萬元)',
            content: '3000'
          },
          {
            title: '高總價註記',
            content: '是'
          }
        ]
      },
    },
    choosen: {
      cardTitle: '顧客選擇方案：綁約專案',
      value: [
        {
          header: '',
          iconClass: '',
          data: [
            {
              title: '貸款方案',
              content: '副擔保方案'
            },
            {
              title: '申請期間(年)',
              content: '20'
            },
            {
              title: '申請額度(萬元)',
              content: '4000'
            },
            {
              title: '貸款利率(%)',
              content: '9'
            },
            {
              title: '優惠專案',
              content: '就4要你好好貸'
            },
            {
              title: '優惠截止日期',
              content: '2018/12/31'
            },
            {
              title: '優惠內容說明',
              content: '優惠內容說明'
            }
          ]
        },
      ]
    },
    calculateResult: {
      cardTitle: '平台試算結果',
      guarantee: {
        header: '副擔保專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '最低利率 9.28% 起'
          },
          {
            title: '線上估價金額(萬元)',
            content: '300'
          },
          {
            title: '無貸款條件說明',
            content: '--'
          }
        ]
      },
      credit: {
        header: '信貸專案',
        iconClass: '',
        data: [
          {
            title: '最高可申貸額度',
            content: 'NTD 80 萬'
          },
          {
            title: '貸款期間',
            content: '5年'
          },
          {
            title: '貸款費用',
            content: 'NTD 6,000'
          },
          {
            title: '貸款利率(%)',
            content: '最低利率 9.28% 起'
          },
          {
            title: '線上估價金額(萬元)',
            content: '300'
          },
          {
            title: '無貸款條件說明',
            content: '--'
          }
        ]
      },
      tag: {
        risk: 3
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ],
    customerUpload: {
      description: '共上傳6個檔案，失敗3個',
      files: [
        {
          fileName: '身分證影本.jpg',
          url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
          type: 'image',
          editable: false
        },
        {
          fileName: '申請書.pdf',
          url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
          type: 'pdf',
          editable: false
        }
      ]
    }
  };

  public transInfo = {
    nameInfo: {
      cardTitle: '名單資訊',
      info: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '轉介產品',
            content: '副擔保'
          },
          {
            title: '轉介人員',
            content: '012345 陳大壕'
          },
          {
            title: '聯繫用電話',
            content: '0933113442'
          },
          {
            title: '備註',
            content: '精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月'
          }
        ]
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ]
  };

  public ebmInfo = {
    nameInfo: {
      cardTitle: '名單資訊',
      info: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '行銷活動名稱',
            content: '精采稅月'
          },
          {
            title: '活動開始日期',
            content: '2017/09/13'
          },
          {
            title: '活動結束日期',
            content: '2017/09/13'
          },
          {
            title: '主要推薦商品',
            content: '純信'
          },
          {
            title: '類別',
            content: '信貸舊貸'
          }
        ]
      },
      infoMore: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '條件',
            content: '50000_4.88%_6000'
          },
          {
            title: '備註',
            content: '本行薪轉戶/有卡循/他行借貸_國泰'
          },
          {
            title: '備註',
            content: '精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月精采稅月'
          }
        ]
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ]
  };

  public boDetail = {
    status: [
      {
        title: '狀態類別',
        content: '未執行',
      },
      {
        title: '狀態細項',
        content: '無',
      },
      {
        title: '細項類別',
        content: '無',
      },
    ],
    pointNote: `果別說手時充上清方歡至直離源機。 不了國樓上型親有作女今了人果別說手時充上清方歡至直離源機。
                不 了國樓上型親有作女今了人果別說手時充上清方歡至直離源機。不了果別說手時充上清方歡至直離源機。
                不了國樓上型親有作樓上型親有作女今了人果別說手時充上清方歡至直離源機。不了國樓 上型親有作女今了人果別說手時充上清方歡至直離源機。
                不了樓上型親有作女今了人果 上型親有作女今了人國樓 上型親有作女今了人`,
    schedule: {
      revisitDate: '2018/03/04',
      revisitTime: '09:29',
      subject: '主旨',
      address: '地址',
      tel: '0911203331',
      note: 'nothing',
    },
    note: {
      time: '2018/02/03',
      content: '更改公司名稱為「陳美科技有限公司」'
    }
  };

  public boHeadCaseDetail = {
    header: '日本東京來回機票資格審核名單',
    creator: '陳先生',
    type: '貸後追蹤・新聞事件・其他',
    replyDate: '2018/01/07',
    content: `急里為精實動較一小夜心所主分遠出條快展在處住要們種一城海馬再正品利動候子天
              人看一回這士反內之建：有兒！會不響品前有現水得面常。喜了說校，人得東自……
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。
              依說成果、小考士明票的。依說成果、小考士明票的。依說成果、小考士明票的。`,
    attachedFiles: [
      {
        link: '',
        title: '日本東京機票'
      },
      {
        link: '',
        title: '日本大阪機票'
      }
    ],
    boHeadCaseList: [
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'reject'
        },
        acct: '陳先生',
        id: '1',
        uniqueId: 'A111111',
        handler: '理大吉',
        creator: '陳先生',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      },
      {
        status: {
          text: '追蹤中',
          light: 'red',
          process: 'none'
        },
        acct: '陳小姐',
        id: '2',
        uniqueId: 'A11133333',
        handler: '理小吉',
        creator: '陳小姐',
        subRow: {
          data: [
            {
              date: '2012/09/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/10/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            },
            {
              date: '2012/11/12',
              note: '行銷顧客精彩歲月專案，顧客表達高度興趣，預計 2018/01/27 再度拜訪'
            }
          ]
        },
      }
    ]
  };

  public selfCreateInfo = {
    nameInfo: {
      cardTitle: '名單資訊',
      info: {
        header: '',
        iconClass: '',
        data: [
          {
            title: '產品別',
            content: '信貸'
          },
          {
            title: '來源說明',
            content: '主動進線'
          },
          {
            title: '介紹人姓名',
            content: '林XX'
          },
          {
            title: '介紹人統一編號',
            content: ''
          },
          {
            title: '類別',
            content: '信貸舊貸'
          }
        ],
        note: '本行薪轉戶/有卡循/他行借貸_國泰'
      }
    },
    uploadedFiles: [
      {
        fileName: '圖片.jpg',
        fileTag: 1,
        url: 'http://2.bp.blogspot.com/-iNh65hz8taI/VCaXzujeRSI/AAAAAAAAHo0/qM1ixClWXqA/s1600/8.jpg',
        type: 'image',
        editable: true
      },
      {
        fileName: '申請書.pdf',
        fileTag: 2,
        url: 'https://vadimdez.github.io/ng2-pdf-viewer/pdf-test.pdf',
        type: 'pdf',
        editable: true
      }
    ]
  };

  public boGroupData = [
    {
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        backTooltip: '待主管覆核'
      },
      uniqueId: 'A128940182',
      acct: '陳先生',
      prod: '房貸',
      source: '網路進件',
      type: '網路留言板',
      hasNote: false,
      id: 1
    },
    {
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        backTooltip: '待主管覆核'
      },
      uniqueId: 'A128940183',
      acct: '陳先生',
      prod: '房貸',
      source: '網路進件',
      type: '網路留言板',
      hasNote: true,
      id: 2
    },
    {
      status: {
        light: 'red',
        text: '追蹤中',
        process: 'wait',
        backTooltip: '待主管覆核'
      },
      uniqueId: 'A128940184',
      acct: '陳先生',
      prod: '房貸',
      source: '網路進件',
      type: '網路留言板',
      hasNote: false,
      id: 3
    }
  ];

  public normalLoanProcessTableData: any[] = [
    {
      favorite: true,
      status: { // 名單狀態
        // light: 'red',
        text: '覆審經辦已撥款',
        // process: 'wait',
        // frontTooltip: '追蹤逾期',
        // backTooltip: '待主管審核',
      },
      activeDate: '107/02/10', // 分派/建立日期
      uniqueId: 'A128940184', // 統一編號
      acct: '陳先生', // 戶名
      id: '1',
      prod: '房貸', // 產品 (房貸、信貸、小型企業(SB))
      department: '01234 板橋分行', // 行銷單位 (單位代碼+單位名稱)
      operator: '13131 王小明', // 行銷人員 (員編+姓名)
      source: 'EBM', // 名單來源 (EBM、網路進件、系統轉介、自建名單)
      type: '精彩稅月', // 名單類型
      action: {
        link: '1', // 同id
        // menus: [
        //   'searchBankAcct', // 調閱行內帳務資料
        //   'createBo', // 新增自建名單
        //   'createSchedule', // 新增行程
        //   'uploadFile', // 上傳文件
        //   // 'rejectToHeadOffice', // 退回總行
        //   'searchGroup', // 查找群組名單
        // ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust', // cust: 個人 comp: 公司
      grantEndDate: '2018/01/02', // 撥款日期
      deliveryDate: '2018/02/02', // 送件日期
      checkCreditClerk: '陳曉東', // 審核經辦
      approvalAmount: '10,000 元', // 核准金額
    },
    {
      favorite: true,
      status: { // 名單狀態
        // light: 'red',
        text: '覆審經辦已撥款',
        // process: 'wait',
        // frontTooltip: '追蹤逾期',
        // backTooltip: '待主管審核',
      },
      activeDate: '107/02/10', // 分派/建立日期
      uniqueId: 'A128940184', // 統一編號
      acct: '陳先生', // 戶名
      id: '2',
      prod: '房貸', // 產品 (房貸、信貸、小型企業(SB))
      department: '01234 板橋分行', // 行銷單位 (單位代碼+單位名稱)
      operator: '13131 王小明', // 行銷人員 (員編+姓名)
      source: 'EBM', // 名單來源 (EBM、網路進件、系統轉介、自建名單)
      type: '精彩稅月', // 名單類型
      action: {
        link: '2', // 同id
        // menus: [
        //   'searchBankAcct', // 調閱行內帳務資料
        //   'createBo', // 新增自建名單
        //   'createSchedule', // 新增行程
        //   'uploadFile', // 上傳文件
        //   // 'rejectToHeadOffice', // 退回總行
        //   'searchGroup', // 查找群組名單
        // ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust', // cust: 個人 comp: 公司
      grantEndDate: '2018/01/02', // 撥款日期
      deliveryDate: '2018/02/02', // 送件日期
      checkCreditClerk: '陳曉東', // 審核經辦
      approvalAmount: '10,000 元', // 核准金額
    },
    {
      favorite: false,
      status: { // 名單狀態
        // light: 'red',
        text: '覆審經辦已撥款',
        // process: 'wait',
        // frontTooltip: '追蹤逾期',
        // backTooltip: '待主管審核',
      },
      activeDate: '107/02/10', // 分派/建立日期
      uniqueId: 'A128940184', // 統一編號
      acct: '陳先生', // 戶名
      id: '3',
      prod: '信貸', // 產品 (房貸、信貸、小型企業(SB))
      department: '01234 板橋分行', // 行銷單位 (單位代碼+單位名稱)
      operator: '13131 王小明', // 行銷人員 (員編+姓名)
      source: '自建名單', // 名單來源 (EBM、網路進件、系統轉介、自建名單)
      type: '', // 名單類型
      action: {
        link: '3', // 同id
        // menus: [
        //   'searchBankAcct', // 調閱行內帳務資料
        //   'createBo', // 新增自建名單
        //   'createSchedule', // 新增行程
        //   'uploadFile', // 上傳文件
        //   // 'rejectToHeadOffice', // 退回總行
        //   'searchGroup', // 查找群組名單
        // ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust', // cust: 個人 comp: 公司
      grantEndDate: '2018/01/02', // 撥款日期
      deliveryDate: '2018/02/02', // 送件日期
      checkCreditClerk: '陳曉東', // 審核經辦
      approvalAmount: '10,000 元', // 核准金額
    },
    {
      favorite: true,
      status: { // 名單狀態
        // light: 'red',
        text: '覆審經辦已撥款',
        // process: 'wait',
        // frontTooltip: '追蹤逾期',
        // backTooltip: '待主管審核',
      },
      activeDate: '107/02/10', // 分派/建立日期
      uniqueId: '97296986', // 統一編號
      acct: '陳先生股份有限公司', // 戶名
      id: '4',
      prod: '小型企業(SB)', // 產品 (房貸、信貸、小型企業(SB))
      department: '01234 板橋分行', // 行銷單位 (單位代碼+單位名稱)
      operator: '13131 王小明', // 行銷人員 (員編+姓名)
      source: '網路進件', // 名單來源 (EBM、網路進件、系統轉介、自建名單)
      type: '額度利率評估-信貸', // 名單類型
      action: {
        link: '4', // 同id
        // menus: [
        //   'searchBankAcct', // 調閱行內帳務資料
        //   'createBo', // 新增自建名單
        //   'createSchedule', // 新增行程
        //   'uploadFile', // 上傳文件
        //   // 'rejectToHeadOffice', // 退回總行
        //   'searchGroup', // 查找群組名單
        // ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust', // cust: 個人 comp: 公司
      grantEndDate: '2018/01/02', // 撥款日期
      deliveryDate: '2018/02/02', // 送件日期
      checkCreditClerk: '陳曉東', // 審核經辦
      approvalAmount: '10,000 元', // 核准金額
    },
    {
      favorite: false,
      status: { // 名單狀態
        // light: 'red',
        text: '覆審經辦已撥款',
        // process: 'wait',
        // frontTooltip: '追蹤逾期',
        // backTooltip: '待主管審核',
      },
      activeDate: '107/02/10', // 分派/建立日期
      uniqueId: 'A128940184', // 統一編號
      acct: '陳先生', // 戶名
      id: '5',
      prod: '房貸', // 產品 (房貸、信貸、小型企業(SB))
      department: '01234 板橋分行', // 行銷單位 (單位代碼+單位名稱)
      operator: '13131 王小明', // 行銷人員 (員編+姓名)
      source: '系統轉介', // 名單來源 (EBM、網路進件、系統轉介、自建名單)
      type: '保險(儲蓄險、房貸壽險)', // 名單類型
      action: {
        link: '5', // 同id
        // menus: [
        //   'searchBankAcct', // 調閱行內帳務資料
        //   'createBo', // 新增自建名單
        //   'createSchedule', // 新增行程
        //   'uploadFile', // 上傳文件
        //   // 'rejectToHeadOffice', // 退回總行
        //   'searchGroup', // 查找群組名單
        // ]
      },
      activity: '潛力副擔保專案',
      mainProd: '幸福加倍貸',
      priority: '1',
      contactType: '事件式行銷',
      firstVisitDate: '2018/01/07',
      activityStartDate: '2018/01/07',
      activityEndDate: '2018/01/07',
      revisitTime: '09:29',
      clientType: 'cust', // cust: 個人 comp: 公司
      grantEndDate: '2018/01/02', // 撥款日期
      deliveryDate: '2018/02/02', // 送件日期
      checkCreditClerk: '陳曉東', // 審核經辦
      approvalAmount: '10,000 元', // 核准金額
    },
  ];

  public updateTrigger: Observable<any>;
  private updateTriggerEvent = new Subject<any>();

  private WFObjectName = 'BOL';
  constructor(
    private api: ApiService,
    private auth: AuthService,
    private response: BolResponseService
  ) {
    this.updateTrigger = this.updateTriggerEvent.asObservable();
  }

  public getMkPersonWorkStatus(): Observable<any> {
    return this.api.get('BOL/MkPersonWorkStatus').pipe( map( data => {
      if (data.isOk) {
        return data.value.map( (el: MkPersonWorkStatusResponseDto): MkPersonWorkStatusDto => {
          return {
            marketingPerson: el.MarketingPerson,
            marketingPersonName: el.MarketingPersonName,
            todayAssignedCount: el.TodayAssignedCount,
            todayLimit: el.TodayLimit,
            netRate: el.NetRate,
            netRateBarValue: this.mapBarValue(el.NetRate),
            netTodo: el.NetTodo,
            netDoing: el.NetDoing,
            ebmRate: el.EbmRate,
            ebmRateBarValue: this.mapBarValue(el.EbmRate),
            ebmTodo: el.EbmTodo,
            ebmDoing: el.EbmDoing,
            referralRate: el.ReferralRate,
            referralRateBarValue: this.mapBarValue(el.ReferralRate),
            referralTodo: el.ReferralTodo,
            referralDoing: el.ReferralDoing,
            progressData: this.mapMarketingPersonProgressData(el)
          };
        });
      }
    }));
  }

  public getBOLAttachments(bolNo): Observable<any> {
    return this.api.get(`BOLFile/${bolNo}`);
  }

  public updateBOLAttachments(params): Observable<any> {
    let data = _.assign({ loginUser: this.auth.getLoginUser()}, params);
    return this.api.patch('BOLFile', data);
  }

  public deleteBOLAttachments(uuid): Observable<any> {
    return this.api.delete(`BOLFile/${uuid}`);
  }

  public updatePotentialCustomer(params): Observable<any> {
    let data = _.assign({ loginUser: this.auth.getLoginUser()}, params);
    return this.api.patch('PotentialCustomer', data);
  }

  public triggerBOLUpdate(value) {
    this.updateTriggerEvent.next(value);
  }

  public getWFObjectName(): string {
    return this.WFObjectName;
  }

  public query(config: BOLNormalCaseSearchParams, searchAction: BOLSearchAction = BOLSearchAction.NORMAL_SEARCH ): Observable<BOLNormalCaseTableRowDto[]> {
    let queryConfig = _.assign(config,
      {
        loginUser: this.auth.getLoginUser(),
        searchAction: searchAction
      }
    );
    return this.api.post('BOL/search', queryConfig).pipe(map( data => {
      if (data.isOk && data.value) {
        return data.value.map( (el: BOLNormalCaseResponseDto) => {
          return this.response.mapToNormalCaseTableRow(el);
        });
      }
    }));
  }

  public queryHeadOffice(config, searchAction: BOLSearchAction = BOLSearchAction.NORMAL_SEARCH ): Observable<BOLHeadofficeCaseTableRowDto[]> {
    let queryConfig = _.assign(config,
      {
        loginUser: this.auth.getLoginUser(),
        searchAction: searchAction
      }
    );
    return this.api.post('HeadOfficeCase/search', queryConfig).pipe(map( data => {
      if (data.isOk && data.value) {
        return data.value.map( (el: BOLHeadofficeCaseResponseDto) => {
          return this.response.mapToHeadofficeCaseTableRow(el);
        });
      }
    }));
  }

  public queryLoanDelivery(searchParams): Observable<any> {
    return this.api.post('BOL/LoanDelivery', searchParams).pipe(map( data => {
      return data.value.map( (el: LoanDeliveryResponseDto): LoanDeliveryTableRowDto => {
        return this.response.mapToLoanDeliveryTableRow(el);
      });
    }));
  }

  public addFavorite(bolNo): Observable<any>{
    let config = {
      bolNo: bolNo,
      loginUser: this.auth.getLoginUser()
    };
    return this.api.post('MyFavorite', config);
  }

  public deletFavorite(bolNo): Observable<any>{
    let config = {
      bolNo: bolNo,
      loginUser: this.auth.getLoginUser()
    };
    return this.api.delete('MyFavorite', config);
  }

  public queryFavorite(config): Observable<any> {
    let queryConfig = _.assign(config,
      {
        loginUser: this.auth.getLoginUser()
      }
    );

    return this.api.post('MyFavorite/Search', queryConfig).pipe(map( data => {
      if (data.isOk && data.value) {
        return data.value.map( (el: BOLNormalCaseResponseDto) => {
          return this.response.mapToNormalCaseTableRow(el);
        });
      }
    }));
  }

  public queryTodaySchedule(body): Observable<any> {
    return this.api.post('Visit/Today', body).pipe( map(
      data => {
        return data.value.map( (el: BOLNormalCaseVisitResponsDto) => {
          return this.response.mapToNormalCaseVisitTableRow(el);
        });
      }
    ));
  }

  public getCustomerBol(circiKey): Observable<any> {
    return this.api.get(`BOL/Customer/${circiKey}`)
            .pipe( map( data => {
                if (data.isOk) {
                  return data.value.map( el => this.mapToBOLOptions(el));
                }
              }
            ));
  }

  public getMarketingPersonAllBOL(): Observable<any> {
    return this.api.get(`BOL/MarketingPerson/${this.auth.getLoginUser().loginEmpId}`)
            .pipe( map( data => {
                  if (data.isOk) {
                    return data.value.map( el => this.mapToBOLOptions(el));
                  }
                }
            ));
  }

  public getBolDuplicate(bolNo): Observable<any> {
    return this.api.get(`BOL/${bolNo}/Duplicate`).pipe( map( data => {
      return data.value.map(el => this.response.mapToNormalCaseDuplicateTableRow(el));
    }));
  }

  public setMainBOL(body: {BOLNo: string, isTransferOldPointAbstract: boolean, mainBOLUUID: string}): Observable<any> {
    return this.api.patch(`BOL/MainBOL`, body);
  }

  public getHeadCaseDetail(UUID): Observable<any> {
    return this.api.get(`HeadOfficeCase/${UUID}`);
  }

  public updateHeadOfficeCase(props): Observable<any> {
    let body = _.assign({
      LoginUser: this.auth.getLoginUser()
    }, props);
    return this.api.patch('HeadOfficeCase', body);
  }

  public getBoDetail(bolNo): Observable<any> {
    return this.api.get(`BOL/${bolNo}`);
  }

  public selfCreateBOL(data): Observable<any> {
    return this.api.post('BOL/SelfBuiltBOL', data);
  }

  public createBOLRemark(data) {
    let body = _.assign({
      loginUser: this.auth.getLoginUser()
    }, data);
    return this.api.post('BOL/MarketingLogRemark', body);
  }

  public updatePointAbstract(data): Observable<any> {
    let body = _.assign({
      loginUser: this.auth.getLoginUser()
    }, data);
    return this.api.patch(`BOL/PointAbstract`, body);
  }

  public updateBOLStatus(data): Observable<any> {
    let body = _.assign({
      loginUser: this.auth.getLoginUser()
    }, data);
    return this.api.patch(`BOL`, body);
  }

  public assignBOL(data): Observable<any> {
    let body = _.assign({
      loginUser: this.auth.getLoginUser()
    }, data);
    return this.api.patch(`BOL/allocation`, body);
  }

  public returnBOLToHeadOffice(data: any): Observable<any> {
    return this.api.post(`BOL/BackToHeadOffice`, data);
  }

  public reviewBOL(data: any): Observable<any> {
    let body = _.assign({
      ActionEmp: this.auth.getLoginUser()
    }, data);
    return this.api.post(`BOL/CheckinWF`, body);
  }

  public checkoutBOLWF(data): Observable<any> {
    let body = _.assign({
      ActionEmp: this.auth.getLoginUser()
    }, data);
    return this.api.post(`BOL/CheckoutWF`, body);
  }

  public cancelCheckoutBOLWF(data): Observable<any> {
    let body = _.assign({
      ActionEmp: this.auth.getLoginUser()
    }, data);
    return this.api.post(`BOL/CancelCheckoutWF`, body);
  }

  private mapToBOLOptions(data: any): ISelectOptionModel {
    return {
      value: data['BOLNo'],
      label: `${data['BOLType']} - ${data['BOLSource']} - ${data['CustomerName']}`,
    };
  }

  private mapBarValue(value: number): string {
    if (value < 1) {
      return value*100 + '%';
    } else {
      return value + '%';
    }
  }

  private mapMarketingPersonProgressData(toMap: MkPersonWorkStatusResponseDto): {value: number}[] {
    return [
      { value: toMap.TodayAssignedCount || 0 },
      { value: toMap.TodayLimit || 0 - toMap.TodayAssignedCount || 0 }
    ];
  }
}
