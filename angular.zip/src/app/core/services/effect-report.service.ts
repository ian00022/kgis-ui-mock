import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ApiService } from './api.service';
import { EffectReportSearchParams, EffectReportExecuteResponseDto, EffectReportExecuteTableDataDto } from './../../effect-report/effect-report.model';
import { BolResponseService } from '../../business-opportunity/bol-response.service';
import { EffectReportDetailResponseDto, EffectReportDetailTableDataDto } from '../../effect-report/effect-report.model';

@Injectable()
export class EffectReportService {
  /**
   * executeTableHeader
   *
   * @memberof EffectReportService
   */
  public executeTableHeader = {
    marketingUnitName: '單位代碼/單位',
    marketingPersonName: '行銷經辦',
    caseSourceName: '名單來源',
    BOLTypeName: '名單類型',
    productName: '產品別',
    BOLTotalCount: '名單數',
    BOLAcceptCount: '執行數',
    BOLAcceptPercentage: '執行率',
    BOLProcessCount: '送件數',
    BOLProcessPercentage: '送件率',
    applicationApprovedCount: '核貸數',
    approvedPercentage: '核貸率',
    applicationApprovedAmount: '核貸金額',
  };

  /**
   * detailTableHeader
   *
   * @memberof EffectReportService
   */
  public detailTableHeader = {
    createDate: '名單日期',
    assignedDate: '分派日期',
    caseSourceName: '名單來源',
    BOLTypeName: '名單類型',
    productName: '產品別',
    referralEmpId: '行銷經辦',
    sourceReferralEmpId: '轉介經辦',
    handleDate: '處理天數',
    BOLStatus: '名單狀態',
    dulpicateGroup: '重覆商機群組',
    auditResult: '審核結果',
    applicationApprovedAmount: '核貸金額'
  };

  constructor(
    private api: ApiService,
    private bolResponse: BolResponseService
  ) { }

  /**
   * 查詢名單執行成效
   *
   * @param {EffectReportSearchParams} config
   * @returns {Observable<any>}
   * @memberof EffectReportService
   */
  public queryExecute(config: EffectReportSearchParams): Observable<any> {
    return this.api.post('BOLReport/Grouping', config)
    .pipe(
      map( resp => {
        return resp.value.map((el: EffectReportExecuteResponseDto): EffectReportExecuteTableDataDto => {
          return {
            marketingPersonName: el.MarketingPersonName,
            marketingUnitName: el.MarketingUnitName,
            marketingUnit: el.MarketingUnit,
            caseSourceName: el.CaseSourceName,
            BOLTypeName: el.BOLTypeName,
            productName: el.ProductName,
            BOLTotalCount: el.BOLTotalCount,
            BOLProcessCount: el.BOLProcessCount,
            BOLProcessPercentage: el.BOLProcessPercentage,
            BOLAcceptCount: el.BOLAcceptCount,
            BOLAcceptPercentage: el.BOLAcceptPercentage,
            applicationApprovedCount: el.ApplicationApprovedCount,
            approvedPercentage: el.ApprovedPercentage,
            applicationApprovedAmount: el.ApplicationApprovedAmount,
          }
        });
      })
    );
  }

  /**
   * 查詢名單執行明細
   *
   * @param {EffectReportSearchParams} config
   * @returns {Observable<any>}
   * @memberof EffectReportService
   */
  public queryDetail(config: EffectReportSearchParams): Observable<any> {
    return this.api.post('BOLReport', config)
    .pipe(
      map( resp => {
        return resp.value.map((el: EffectReportDetailResponseDto): EffectReportDetailTableDataDto => {
          return {
            createDate: el.CreateDate,
            assignedDate: el.AssignedDate,
            caseSourceName: el.CaseSourceName,
            BOLTypeName: el.BOLTypeName,
            productName: el.ProductName,
            identityCardNo: el.IdentityCardNo,
            customerName: el.CustomerName,
            referralEmpId: el.ReferralEmpId,
            sourceReferralEmpId: el.SourceReferralEmpId,
            handleDate: el.HandleDate,
            BOLStatus: el.BOLStatus,
            mainBOLUUID: el.MainBOLUUID,
            auditResult: el.AuditResult,
            applicationApprovedAmount: el.ApplicationApprovedAmount,
            customerLink: this.mapLink(el)
          };
        });
      })
    );

  }

  /**
   * get executeTable header for excel file
   *
   * @returns
   * @memberof EffectReportService
   */
  public getExecuteTableHeader(): any {
    return _.cloneDeep(this.executeTableHeader);
  }

  /**
   * get DetailTable header for excel file
   *
   * @returns {*}
   * @memberof EffectReportService
   */
  public getDetailTableHeader(): any {
    return _.cloneDeep(this.detailTableHeader);
  }

  /**
   * map customer link
   *
   * @private
   * @param {*} obj
   * @returns {Array<string>}
   * @memberof EffectReportService
   */
  private mapLink(obj: EffectReportDetailResponseDto): Array<string> {
    if (obj.IdentityCardNo.length === 8) {
      // 判斷為公司戶
      return ['/clients', 'client', obj.IdentityCardNo, 'comp-overview'];

    } else if (obj.IdentityCardNo.length === 10 ) {
      // 判斷為個人戶
      return ['/clients', 'client', obj.IdentityCardNo,  'cust-overview'];
    }
    return [];
  }
}
