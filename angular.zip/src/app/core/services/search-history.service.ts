import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchHistoryService {

  private historys: { [key: string]: any };

  constructor() {
    this.historys = {};
  }

  public storeHistory(key: string, value: any) {
    this.historys[key] = value;
  }

  public getHistoryOf(key: string) {
    return this.historys[key];
  }

  public getAllHistory(): any {
    return this.historys;
  }

}
