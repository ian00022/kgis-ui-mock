import { BaseListConfig } from './base-list-config';
export interface BoListConfig extends BaseListConfig {
  favorite?: boolean;
  filters: {
    status?: string[],
    source?: string[],
    uniqueId?: string,
    activeDate?: string,
    number?: string,
    subject?: string,
    bulider?: string,
    dateType?: string,
  };
}
