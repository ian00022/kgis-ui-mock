import * as _ from 'lodash';

export interface BaseResponseDto {
  /**
   * 建立日期
   */
  CreateDate: string;
  /**
   * 建立者
   */
  CreateEmpId: string;
  /**
   * 更新日期
   */
  UpdateDate: string;
  /**
   * 更新者
   */
  UpdateEmpId: string;
}

export interface MenuItem {
  id: number;
  url: string;
  text: string;
  permissions?: string[];
  collapsed?: boolean;
  children?: MenuItem[];
}

export interface ClientDetail {
  // customerType: ClientType;
  customerAttribute: ClientType;
  name: string;
  phone: string;
  email: string;
  address: string;
  gender?: string;
  circiKey?: string;
  birthday?: string;
  marriage?: string;
  career?: string;
  principleName?: string;
  companyAddr?: string;
  age? : string;
  chips?: ClientDetailChips;
  companyInfo360Block?: any;
  personalInfo360Block?: any;
  identitysBlock: any;
  marketingAlertBlock: any;
}

export interface ClientDetailChips {
  dm: {
    title: string;
    enable: boolean;
  };
  email: {
    title: string;
    enable: boolean;
  };
  phone: {
    title: string;
    enable: boolean;
  };
  sms: {
    title: string;
    enable: boolean;
  };
  collectData: {
    title: string;
    enable: boolean;
  };
  useData: {
    title: string;
    enable: boolean;
  };
}

export interface CardItem {
  title: string;
  text: string;
  editable?: boolean;
}

export enum ChartSwitchMode {
  ASSET = 'asset',
  LIABILITY = 'liability'
}

export interface ContentRowModel {
  title: string;
  content: string | Array<string>;
  contentType?: string;
}

export enum ClientType {
  CUST = '1',
  COMP = '2',
  POTENTIAL = '3'
}

export interface ISelectOptionModel {
  value: any;
  label: string;
}

export interface IEmployee {
  empId: string;
  empName: string;
}

export interface IBranch {
  branchCode: string;
  branchName: string;
}

export interface WFStatus {
  Action: WFAction;
  ActionLog: string;
}

export enum WFAction {
  WAITAPPROVE = 'WaitForApproval',
  REJECT = 'Rejected',
  APPROVE = 'Approved'
}

export interface BaseSearchParams {
  pf: {
    skip: number,
    take: number
  };
  orderCol?: string;
}

export interface DateRange {
  startTime: string;
  endTime: string;
}

export interface VacationAgentResponseDto {
  /// 休假代理編號
  UUID: string;

  /// 請假起始日
  VacationStartDate: string;

  /// 請假起始時間
  VacationStartTime: string;

  /// 請假結束日
  VacationEndDate: string;

  /// 請假結束時間
  VacationEndTime: string;

  /// 代理人員工編號
  AgentEmpId: string;

  /// 代理人員工姓名
  AgentEmpName: string;
}

export interface VacationAgentDto {
  /// 休假代理編號
  UUID: string;

  /// 請假起始日
  vacationStartDate: string;

  /// 請假起始時間
  vacationStartTime: string;

  /// 請假結束日
  vacationEndDate: string;

  /// 請假結束時間
  vacationEndTime: string;

  /// 代理人員工編號
  agentEmpId: string;

  /// 代理人員工姓名
  agentEmpName: string;
}

// export enum Prod {
//   CREDIT = '1',         // 信貸
//   GUARANTEE = '2',      // 副擔保
//   HOUSE = '3',          // 房貸
//   SB = '4',             // 小型事業 (SB)
//   CARD = '5',           // 卡友貸
//   INSURENCE = '6',      // 保險(儲蓄險、房貸壽險)
// }

// 轉介產品
export enum ReferralProd {
  SB = '1',             // 小型事業 (SB)
  GUARANTEE = '2',      // 副擔保
  HOUSE = '3',          // 房貸
  CREDIT = '4',         // 信貸
  INSURENCE = '5',      // 保險(儲蓄險、房貸壽險)
  CARD = '6',           // 卡友貸
  COMPANYCREDIT = '7',  // 法金-授信
  TMU = '8',            // 法金-TMU曝險額度
  FOREIGNEXCHANGE = '9',// 法金-外匯
  OTHERINSURENCE = '10',// 其他保險(非儲蓄險、非房貸壽險)
  FUND = '11',           // 基金(含ETF、海外債等)
  TWDEP = '12',          // 台幣存款
  FORDEP = '13',        // 外幣存款
  GOLDDEP = '14',       // 黃金存摺
  SECURITIES = '15',    // 玉證連結
  OTHER = '16'          // 其他
}

export class ProductHelper {
  public static ProductLabelMap = {
    '4': '信貸',
    '2': '副擔保',
    '3': '房貸',
    '1': '小型事業貸款(SB)',
    '6': '卡友貸',
    '5': '保險(儲蓄險、房貸壽險)',
    '7': '法金-授信',
    '8': '法金-TMU曝險額度',
    '9': '法金-外匯',
    '10': '其他保險(非儲蓄險、非房貸壽險)',
    '11': '基金(含ETF、海外債等)',
    '12': '台幣存款',
    '13': '外幣存款',
    '14': '黃金存摺',
    '15': '玉證連結',
    '16': '其他',
  };

  public static CodeEnum = ReferralProd;
  public static mapTo(key: ReferralProd): string {
    return this.ProductLabelMap[key];
  }
  public static getOptionsOf(values: string[], order?: string) {
    return this.sortOptions(Object.keys(this.ProductLabelMap).filter(
      (k: string) => _.includes(values, k)
    ).map( (k) => {
      return { value: k, label: this.ProductLabelMap[k] };
    }), order);
  }
  public static getAllOptions(order?: string) {
    return this.sortOptions(Object.keys(this.ProductLabelMap).map( (k) => {
      return { value: k, label: this.ProductLabelMap[k] };
    }), order);
  }

  private static sortOptions(options: any[], order?: string): any[] {
    if (order && order.toLocaleLowerCase() === 'asc') {
      return options.sort((a, b) => a.value - b.value);
    }
    return _.orderBy(options, (o) => {
      return this.optionOrder(o.value);
    });
  }

  private static optionOrder(key: string): number {
    const optionOrderMap = {
      '4': 1,
      '2': 2,
      '3': 3,
      '1': 4,
      '6': 5,
      '5': 6,
      '7': 7,
      '8': 8,
      '9': 9,
      '10': 10,
      '11': 11,
      '12': 12,
      '13': 13,
      '14': 14,
      '15': 15,
      '16': 16,
    };
    return optionOrderMap[key];
  }
}


// 來源說明
export enum SourceDescription {
  POSITIVEINLINE = '1', // 主動進線
  EXISTCUST = '2',      // 自來件(既有顧客)
  NONEXISTCUST = '3',   // 自來件(非既有顧客)
  BANKREFER = '4',      // 聯行轉介
  CSREFER = '5',        // 客服轉介
  HEADASSIGN = '6',     // 總行指派
  RECOMMEND = '7',      // 推薦產品
  CUSTINTRO = '8',      // 顧客介紹
  AGENTREFER = '9',     // 代書或房仲轉介
  ISMS = '10',          // ISMS雙向簡訊
  EDM = '11',           // EDM行銷
  OTHER = '12',         // 其他
}

export class OptionsHelper {
  public static mapTo(key: any, labelMap: any): string {
    return labelMap[key];
  }
  public static getOptionsOf(values: string[], labelMap: any, order?: string) {
    return Object.keys(labelMap).filter(
      (k: string) => _.includes(values, k)
    ).map( (k) => {
      return { value: k, label: labelMap[k] };
    });
  }
  public static getAllOptions(labelMap: any) {
    return Object.keys(labelMap).map( (k) => {
      return { value: k, label: labelMap[k] };
    });
  }
}

export enum SearchHistoryKey {
  CLIENTSEARCH = 'clientSearch',
  MARKETINGTEAM = 'marketingTeam',
}
