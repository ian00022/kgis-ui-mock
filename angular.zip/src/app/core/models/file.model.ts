import { FileDto } from './file.model';

export interface FileDto {
  FileUUID: string;
  FileDownloadPath: string;
  FileName: string;
  DataCount?: number;
  isNew?: boolean;
}
export interface UploadHeadOfficeAssignResponseDto {
  Result: FileDto;
  Id: number;
  Exception?: any;
  Status: number;
  IsCanceled: boolean;
  IsCompleted: boolean;
  CreationOptions: any;
  AsyncState: any;
  IsFaulted: boolean;
}

export interface UploadFileResponseDto {
  FileUUID: string;
  FileDownloadPath: string;
}
