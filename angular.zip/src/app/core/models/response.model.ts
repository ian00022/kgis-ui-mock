// export interface MarsHttpResponseBody {
//   id?: number;
//   exception: string;
//   status: number;
//   result: MarsHttpResponseResult;
//   asyncState?: string;
//   creationOptions?: string;
//   isCanceled?: boolean;
//   isCompleted?: boolean;
//   isFaulted?: boolean;
// }

export interface MarsHttpResponseResult {
  isOk: boolean;
  messages: Array<any>;
  value: Array<any> | any;
  properties?: any;
}
