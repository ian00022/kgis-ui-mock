export interface BaseListConfig {
  type?: string;
  filters?: object;
  pf?: {
    skip: number;
    take: number;
  };
  loginUser?: object;
}
