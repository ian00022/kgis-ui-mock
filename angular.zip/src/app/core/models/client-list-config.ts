import { BaseListConfig } from './base-list-config';
export interface ClientListConfig extends BaseListConfig {
  circiKey?: string;
  contactPhone?: string;
  customerName?: string;
}
