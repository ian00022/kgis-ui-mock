import { filter, map } from 'rxjs/operators';
import * as _ from 'lodash';

export abstract class BaseCodeHelper<T> implements ICodeHelper {
    constructor(public CodeLabelMap) {
    }

    mapTo(key): string {
        return this.CodeLabelMap[key];
    }

    public getOptionsOf(codes: any[]) {
        return this.getAllOptions().filter(options => {
            return _.includes(codes, options.value);
        });
    }

    public getAllOptions() {
        return Object.keys(this.CodeLabelMap).map(
            (k: string) => { return {value: k, label: this.CodeLabelMap[k]}; }
        );
    }
}

export interface ICodeHelper {
    CodeLabelMap;
    mapTo<T>(CodeEnum: T): string;
}
