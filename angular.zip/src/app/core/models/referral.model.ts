import { IEmployee, IBranch } from './comm-data';
import { StatusColumn } from '../../shared/components/ibm-table/ibm-table.model';

export interface Referral {
    id: string;
    uniqueId: string;
    prod: string;
    acct: string;
    tel: string;
    branch: IBranch;
    operator: IEmployee;
    referralBranch: IBranch;
    referralOperator: IEmployee;
    referralTime: Date | number;
    status: StatusColumn;
    prodNote?: string;
    note?: string;
}
