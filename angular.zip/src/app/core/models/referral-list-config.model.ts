import { BaseListConfig } from './base-list-config';
export interface ReferralListConfig extends BaseListConfig {
}
