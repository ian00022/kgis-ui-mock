export enum Permissions {
  // 顧客360>個人戶
  PERSONAL_SEARCH = 'Personal_S',
  PERSONAL_SPECIAL_MEMBER_SEARCH = 'PersonalSpecificMember_S',
  PERSONAL_FIND = 'Personal_F',
  PRODUCT_RECOMMEND_UPDATE = 'ProductRecommend_U',
  PERSONAL_MARKETING_LOG_REMARK_ADD = 'ProsonalMarketingLogRemark_A',
  PERSONAL_MARKETING_NOTICE_FIND = 'PersonalMarketingNotice_F',
  PERSONAL_MARKETING_NOTICE_ADD = 'PersonalMarketingNotice_A',
  PERSONAL_MARKETING_NOTICE_UPDATE = 'PersonalMarketingNotice_U',
  PERSONAL_ACCOUNT_INFO_FIND = 'PersonalAccountInfo_F',
  PERSONAL_DEBT_INFO_FIND = 'PersonalDebtInfo_F',
  PERSONAL_EXCLUSIVE_MARKETING_FIND = 'PersonalExclusiveMarketing_F',
  PERSONAL_VISIT_ADD = 'PersonalVisit_A',
  PERSONAL_SELF_BUILT_ADD = 'PersonalSelfBuilt_A',
  PERSONAL_REFERRAL_UPDATE = 'PersonalReferral_U',
  PERSONAL_EDM_MAIL_SEARCH = 'PersonalEDMMail_S',
  // 顧客360>公司戶
  COMPANY_MARKETING_LOG_REMARK_ADD = 'CompanyMarketingLogRemark_A',
  COMPANY_MARKETING_NOTICE_FIND = 'CompanyMarketingNotice_F',
  COMPANY_MARKETING_NOTICE_ADD = 'CompanyMarketingNotice_A',
  COMPANY_MARKETING_NOTICE_UPDATE = 'CompanyMarketingNotice_U',
  COMPANY_ACCOUNT_INFO_FIND = 'CompanyAccountInfo_F',
  COMPANY_DEBT_INFO_FIND = 'CompanyDebtInfo_F',
  COMPANY_EXCLUSIVE_MARKETING_FIND = 'CompanyExclusiveMarketing_F',
  COMPANY_VISIT_ADD = 'CompanyVisit_A',
  COMPANY_SELF_BUILT_ADD = 'CompanySelfBuild_A',
  COMPANY_REFERRAL_UPDATE = 'CompanyReferral_U',
  COMPANY_EDM_MAIL_SEARCH = 'CompanyEDMMail_S',
  // 顧客360>潛在顧客
  POTENTIAL_CUSTOMER_ADD = 'PotentialCustomer_A',
  POTENTIAL_CUSTOMER_UPDATE = 'PotentialCustomer_U',

  // 名單管理
  GENERAL_BOL_SEARCH = 'GeneralBOL_S',
  HEAD_OFFICE_BOL_SEARCH = 'HeadOfficeBOL_S',
  MY_FAVORITE_BOL_SEARCH = 'MyFavoriteBOL_S',
  MY_FAVORITE_BOL_UPDATE = 'MyFavoriteBOL_U',
  TODAY_VISIT_BOL_FIND = 'TodayVisitBOL_F',
  LOAN_BOL_SEARCH = 'LoanBOL_S',
  // 名單管理>一般名單
  GENERAL_BOL_EBM_FIND = 'GeneralBOLEBM_F',
  GENERAL_BOL_NET_FIND = 'GeneralBOLNet_F',
  GENERAL_BOL_REFERRAL_FIND = 'GeneralBOLReferral_F',
  GENERAL_BOL_SELF_BUILD_FIND = 'GeneralBOLSelfBuild_F',
  GENERAL_BOL_STATUS_UPDATE = 'GeneralBOLStatus_U',
  GENERAL_BOL_POINT_ABSTRACT_UPDATE = 'GeneralBOLPointAbstract_U',
  GENERAL_BOL_VISIT_ADD = 'GeneralBOLVisit_A',
  GENERAL_BOL_VISIT_UPDATE = 'GeneralBOLVisit_U',
  GENERAL_BOL_MARKETING_LOG_REMARK_ADD = 'GeneralBOLMarketingLogRemark_A',
  GENERAL_BOL_GROUP_UPDATE = 'GeneralBOLGroup_U',
  GENERAL_BOL_UPLOAD_ADD = 'GeneralBOLUpload_A',
  GENERAL_BOL_UPLOAD_UPDATE = 'GeneralBOLUpload_U',
  GENERAL_BOL_REJECT_UPDATE = 'GeneralBOLReject_U',
  GENERAL_BOL_ACCOUNT_INFO_FIND = 'GeneralBOLAccountInfo_F',
  GENERAL_BOL_POTENTIAL_CUSTOMER_ADD = 'GeneralBOLPotentialCustomer_A',
  // 名單管理>總行指派
  HEAD_OFFICE_BOL_FIND = 'HeadOfficeBOL_F',
  HEAD_OFFICE_BOL_STATUS_UPDATE = 'HeadOfficeBOLStatus_U',
  HEAD_OFFICE_BOL_MARKETING_LOG_REMARK_ADD = 'HeadOfficeBOLMarketingLogRemark_A',
  // 名單管理>自建名單
  SELF_BUILD_ADD = 'SelfBuild_A',
  // 名單管理>名單分派
  ASSIGN_GENETAL_BOL_SEARCH = 'AssignGeneralBOL_S',
  ASSIGN_GENETAL_BOL_UPDATE = 'AssignGeneralBOL_U',
  MARKETING_EMPLOYEE_WORK_FIND = 'MarketingEmployeeWork_F',
  ASSIGN_HEAD_OFFFICE_SEARCH = 'AssignHeadOfficeBOL_S',
  ASSIGN_HEAD_OFFFICE_UPDATE = 'AssignHeadOfficeBOL_U',
  // 名單管理>名單改派
  ASSIGN_CHANGE_GENERAL_BOL_UPDATE= 'AssignChangeGeneralBOL_U',
  ASSIGN_CHANGE_HEAD_OFFFICE_BOL_UPDATE= 'AssignChangeHeadOfficeBOL_U',
  // 名單管理>名單覆核
  GENERAL_BOL_APPROVE_SEARCH = 'GeneralBOLApprove_S',
  GENERAL_BOL_APPROVE_UPDATE = 'GeneralBOLApprove_U',
  HEAD_OFFICE_BOL_APPROVE_SEARCH = 'HeadOfficeBOLApprove_S',
  HEAD_OFFICE_BOL_APPROVE_UPDATE = 'HeadOfficeBOLApprove_U',
  BACK_TO_OFFICE_BOL_SEARCH = 'BackToOfficeBOL_S',
  BACK_TO_OFFICE_BOL_UPDATE = 'BackToOfficeBOL_U',
  // 名單管理>名單退回
  BACK_TO_OFFICE_GENERAL_BOL_UPDATE = 'BackToOfficeGeneralBOL_U',
  BACK_TO_OFFICE_HEAD_OFFICE_BOL_UPDATE = 'BackToOfficeHeadOfficeBOL_U',
  //商機轉介
  REFERRAL_SEARCH = 'Referral_S',
  REFERRAL_UPDATE = 'Referral_U',
  REFERRAL_ADD = 'Referral_A',
  REFERRAL_EXPORT_SEARCH = 'ReferralExport_S',
  // 行銷管理
  LOAN_CALCULATE_SEARCH = 'LoanCalculate_S',
  LOAN_CALCULATE_EMAIL_SEARCH = 'LoanCalculateEmail_S',
  LOAN_CALCULATE_PRINT_SEARCH = 'LoanCalculatePrint_S',
  LOAN_CALCULATE_DOWNLOAD_SEARCH = 'LoanCalculateDownload_S',
  EDM_SEARCH = 'EDM_S',
  EDM_FIND = 'EDM_F',
  EDM_QRCODE_ADD = 'EDMQRcode_A',
  EDM_EMAIL_SEARCH = 'EDMEmail_S',
  EDM_EMAIL_HISTORY_FIND = 'EDMEmailHistory_F',
  MAP_SEARCH = 'Map_S',
  MAP_COMPANY_INFO_FIND = 'MapCompanyInfo_F',
  REAL_ESTATE_TRANSACTION_SEARCH = 'RealEstateTransaction_S',
  // 管理功能>角色權限
  USER_ROLE_SEARCH = 'UserRole_S',
  USER_ROLE_UPDATE = 'UserRole_U',
  ROLE_SEARCH = 'Role_S',
  ROLE_ADD = 'Role_A',
  ROLE_UPDATE = 'Role_U',
  USER_ROLE_APPROVE_UPDATE = 'UserRoleApprove_U',
  // 管理功能>行銷團隊設定
  MARKETING_TEAM_SEARCH = 'MarketingTeam_S',
  MARKETING_TEAM_ADD = 'MarketingTeam_A',
  MARKETING_TEAM_FIND = 'MarketingTeam_F',
  MARKETING_TEAM_MEMBER_UPDATE = 'MarketingTeamMember_U',
  MARKETING_TEAM_UPDATE = 'MarketingTeam_U',
  MARKETING_TEAM_APPROVE_UPDATE = 'MarketingTeamApprove_U',
  // 管理功能>E-mail 樣板設定
  EMAIL_TEMPLATE_LIST_SEARCH = 'EmailTemplate_S',
  EMAIL_TEMPLATE_ADD = 'EmailTemplate_A',
  EMAIL_TEMPLATE_DETAIL_FIND = 'EmailTemplate_F',
  EMAIL_TEMPLATE_UPDATE = 'EmailTemplate_U',
  EMAIL_TEMPLATE_HTML_UPDATE = 'EmailTemplate_HTML_U',
  EMAIL_TEMPLATE_APPROVE_UPDATE = 'EmailTemplateApprove_U',
  // 管理功能>推播通知設定
  NOTIFICATION_SEARCH = 'Notification_S',
  NOTIFICATION_ADD = 'Notification_A',
  NOTIFICATION_FIND = 'Notification_F',
  NOTIFICATION_UPDATE = 'Notification_U',
  NOTIFICATION_APPROVE_UPDATE = 'NotificationApprove_U',
  // 管理功能>總行指派案件
  CASE_MANAGEMENT_BOL_SEARCH = 'CaseManagementBOL_S',
  CASE_MANAGEMENT_BOL_ADD = 'CaseManagementBOL_A',
  CASE_MANAGEMENT_BOL_UPDATE = 'CaseManagementBOL_U',
  CASE_MANAGEMENT_BOL_COPY_ADD = 'CaseManagementBOLCopy_A',
  CASE_MANAGEMENT_BOL_FIND = 'CaseManagementBOL_F',
  CASE_MANAGEMENT_BOL_APPROVE_UPDATE = 'CaseManagementBOLApprove_U',
  // 管理功能>名單/案件逾期通知設定
  OVERDUE_NOTIFICATION_LIST_SEARCH = 'OverdueNotification_S',
  OVERDUE_NOTIFICATION_ADD = 'OverdueNotification_A',
  OVERDUE_NOTIFICATION_UPDATE = 'OverdueNotification_U',
  OVERDUE_NOTIFICATION_DETAIL_FIND = 'OverdueNotification_F',
  OVERDUE_NOTIFICATION_APPROVE_UPDATE = 'OverdueNotificationApprove_U',
  // 管理功能>推薦產品標籤
  RECOMMEND_PRODUCTS_SEARCH = 'RecommendProducts_S',
  RECOMMEND_PRODUCTS_UPDATE = 'RecommendProducts_U',
  RECOMMEND_PRODUCTS_APPROVE_UPDATE = 'RecommendProductsApprove_U',
  // 管理功能>產品參數
  PRODUCT_PARAMETER_SEARCH = 'ProductParameter_S',
  PRODUCT_PARAMETER_ADD = 'ProductParameter_A',
  PRODUCT_PARAMETER_UPDATE = 'ProductParameter_U',
  PRODUCT_PARAMETER_APPROVE_UPDATE = 'ProductParameterApprove_U',
  // 管理功能>系統參數
  SYSTEM_PROPERTY_SEARCH = 'SystemProperty_S',
  SYSTEM_PROPERTY_ADD = 'SystemProperty_A',
  SYSTEM_PROPERTY_UPDATE = 'SystemProperty_U',
  SYSTEM_PROPERTY_VALUE_ADD = 'SystemPropertyValue_A',
  SYSTEM_PROPERTY_VALUE_UPDATE = 'SystemPropertyValue_U',
  SYSTEM_PROPERTY_VALUE_APPROVE_UPDATE = 'SystemPropertyValueApprove_U',
  SYSTEM_PROPERTY_DOMAIN_SEARCH = 'SystemPropertyDomain_S',
  SYSTEM_PROPERTY_DOMAIN_ADD = 'SystemPropertyDomain_A',
  SYSTEM_PROPERTY_DOMAIN_UPDATE = 'SystemPropertyDomain_U',
  // 檔案上傳
  FILE_ATTACHMENT_SEARCH = 'FileAttachment_S',
  FILE_ATTACHMENT_UPDATE = 'FileAttachment_U',
  SYSTEM_APPROVE_UPDATE = 'SystemApprove_U',
  // 成效管理>名單執行成效
  BOL_RESULT_SEARCH = 'BOLResult_S',
  BOL_RESULT_EXPORT_SEARCH = 'BOLResultExport_S',
  // 成效管理>名單執行明細
  BOL_DETAIL_SEARCH= 'BOLDetail_S',
  BOL_DETAIL_EXPORT_SEARCH = 'BOLDetailExport_S',
  // 首頁>行事曆
  VISIT_SEARCH = 'Visit_S',
  VISIT_FIND = 'Visit_F',
  VISIT_ADD = 'Visit_A',
  VISIT_UPDATE = 'Visit_U',
  // 首頁>輪播訊息
  ANNOUNCE_SEARCH = 'Announce_S',
  ANNOUNCE_FIND = 'Announce_F',
  // 首頁>相關專區
  REAL_LINK_SEARCH= 'RealLink_S',
  // 首頁>今日行程
  TODAY_VISIT_SEARCH= 'TodayVisit_S',
}

export interface PermissionResponseDto {
  TokenId: string;
  EmpId: string;
  Name: string;
  UnitId: string;
  UnitName: string;
  Roles: SimpleRoleDescriptionDto[];
  Permissions: SimplePermissionDto[];
}

export interface SimpleRoleDescriptionDto {
  RoleNo: string;
  Name: string;
  UseType: string;
}

export interface SimplePermissionDto {
  ParentCode: string;
  ParentComment: string;
  Code: string;
  Comment: string;
}

export interface LoginUserDto {
  loginEmpId: string;
  token: string;
  name: string;
  unitId: string;
  unitName: string;
  // these are not in use
  useType?: any;
  agentEmpId?: any;
}
