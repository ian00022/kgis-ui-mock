import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpRequest, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JwtService } from '../services/jwt.service';

@Injectable()
export class GlobalHttpInterceptor implements HttpInterceptor {

  constructor(private jwt: JwtService) { }

  public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let headersConfig = {
      'Content-Type': 'application/json',
    };

    let token = this.jwt.getToken();

    if (token) {
      headersConfig['authorization'] = `token ${token}`;
    }

    if (req.body instanceof FormData) {
      delete headersConfig['Content-Type'];
    }

    const newRequest = req.clone({ setHeaders: headersConfig });
    return next.handle(newRequest);
  }
}
