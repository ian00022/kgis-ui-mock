import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoggerService } from '../shared/logger.service';
import { SelectOptionsService } from '../shared/services/select-options.service';
import {
  ApiService,
  AuthService,
  BreadcrumbService,
  BusinessOppotunityService,
  ClientService,
  DashboardService,
  EffectReportService,
  EmailService,
  JwtService,
  ManagementService,
  MarketingService,
  MenuService,
  ReferralService,
} from './services';
import { SearchHistoryService } from './services/search-history.service';



@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  providers: [
    MenuService,
    ClientService,
    BusinessOppotunityService,
    LoggerService,
    ApiService,
    ReferralService,
    EffectReportService,
    DashboardService,
    BreadcrumbService,
    MarketingService,
    ManagementService,
    EmailService,
    SelectOptionsService,
    AuthService,
    JwtService,
    SearchHistoryService
  ]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      // Prevent reimport of the CoreModule
      throw new Error(
        'Prevent reimport of the CoreModule, CoreModule is already loaded. Import it in the AppModule only');
    }
  }
}
