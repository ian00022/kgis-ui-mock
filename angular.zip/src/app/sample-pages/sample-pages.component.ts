import { TextareaControl } from './../shared/components/dynamic-form/controls/textarea-control';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ControlBase } from '../shared/components/dynamic-form/controls/control-base';
import { SingleDropdownControl } from '../shared/components/dynamic-form/controls/single-dropdown-control';
import { TextControl } from '../shared/components/dynamic-form/controls/text-control';
import { DatepickerControl } from '../shared/components/dynamic-form/controls/datepicker-control';
import { SharedService } from '../shared/services/shared.service';
import { DynamicFormComponent } from '../shared/components/dynamic-form/dynamic-form.component';
import { ApiService } from '../core/services/api.service';
import { ClockpickerControl } from '../shared/components/dynamic-form/controls/clockpicker-control';
import { MultiSelectControl } from '../shared/components/dynamic-form/controls/multi-select-control';
import { RadioControl } from '../shared/components/dynamic-form/controls/radio-control';
import { SingleCheckboxControl } from '../shared/components/dynamic-form/controls/single-checkbox';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'esun-sample-pages',
  templateUrl: './sample-pages.component.html',
  styleUrls: ['./sample-pages.component.css']
})
export class SamplePagesComponent implements OnInit {
  rawHtml = 
   `<body>
      <span style="color:#ce00c0;">
        text
      </span>
      <div>
        <button style="background-color:#031a89;color:#fff;padding:10px">
          a button
        </button>
      </div>
    <body>`;

  get safeRawHtml() {
    return this.sanitizer.bypassSecurityTrustHtml(this.rawHtml);
  }

  imgUrl = './assets/images/E.SUN_Bank.png';

  @ViewChild('formContainer') formContainer: DynamicFormComponent;
  controls: ControlBase<any>[] = [];
  requiredAnyKeys = ['lastName', 'firstName'];

  tableData: any[] = [];
  options: any[] = [];
  slideToggleModel = true;
  rowClassNameFunction;
  datepickerModel = '0.0';
  dateRangepickerModel = '0.0';
  clockpickerModel = '0.0';
  dialogClick = '';
  selectedValue = 3;
  public dateOptions: any = {
      locale: { format: 'YYYY-MM-DD' },
      alwaysShowCalendars: false,
  };

  public selectedValues: any[] = [];

  constructor(public shared: SharedService, private api: ApiService, private sanitizer: DomSanitizer) {
    this.api.get('products', {name: 'Product001'}).subscribe((data) => {
      console.log(data);
    });

    this.api.post('products', {
      name: 'test001',
      'cost': 25.0,
      'quantity': 2500
    }).subscribe((data) => {
      console.log(data);
    });
  }

  public addAnOption() {
    this.options.push({
      value: 'a value',
      label: '***'
    });
  }

  public onSubmit(value) {
    console.log(value);
  }

  get isFormValid() {
    return this.formContainer.form.valid;
  }

  ngOnInit() {
    this.prepareControls();

    this.genTableData();
  }

  private prepareControls() {
    this.controls = [

      new SingleDropdownControl({
        key: 'brave',
        label: 'Bravery Rating',
        enableAutocomplete: true,
        placeholder: 'test place holder',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: [
          {value: 'solid',  label: 'Solid'},
          {value: 'great',  label: 'Great'},
          {value: 'good',   label: 'Good'},
          {value: 'unproven', label: 'Unproven'}
        ],
        required: true,
        disabled: false
      }),

      new SingleCheckboxControl({
        key: 'checkboxSamdple',
        dividerBefore: true,
        label: 'i am checkbox',
        warningBeforeText: '下列選項用於自建名單',
        breakBefore: true,
        breakAfter: true,
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
      }),

      new RadioControl({
        key: 'gender',
        dividerBefore: true,
        label: 'Gender',
        value: 'm',
        breakBefore: true,
        breakAfter: true,
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: [
          {value: 'm',  label: 'male'},
          {value: 'f',  label: 'female'},
        ],
        disabled: true
      }),

      new TextControl({
        key: 'firstName',
        label: 'First name',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        required: false,
        disabled: true,
        placeholder: 'placeholder from sample'
      }),

      new TextControl({
        key: 'lastName',
        label: 'last Name',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        required: false,
        disabled: true,
        placeholder: 'placeholder from sample'
      }),

      new TextControl({
        key: 'emailAddress',
        label: 'Email',
        columnClasses: ['3'],
        offsetClasses: ['lg-4', 'md-3', '6'],
        type: 'email',
        required: true,
        value: '',
        condition: (form: FormGroup) => {
          return form.controls['brave'].value === 'solid';
        },
        disabled: true,
      }),

      new TextareaControl({
        key: 'textarea',
        label: 'Textarea',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        offsetClasses: ['lg-4', 'md-3', '6'],
        value: '23123123',
        disabled: false,
        rows: 10,
        isWordCount: true,
      }),

      new DatepickerControl({
        key: 'birthday',
        label: 'Birthday',
        columnClasses: ['3'],
        offsetClasses: ['lg-4', 'md-6', 'sm-12'],
        type: 'datepicker',
        value: '2012/02/03',
        singleDatePicker: true,
        placeholder: 'placeholder',
      }),

      new ClockpickerControl({
        key: 'clock',
        value: '10:00',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        label: 'sample clock',
        placeholder: 'placeholder',
      }),

      new MultiSelectControl({
        key: 'multiSelect',
        label: 'multi-select',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: this.options,
        enableAutocomplete: true,
        breakBefore: true,
        placeholder: 'test place holder',
        disabled: true,
      }),
      new MultiSelectControl({
        key: 'multiSelect2',
        label: 'multi-select WithoutValue',
        columnClasses: ['lg-4', 'md-6', 'sm-12'],
        options: this.options,
        enableAutocomplete: true,
        breakBefore: true,
        placeholder: 'test place holder',
      }),

    ];
  }

  private genTableData() {
    for (let i = 0; i < 43; i++) {
      let k = i%20;
      this.tableData.push(
        {name: 'albert' + k, age: 22 + i, sex: 'M'},
      );

      this.options.push(
        {value: i, label: 'option ' + i}
      );
    }

    this.rowClassNameFunction = (row, index) => {
      if (index === 3) {
        return 'red-row';
      }
      if (row.name === 'albert5') {
        return 'blue-row';
      }
    };
  }
}
