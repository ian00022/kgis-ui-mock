export declare class RenderEventModel {
    event: any;
    element: any;
    view?: any;
}
