export declare class ButtonClickModel {
    buttonType: string;
    data: any;
}
