export declare class UpdateEventModel {
    event: any;
    duration: any;
}
