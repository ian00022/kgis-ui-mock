export declare class FullCalendarModule {
}
