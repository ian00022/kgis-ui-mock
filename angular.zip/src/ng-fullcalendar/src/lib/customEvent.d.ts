interface Window {
    CustomEvent: CustomEvent;
}
